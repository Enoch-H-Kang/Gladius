#!/usr/bin/env python3
"""Regenerate frozen RR bus pools for a GLADIUS or repaired SAmQ shard."""
import argparse
from contextlib import redirect_stderr
import hashlib
import json
from pathlib import Path
import sys

from normalize_npz import normalize


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('shard_file', type=Path)
    parser.add_argument('--bundle-root', type=Path, default=Path('/home/ehwkang'))
    args = parser.parse_args()
    items = json.loads(args.shard_file.read_text())
    seeds = set()
    for item in items:
        if item['suite'] == 'bus':
            seeds.add(int(item['source_spec']['data_id'].removeprefix('bus_seed')))
        elif item['suite'] == 'samq_nn':
            seeds.add(int(item['source_spec']['seed']))
    if not seeds:
        return
    root = args.bundle_root.resolve()
    repo = root / 'DDC-DPT-busrerun'
    sys.path.insert(0, str(repo))
    from experiments.fleet_capacity_one.bus_rerun import cached_generator
    from experiments.fleet_capacity_one.tuning import bus_data
    manifest_path = repo / 'results/bus_rerun/data_freeze.json'
    manifest = json.loads(manifest_path.read_text())
    expected = {item['seed']: item['sha256'] for item in manifest['pools']}
    output = repo / 'artifacts/bus_rerun/data'
    output.mkdir(parents=True, exist_ok=True)
    for seed in sorted(seeds):
        path = output / f'bus_seed{seed}.npz'
        if seed not in expected:
            raise ValueError('seed absent from frozen bus manifest')
        if not path.exists():
            log = output / f'bus_seed{seed}.generate.log'
            with log.open('w') as stream, redirect_stderr(stream):
                train, val = cached_generator.generate(seed, 5000)
            bus_data.export_pool(train, val, str(path))
            normalize(path)
        if sha(path) != expected[seed]:
            raise ValueError('frozen bus pool SHA mismatch: ' + str(path))
        for item in items:
            if item['suite'] == 'samq_nn' and item['source_spec']['seed'] == seed:
                if item['source_spec']['pool_sha256'] != expected[seed]:
                    raise ValueError('SAmQ descriptor pool SHA mismatch')
        print(json.dumps({'pool_verified': f'bus_seed{seed}', 'sha256': expected[seed]}), flush=True)


if __name__ == '__main__':
    main()
