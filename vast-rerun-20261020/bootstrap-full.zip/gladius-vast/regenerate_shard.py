#!/usr/bin/env python3
"""Generate and verify every frozen pool used by a shard before any fit starts."""
import argparse
import json
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('shard_file', type=Path)
    parser.add_argument('--bundle-root', type=Path, default=Path('/home/ehwkang'))
    args = parser.parse_args()
    items = json.loads(args.shard_file.read_text())
    here = Path(__file__).resolve().parent
    for script in ('regenerate_bus.py', 'regenerate_r1.py', 'regenerate_ext.py'):
        subprocess.run([sys.executable, str(here / script), str(args.shard_file),
                        '--bundle-root', str(args.bundle_root)], check=True)
    data_ids = sorted({item['source_spec']['data_id'] for item in items if item['suite'] == 'S2'})
    if data_ids:
        subprocess.run([sys.executable, str(here / 'regenerate_s2.py'),
                        '--bundle-root', str(args.bundle_root), '--data-ids',
                        *map(str, data_ids)], check=True)
    print(json.dumps({'shard_inputs_verified': args.shard_file.stem,
                      'fits': len(items)}), flush=True)


if __name__ == '__main__':
    main()
