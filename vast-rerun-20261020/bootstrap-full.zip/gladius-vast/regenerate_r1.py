#!/usr/bin/env python3
"""Regenerate the R1 FL and headline pools required by one shard."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

from normalize_npz import normalize


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('shard_file', type=Path)
    parser.add_argument('--bundle-root', type=Path, default=Path('/home/ehwkang'))
    args = parser.parse_args()
    pools = {}
    for item in json.loads(args.shard_file.read_text()):
        if item['suite'] not in ('FL', 'headline', 'matrix'):
            continue
        spec = item['source_spec']
        pool = spec['pool']
        if pool in pools and pools[pool] != spec['pool_sha256']:
            raise ValueError('conflicting frozen pool SHA: ' + pool)
        pools[pool] = spec['pool_sha256']
    if not pools:
        return
    root = args.bundle_root.resolve()
    sys.path.insert(0, str(root / 'DDC-DPT-fleet-r1literal'))
    from experiments.fleet_r1literal import freeze_data
    from experiments.fleet_r1literal.assemble import load
    reference = load(freeze_data.REFROOT)
    for relative, expected in sorted(pools.items()):
        path = freeze_data.ROOT / relative
        if not path.exists():
            stem = path.stem
            stage, number = stem.rsplit('_', 1)
            role = 'development' if stage == 'FL' else 'headline'
            if stage not in ('FL', 'headline'):
                raise ValueError('unexpected R1 pool stage: ' + stage)
            freeze_data.export_pool(stage, int(number), 1000, reference, role)
            normalize(path)
        if sha(path) != expected:
            raise ValueError('frozen R1 pool SHA mismatch: ' + str(path))
        print(json.dumps({'pool_verified': relative, 'sha256': expected}), flush=True)


if __name__ == '__main__':
    main()
