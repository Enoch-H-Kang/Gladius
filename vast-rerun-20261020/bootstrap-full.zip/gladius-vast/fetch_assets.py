#!/usr/bin/env python3
"""Download frozen raw assets in parallel and verify every part and whole file."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
import urllib.request


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def fetch(part, base_url, folder):
    path = folder / part['name']
    if path.exists() and sha(path) == part['sha256']:
        return path
    for attempt in range(5):
        try:
            with urllib.request.urlopen(base_url + part['name'], timeout=90) as response, path.open('wb') as output:
                shutil.copyfileobj(response, output)
            if path.stat().st_size != part['bytes'] or sha(path) != part['sha256']:
                raise ValueError('asset part hash mismatch: ' + part['name'])
            return path
        except Exception:
            path.unlink(missing_ok=True)
            if attempt == 4:
                raise
            time.sleep(min(15, 2 ** attempt))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--base-url', required=True)
    parser.add_argument('--key', required=True, choices=('oracle_k31', 'r1_e2', 'r1_screen', 's2_e2'))
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--work-dir', type=Path, required=True)
    args = parser.parse_args()
    metadata = json.loads(args.manifest.read_text())[args.key]
    folder = args.work_dir / args.key
    folder.mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(max_workers=12) as executor:
        list(executor.map(lambda part: fetch(part, args.base_url, folder), metadata['parts']))
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    assembled = args.destination.with_name(args.destination.name + '.download')
    with assembled.open('wb') as output:
        for part in metadata['parts']:
            with (folder / part['name']).open('rb') as stream:
                shutil.copyfileobj(stream, output)
    if assembled.stat().st_size != metadata['bytes'] or sha(assembled) != metadata['sha256']:
        raise ValueError('assembled frozen asset hash mismatch: ' + args.key)
    if args.key == 'oracle_k31':
        with gzip.open(assembled, 'rb') as source, args.destination.open('wb') as output:
            shutil.copyfileobj(source, output)
        if sha(args.destination) != metadata['uncompressed_sha256']:
            raise ValueError('decompressed K31 oracle SHA mismatch')
        assembled.unlink()
    else:
        os.replace(assembled, args.destination)
    print(json.dumps({'asset_verified': args.key, 'bytes': args.destination.stat().st_size,
                      'sha256': sha(args.destination)}), flush=True)


if __name__ == '__main__':
    main()
