#!/usr/bin/env python3
"""Regenerate K31 coupled pools required by one shard and verify exact hashes."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

from normalize_npz import normalize


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('shard_file', type=Path)
    parser.add_argument('--bundle-root', type=Path, default=Path('/home/ehwkang'))
    args = parser.parse_args()
    pools = {}
    for item in json.loads(args.shard_file.read_text()):
        if item['suite'] not in ('EL', 'EX'):
            continue
        spec = item['source_spec']
        pool = spec['pool']
        if pool in pools and pools[pool] != spec['pool_sha256']:
            raise ValueError('conflicting coupled pool SHA: ' + pool)
        pools[pool] = spec['pool_sha256']
    if not pools:
        return
    root = args.bundle_root.resolve()
    sys.path.insert(0, str(root / 'DDC-DPT-fleet-r1literal'))
    from experiments.fleet_r1literal import frozen_followups as q
    from experiments.fleet_r1literal import frozen_extension as ext
    q.SOURCE = root / 'DDC-DPT-fleet/experiments/fleet_capacity_one'
    ext.SOURCE = q.SOURCE
    params, hashes = ext.check_source()
    policy = ext.expert(params)
    for relative, expected in sorted(pools.items()):
        path = q.ROOT / relative
        if not path.exists():
            stage, number = path.stem.rsplit('_', 1)
            if stage not in ('FL_ext', 'headline_ext'):
                raise ValueError('unexpected coupled pool stage: ' + stage)
            ext.generate(stage, int(number), 1000, params, policy, hashes)
            normalize(path)
        if sha(path) != expected:
            raise ValueError('frozen coupled pool SHA mismatch: ' + str(path))
        print(json.dumps({'pool_verified': relative, 'sha256': expected}), flush=True)


if __name__ == '__main__':
    main()
