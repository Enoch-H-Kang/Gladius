# SAmQ matched bus repair fork

Base: `dce1a658d0e750be913c244d52b3e97447554965`. Branch: `samq-matched-repaired`. The estimator has only these two repairs.

1. `SAmQ/rl/ddm.py`, `rust_ddm.get_q`: the original TD backup used `aggregated_s[j+1]` as the successor and skipped the last row. Consecutive rows can belong to different bus chains; the data already records `s_next` for each transition, and `pqr_aggregation.aggregate` already writes its matching `aggregated_s_next.npy`. Load that file, use `aggregated_s_next[j]`, and iterate over every recorded row. This restores the published transition-based Bellman update, including the last transition.
2. `SAmQ/irl/pqr.py`, `pqr_aggregation.aggregate`: sklearn rejects simultaneous non-null `n_clusters` and `distance_threshold`. The authors' call supplies a cluster count and the method's default `delta=None`; the downstream code expects the requested number of aggregate states. Keep `n_clusters=n_states_aggregated` and set `distance_threshold=None`. Thus Ward clustering stops at the authors' requested cluster count rather than a distance cutoff.

The matched runner lives outside this estimator fork. Its pool import reverses numeric action codes (SAmQ: 0 replace, 1 keep; frozen bus: 0 keep, 1 replace), and scoring subtracts the common 5 reward anchor so replace is -5 and keep is `-theta*s`. These are data and scoring adapters, not estimator changes. The preexisting simplified tabular SAmQ results remain separate.
