"""Shared trainer core: separate Q / zeta networks, disjoint optimizers, loss in {none, clip0, abs},
k zeta updates per Q update, observable-only checkpoint selection.

This module (with models, losses, select, seeds) is the whole training path. It must not import
anything that knows the truth (oracle, kernels, transition parameters, evaluators); the import-graph
test enforces that. Data arrive as plain arrays plus the public anchor interface (r0 per row).
"""
import copy
import hashlib
import math
import time

import numpy as np
import torch

from .losses import be_term, ce_term, zeta_term
from .models import MLP, init_mlp
from .select import select_checkpoint

DEFAULTS = dict(
    loss="none", k=1, lr_q=3e-4, rho=1.0, batch=256, c_be=1.0, width=10, depth=2,
    opt="adamw", wd=1e-4, bias="anchor", cap_q=5000, beta=0.95, val_every=500, elig_start=5000,
    anchor_tol=0.10, grad_clip=1.0, lr_decay=10000.0,
)


def _hash_params(q, z):
    h = hashlib.sha256()
    for net in (q, z):
        for p in net.state_dict().values():
            h.update(p.detach().cpu().numpy().astype(np.float32).tobytes())
    return h.hexdigest()


def _make_opt(params, cfg, lr):
    if cfg["opt"] == "adamw":
        return torch.optim.AdamW(params, lr=lr, betas=(0.9, 0.999), eps=1e-8, weight_decay=cfg["wd"])
    if cfg["opt"] == "sgd":
        return torch.optim.SGD(params, lr=lr, momentum=0.0, weight_decay=0.0)
    raise ValueError(cfg["opt"])


def _clip(params, clip):
    """Gradient value clipping; returns True when any gradient exceeded the bound."""
    grads = [p.grad for p in params if p.grad is not None]
    hit = bool(torch.stack([g.abs().max() for g in grads]).max() > clip)
    torch.nn.utils.clip_grad_value_(params, clip)
    return hit


def _tensors(part, scale):
    return dict(
        x=torch.as_tensor(np.asarray(part["s"], dtype=np.float32) / scale),
        xp=torch.as_tensor(np.asarray(part["sp"], dtype=np.float32) / scale),
        a=torch.as_tensor(np.asarray(part["a"], dtype=np.int64)),
        r0=torch.as_tensor(np.asarray(part["r0"], dtype=np.float32)),
    )


@torch.no_grad()
def validate(q, z, val, meta, beta):
    lq = q(val["x"])
    nll = torch.nn.functional.cross_entropy(lq, val["a"]).item()
    top1 = (lq.argmax(1) == val["a"]).float().mean().item()
    m = val["a"] == meta["anchor_action"]
    a0 = meta["anchor_action"]
    if int(m.sum()) > 0:
        err = lq[m, a0] - beta * z(val["x"][m])[:, a0] - val["r0"][m]
        anchor = float(torch.sqrt((err ** 2).mean()))
    else:
        anchor = float("nan")
    zs = z(val["x"]).gather(1, val["a"][:, None])[:, 0]
    zl = float(((zs - torch.logsumexp(q(val["xp"]), 1)) ** 2).mean())
    finite = bool(all(torch.isfinite(p).all() for net in (q, z) for p in net.parameters())
                  and math.isfinite(nll) and math.isfinite(zl))
    return dict(nll=nll, top1=top1, anchor_rmse=anchor, zeta_mse=zl, n_anchor=int(m.sum()), finite=finite)


def fit(data, cfg, seeds, horizons=None, ckpt_dir=None, probe=None, model_factory=None, model_initializer=None):
    """Run one fit from scratch. Returns a record dict; writes selected checkpoints when ckpt_dir is given."""
    import os
    cfg = {**DEFAULTS, **cfg}
    torch.set_num_threads(1)
    meta = data["meta"]
    beta = float(cfg["beta"])
    scale = float(meta["state_scale"])
    tr, va = _tensors(data["train"], scale), _tensors(data["val"], scale)
    n_train = tr["x"].shape[0]
    B = min(int(cfg["batch"]), math.ceil(n_train / 8))
    n_act, in_dim = int(meta["n_actions"]), tr["x"].shape[1]
    a0 = int(meta["anchor_action"])
    horizons = sorted(set(horizons or [cfg["cap_q"]]))
    assert max(horizons) <= cfg["cap_q"]

    out_bias = float(tr["r0"].mean()) / (1.0 - beta) if cfg["bias"] == "anchor" else 0.0
    if model_factory is None:
        q = init_mlp(MLP(in_dim, n_act, cfg["width"], cfg["depth"]), seeds["qinit"], out_bias)
        z = init_mlp(MLP(in_dim, n_act, cfg["width"], cfg["depth"]), seeds["zinit"], out_bias)
    else:
        if model_initializer is None:
            raise ValueError("model initializer required with model factory")
        q = model_initializer(model_factory(cfg, meta), seeds["qinit"], out_bias)
        z = model_initializer(model_factory(cfg, meta), seeds["zinit"], out_bias)
    qp, zp = list(q.parameters()), list(z.parameters())
    assert not ({id(p) for p in qp} & {id(p) for p in zp})
    opt_q = _make_opt(qp, cfg, cfg["lr_q"])
    opt_z = _make_opt(zp, cfg, cfg["lr_q"] * cfg["rho"])

    k, cap = int(cfg["k"]), int(cfg["cap_q"])
    c = dict(q_updates=0, z_updates=0, draws=0, q_clip_hits=0, z_clip_hits=0)
    tm = dict(q=0.0, z=0.0, val=0.0)
    trace, snaps, diverged_at = [], [], None
    t0 = time.perf_counter()

    def draw(seed, tag, *idx):
        rng = np.random.default_rng([seed, *idx])
        i = torch.as_tensor(rng.integers(0, n_train, B))
        c["draws"] += 1
        if probe is not None:
            probe.append((tag, idx, i.tolist()))
        return {key: v[i] for key, v in tr.items()}

    for t in range(cap):
        sched = 1.0 / (1.0 + t / cfg["lr_decay"])
        for g in opt_q.param_groups:
            g["lr"] = cfg["lr_q"] * sched
        for g in opt_z.param_groups:
            g["lr"] = cfg["lr_q"] * cfg["rho"] * sched
        ce_b = None
        ok = True
        for j in range(1, k + 1):
            b = draw(seeds["ce"], "ce", t) if j == k else draw(seeds["extrazeta"], "extrazeta", t, j)
            if j == k:
                ce_b = b
            ts = time.perf_counter()
            with torch.no_grad():
                v = torch.logsumexp(q(b["xp"]), 1)
            zl = zeta_term(z(b["x"]).gather(1, b["a"][:, None])[:, 0], v)
            opt_z.zero_grad(set_to_none=True)
            zl.backward()
            if not torch.isfinite(zl):
                ok = False
                break
            c["z_clip_hits"] += _clip(zp, cfg["grad_clip"])
            opt_z.step()
            c["z_updates"] += 1
            tm["z"] += time.perf_counter() - ts
        if not ok:
            diverged_at = t
            break
        ab = draw(seeds["anchor"], "anchor", t)
        ts = time.perf_counter()
        ce = ce_term(q(ce_b["x"]), ce_b["a"])
        q_all = q(ab["x"])
        q_sa = q_all.gather(1, ab["a"][:, None])[:, 0]
        v = torch.logsumexp(q(ab["xp"]), 1)
        with torch.no_grad():
            zsa = z(ab["x"]).gather(1, ab["a"][:, None])[:, 0]
        be = be_term(q_sa, ab["r0"], v, zsa, ab["a"] == a0, beta, cfg["loss"])
        loss = ce + cfg["c_be"] * be
        opt_q.zero_grad(set_to_none=True)
        loss.backward()
        if not torch.isfinite(loss):
            diverged_at = t
            break
        c["q_clip_hits"] += _clip(qp, cfg["grad_clip"])
        opt_q.step()
        c["q_updates"] += 1
        tm["q"] += time.perf_counter() - ts
        step = t + 1
        if step % cfg["val_every"] == 0:
            tv = time.perf_counter()
            r = validate(q, z, va, meta, beta)
            r.update(t=step, hash=_hash_params(q, z))
            tm["val"] += time.perf_counter() - tv
            trace.append(r)
            snaps.append((step, copy.deepcopy(q.state_dict()), copy.deepcopy(z.state_dict())))
            if not r["finite"]:
                diverged_at = step - 1
                break

    results = {}
    for h in horizons:
        if diverged_at is not None and diverged_at < h:
            results[h] = dict(status="failed_diverged", step=None, hash=None)
            continue
        status, ch = select_checkpoint(trace, h, cfg["elig_start"], cfg["anchor_tol"])
        res = dict(status=status, step=None if ch is None else ch["t"], hash=None if ch is None else ch["hash"])
        if ch is not None:
            res.update({key: ch[key] for key in ("nll", "top1", "anchor_rmse", "zeta_mse")})
            if ckpt_dir is not None:
                os.makedirs(ckpt_dir, exist_ok=True)
                _, qs, zs_ = next(s for s in snaps if s[0] == ch["t"])
                torch.save(dict(q=qs, z=zs_, step=ch["t"], hash=ch["hash"], cfg=cfg, meta=meta),
                           os.path.join(ckpt_dir, f"ckpt_h{h}.pt"))
        results[h] = res
    if ckpt_dir is not None and diverged_at is None:
        os.makedirs(ckpt_dir, exist_ok=True)
        torch.save(dict(q=q.state_dict(), z=z.state_dict(), step=cap, hash=_hash_params(q, z), cfg=cfg, meta=meta),
                   os.path.join(ckpt_dir, "ckpt_final.pt"))
    nq = max(c["q_updates"], 1)
    return dict(
        cfg=cfg, seeds=seeds, batch_eff=B, horizons=results, trace=trace, diverged_at=diverged_at,
        fit_status="complete" if diverged_at is None else "diverged",
        counts=c, q_clip_rate=c["q_clip_hits"] / nq, z_clip_rate=c["z_clip_hits"] / max(c["z_updates"], 1),
        time=dict(tm, total=time.perf_counter() - t0),
    )
