"""Queue runner with a dynamic thread-token admission manager (44-token project cap).

Each fit is a fresh single-thread process at nice 10. Tokens held by other project jobs (anything with
'fleet_capacity_one' in its command line that is not one of ours) are measured from instantaneous CPU and
subtracted from the 44-token cap before each admission.
"""
import csv
import json
import math
import os
import subprocess
import sys
import time

CAP = 44
ADMISSION_HEADROOM = 1  # allow a one-token rise in another job between admission samples
PY = sys.executable
MARK = "TUNING_FIT_WORKER"


def _cpu_ticks(pid):
    try:
        with open(f"/proc/{pid}/stat") as f:
            parts = f.read().rsplit(")", 1)[1].split()
        return int(parts[11]) + int(parts[12])
    except Exception:
        return None


def other_project_tokens(my_pids, sample=1.0):
    pids = []
    for d in os.listdir("/proc"):
        if not d.isdigit() or int(d) in my_pids or int(d) == os.getpid():
            continue
        try:
            cmd = open(f"/proc/{d}/cmdline").read().replace("\0", " ")
        except Exception:
            continue
        if ("python" in cmd and any(x in cmd for x in ("fleet_capacity_one", "/tmp/audit_", "DDC-DPT"))
                and MARK not in cmd and "tuning.runner" not in cmd and "unittest" not in cmd):
            pids.append(int(d))
    t0 = {p: _cpu_ticks(p) for p in pids}
    time.sleep(sample)
    hz = os.sysconf("SC_CLK_TCK")
    tot, detail = 0, {}
    for p in pids:
        a, b = t0[p], _cpu_ticks(p)
        if a is None or b is None:
            continue
        measured = max(1, math.ceil((b - a) / hz / sample - 0.2))
        try:
            nlwp = int([l for l in open(f"/proc/{p}/status") if l.startswith("Threads:")][0].split()[1])
        except Exception:
            nlwp = 1
        tok = max(measured, min(nlwp, 32))      # reserve what the job holds, not only what it uses this second
        tot += tok
        detail[p] = tok
    return tot, detail


def done(fits_root, spec, code_hash_now):
    p = os.path.join(fits_root, spec["fit_id"], "record.json")
    if not os.path.exists(p):
        return False
    r = json.load(open(p))
    return r.get("config_id") == spec["config_id"] and r.get("code_hash") == code_hash_now


def run(manifest, fits_root, export, ledger_dir, max_workers=None, poll=15):
    from .run_fit import code_hash
    m = json.load(open(manifest))
    ch = code_hash()
    os.makedirs(fits_root, exist_ok=True)
    os.makedirs(ledger_dir, exist_ok=True)
    pending = [f for f in m["fits"] if not done(fits_root, f, ch)]
    # longest jobs first (large k) to reduce the tail
    pending.sort(key=lambda f: (-f["config"]["k"], f["fit_id"]))
    running = {}
    qlog = open(os.path.join(ledger_dir, f"queue_{m['stage']}.csv"), "a", newline="")
    ulog = open(os.path.join(ledger_dir, f"usage_{m['stage']}.csv"), "a", newline="")
    qw, uw = csv.writer(qlog, lineterminator="\n"), csv.writer(ulog, lineterminator="\n")
    last_u = 0
    print(f"[runner] {len(pending)} pending of {m['n_fits']}", flush=True)
    while pending or running:
        for fid, (proc, t0) in list(running.items()):
            if proc.poll() is not None:
                rec = os.path.exists(os.path.join(fits_root, fid, "record.json"))
                qw.writerow([fid, "end", time.time(), proc.returncode, int(rec)])
                qlog.flush()
                del running[fid]
        other, detail = other_project_tokens({p.pid for p, _ in running.values()}, sample=1.0)
        budget = max(0, CAP - other - ADMISSION_HEADROOM)
        if max_workers:
            budget = min(budget, max_workers)
        while pending and len(running) < budget:
            spec = pending.pop(0)
            env = dict(os.environ, OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
                       CUDA_VISIBLE_DEVICES="", PYTHONHASHSEED="0")
            cmd = ["nice", "-n", "10", PY, "-m", "experiments.fleet_capacity_one.tuning.run_fit", manifest,
                   spec["fit_id"], fits_root, export, MARK]
            proc = subprocess.Popen(cmd, env=env, stdout=open(os.path.join(ledger_dir, "worker_stdout.log"), "a"),
                                    stderr=subprocess.STDOUT)
            running[spec["fit_id"]] = (proc, time.time())
            qw.writerow([spec["fit_id"], "start", time.time(), proc.pid, ""])
            qlog.flush()
        if time.time() - last_u > 60:
            uw.writerow([time.time(), len(running), other, budget, len(pending)])
            ulog.flush()
            last_u = time.time()
            print(f"[runner] running={len(running)} others={other} budget={budget} pending={len(pending)}", flush=True)
        time.sleep(poll)
    print("[runner] all done", flush=True)


if __name__ == "__main__":
    run(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], max_workers=int(sys.argv[5]) if len(sys.argv) > 5 else None)
