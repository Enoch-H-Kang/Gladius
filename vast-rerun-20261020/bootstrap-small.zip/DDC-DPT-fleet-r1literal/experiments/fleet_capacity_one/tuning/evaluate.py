"""Separate-process truth evaluator (development occupancy panel, seed 7199). EVALUATOR ONLY.

python -m experiments.fleet_capacity_one.tuning.evaluate MANIFEST FITS_ROOT TRUTH_OUT [PANEL_SEED]
Reads committed checkpoints (verifying their recorded hashes) and writes truth metrics to a separate root.
It never writes to the fit records and cannot alter a selection.
"""
import json
import os
import sys

import numpy as np
import torch

from ..fleet.models import MLP
from . import bus_truth as bt

PANEL_SEED = 7199


def build_panel(seed=PANEL_SEED):
    from . import bus_data
    chains = bus_data.generate_chains(seed, 200)       # the audited review generator, legacy seeding
    s = np.concatenate([np.asarray(c["states"]).reshape(-1) for c in chains]).astype(np.int64)
    return bt.vfi(), s


def _nets(ck):
    cfg, meta = ck["cfg"], ck["meta"]
    q = MLP(1, meta["n_actions"], cfg["width"], cfg["depth"])
    z = MLP(1, meta["n_actions"], cfg["width"], cfg["depth"])
    q.load_state_dict(ck["q"])
    z.load_state_dict(ck["z"])
    return q, z, cfg, meta


def fleet_nets(ck):
    """Reload the checkpoint declared 32-action architecture for fleet evaluation."""
    from experiments.fleet_r1literal.models import factory
    cfg, meta = ck["cfg"], ck["meta"]
    if meta.get("arm") != "independent_r1literal" or meta["n_actions"] != 32:
        raise ValueError("not an independent fleet checkpoint")
    q, z = factory(cfg, meta), factory(cfg, meta)
    q.load_state_dict(ck["q"])
    z.load_state_dict(ck["z"])
    return q, z, cfg, meta


def metrics(ck, sol, occ):
    q, z, cfg, meta = _nets(ck)
    beta, scale = cfg["beta"], meta["state_scale"]
    states = np.arange(bt.XMAX + 1)
    with torch.no_grad():
        def run(s):
            x = torch.as_tensor(s.astype(np.float32)[:, None] / scale)
            return q(x).double().numpy(), z(x).double().numpy()
        Qh, Zh = run(states)
    U, Qt, EP = sol["U"], sol["Q"], sol["EP"]
    rhat = Qh - beta * Zh                                   # (11, 2) implied reward
    err_keep = rhat[:, 0] - U[:, 0]
    err_rep = rhat[:, 1] - U[:, 1]
    cnt = np.bincount(occ, minlength=bt.XMAX + 1).astype(float)
    w = cnt / cnt.sum()
    rms = lambda e, ww: float(np.sqrt((ww / ww.sum() * e ** 2).sum()))
    rscale = float(np.sqrt((w * U[:, 0] ** 2).sum()))
    pi_hat = np.exp(Qh - np.log(np.exp(Qh).sum(1, keepdims=True)))
    kl = float((w * (EP * (np.log(EP) - np.log(pi_hat))).sum(1)).sum())
    # zeta lag against the learned Q: E[V_Q(s')|s,a]
    VQ = np.log(np.exp(Qh).sum(1))
    ev_keep = np.array([np.mean([VQ[min(s + j, bt.XMAX)] for j in range(1, 5)]) for s in states])
    ev_rep = np.full(len(states), VQ[1])
    lag = np.sqrt((w * ((Zh[:, 0] - ev_keep) ** 2 + (Zh[:, 1] - ev_rep) ** 2) / 2).sum())
    tail = (w < 0.02)
    vis = cnt > 0
    mape = float((w[vis] * np.abs(err_keep[vis] / U[vis, 0])).sum())
    return dict(
        nonanchor_rmse=rms(err_keep, w), reward_scale=rscale, nonanchor_mape=mape,
        q_rmse=float(np.sqrt((w[:, None] * (Qh - Qt) ** 2).sum() / 2)),
        adv_rmse=float(np.sqrt((w * ((Qh[:, 0] - Qh[:, 1]) - (Qt[:, 0] - Qt[:, 1])) ** 2).sum())),
        err_keep_rmse=rms(err_keep, w), err_replace_rmse=rms(err_rep, w), kl=kl, zeta_lag_rmse=float(lag),
        uniform_nonanchor_rmse=float(np.sqrt((err_keep ** 2).mean())),
        tail_nonanchor_rmse=float(np.sqrt((err_keep[tail] ** 2).mean())) if tail.any() else float("nan"),
        n_tail_states=int(tail.sum()), occupancy=[float(x) for x in w],
    )


def main(manifest, fits_root, out_root, panel_seed=PANEL_SEED):
    m = json.load(open(manifest))
    sol, occ = build_panel(int(panel_seed))
    os.makedirs(out_root, exist_ok=True)
    for f in m["fits"]:
        rp = os.path.join(fits_root, f["fit_id"], "record.json")
        res = dict(fit_id=f["fit_id"], panel_seed=int(panel_seed), horizons={})
        if os.path.exists(rp):
            rec = json.load(open(rp))
            for h, hr in rec["horizons"].items():
                if hr.get("hash") is None:
                    res["horizons"][h] = None
                    continue
                ck = torch.load(os.path.join(fits_root, f["fit_id"], f"ckpt_h{h}.pt"), weights_only=False)
                assert ck["hash"] == hr["hash"], "checkpoint hash mismatch"
                res["horizons"][h] = metrics(ck, sol, occ)
        tmp = os.path.join(out_root, f["fit_id"] + ".json.tmp")
        json.dump(res, open(tmp, "w"))
        os.replace(tmp, os.path.join(out_root, f["fit_id"] + ".json"))


if __name__ == "__main__":
    main(*sys.argv[1:])
