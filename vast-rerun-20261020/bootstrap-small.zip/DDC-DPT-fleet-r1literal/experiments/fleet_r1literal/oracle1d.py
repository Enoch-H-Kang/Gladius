"""One-bus float64 soft reference with exact truncated-exponential hat integration."""
import time
import numpy as np
from scipy.special import logsumexp
from .params import BETA, U, V, KCOST, D
from .texp import RHO, L, Z, cap_mass

class Component:
    def __init__(self, f, values):
        self.f = int(f)
        self.values = np.asarray(values, dtype=np.float64)
        self.K = len(values)
        self.h = 1.0 / (self.K - 1)
        if self.values.ndim != 1 or self.K < 2 or not np.isfinite(self.values).all():
            raise ValueError("invalid value grid")
        self.rho = float(RHO[f])
        self.z = float(Z[f])
        self.slopes = np.diff(self.values) / self.h
        self._make_integral()

    def _make_integral(self):
        grid = np.linspace(0., 1., self.K)
        self.grid = grid
        e = np.exp(-self.rho * grid)
        # Primitive of v(y) exp(-rho*y), from 0 to each grid node.
        k = self.slopes
        h = self.h
        p = -np.expm1(-self.rho*h)/self.rho
        j = (p - h*np.exp(-self.rho*h))/self.rho
        cell = e[:-1]*(self.values[:-1]*p+k*j)
        self.suffix = np.r_[np.cumsum(cell[::-1])[::-1], 0.]

    def primitive(self, y):
        y = np.clip(np.asarray(y, dtype=np.float64), 0., 1.)
        idx = np.minimum((y/self.h).astype(np.int64), self.K-2)
        d = y-self.grid[idx]
        p = -np.expm1(-self.rho*d)/self.rho
        j = (p-d*np.exp(-self.rho*d))/self.rho
        return self.suffix[idx]-np.exp(-self.rho*self.grid[idx])*(self.values[idx]*p+self.slopes[idx]*j)

    def interp(self, x):
        return np.interp(np.asarray(x, dtype=np.float64), self.grid, self.values)

    def continuation(self, x):
        x = np.asarray(x, dtype=np.float64)
        if np.any((x<0)|(x>1)):
            raise ValueError("mileage outside [0,1]")
        y = np.minimum(1., x+L[self.f])
        integral = np.exp(self.rho*x)*self.rho/self.z*(self.primitive(x)-self.primitive(y))
        return integral + cap_mass(x,self.f)*self.values[-1]

    def q(self, x, beta=BETA):
        x = np.asarray(x, dtype=np.float64)
        q0 = -(U[self.f]*x+V[self.f]*x*x)+beta*self.continuation(x)
        q1 = -(KCOST[self.f]+D[self.f]*x*x)+beta*self.values[0]
        return q0, q1

    def query(self, x):
        q0,q1 = self.q(x)
        return q0,q1,np.logaddexp(q0,q1),self.interp(x)

    def residual(self, x):
        q0,q1,soft,interp = self.query(x)
        return soft-interp

def solve(f,K,tol=1e-11,max_sweeps=2000):
    t0=time.perf_counter()
    x=np.linspace(0.,1.,K)
    # Relative value initialization saves iterations without changing the fixed point.
    values=np.zeros(K,dtype=np.float64)
    hist=[]
    for sweep in range(1,max_sweeps+1):
        comp=Component(f,values)
        q0,q1=comp.q(x)
        new=np.logaddexp(q0,q1)
        err=float(np.max(np.abs(new-values)))
        if not np.isfinite(err): raise FloatingPointError("nonfinite iteration")
        hist.append(err); values=new
        if err<=tol and float(np.max(np.abs(Component(f,values).residual(x))))<=tol: break
    else: raise RuntimeError("VI did not converge in 2000 sweeps")
    comp=Component(f,values)
    reloaded=float(np.max(np.abs(comp.residual(x))))
    if reloaded>tol: raise RuntimeError("reloaded residual exceeds tolerance")
    return comp,dict(f=f,K=K,sweeps=sweep,last_change=err,reloaded_residual=reloaded,
                     wall_s=time.perf_counter()-t0)

def direct_hat(x,comp):
    """Independent slow hat-row integral, for validation points."""
    from .texp import mass,first_moment
    f=comp.f; x=float(x); ans=0.
    for i in range(comp.K-1):
        l=max(0.,comp.grid[i]-x)
        u=min(float(L[f]),1.-x,comp.grid[i+1]-x)
        if l>=u: continue
        p=mass(l,u,f); moment=first_moment(l,u,f)
        ans+=comp.values[i]*p+comp.slopes[i]*((x-comp.grid[i])*p+moment)
    return ans+float(cap_mass(x,f))*comp.values[-1]
