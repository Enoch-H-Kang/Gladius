"""Evaluator-only truth scoring interface for later comparator work."""
import numpy as np
from .rewards import all_actions

def score(pred_fn,states,reference):
    s=np.asarray(states,dtype=np.float64).reshape(-1,5)
    truth_r=all_actions(s)
    truth_q,_,truth_pi=reference.joint_query(s)
    prediction=pred_fn(s.astype(np.float32))
    reward=np.asarray(prediction["reward"],dtype=np.float64)
    q=np.asarray(prediction["Q"],dtype=np.float64)
    pi=np.asarray(prediction["pi"],dtype=np.float64)
    if reward.shape!=truth_r.shape or q.shape!=truth_q.shape or pi.shape!=truth_pi.shape:
        raise ValueError("expected n by 32 predictions")
    if not np.isfinite(reward).all() or not np.isfinite(q).all() or not np.isfinite(pi).all():
        raise ValueError("nonfinite prediction")
    err=reward-truth_r
    return dict(nonanchor_reward_rmse=float(np.sqrt(np.mean(err[:,1:]**2))),
                anchor_reward_rmse=float(np.sqrt(np.mean(err[:,0]**2))),
                raw_Q_rmse=float(np.sqrt(np.mean((q-truth_q)**2))),
                mean_TV=float(np.mean(.5*np.sum(np.abs(pi-truth_pi),axis=1))))
