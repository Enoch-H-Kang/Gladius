import tempfile
import unittest
from pathlib import Path
import numpy as np
import torch
from .params import ACTIONS,encode,decode,BETA,MU,F,DGP_PATH,ACTION_PATH,sha256
from .rewards import reward,r0,all_actions,maintenance,replacement
from .texp import draw,cdf,cap_mass,L
from .env import step
from .oracle1d import solve,direct_hat
from .query import Reference
from .models import build,factory,initialize
from .data_io import load_fleet
from .launcher import PROTOCOL_PATH
from .numerical_checks import kernel_matrix
from .tensor_subsets import bellman
from scipy.special import logsumexp

class ModelTests(unittest.TestCase):
    def test_actions_and_rewards(self):
        a=np.arange(32);np.testing.assert_array_equal(encode(decode(a)),a)
        s=np.array([[.2,.4,.6,.8,1.]])
        np.testing.assert_allclose(all_actions(s)[0,0],r0(s)[0])
        np.testing.assert_allclose(all_actions(s)[0,31],-replacement(s).sum())
        np.testing.assert_allclose(all_actions(s)[0],reward(np.repeat(s,32,axis=0),a))
    def test_transition(self):
        s=np.array([[.3,.7,.99,.2,1.]])
        inc=np.full_like(s,.2); bits=np.array([[1,0,0,1,0]])
        np.testing.assert_allclose(step(s,bits,inc),[[0.,.9,1.,0.,1.]])
        self.assertEqual(cap_mass(1.,0),1.)
        self.assertEqual(cap_mass(0.,0),0.)
    def test_draw_support_cdf(self):
        for f in range(F):
            self.assertAlmostEqual(draw(0.,f),0.)
            self.assertAlmostEqual(draw(1.,f),L[f])
            self.assertAlmostEqual(cdf(draw(.37,f),f),.37,places=14)
    def test_zero_reward_entropy(self):
        v=np.log(2)/(1-BETA)
        self.assertAlmostEqual(5*v,np.log(32)/(1-BETA))
        self.assertAlmostEqual(np.logaddexp(BETA*v,BETA*v),v)
        self.assertAlmostEqual(logsumexp(np.zeros(32)),np.log(32))
    def test_beta_zero_and_zero_reward_operator(self):
        from .oracle1d import Component
        x=np.linspace(0.,1.,17)
        c=Component(0,np.linspace(-2.,1.,101))
        q0,q1=c.q(x,beta=0.)
        np.testing.assert_allclose(q0,-(x+2*x*x),atol=1e-14)
        np.testing.assert_allclose(q1,-(3+.15*x*x),atol=1e-14)
        constant=np.log(2)/(1-BETA)
        zero=Component(0,np.full(101,constant))
        vals=np.logaddexp(BETA*zero.continuation(x),BETA*zero.values[0])
        np.testing.assert_allclose(vals,constant,atol=1e-12)

    def test_component_solver_and_identity(self):
        c,r=solve(0,101)
        x=np.array([0.,.13,.5,.8,1.])
        q0,q1,soft,interp=c.query(x)
        np.testing.assert_allclose(q0-BETA*c.continuation(x),
                                   -(1*x+2*x*x),atol=1e-12)
        np.testing.assert_allclose(q1-BETA*c.values[0],
                                   -(3+.15*x*x),atol=1e-12)
        self.assertLess(r["reloaded_residual"],1e-11)
        for y in (.03,.32,.88): self.assertLess(abs(c.continuation(y)-direct_hat(y,c)),1e-11)
    def test_joint_shapes_algebra(self):
        comps=[solve(f,101)[0] for f in range(F)]
        q,v,p=Reference(comps).joint_query(np.random.default_rng(1).random((7,5)))
        self.assertEqual(q.shape,(7,32));self.assertEqual(v.shape,(7,));self.assertEqual(p.shape,(7,32))
        np.testing.assert_allclose(logsumexp(q,axis=1),v,atol=1e-12)
        np.testing.assert_allclose(p.sum(1),1,atol=1e-12)
    def test_architectures_and_init(self):
        x=torch.rand(4,5)
        for arch in ("linear","mlp1x5","mlp2x10","mlp2x64","mlp2x128","additive","factored"):
            info={"bits":ACTIONS.tolist()} if arch=="factored" else None
            m=initialize(build(arch,info),13,-4.)
            self.assertEqual(tuple(m(x).shape),(4,32))
            self.assertTrue(torch.isfinite(m(x)).all())
        with self.assertRaises(ValueError):build("mlp2x64",{"bits":ACTIONS.tolist()})
        with self.assertRaises(ValueError):build("factored",None)
    def test_truth_stripped_loader(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"d.npz"
            s=np.zeros((2,100,5),dtype=np.float32)
            kw=dict(s=s,sp=s,a=np.zeros((2,100),dtype=np.int8),r0=np.zeros((2,100)),
                    is_val=np.array([False,True]),chain_id=np.arange(2),arm="independent_r1literal",
                    dgp_sha256=sha256(DGP_PATH),action_sha256=sha256(ACTION_PATH),
                    reference_sha256="reference",protocol_sha256=sha256(PROTOCOL_PATH),
                    n_actions=32,anchor_action=0)
            np.savez(p,**kw)
            d=load_fleet(p,2,"reference")
            self.assertEqual(d["train"]["s"].shape,(100,5))
            self.assertEqual(d["meta"]["n_actions"],32)
            with self.assertRaises(ValueError):load_fleet(p,2,"wrong")
            kw["a"][:]=32;np.savez(p,**kw)
            with self.assertRaises(ValueError):load_fleet(p,2,"reference")
    def test_injected_trainer_and_checkpoint_reload(self):
        from .trainer import fit_fleet
        from experiments.fleet_capacity_one.tuning.evaluate import fleet_nets
        from .models import factory,initialize
        rng=np.random.default_rng(8)
        def part(n):
            return dict(s=rng.random((n,5)).astype(np.float32),
                        sp=rng.random((n,5)).astype(np.float32),
                        a=np.zeros(n,dtype=np.int64),r0=np.full(n,-2.,dtype=np.float32))
        data=dict(train=part(40),val=part(10),meta=dict(n_actions=32,anchor_action=0,
                  state_scale=1.,arm="independent_r1literal"))
        seeds={k:i+10 for i,k in enumerate(("qinit","zinit","ce","extrazeta","anchor"))}
        with tempfile.TemporaryDirectory() as td:
            cfg=dict(architecture="mlp2x10",cap_q=2,val_every=1,elig_start=1,batch=8,
                     loss="signed",bias="zero")
            rec=fit_fleet(data,cfg,seeds,horizons=[2],ckpt_dir=td)
            self.assertEqual(rec["counts"]["q_updates"],2)
            ck=torch.load(Path(td)/"ckpt_final.pt",weights_only=False)
            q,z,_,meta=fleet_nets(ck)
            self.assertEqual(tuple(q(torch.zeros(2,5)).shape),(2,32))
            self.assertEqual(tuple(z(torch.zeros(2,5)).shape),(2,32))
            self.assertEqual(meta["anchor_action"],0)

    def test_action_permutation_updates(self):
        import copy
        from experiments.fleet_capacity_one.fleet.losses import be_term,zeta_term
        torch.manual_seed(17)
        q=torch.nn.Linear(5,32).double();z=torch.nn.Linear(5,32).double()
        perm=torch.randperm(32);inverse=torch.empty_like(perm);inverse[perm]=torch.arange(32)
        qp=copy.deepcopy(q);zp=copy.deepcopy(z)
        with torch.no_grad():
            for orig,other in ((q,qp),(z,zp)):
                other.weight.copy_(orig.weight[perm])
                other.bias.copy_(orig.bias[perm])
        oq=torch.optim.AdamW(q.parameters(),lr=.001)
        oz=torch.optim.AdamW(z.parameters(),lr=.001)
        opq=torch.optim.AdamW(qp.parameters(),lr=.001)
        opz=torch.optim.AdamW(zp.parameters(),lr=.001)
        x=torch.rand(19,5,dtype=torch.float64)
        xp=torch.rand(19,5,dtype=torch.float64)
        a=torch.randint(0,32,(19,))
        a[0]=0
        r0=torch.rand(19,dtype=torch.float64)
        for _ in range(2):
            pairs=((q,z,oq,oz,a,0),(qp,zp,opq,opz,inverse[a],int(inverse[0])))
            losses=[];qgrads=[]
            for qm,zm,o_q,o_z,labels,anchor in pairs:
                target=torch.logsumexp(qm(xp),1).detach()
                zl=zeta_term(zm(x).gather(1,labels[:,None])[:,0],target)
                o_z.zero_grad();zl.backward();o_z.step()
                qout=qm(x)
                qsa=qout.gather(1,labels[:,None])[:,0]
                vv=torch.logsumexp(qm(xp),1)
                zz=zm(x).gather(1,labels[:,None])[:,0].detach()
                loss=torch.nn.functional.cross_entropy(qout,labels)+be_term(
                    qsa,r0,vv,zz,labels==anchor,.95,"none")
                o_q.zero_grad();loss.backward()
                losses.append(loss.item())
                qgrads.append(qm.weight.grad.detach().clone())
                o_q.step()
            self.assertLess(abs(losses[0]-losses[1]),1e-10)
            self.assertLess(torch.max(torch.abs(qgrads[0]-qgrads[1][inverse])).item(),1e-10)
            self.assertLess(torch.max(torch.abs(q.weight-qp.weight[inverse])).item(),1e-10)
            self.assertLess(torch.max(torch.abs(z.weight-zp.weight[inverse])).item(),1e-10)

    def test_launcher_fail_closed(self):
        from .launcher import admit_fleet
        meta=dict(arm="independent_r1literal",n_actions=32,anchor_action=0,
                  dgp_sha256=sha256(DGP_PATH),action_sha256=sha256(ACTION_PATH),
                  protocol_sha256=sha256(PROTOCOL_PATH),reference_sha256="artifact")
        ref=dict(status="certified",dgp_sha256=sha256(DGP_PATH),
                 action_sha256=sha256(ACTION_PATH),artifact_sha256="artifact")
        with self.assertRaisesRegex(ValueError,"pilot acceptance"):
            admit_fleet(meta,ref,dict(status="descriptive_only_U1_open"),sha256(PROTOCOL_PATH))
        self.assertTrue(admit_fleet(meta,ref,dict(status="accepted"),sha256(PROTOCOL_PATH)))
        with self.assertRaisesRegex(ValueError,"reference hash"):
            admit_fleet({**meta,"reference_sha256":"wrong"},ref,
                        dict(status="accepted"),sha256(PROTOCOL_PATH))

    def test_five_dimensional_tensor(self):
        K=9;comps=[solve(f,K)[0] for f in range(F)]
        kernels=[kernel_matrix(f,K) for f in range(F)]
        g=np.linspace(0,1,K)
        shape=(K,)*F;value=np.zeros(shape)
        for f,c in enumerate(comps):
            sh=[1]*F;sh[f]=K;value+=c.values.reshape(sh)
        mesh=np.stack(np.meshgrid(*([g]*F),indexing="ij"),axis=-1)
        rew=all_actions(mesh.reshape(-1,5)).T.reshape((32,)+shape)
        self.assertLess(np.max(np.abs(bellman(value,kernels,rew,BETA)-value)),1e-10)

if __name__=="__main__":unittest.main()
