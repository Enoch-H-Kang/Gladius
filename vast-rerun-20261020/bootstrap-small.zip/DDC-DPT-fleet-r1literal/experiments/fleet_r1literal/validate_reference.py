"""Whole-grid reference checks and a second-derivative interval enclosure."""
import json
import math
import time
from pathlib import Path
import numpy as np
from .oracle1d import solve, direct_hat
from .params import BETA,U,V,D,sha256,DGP_PATH,ACTION_PATH
from .texp import RHO,L,Z
from .assemble import save
from .query import Reference

GRIDS=(1001,2001,4001,8001)
ARITH_ALLOWANCE=1e-9
QUERY_ALLOWANCE=1e-8

def curvature_bound(comp):
    f=comp.f
    slope=float(np.max(np.abs(comp.slopes)))
    rho=float(RHO[f]); z=float(Z[f])
    # W prime is bounded by Lip(v). Almost everywhere, W double prime
    # equals rho W prime - p(0)v prime(x) + p(L)v prime(x+L)
    # before the cap junction; the last term vanishes beyond it.
    w2=slope*(rho+rho/z+rho*math.exp(-rho*L[f])/z)
    q02=2*V[f]+BETA*w2
    q12=2*D[f]
    q0p=U[f]+2*V[f]+BETA*slope
    q1p=2*D[f]
    return float(max(q02,q12)+.25*(q0p+q1p)**2)

def interval_enclosure(comp,subdiv=16):
    K=comp.K; h=comp.h
    shifted=(np.arange(K)/(K-1)-L[comp.f])
    aligned=np.max(np.abs(shifted*(K-1)-np.rint(shifted*(K-1))))
    if aligned>1e-9: raise RuntimeError("shifted knots require extra splitting")
    t=np.arange(K-1)[:,None]+np.arange(subdiv+1)[None,:]/subdiv
    x=(t/(K-1)).reshape(-1)
    residual=np.abs(comp.residual(x)).reshape(K-1,subdiv+1)
    endpoints=np.maximum(residual[:,:-1],residual[:,1:])
    M=curvature_bound(comp)
    interpolation=M*(h/subdiv)**2/8
    bound=float(np.max(endpoints)+interpolation+ARITH_ALLOWANCE)
    return dict(max_endpoints=float(residual.max()),curvature_M=M,
                interpolation_allowance=interpolation,arithmetic_allowance=ARITH_ALLOWANCE,
                bound=bound,subintervals=(K-1)*subdiv,shifted_alignment=aligned)

def panels(comp,seed):
    f=comp.f;K=comp.K
    rng=np.random.default_rng(seed)
    points=np.r_[np.linspace(0.,1.,20001),rng.random(10000),
                 (np.arange(K-1)+.5)/(K-1),0.,1.,1-L[f],
                 np.nextafter([0.,1.,1-L[f]],[1.,0.,0.]),
                 np.nextafter([0.,1.,1-L[f]],[1.,0.,1.])]
    return dict(n=len(points),max_abs_residual=float(np.max(np.abs(comp.residual(points)))))

def cross(a,b):
    x=np.linspace(0.,1.,20001)
    d=np.stack(a.q(x))-np.stack(b.q(x))
    return dict(max_abs=float(np.abs(d).max()),rms=float(np.sqrt(np.mean(d*d))))

def validate(root):
    t0=time.perf_counter();root=Path(root);root.mkdir(parents=True,exist_ok=True)
    records=[]; candidate=[]
    for f in range(5):
        bus=[]; comps={}
        for K in GRIDS:
            comp,rec=solve(f,K)
            comps[K]=comp;bus.append(rec)
        c=comps[4001];candidate.append(c)
        cert=interval_enclosure(c)
        if cert["bound"]>1e-6:
            cert=interval_enclosure(comps[8001])
            c=comps[8001];candidate[-1]=c
        xs=np.random.default_rng(9100+f).random(30)
        direct=float(max(abs(c.continuation(float(x))-direct_hat(x,c)) for x in xs))
        rec=dict(bus=f+1,grids=bus,certificate=cert,
                 panels=panels(c,8100+f),cross_2001_4001=cross(comps[2001],comps[4001]),
                 cross_4001_8001=cross(comps[4001],comps[8001]),direct_hat_max=direct,
                 release_K=c.K)
        records.append(rec)
        print(json.dumps(rec),flush=True)
    ref=Reference(candidate)
    states=np.random.default_rng(7821).random((300,5))
    Q,jv,pi=ref.joint_query(states)
    algebra=float(max(np.max(np.abs(np.log(np.exp(Q-Q.max(1,keepdims=True)).sum(1))+Q.max(1)-jv)),
                      np.max(np.abs(pi.sum(1)-1))))
    bound=BETA/(1-BETA)*sum(r["certificate"]["bound"] for r in records)+QUERY_ALLOWANCE
    status=("certified" if all(r["certificate"]["bound"]<=1e-6 for r in records)
            and bound<=1e-4 and algebra<=1e-12 and
            all(r["cross_2001_4001"]["max_abs"]<=2e-5 for r in records)
            and all(r["direct_hat_max"]<=1e-10 for r in records) else "failed")
    manifest=dict(status=status,base_commit="5c6cfcfa3bb449239a4386473e3214f42093111d",
                  dgp_sha256=sha256(DGP_PATH),action_sha256=sha256(ACTION_PATH),
                  buses=records,joint_Q_bound=bound,query_allowance=QUERY_ALLOWANCE,
                  algebra_max=algebra,wall_s=time.perf_counter()-t0)
    save(root,candidate,manifest)
    (root/"reference_status.md").write_text(
        "# Reference status: "+status+"\n\nJoint Q bound: "+repr(bound)+
        "\n\nThe exact additive decomposition uses certified component value enclosures.\n")
    print(json.dumps(dict(status=status,joint_Q_bound=bound,algebra_max=algebra,
                          wall_s=manifest["wall_s"])),flush=True)
    return manifest

if __name__=="__main__":
    import sys
    validate(sys.argv[1])
