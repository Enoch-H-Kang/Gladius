"""Truth-stripped 32-action fleet data loader and independent schema checks."""
import json
import numpy as np
from .params import DGP_PATH,ACTION_PATH,sha256
from .launcher import PROTOCOL_PATH

def load_fleet(path,n_chains=None,reference_sha256=None):
    z=np.load(path,allow_pickle=False)
    for field in ("s","sp","a","r0","is_val","chain_id"):
        if field not in z: raise ValueError("missing "+field)
    if str(z["arm"])!="independent_r1literal": raise ValueError("wrong arm")
    if int(z["n_actions"])!=32 or int(z["anchor_action"])!=0:
        raise ValueError("wrong action metadata")
    if str(z["dgp_sha256"])!=sha256(DGP_PATH) or str(z["action_sha256"])!=sha256(ACTION_PATH):
        raise ValueError("config hash mismatch")
    if str(z["protocol_sha256"])!=sha256(PROTOCOL_PATH):
        raise ValueError("protocol hash mismatch")
    if reference_sha256 is not None and str(z["reference_sha256"])!=reference_sha256:
        raise ValueError("reference hash mismatch")
    n=len(z["is_val"]) if n_chains is None else n_chains
    if n>len(z["is_val"]): raise ValueError("too many chains")
    if z["s"].shape[1:]!=(100,5) or z["sp"].shape!=z["s"].shape or z["a"].shape[1:]!=(100,):
        raise ValueError("fleet data shape mismatch")
    if np.any((z["a"]<0)|(z["a"]>31)): raise ValueError("invalid action")
    mask=z["is_val"][:n].astype(bool)
    def part(which):
        return dict(s=z["s"][:n][which].reshape(-1,5).astype(np.float32),
                    sp=z["sp"][:n][which].reshape(-1,5).astype(np.float32),
                    a=z["a"][:n][which].reshape(-1).astype(np.int64),
                    r0=z["r0"][:n][which].reshape(-1).astype(np.float32))
    return dict(train=part(~mask),val=part(mask),
                meta=dict(n_actions=32,anchor_action=0,beta=.95,state_scale=1.,
                          arm="independent_r1literal",dgp_sha256=sha256(DGP_PATH),
                          action_sha256=sha256(ACTION_PATH),protocol_sha256=sha256(PROTOCOL_PATH),
                          reference_sha256=str(z["reference_sha256"])),
                n_chains=n,n_train_chains=int((~mask).sum()),n_val_chains=int(mask.sum()))

def load_split(path,n_chains=None,reference_sha256=None):
    return load_fleet(path,n_chains,reference_sha256)
