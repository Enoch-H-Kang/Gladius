"""Independent kernel, sampler, algebra and tensor controls."""
import json
import math
import time
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.special import logsumexp
from .params import ACTIONS,F,BETA,MU,encode,decode
from .texp import RHO,L,Z,draw,cdf,cap_mass,mass
from .oracle1d import Component,solve,direct_hat
from .assemble import load
from .query import Reference
from .tensor_subsets import bellman as tensor_bellman
from .rewards import all_actions,r0

def quadrature(comp,x,order):
    f=comp.f;rho=RHO[f];z=Z[f]
    end=min(L[f],1-x)
    grid=comp.grid
    knots=grid[(grid>x)&(grid<x+end)]-x
    bounds=np.r_[0.,knots,end]
    nodes,weights=leggauss(order)
    total=0.
    for lo,hi in zip(bounds[:-1],bounds[1:]):
        if hi<=lo:continue
        d=(lo+hi)/2+(hi-lo)/2*nodes
        y=x+d
        total+=(hi-lo)/2*np.dot(weights,comp.interp(y)*rho*np.exp(-rho*d)/z)
    return total+float(cap_mass(x,f))*comp.values[-1]

def kernel_matrix(f,K):
    # Independent direct hat rows. Small K only, for tensor controls.
    from .texp import first_moment
    grid=np.linspace(0,1,K)
    P=np.zeros((K,K))
    for j,x in enumerate(grid):
        for i in range(K-1):
            lo=max(0.,grid[i]-x)
            hi=min(L[f],1-x,grid[i+1]-x)
            if hi<=lo:continue
            p=mass(lo,hi,f);m=first_moment(lo,hi,f)
            high=((x-grid[i])*p+m)*(K-1)
            P[j,i]+=p-high;P[j,i+1]+=high
        P[j,-1]+=cap_mass(x,f)
    return P

def checks(refroot,outroot):
    t0=time.perf_counter();out=Path(outroot);out.mkdir(parents=True,exist_ok=True)
    ref=load(refroot);rng=np.random.default_rng(20261018)
    per=[]
    for f,c in enumerate(ref.components):
        xs=rng.uniform(0,1,12)
        e10=max(abs(c.continuation(x)-quadrature(c,float(x),10)) for x in xs)
        e20=max(abs(c.continuation(x)-quadrature(c,float(x),20)) for x in xs)
        uniforms=rng.random(1000000)
        sample=draw(uniforms,f)
        moment=float(sample.mean());cdf_err=max(abs(np.mean(sample<=v)-cdf(v,f))
                                          for v in np.quantile(sample,[.1,.5,.9]))
        caps=np.mean(np.minimum(1.,rng.random(1000000)+sample)==1.)
        # Kernel row controls at K=101, where constructing rows remains cheap.
        P=kernel_matrix(f,101)
        per.append(dict(bus=f+1,gauss10=e10,gauss20=e20,
                        sample_min=float(sample.min()),sample_max=float(sample.max()),
                        sample_mean=moment,mean_target=float(MU[f]),cdf_error=float(cdf_err),
                        cap_diagnostic=float(caps),
                        row_sum_error=float(np.max(np.abs(P.sum(1)-1))),
                        min_weight=float(P.min())))
    S=rng.random((1000,5));Q,V,pi=ref.joint_query(S)
    binary=np.array([np.stack(c.q(S[:,f]),axis=1) for f,c in enumerate(ref.components)])
    marginal=np.exp(binary-logsumexp(binary,axis=2,keepdims=True))
    product=np.ones_like(pi)
    for f in range(F):product*=marginal[f][:,ACTIONS[:,f]]
    algebra=dict(lse_max=float(np.max(np.abs(logsumexp(Q,axis=1)-V))),
                 product_max=float(np.max(np.abs(product-pi))),
                 probability_sum=float(np.max(np.abs(pi.sum(1)-1))),
                 reward_anchor_max=float(np.max(np.abs(all_actions(S)[:,0]-r0(S)))),
                 encode_roundtrip=bool(np.array_equal(encode(decode(np.arange(32))),np.arange(32))))
    # Million fixed-state independent-binary versus categorical draws.
    fixed=np.full((1,5),.4)
    _,_,prob=ref.joint_query(fixed)
    sample_n=1000000
    binary_draw=(rng.random((sample_n,5))<
        np.array([np.exp(ref.components[f].q(.4)[1]-
                         np.logaddexp(*ref.components[f].q(.4))) for f in range(F)]))
    prod_counts=np.bincount(encode(binary_draw),minlength=32)/sample_n
    cat_counts=np.bincount(rng.choice(32,size=sample_n,p=prob[0]),minlength=32)/sample_n
    algebra["joint_sampling_max_gap"]=float(np.max(np.abs(prod_counts-cat_counts)))
    # Same-grid five-axis additive fixed-point control; contraction gives
    # uniqueness of the tensor Bellman solution without a second long VI.
    K=9;comps=[solve(f,K)[0] for f in range(F)]
    kernels=[kernel_matrix(f,K) for f in range(F)]
    grid=np.linspace(0,1,K)
    shape=(K,)*F
    values=np.zeros(shape)
    for f,c in enumerate(comps):
        shp=[1]*F;shp[f]=K;values+=c.values.reshape(shp)
    mesh=np.stack(np.meshgrid(*([grid]*F),indexing="ij"),axis=-1)
    reward=all_actions(mesh.reshape(-1,F)).T.reshape((32,)+shape)
    update=tensor_bellman(values,kernels,reward,BETA)
    tensor_res=float(np.max(np.abs(update-values)))
    result=dict(per_bus=per,algebra=algebra,tensor_k9_residual=tensor_res,
                wall_s=time.perf_counter()-t0)
    (out/"numerical_checks.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(dict(per_bus=per,algebra=algebra,tensor_k9_residual=tensor_res,
                          wall_s=result["wall_s"])),flush=True)
    return result
if __name__=="__main__":
    import sys
    checks(*sys.argv[1:])
