"""Independent off-grid subset-action and two-bus tensor diagnostics."""
import json
import time
from pathlib import Path
import numpy as np
from scipy.special import logsumexp
from .oracle1d import solve
from .numerical_checks import kernel_matrix
from .params import BETA,ACTIONS
from .rewards import all_actions
from .texp import mass,first_moment,cap_mass,L
from .tensor_subsets import bellman

def row(f,K,x):
    grid=np.linspace(0.,1.,K);out=np.zeros(K)
    for i in range(K-1):
        lo=max(0.,grid[i]-x);hi=min(L[f],1-x,grid[i+1]-x)
        if hi<=lo:continue
        p=mass(lo,hi,f);m=first_moment(lo,hi,f)
        higher=((x-grid[i])*p+m)*(K-1)
        out[i]+=p-higher;out[i+1]+=higher
    out[-1]+=cap_mass(x,f)
    return out

def lookahead_tensor(values,states,component_ids):
    K=values.shape[0];q=[]
    for state in states:
        rows=[row(f,K,float(x)) for f,x in zip(component_ids,state)]
        qa=[]
        for bits in range(1<<len(component_ids)):
            contracted=values
            for axis in reversed(range(len(component_ids))):
                if (bits>>axis)&1:contracted=np.take(contracted,0,axis=axis)
            keep=[axis for axis in range(len(component_ids)) if not ((bits>>axis)&1)]
            for current in reversed(range(len(keep))):
                contracted=np.tensordot(contracted,rows[keep[current]],axes=([current],[0]))
            # Reward uses only selected component coordinates.
            reward=0.
            from .params import U,V,KCOST,D
            for axis,(f,x) in enumerate(zip(component_ids,state)):
                reward-=KCOST[f]+D[f]*x*x if ((bits>>axis)&1) else U[f]*x+V[f]*x*x
            qa.append(reward+BETA*float(contracted))
        q.append(qa)
    return np.array(q)

def run(outroot):
    t0=time.perf_counter();out=Path(outroot);out.mkdir(parents=True,exist_ok=True)
    K=9;comps=[solve(f,K)[0] for f in range(5)]
    values=np.zeros((K,)*5)
    for f,c in enumerate(comps):
        shape=[1]*5;shape[f]=K;values+=c.values.reshape(shape)
    states=np.random.default_rng(314).random((3,5))
    tensor=lookahead_tensor(values,states,list(range(5)))
    additive=np.zeros_like(tensor)
    for f,c in enumerate(comps):
        q0,q1=c.q(states[:,f])
        additive+=np.where(ACTIONS[:,f],q1[:,None],q0[:,None])
    five_offgrid=float(np.max(np.abs(tensor-additive)))
    K=401;coarse=[solve(f,K)[0] for f in range(2)]
    fine=[solve(f,4001)[0] for f in range(2)]
    values=coarse[0].values[:,None]+coarse[1].values[None,:]
    kernels=[kernel_matrix(f,K) for f in range(2)]
    grid=np.linspace(0.,1,K)
    mesh=np.stack(np.meshgrid(grid,grid,indexing="ij"),axis=-1)
    rew=np.empty((4,K,K))
    for a in range(4):
        bits=((a>>np.arange(2))&1)
        from .params import U,V,KCOST,D
        rew[a]=sum(-np.where(bits[f],KCOST[f]+D[f]*mesh[:,:,f]**2,
                              U[f]*mesh[:,:,f]+V[f]*mesh[:,:,f]**2) for f in range(2))
    residual=float(np.max(np.abs(bellman(values,kernels,rew,BETA)-values)))
    states=np.random.default_rng(315).random((100,2))
    tensorq=lookahead_tensor(values,states,[0,1])
    same=np.zeros_like(tensorq);fineq=np.zeros_like(tensorq)
    for f in range(2):
        q0,q1=coarse[f].q(states[:,f]);a0,a1=fine[f].q(states[:,f])
        bits=((np.arange(4)>>f)&1)
        same+=np.where(bits,q1[:,None],q0[:,None])
        fineq+=np.where(bits,a1[:,None],a0[:,None])
    result=dict(k9_five_offgrid_max=five_offgrid,k401_two_bus_tensor_residual=residual,
                k401_two_bus_offgrid_same_grid_max=float(np.max(np.abs(tensorq-same))),
                k401_vs_k4001_max=float(np.max(np.abs(tensorq-fineq))),
                k401_vs_k4001_rms=float(np.sqrt(np.mean((tensorq-fineq)**2))),
                wall_s=time.perf_counter()-t0)
    (out/"tensor_controls.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result),flush=True)
if __name__=="__main__":
    import sys
    run(sys.argv[1])
