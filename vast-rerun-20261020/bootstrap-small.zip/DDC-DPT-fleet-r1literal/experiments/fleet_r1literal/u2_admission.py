"""Fail-closed pre-admission hash and dependency barrier for U2 tuning stages."""
import hashlib
import json
from pathlib import Path

EMBEDDED_AMENDMENT_SHA256 = "215a24fb439a0dd950ea0fce33f0ff147bca9dd8edfee4d884bf4ee5a6f3f25c"

from .u2_decision import AMENDMENT_SHA256, Stop
assert AMENDMENT_SHA256 == EMBEDDED_AMENDMENT_SHA256

ROOT = Path(__file__).resolve().parent
AMENDMENT = ROOT / "protocol/u2-amendment-merged.md"
ACTIVATION = ROOT / "protocol/u2_activation.json"
AUDIT = ROOT / "results/tuning/u2_audit.json"


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_stage(manifest):
    """Return only after the stage and all earlier U2 barriers are evidenced."""
    stage = manifest["stage"]
    if stage == "FR":
        return  # Historical, completed diagnostic predates U2.
    if not AMENDMENT.is_file() or not ACTIVATION.is_file() or not AUDIT.is_file():
        raise Stop("HASH_BARRIER")
    if file_sha(AMENDMENT) != AMENDMENT_SHA256:
        raise Stop("HASH_BARRIER")
    activation = json.loads(ACTIVATION.read_text())
    audit = json.loads(AUDIT.read_text())
    if activation.get("amendment_sha256") != AMENDMENT_SHA256 or audit.get("amendment_sha256") != AMENDMENT_SHA256:
        raise Stop("HASH_BARRIER")
    if manifest.get("amendment_sha256") != AMENDMENT_SHA256:
        raise Stop("HASH_BARRIER")
    if manifest.get("n_fits") != len(manifest.get("fits", [])):
        raise Stop("HASH_BARRIER")
    # The 2026-10-19 19:48 author freeze closes common-design selection.
    # These manifests are development-only transfer/feasibility evidence.
    # They do not certify the exposed B3 decision or rerank any design.
    if manifest.get("frozen_evidence") and stage in ("F1", "F2", "F3", "D"):
        freeze = ROOT / "protocol/common_protocol_freeze.json"
        if not freeze.is_file() or manifest.get("freeze_sha256") != file_sha(freeze):
            raise Stop("HASH_BARRIER")
        frozen = json.loads(freeze.read_text())
        if (frozen.get("status") != "author_frozen_exploratory" or
            manifest.get("bus_lock_sha256") != frozen.get("bus_lock_embedded_sha256") or
            frozen.get("u2_amendment_sha256") != AMENDMENT_SHA256):
            raise Stop("HASH_BARRIER")
        return
    # No pre-exposure hash or independent-data evidence may be invented after B3 truth release.
    blocking = {x["reason"] for x in audit.get("stops", [])}
    if blocking:
        raise Stop("CONFIRMATION_EXPOSED" if "CONFIRMATION_EXPOSED" in blocking else sorted(blocking)[0])
    if stage in ("F1", "F2", "F3", "B3x", "FL", "FACTORED_LOCK", "FS", "D", "AF"):
        if not manifest.get("c_bus_sha256") or not manifest.get("bus_lock_sha256"):
            raise Stop("HASH_BARRIER")
    if stage in ("F3", "B3x", "FL", "FACTORED_LOCK", "FS", "D", "AF"):
        for field in ("candidate_map_sha256", "rate_map_sha256", "reference_map_sha256",
                      "decision_sha256", "bootstrap_indices_sha256", "additional_work_ledger_sha256"):
            if not manifest.get(field):
                raise Stop("HASH_BARRIER")
    if stage == "AF" and not (ROOT / "protocol/common_protocol_freeze.json").is_file():
        raise Stop("HASH_BARRIER")
