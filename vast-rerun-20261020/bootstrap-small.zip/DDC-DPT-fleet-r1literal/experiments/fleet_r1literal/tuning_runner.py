"""Detached fleet stage runner; one-thread fits with explicit token accounting."""
import csv
import fcntl
import json
import os
import subprocess
import sys
import time
from pathlib import Path

from .tuning_run_fit import code_hash, hashfile
from .cpu_budget import worker_budget
from .u2_admission import verify_stage
from .u2_decision import AMENDMENT_SHA256

U2_AMENDMENT_SHA256 = "215a24fb439a0dd950ea0fce33f0ff147bca9dd8edfee4d884bf4ee5a6f3f25c"
assert AMENDMENT_SHA256 == U2_AMENDMENT_SHA256

ROOT=Path(__file__).resolve().parent
CAP=44
FIT_MAX=36
CTRL_RESERVATION=2
PY=sys.executable
MARK="R1LITERAL_FIT_WORKER"

def bus_workers():
    n=0
    for p in Path("/proc").iterdir():
        if not p.name.isdigit(): continue
        try: cmd=(p/"cmdline").read_bytes().replace(b"\0",b" ")
        except (OSError,PermissionError): continue
        if b"experiments.fleet_capacity_one.tuning.run_fit" in cmd:
            n+=1
    return n

def complete(spec,fits_root,manifest_sha,code_sha):
    p=Path(fits_root)/spec["fit_id"]/"record.json"
    if not p.exists(): return False
    r=json.loads(p.read_text())
    if r.get("config_id")!=spec["config_id"] or r.get("manifest_sha256")!=manifest_sha:
        raise RuntimeError("existing record conflicts with manifest: "+spec["fit_id"])
    if r.get("code_hash")!=code_sha:
        raise RuntimeError("existing record conflicts with code: "+spec["fit_id"])
    return True

def main(manifest,fits_root,ledger_root):
    m=json.loads(Path(manifest).read_text())
    stage=m["stage"]
    verify_stage(m)
    led=Path(ledger_root); led.mkdir(parents=True,exist_ok=True)
    lock=(led/"admission.lock").open("a+")
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    ch=code_hash(stage)
    pending=[s for s in m["fits"] if not complete(s,fits_root,m["sha256"],ch)]
    pending.sort(key=lambda s:(-s["config"]["k"],s["fit_id"]))
    queue=led/f"queue_{stage}.csv"
    usage=led/f"usage_{stage}.csv"
    qf=queue.open("a",newline=""); uf=usage.open("a",newline="")
    qw=csv.writer(qf); uw=csv.writer(uf)
    running={}
    t0=time.time()
    print(json.dumps(dict(stage=stage,pending=len(pending),total=len(m["fits"]),code_hash=ch)),flush=True)
    while pending or running:
        for fid,(proc,started) in list(running.items()):
            rc=proc.poll()
            if rc is not None:
                has=(Path(fits_root)/fid/"record.json").exists()
                qw.writerow([time.time(),fid,"end",rc,int(has),time.time()-started])
                qf.flush(); del running[fid]
        bus=bus_workers()
        # The existing bus runner has priority. An active bus tuning queue
        # prevents any new fleet admission, avoiding an unshared-ledger race.
        bus_runner=subprocess.run(["pgrep","-f","experiments.fleet_capacity_one.tuning.runner"],
                                  stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
        budget=0 if bus_runner or bus else worker_budget(len(running),CAP,CTRL_RESERVATION,FIT_MAX)
        while pending and len(running)<budget:
            spec=pending.pop(0)
            fid=spec["fit_id"]
            env=dict(os.environ,OMP_NUM_THREADS="1",MKL_NUM_THREADS="1",
                     OPENBLAS_NUM_THREADS="1",NUMEXPR_NUM_THREADS="1",
                     PYTHONHASHSEED="0",CUDA_VISIBLE_DEVICES="")
            logfile=(led/(fid+".log")).open("a")
            module="experiments.fleet_r1literal.tuning_run_refcode" if stage=="FR" else "experiments.fleet_r1literal.tuning_run_fit"
            cmd=["nice","-n","10",PY,"-m",module,
                 manifest,fid,fits_root,MARK]
            proc=subprocess.Popen(cmd,stdout=logfile,stderr=subprocess.STDOUT,env=env)
            running[fid]=(proc,time.time())
            qw.writerow([time.time(),fid,"start",proc.pid,bus,budget])
            qf.flush()
        uw.writerow([time.time(),stage,len(running),len(pending),bus,budget,CTRL_RESERVATION])
        uf.flush()
        if pending or running: time.sleep(15)
    statuses={}
    core=0.0
    missing=[]
    for s in m["fits"]:
        p=Path(fits_root)/s["fit_id"]/"record.json"
        if not p.exists():
            missing.append(s["fit_id"]);continue
        r=json.loads(p.read_text())
        statuses[r["fit_status"]]=statuses.get(r["fit_status"],0)+1
        core+=r["time"]["total"]
    result=dict(stage=stage,scheduled=len(m["fits"]),records=len(m["fits"])-len(missing),
                missing=missing,statuses=statuses,active_fit_core_seconds=core,
                elapsed_wall_seconds=time.time()-t0,manifest_sha256=hashfile(manifest),
                code_hash=ch,thread_cap=CAP,max_fleet_workers=FIT_MAX,
                controller_reservation=CTRL_RESERVATION)
    (led/f"accounting_{stage}.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result),flush=True)
    if missing: raise RuntimeError("missing fit records")

if __name__=="__main__":
    main(*sys.argv[1:4])
