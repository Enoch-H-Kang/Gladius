"""Synthetic pre-truth-release checks for the U2 decision implementation."""
import unittest

from . import u2_decision as d

AMENDMENT_SHA256 = d.AMENDMENT_SHA256

class SyntheticU2Checks(unittest.TestCase):
    def test_disjoint_finalist_unions(self):
        x=d.confirmation_sets(["b1","shared"],["f1","shared"])
        self.assertEqual(x["B3"],["b1","shared"])
        self.assertEqual(x["B3x"],["f1"])
        self.assertEqual(x["F3"],["b1","f1","shared"])

    def test_unchanged_c_bus_domain(self):
        x=d.confirmation_sets(["b","shared"],["f","shared"])
        self.assertEqual(x["c_bus_domain"],x["B3"])
        self.assertNotIn("f",x["c_bus_domain"])

    def test_persistent_rescues(self):
        x=d.confirmation_sets(["b","r"],["f","r"],rescue=["r"])
        self.assertEqual(x["excluded_rescue"],["r"])
        self.assertIn("r",x["F3"])

    def test_identical_B3_B3x_streams(self):
        self.assertEqual(d.stream_seed("bus","B3",7200,1,"qinit"),
                         d.stream_seed("bus","B3x",7200,1,"qinit"))

    def test_fleet_ten_of_ten(self):
        self.assertTrue(d.fit_count_ok("F3",["ok"]*10))
        self.assertFalse(d.fit_count_ok("F3",["ok"]*9+["anchor_fail"]))

    def test_failed_initialization_dispersion_stop(self):
        with self.assertRaisesRegex(d.Stop,"FAILED_FIT_DISPERSION"):
            d.seed_dispersion([[0.1,None],[0.2,0.3]])
        self.assertEqual(d.paired_log_score(None,1.0,False),__import__("math").log(10))

    def test_single_dataset_stop(self):
        with self.assertRaisesRegex(d.Stop,"SEED_DISPERSION_UNDEFINED"):
            d.seed_dispersion([[0.1,0.2]])

    def test_invalid_references(self):
        for v,reason in ((None,"REFERENCE_FAILED"),(0,"REFERENCE_UNDEFINED"),(-1,"REFERENCE_UNDEFINED")):
            with self.subTest(v=v),self.assertRaisesRegex(d.Stop,reason):
                d.paired_log_score(1.0,v)
        with self.assertRaisesRegex(d.Stop,"REFERENCE_SELECTION_UNRESOLVED"):
            d.require_p0star({"map_sha256":"x"})

    def test_literal_zero_sd_inequality(self):
        self.assertTrue(d.dispersion_pass(0,0))
        self.assertFalse(d.dispersion_pass(.00001,0))

    def test_unsupported_compute_prefix(self):
        with self.assertRaisesRegex(d.Stop,"COMPUTE_SUPPORT_MISSING"):
            d.compute_cutoff("B1",10,5)
        self.assertEqual(d.compute_cutoff("F1",10,5),9090)

    def test_heterogeneous_locks_identical_design_key(self):
        x=dict(loss="none",k=10,opt="adamw",c_be=1,batch=256,bias="anchor",lr_q=.001,rho=1,horizon=50000,width=10)
        y=dict(x,lr_q=.0003,rho=3,horizon=20000,width=64,N=100000)
        self.assertTrue(d.same_design_different_locks(x,y))
        self.assertNotEqual(d.canonical_design(x),d.canonical_design(dict(y,k=5)))

    def test_manifest_derived_counts(self):
        m=dict(n_fits=2,fits=[{},{}])
        self.assertEqual(d.required_counts(["b","shared"],["f","shared"],m),
                         dict(B3x=20,F3=120,additional_fleet=40))
        with self.assertRaisesRegex(d.Stop,"HASH_BARRIER"):
            d.required_counts(["b"],["f"],dict(n_fits=2,fits=[{}]))

if __name__ == "__main__":
    unittest.main()
