"""Frozen model parameters and canonical action order."""
import hashlib
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
DGP_PATH = ROOT / "configs/dgp_r1literal.json"
DGP = json.loads(DGP_PATH.read_text())
BETA = float(DGP["beta"])
F = 5
ACTIONS = ((np.arange(32)[:, None] >> np.arange(F)) & 1).astype(np.int8)
U = np.array([b["u"] for b in DGP["buses"]], dtype=np.float64)
V = np.array([b["v"] for b in DGP["buses"]], dtype=np.float64)
KCOST = np.array([b["Kcost"] for b in DGP["buses"]], dtype=np.float64)
D = np.array([b["d"] for b in DGP["buses"]], dtype=np.float64)
MU = np.array([b["mu"] for b in DGP["buses"]], dtype=np.float64)
ACTION_PATH = ROOT / "configs/actions_r1literal.json"

def write_actions():
    ACTION_PATH.write_text(json.dumps({"encoding": "bus_1_least_significant", "actions": ACTIONS.tolist()}, sort_keys=True, separators=(",", ":")) + "\n")

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def encode(bits):
    b = np.asarray(bits, dtype=np.int64)
    if b.shape[-1] != F or np.any((b != 0) & (b != 1)):
        raise ValueError("expected five binary action bits")
    return np.sum(b * (1 << np.arange(F)), axis=-1).astype(np.int64)

def decode(a):
    a = np.asarray(a, dtype=np.int64)
    if np.any((a < 0) | (a >= 32)):
        raise ValueError("action outside 0..31")
    return ((a[..., None] >> np.arange(F)) & 1).astype(np.int8)
