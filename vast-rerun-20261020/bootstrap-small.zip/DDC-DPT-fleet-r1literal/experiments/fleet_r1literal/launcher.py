"""Fail-closed fleet admission. Bus study launchers are independent."""
import json
from pathlib import Path
from .params import DGP_PATH,ACTION_PATH,sha256

PROTOCOL_PATH=Path(__file__).resolve().parent/"configs/protocol_r1literal.md"

def admit_fleet(data_meta,reference_manifest,pilot_record,protocol_sha256):
    if data_meta.get("arm")!="independent_r1literal":
        raise ValueError("wrong arm")
    for field,actual in (("dgp_sha256",sha256(DGP_PATH)),
                         ("action_sha256",sha256(ACTION_PATH))):
        if data_meta.get(field)!=actual or reference_manifest.get(field)!=actual:
            raise ValueError(field+" mismatch")
    if protocol_sha256!=sha256(PROTOCOL_PATH) or data_meta.get("protocol_sha256")!=protocol_sha256:
        raise ValueError("protocol hash mismatch")
    if reference_manifest.get("status")!="certified":
        raise ValueError("reference not certified")
    if data_meta.get("reference_sha256")!=reference_manifest.get("artifact_sha256"):
        raise ValueError("reference hash mismatch")
    if pilot_record.get("status")!="accepted":
        raise ValueError("pilot acceptance unresolved")
    return True
