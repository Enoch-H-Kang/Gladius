#!/bin/bash
set -euo pipefail
cd "$HOME/DDC-DPT-fleet-r1literal"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONHASHSEED=0 CUDA_VISIBLE_DEVICES=""
for i in $(seq 1 100000); do
  if test -f experiments/fleet_r1literal/artifacts/logs/D_ref_frozen.DONE; then break; fi
  sleep 30
done
test -f experiments/fleet_r1literal/artifacts/logs/D_ref_frozen.DONE
~/miniconda3/envs/gym/bin/python -u -m experiments.fleet_r1literal.frozen_headline_pipeline run
printf '%s\n' "$(date -u +%FT%TZ) headline complete" > experiments/fleet_r1literal/artifacts/logs/H_frozen.DONE
