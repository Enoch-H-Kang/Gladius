"""U2 decision primitives. Development inputs only; no truth files are imported."""
import hashlib
import json
import math
import statistics

AMENDMENT_SHA256 = "215a24fb439a0dd950ea0fce33f0ff147bca9dd8edfee4d884bf4ee5a6f3f25c"
CAP = {"B1": 20000, "B2": 50000, "B3": 50000, "B3x": 50000,
       "F1": 50000, "F2": 50000, "F3": 50000}

class Stop(RuntimeError):
    def __init__(self, reason):
        self.reason = reason
        super().__init__("STOP(" + reason + ")")

def canonical_design(config):
    """Identity excludes rates, rho, horizon, width, N and random seeds."""
    loss = {"none": "signed", "signed": "signed", "clip0": "clip0", "abs": "abs"}[config["loss"]]
    c_be = format(float(config["c_be"]), ".15g")
    fields = dict(L=loss, k=int(config["k"]), trunk="separate",
                  optimizer_family=config["opt"], c_BE=c_be,
                  B=int(config["batch"]), bias_rule=config["bias"],
                  stopping_policy="obs_lock_v1")
    encoded = json.dumps(fields, sort_keys=True, separators=(",", ":"),
                         allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()

def confirmation_sets(bus, fleet, rescue=()):
    b, f = set(bus), set(fleet)
    if len(b) != len(bus) or len(f) != len(fleet):
        raise ValueError("duplicate finalist design key")
    c = b | f
    return dict(B3=sorted(b), B3x=sorted(f-b), F3=sorted(c),
                c_bus_domain=sorted(b), excluded_rescue=sorted(c & set(rescue)))

def stream_seed(testbed, stage, data_id, init_index, stream_name):
    stage = "B3" if stage == "B3x" else stage
    payload = f"20261018|{testbed}|{stage}|{data_id}|{init_index}|{stream_name}"
    return int.from_bytes(hashlib.sha256(payload.encode()).digest()[:8], "big") % (2**63-1)

def fit_count_ok(stage, statuses):
    n = sum(s == "ok" for s in statuses)
    if stage == "F3":
        return len(statuses) == 10 and n == 10
    if stage in ("B3", "B3x"):
        return len(statuses) == 10 and n >= 9
    return bool(statuses) and n == len(statuses)

def seed_dispersion(seed_log_metrics, reference=False):
    """Each element is the complete list of measured log(M) for one data seed."""
    if len(seed_log_metrics) < 2:
        raise Stop("SEED_DISPERSION_UNDEFINED")
    if any(not x or any(v is None or not math.isfinite(v) for v in x)
           for x in seed_log_metrics):
        raise Stop("REFERENCE_COMPARISON_UNDEFINED" if reference else "FAILED_FIT_DISPERSION")
    return statistics.stdev(statistics.mean(x) for x in seed_log_metrics)

def dispersion_pass(candidate_sd, reference_sd):
    if not all(math.isfinite(x) and x >= 0 for x in (candidate_sd, reference_sd)):
        raise Stop("SEED_DISPERSION_UNDEFINED")
    return candidate_sd <= 1.5 * reference_sd

def paired_log_score(candidate_m, reference_m, candidate_ok=True):
    if reference_m is None:
        raise Stop("REFERENCE_FAILED")
    if not math.isfinite(reference_m) or reference_m <= 0:
        raise Stop("REFERENCE_UNDEFINED")
    if not candidate_ok:
        return math.log(10)
    if candidate_m == 0:
        raise Stop("ZERO_LOG_METRIC")
    if candidate_m is None or not math.isfinite(candidate_m) or candidate_m < 0:
        raise Stop("EVALUATOR_UNDEFINED")
    return math.log(candidate_m / reference_m)

def nll_benchmark(candidates):
    vals = [x["median_nll"] for x in candidates if x["fit_count_ok"]
            and x.get("median_nll") is not None and math.isfinite(x["median_nll"])]
    if not vals:
        raise Stop("NLL_BENCHMARK_UNDEFINED")
    return min(vals)

def compute_cutoff(stage, k, timing_ratio):
    h = CAP[stage]
    if not math.isfinite(timing_ratio) or timing_ratio <= 0:
        raise Stop("REFERENCE_COMPARISON_UNDEFINED")
    if timing_ratio <= 4:
        return h
    t = (2*h) // (int(k)+1)
    if t < 5000:
        raise Stop("COMPUTE_SUPPORT_MISSING")
    return t

def rate_donor(donors, loss, k, width, optimizer):
    matches = [x for x in donors if x["loss"] == loss and x["k"] == k
               and x.get("width", width) == width and x["optimizer"] == optimizer
               and x["all_eligible"]]
    if not matches:
        raise Stop("RATE_DONOR_MISSING")
    return min(matches, key=lambda x: (x["median_nll"], x["median_A"],
                x["horizon"], x["rho"] != 1, x["lr_q"], x["id"]))

def require_p0star(provenance):
    if not provenance or not provenance.get("noncircular_adopted_rule") or not provenance.get("map_sha256"):
        raise Stop("REFERENCE_SELECTION_UNRESOLVED")
    return provenance["map_sha256"]

def required_counts(bus_keys, fleet_keys, manifest, reference=0, lock=0, audit=0):
    sets = confirmation_sets(bus_keys, fleet_keys)
    if int(manifest["n_fits"]) != len(manifest["fits"]):
        raise Stop("HASH_BARRIER")
    return dict(B3x=20*len(sets["B3x"]), F3=40*len(sets["F3"]),
                additional_fleet=40*len(set(bus_keys)-set(fleet_keys))+reference+lock+audit)

def same_design_different_locks(config_a, config_b):
    return canonical_design(config_a) == canonical_design(config_b)
