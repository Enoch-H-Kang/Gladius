"""Five independent mileage coordinates; streams are supplied by the caller."""
import numpy as np
from .params import F, encode
from .texp import draw
from .rewards import reward, r0

def step(s, bits, increments):
    s, bits, increments = map(np.asarray, (s, bits, increments))
    if s.shape != bits.shape or s.shape != increments.shape or s.shape[-1] != F:
        raise ValueError("shape mismatch")
    return np.where(bits == 1, 0., np.minimum(1., s+increments)).astype(np.float64)

def generate_chains(nchains, horizon, component_query, streams, burn=0):
    """Policy samples independent binary logits; final successor is retained."""
    starts, action_rngs, increment_rngs = streams
    s = starts.random((nchains, F), dtype=np.float64)*.5
    states = np.empty((nchains, horizon, F), dtype=np.float64)
    succ = np.empty_like(states)
    actions = np.empty((nchains, horizon), dtype=np.int8)
    for t in range(horizon+burn):
        bits = np.empty((nchains, F), dtype=np.int8)
        inc = np.empty((nchains, F), dtype=np.float64)
        for f in range(F):
            q0, q1, _, _ = component_query(f, s[:, f])
            p1 = 1/(1+np.exp(q0-q1))
            bits[:, f] = (action_rngs[f].random(nchains) < p1)
            inc[:, f] = draw(increment_rngs[f].random(nchains), f)
        sp = step(s, bits, inc)
        if t >= burn:
            j = t-burn
            states[:, j] = s
            succ[:, j] = sp
            actions[:, j] = encode(bits)
        s = sp
    return {"s":states,"sp":succ,"a":actions,"r0":r0(states)}
