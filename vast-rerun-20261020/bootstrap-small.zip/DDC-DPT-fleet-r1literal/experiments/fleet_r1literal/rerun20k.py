"""Detached, restartable 20,000-pass queue for frozen fleet, S2, and coupled fits."""
import hashlib
import importlib.util
import json
import math
import os
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np
import torch

from . import frozen_extension as ext
from .data_io import load_split
from .rerun20k_train import fit

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
S2ROOT = Path('/home/ehwkang/DDC-DPT-fleet-s2/experiments/fleet_commonshock')
OUT = ROOT / 'results/rerun20k'
FITS = OUT / 'fits'
STATUS = OUT / 'STATUS.json'
SUITES = {
    'FL': ROOT/'results/frozen_followups/manifest_FL_followup.json',
    'headline': ROOT/'results/headline_frozen/manifest.json',
    'matrix': ROOT/'results/frozen_followups/manifest_M1_followup.json',
    'S2': S2ROOT/'results/manifest_S2.json',
    'EL': ROOT/'results/frozen_followups/manifest_EL_followup.json',
    'EX': ROOT/'results/frozen_followups/manifest_EX_followup.json',
}
MAX_WORKERS = 40  # shared 44-thread ceiling is enforced by worker_budget


def bus_workers():
    count=0
    for path in Path('/proc').glob('[0-9]*/cmdline'):
        try:
            args=path.read_bytes().split(b'\0')
            count+=b'experiments.fleet_capacity_one.bus_rerun.epochs20000_worker' in args
        except (OSError,PermissionError): pass
    return count


class ExistingProcess:
    def __init__(self,pid): self.pid=pid
    def poll(self):
        try:
            fields=Path(f'/proc/{self.pid}/stat').read_text().split()
            return None if fields[2]!='Z' else 1
        except OSError: return 1


def adoptable(pid,fit_id):
    try:
        args=Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
        return b'experiments.fleet_r1literal.rerun20k' in args and fit_id.encode() in args
    except OSError: return False


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n')
    os.replace(tmp, path)


def s2_fit_module():
    spec = importlib.util.spec_from_file_location('s2_rerun_fit', S2ROOT/'fit.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def queue():
    items=[]
    for suite, path in SUITES.items():
        m=json.loads(path.read_text())
        assert len(m['fits'])=={'FL':108,'headline':40,'matrix':200,'S2':80,'EL':54,'EX':45}[suite]
        for spec in m['fits']:
            c=spec['config']; n=spec['n_chains']; train=n*80
            batch=min(int(c['batch']),math.ceil(train/8))
            steps=math.ceil(20000*train/batch)
            cadence=max(1,train//batch)
            items.append(dict(suite=suite,fit_id=spec['fit_id'],steps=steps,
                              cadence=cadence,train_transitions=train,batch_eff=batch,
                              manifest=str(path),manifest_sha256=sha(path)))
    ids=[x['fit_id'] for x in items]
    assert len(items)==527 and len(set(ids))==527
    return sorted(items,key=lambda x:(x['steps'],x['suite'],x['fit_id']))


def panel(suite, arm=None, data=None, pool_path=None):
    if suite in ('headline','matrix','FL'):
        path=ROOT/('artifacts/eval/screen_uniform_truth.npz' if suite=='FL' else 'artifacts/eval/E2_truth.npz')
        with np.load(path,allow_pickle=False) as z:
            return dict(states=z['states'],reward=z['reward']),path
    if suite=='S2':
        path=S2ROOT/'artifacts/eval/E2_truth.npz'
        with np.load(path,allow_pickle=False) as z:
            states=z['states'] if arm=='omit' else np.column_stack([z['states'],z['z']])
            return dict(states=states,reward=z['reward']),path
    path=ext.SOURCE/'artifacts/oracle/evalsets.npz'
    if suite=='EL':
        states=np.asarray(data['val']['s'],dtype=np.float32)
        path=pool_path
    else:
        with np.load(path,allow_pickle=False) as z: states=z['occ']
    from experiments.fleet_capacity_one.fleet.params import Params
    from experiments.fleet_capacity_one.fleet.rewards import reward_all
    p=Params.from_json(ext.source_paths()['dgp'])
    return dict(states=states,reward=reward_all(states,p)),path


def lock_path(stage):
    return OUT/f'locks_{stage}.json'


def class_name(spec):
    return spec.get('architecture',spec['config']['architecture'])


def choose_locks(stage, items):
    """Rank six rate pairs by development validation observables only."""
    slots=[x for x in items if x['suite']==stage]
    if not all((FITS/stage/x['fit_id']/'DONE.json').exists() for x in slots): return False
    if lock_path(stage).exists(): return True
    manifest=json.loads(SUITES[stage].read_text())
    choices={}; unavailable={}
    for arch in sorted(set(s['architecture'] for s in manifest['fits'])):
        candidates=[]
        for lr in (1e-4,3e-4,1e-3):
            for rho in (1,3):
                specs=[s for s in manifest['fits'] if s['architecture']==arch and
                       s['config']['lr_q']==lr and s['config']['rho']==rho]
                assert len(specs)==3
                rec=[json.loads((FITS/stage/s['fit_id']/'record.json').read_text()) for s in specs]
                val=[r.get('best_validation') or {} for r in rec]
                if not all(r.get('fit_status')=='complete' and v.get('finite') and
                           math.isfinite(v.get('nll',float('nan'))) and
                           math.isfinite(v.get('anchor_rmse',float('nan')))
                           for r,v in zip(rec,val)): continue
                candidates.append(dict(lr_q=lr,rho=rho,median_nll=sorted(v['nll'] for v in val)[1],
                                       median_anchor=sorted(v['anchor_rmse'] for v in val)[1],
                                       fit_ids=[s['fit_id'] for s in specs],
                                       anchor_errors={str(s['data_id']):v['anchor_rmse'] for s,v in zip(specs,val)}))
        if not candidates:
            unavailable[arch]='no complete three-block rate pair with finite validation observables'
            continue
        floor=min(c['median_nll'] for c in candidates)
        tied=[c for c in candidates if c['median_nll']<=floor+.001]
        choices[arch]=min(tied,key=lambda c:(c['median_anchor'],c['rho']!=1,c['lr_q']))
    atomic(lock_path(stage),dict(stage=stage,choices=choices,unavailable=unavailable,
         rule='minimum three-block median validation NLL within 0.001; tie by median anchor, rho=1, lower rate; anchor diagnostic only',
         source_manifest_sha256=sha(SUITES[stage]),created_unix=time.time()))
    return True


def load_data(suite,spec,m):
    if suite in ('headline','matrix','FL'):
        path=ROOT/spec['pool']
        if sha(path)!=spec['pool_sha256']: raise ValueError('pool hash mismatch')
        dev=json.loads((ROOT/'artifacts/data/development_freeze_manifest.json').read_text())
        return load_split(path,spec['n_chains'],dev['reference_sha256'])
    if suite=='S2':
        mod=s2_fit_module();path=S2ROOT/spec['pool']
        return mod.load_split(path,spec['arm'],spec['n_chains'],spec['pool_sha256'])
    return ext.load_data(spec,m['source_hashes'])


def worker(item,pilot=False):
    torch.set_num_threads(1)
    try: torch.set_num_interop_threads(1)
    except RuntimeError: pass
    suite=item['suite'];fit_id=item['fit_id']
    m=json.loads(Path(item['manifest']).read_text())
    if sha(item['manifest'])!=item['manifest_sha256']: raise ValueError('manifest changed')
    spec=next(s for s in m['fits'] if s['fit_id']==fit_id)
    out=(OUT/'pilot'/fit_id) if pilot else FITS/suite/fit_id
    out.mkdir(parents=True,exist_ok=True)
    began=time.time()
    try:
        data=load_data(suite,spec,m)
        truth,ppath=panel(suite,spec.get('arm'),data,ROOT/spec['pool'] if suite=='EL' else None)
        cfg={k:v for k,v in spec['config'].items() if k!='N'}
        cfg['loss']='none' if cfg['loss']=='signed' else cfg['loss']
        applied_lock=None
        if suite in ('headline','matrix','EX') and not pilot:
            stage='EL' if suite=='EX' else 'FL'
            locks=json.loads(lock_path(stage).read_text())
            arch=class_name(spec)
            if arch not in locks['choices']:
                raise RuntimeError(f'{stage} rate lock unavailable for {arch}: {locks["unavailable"].get(arch)}')
            applied_lock=locks['choices'][arch]
            cfg['lr_q']=applied_lock['lr_q'];cfg['rho']=applied_lock['rho']
        cfg['cap_q']=32 if pilot else item['steps']
        cadence=item['cadence']
        kw={}
        if suite in ('headline','matrix','FL'):
            from .models import factory,initialize
            kw=dict(model_factory=factory,model_initializer=initialize)
        elif suite=='S2':
            mod=s2_fit_module()
            from .models import initialize
            kw=dict(model_factory=mod.factory,model_initializer=initialize)
        else: kw=dict(model_factory=ext.model_factory,model_initializer=ext.model_init)
        result=fit(data,cfg,spec['seeds'],truth,cadence,ckpt_dir=out,
                   progress_path=out/'progress.json',**kw)
        result.update(panel_sha256=sha(ppath),panel_path=str(ppath),
                      original_config=spec['config'],pool_sha256=spec['pool_sha256'],
                      n_train_chains=data['n_train_chains'],n_val_chains=data['n_val_chains'],
                      applied_lock=applied_lock)
    except BaseException as e:
        import traceback
        result=dict(fit_status='process_failure',error=f'{type(e).__name__}: {e}',traceback=traceback.format_exc())
    result.update(suite=suite,fit_id=fit_id,source_manifest_sha256=item['manifest_sha256'],
                  scheduled_steps=item['steps'],scheduled_cadence=item['cadence'],
                  selection_panel=('development_uniform' if suite=='FL' else
                                   'development_validation_states' if suite=='EL' else
                                   'E2' if suite in ('headline','matrix','S2') else 'K31_occ'),
                  start_unix=began,end_unix=time.time(),pilot=pilot)
    atomic(out/'record.json',result)
    atomic(out/'DONE.json',dict(fit_id=fit_id,suite=suite,status=result['fit_status'],
                                record_sha256=sha(out/'record.json'),finished_unix=time.time()))
    print(json.dumps(dict(fit_id=fit_id,status=result['fit_status'],best_step=result.get('best_step'),
                          evaluations=result.get('evaluations'))),flush=True)
    return 0 if result['fit_status']=='complete' else 2


def snapshot(items,active,started,phase='running'):
    suites={}
    for suite in SUITES:
        slots=[x for x in items if x['suite']==suite]
        done=[];failed=0
        for x in slots:
            p=FITS/suite/x['fit_id']/'DONE.json'
            if p.exists():
                try:
                    d=json.loads(p.read_text()); done.append(x)
                    failed+=d['status']!='complete'
                except Exception: pass
        suites[suite]=dict(scheduled=len(slots),started=sum(x['fit_id'] in started for x in slots),
                           complete=len(done)-failed,failed=failed,
                           pending=len(slots)-len(done)-sum(x['fit_id'] in active for x in slots))
        atomic(OUT/f'accounting_{suite}.json',dict(suite=suite,**suites[suite],
               terminal=len(done),missing=[x['fit_id'] for x in slots if x not in done]))
        if len(done)==len(slots): atomic(OUT/f'{suite}.DONE.json',dict(suite=suite,terminal=len(done),failed=failed,finished_unix=time.time()))
    running=[]
    for fid,(proc,x,t0) in active.items():
        p=FITS/x['suite']/fid/'progress.json'
        try: progress=json.loads(p.read_text())
        except Exception: progress={}
        running.append(dict(fit_id=fid,suite=x['suite'],N=x['train_transitions']*5//4,
                            steps=x['steps'],elapsed_seconds=round(time.time()-t0),
                            progress=progress))
    running.sort(key=lambda x:(-x['steps'],-x['elapsed_seconds']))
    atomic(STATUS,dict(state=phase,updated_unix=time.time(),queue_size=len(items),
                       workers_active=len(active),bus_workers=bus_workers(),
                       workers_cap_total=MAX_WORKERS,
                       suites=suites,longest_running_cells=running[:12],
                       longest_cells=sorted((dict(suite=x['suite'],fit_id=x['fit_id'],
                                   train_transitions=x['train_transitions'],steps=x['steps'])
                                   for x in items),key=lambda x:-x['steps'])[:12]))


def run():
    from .cpu_budget import worker_budget
    import fcntl
    OUT.mkdir(parents=True,exist_ok=True)
    lock=(OUT/'controller.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    items=queue();atomic(OUT/'queue.json',items)
    pending=[];started=set();active={}
    for x in items:
        p=FITS/x['suite']/x['fit_id']/'DONE.json'
        if p.exists():
            d=json.loads(p.read_text())
            assert d['fit_id']==x['fit_id']
            started.add(x['fit_id'])
        else:
            runfile=FITS/x['suite']/x['fit_id']/'RUNNING.json'
            try: run=json.loads(runfile.read_text())
            except (OSError,ValueError): run={}
            pid=run.get('pid')
            if isinstance(pid,int) and adoptable(pid,x['fit_id']):
                active[x['fit_id']]=(ExistingProcess(pid),x,run['started_unix'])
                started.add(x['fit_id'])
            else: pending.append(x)
    snapshot(items,active,started)
    while pending or active:
        for fid,(proc,x,t0) in list(active.items()):
            if proc.poll() is not None:
                done=FITS/x['suite']/fid/'DONE.json'
                if not done.exists():
                    record=FITS/x['suite']/fid/'record.json'
                    atomic(record,dict(fit_id=fid,suite=x['suite'],fit_status='process_failure',
                                       error=f'worker exited {proc.returncode} without DONE marker',
                                       scheduled_steps=x['steps'],scheduled_cadence=x['cadence'],
                                       source_manifest_sha256=x['manifest_sha256']))
                    atomic(done,dict(fit_id=fid,suite=x['suite'],status='process_failure',
                                     record_sha256=sha(record),finished_unix=time.time()))
                del active[fid]
        for stage in ('FL','EL'):
            choose_locks(stage,items)
        # Measure actual baker load, reserve three cores, and leave space for bus workers.
        admit=min(MAX_WORKERS-bus_workers(),
                  worker_budget(len(active),cap=44,reserve=3,max_workers=MAX_WORKERS))
        while pending and len(active)<admit:
            index=next((i for i,x in enumerate(pending)
                        if x['suite'] not in ('headline','matrix','EX') or
                        lock_path('EL' if x['suite']=='EX' else 'FL').exists()),None)
            if index is None: break
            x=pending.pop(index);fid=x['fit_id'];out=FITS/x['suite']/fid
            out.mkdir(parents=True,exist_ok=True)
            env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
                     NUMEXPR_NUM_THREADS='1',CUDA_VISIBLE_DEVICES='',PYTHONHASHSEED='0')
            log=(out/'worker.log').open('a')
            proc=subprocess.Popen(['nice','-n','10',sys.executable,'-u','-m',
                 'experiments.fleet_r1literal.rerun20k','worker',x['fit_id']],
                 cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            atomic(out/'RUNNING.json',dict(pid=proc.pid,fit_id=fid,started_unix=time.time()))
            active[fid]=(proc,x,time.time());started.add(fid)
        snapshot(items,active,started)
        if pending or active:time.sleep(15)
    snapshot(items,active,started,'terminal')
    atomic(OUT/'ALL.DONE.json',dict(terminal=527,finished_unix=time.time()))


def main():
    mode=sys.argv[1]
    if mode=='pilot':
        x=next(x for x in queue() if x['suite']=='FL')
        sys.exit(worker(x,pilot=True))
    if mode=='run': return run()
    if mode=='worker':
        fid=sys.argv[2];x=next(x for x in queue() if x['fit_id']==fid)
        sys.exit(worker(x))
    if mode=='check':
        print(json.dumps(dict(queue_size=len(queue()),sizes=[dict(suite=k[0],train_transitions=k[1],steps=k[2],fits=v) for k,v in sorted(Counter((x['suite'],x['train_transitions'],x['steps']) for x in queue()).items())])))
        return
    raise ValueError(sys.argv)

if __name__=='__main__':main()
