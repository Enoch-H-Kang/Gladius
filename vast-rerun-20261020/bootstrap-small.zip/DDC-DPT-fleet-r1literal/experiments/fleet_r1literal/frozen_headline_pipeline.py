"""Author-frozen R1-literal headline launch, gated by development evidence."""
import csv
import fcntl
import hashlib
import json
import os
import subprocess
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ART = ROOT / 'artifacts'
LOG = ART / 'logs'
RESULT = ROOT / 'results' / 'headline_frozen'
AMENDMENT = RESULT / 'feasibility_amendment.json'
FREEZE = ROOT / 'protocol' / 'common_protocol_freeze.json'
HEAD = ART / 'data' / 'headline_freeze_manifest.json'
LEDGER = ROOT / 'results' / 'tuning' / 'ledger'
FITS = ART / 'headline_frozen' / 'fits'
PY = sys.executable
CAP = 36  # one-thread fit processes; at least eight of 44 project tokens remain free
STREAMS = ('qinit', 'zinit', 'ce', 'anchor', 'eval', 'extrazeta')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def atomic(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, sort_keys=True, indent=2, allow_nan=False) + '\n')
    os.replace(tmp, path)

def specs():
    frozen = json.loads(FREEZE.read_text())
    assert sha(FREEZE) == 'dcba37006a1ef6747671f03fc4e9a88f388ad2f4261086c45a32656788d7afba'
    assert sha(HEAD) == frozen['headline_manifest_sha256']
    head = json.loads(HEAD.read_text())
    assert head['mode'] == 'headline' and head['status'] == 'frozen' and len(head['pools']) == 10
    d = frozen['design']
    assert (d['loss'], d['k'], d['lr_q'], d['rho'], d['batch'], d['horizon'], d['architecture']) == ('signed', 10, .001, 1., 1024, 50000, 'mlp2x10')
    from .freeze_data import seed
    from .tuning_manifest import config_id
    cfg = dict(N=0, anchor_tol=.1, architecture='mlp2x10', batch=1024, beta=.95,
               bias='anchor', c_be=1., cap_q=50000, depth=2, elig_start=5000,
               grad_clip=1., k=10, loss='signed', lr_decay=10000., lr_q=.001,
               opt='adamw', rho=1., val_every=500, wd=.0001, width=10)
    pools = {p['data_id']: p for p in head['pools']}
    assert sorted(pools) == list(range(1000, 1010))
    fits = []
    for data_id in sorted(pools):
        pool = pools[data_id]
        assert pool['role'] == 'headline' and pool['stage'] == 'headline'
        for n in (1000, 5000, 20000, 100000):
            c = dict(cfg, N=n)
            fit_id = f'H_frozen_{data_id}_{n}'
            fits.append(dict(fit_id=fit_id, config=c, config_id=config_id(c),
                             pool=pool['path'], pool_sha256=pool['sha256'],
                             data_id=data_id, n_chains=n//100,
                             seeds={s: seed('headline', data_id, s, 0) for s in STREAMS},
                             horizons=[10000, 20000, 50000]))
    body = json.dumps(fits, sort_keys=True, separators=(',', ':')).encode()
    return dict(stage='headline_frozen', n_fits=len(fits), sha256=hashlib.sha256(body).hexdigest(),
                freeze_sha256=sha(FREEZE), headline_manifest_sha256=sha(HEAD),
                design=d, fits=fits)

def stage_record(stage, spec):
    return ROOT / 'artifacts' / 'tuning' / f'fits_{stage}_frozen' / spec['fit_id'] / 'record.json'

def reference_specs():
    """Paired signed/k=1 D reference slots required by the frozen spec."""
    from .tuning_manifest import config_id
    base = json.loads((ROOT / 'results/tuning/manifests/manifest_D_frozen.json').read_text())
    fits = []
    for original in base['fits']:
        if original['config']['width'] != 64 or original['config']['N'] != 100000:
            continue
        spec = json.loads(json.dumps(original))
        spec['config']['k'] = 1
        spec['config_id'] = config_id(spec['config'])
        spec['fit_id'] = f'D_ref_signed_k1_{spec["data_id"]}_i0'
        spec['family'] = 'signed_k1_reference'
        spec['row'] = 'reference'
        fits.append(spec)
    assert len(fits) == 2 and sorted(s['data_id'] for s in fits) == [9700, 9701]
    body = json.dumps(fits, sort_keys=True, separators=(',', ':')).encode()
    return dict(stage='D', n_fits=2, sha256=hashlib.sha256(body).hexdigest(),
                development_manifest_sha256=base['development_manifest_sha256'],
                amendment_sha256=base['amendment_sha256'], frozen_evidence=True,
                freeze_sha256=base['freeze_sha256'], bus_lock_sha256=base['bus_lock_sha256'],
                c_bus_sha256=base['c_bus_sha256'], design_selection='closed_by_author',
                role='compulsory signed/k=1 D reference; no design selection', fits=fits)

def write_reference_manifest():
    manifest = reference_specs()
    path = ROOT / 'results/tuning/manifests/manifest_D_ref_frozen.json'
    if path.exists():
        assert json.loads(path.read_text()) == manifest
    else:
        atomic(path, manifest)
    return manifest

def verify_accounting(stage):
    manpath = ROOT / 'results' / 'tuning' / 'manifests' / f'manifest_{stage}_frozen.json'
    m = json.loads(manpath.read_text())
    done = LOG / f'{stage}_frozen.DONE'
    account = LEDGER / f'accounting_{stage}.json'
    assert done.is_file() and account.is_file(), f'{stage} not DONE'
    a = json.loads(account.read_text())
    assert a['scheduled'] == a['records'] == m['n_fits'] and not a['missing'], f'{stage} incomplete'
    assert a['manifest_sha256'] == sha(manpath)
    from .tuning_run_fit import code_hash
    assert a['code_hash'] == code_hash(stage), f'{stage} code changed'
    for spec in m['fits']:
        p = stage_record(stage, spec)
        assert p.is_file(), f'missing {spec["fit_id"]}'
        rec = json.loads(p.read_text())
        assert rec['fit_id'] == spec['fit_id'] and rec['config_id'] == spec['config_id']
        assert rec['manifest_sha256'] == m['sha256'] and rec['code_hash'] == a['code_hash']
    return m

def eligibility(rec):
    hr = rec.get('horizons', {}).get('50000', {})
    return (rec.get('fit_status') == 'complete' and hr.get('status') == 'ok'
            and hr.get('hash') and hr.get('step') is not None)

def gate():
    from .tuning_evaluate import metrics, panel
    import torch
    torch.set_num_threads(1)
    manifests = {stage: verify_accounting(stage) for stage in ('F1', 'F2', 'F3', 'D', 'D_ref')}
    f1_counts = defaultdict(lambda: {'eligible': 0, 'total': 0})
    for spec in manifests['F1']['fits']:
        key = (spec['config']['width'], spec['config']['N'])
        rec = json.loads(stage_record('F1', spec).read_text())
        f1_counts[key]['total'] += 1
        f1_counts[key]['eligible'] += int(bool(eligibility(rec)))
    assert len(f1_counts) == 4 and all(x['total'] == 3 for x in f1_counts.values())
    f1_pass = all(x['eligible'] == 3 for x in f1_counts.values())
    f3 = json.loads((ROOT / 'results/tuning/manifests/manifest_F3_frozen.json').read_text())
    counts = defaultdict(lambda: {'eligible': 0, 'total': 0})
    for spec in f3['fits']:
        key = (spec['config']['width'], spec['config']['N'])
        rec = json.loads(stage_record('F3', spec).read_text())
        counts[key]['total'] += 1
        counts[key]['eligible'] += int(bool(eligibility(rec)))
    assert len(counts) == 4 and all(x['total'] == 10 for x in counts.values())
    f3_pass = all(x['eligible'] == 10 for x in counts.values())
    d = json.loads((ROOT / 'results/tuning/manifests/manifest_D_frozen.json').read_text())
    truth, panel_sha = panel('D_occupancy')
    dev = json.loads((ART / 'data/development_freeze_manifest.json').read_text())
    assert panel_sha == dev['panels']['D_occupancy']['sha256']
    d_results = []
    for spec in d['fits']:
        if spec['config']['width'] != 64 or spec['config']['N'] != 100000:
            continue
        rec = json.loads(stage_record('D', spec).read_text())
        item = dict(fit_id=spec['fit_id'], data_id=spec['data_id'], eligible=bool(eligibility(rec)), kl=None)
        if item['eligible']:
            p = stage_record('D', spec).parent / 'ckpt_h50000.pt'
            ck = torch.load(p, map_location='cpu', weights_only=False)
            assert ck['hash'] == rec['horizons']['50000']['hash']
            item['kl'] = metrics(ck, truth)['kl']
            item['checkpoint_sha256'] = sha(p)
        d_results.append(item)
    assert len(d_results) == 2 and sorted(x['data_id'] for x in d_results) == [9700, 9701]
    d_pass = all(x['eligible'] and x['kl'] is not None and x['kl'] <= .02 for x in d_results)
    dref_results = []
    for spec in manifests['D_ref']['fits']:
        rec = json.loads(stage_record('D_ref', spec).read_text())
        item = dict(fit_id=spec['fit_id'], data_id=spec['data_id'], eligible=bool(eligibility(rec)), kl=None)
        if item['eligible']:
            p = stage_record('D_ref', spec).parent / 'ckpt_h50000.pt'
            ck = torch.load(p, map_location='cpu', weights_only=False)
            assert ck['hash'] == rec['horizons']['50000']['hash']
            item['kl'] = metrics(ck, truth)['kl']
            item['checkpoint_sha256'] = sha(p)
        dref_results.append(item)
    assert len(dref_results) == 2
    dref_pass = all(x['eligible'] and x['kl'] is not None and x['kl'] <= .02 for x in dref_results)
    report = dict(freeze_sha256=sha(FREEZE),
                  f1={f'w{w}_N{n}': x for (w,n), x in sorted(f1_counts.items())}, f1_pass=f1_pass,
                  f3={f'w{w}_N{n}': x for (w,n), x in sorted(counts.items())},
                  f3_pass=f3_pass, d=d_results, d_panel_sha256=panel_sha,
                  d_kl_limit=.02, d_pass=d_pass, d_reference=dref_results, d_reference_pass=dref_pass,
                  headline_admitted=bool(f1_pass and f3_pass and d_pass and dref_pass),
                  u2_comparative_gates='unresolved; not represented as passed',
                  assessed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    original = RESULT / 'feasibility.json'
    if original.exists():
        recorded = json.loads(original.read_text())
        assert {k: v for k, v in recorded.items() if k != 'assessed_utc'} == {
            k: v for k, v in report.items() if k != 'assessed_utc'}, 'original gate evidence changed'
        return recorded
    atomic(original, report)
    return report

def admission():
    """Validate the author's post-hoc amendment without rewriting the original gate."""
    original = RESULT / 'feasibility.json'
    raw = json.loads(original.read_text())
    amended = json.loads(AMENDMENT.read_text())
    assert amended['original_feasibility_sha256'] == sha(original)
    assert amended['freeze_sha256'] == sha(FREEZE) == raw['freeze_sha256']
    assert amended['author_decision'] == 'planning/final-decisions.md, 2026-10-20 09:20 PDT'
    assert amended['removed_gate_leg'] == 'd_reference_pass'
    assert amended['headline_admitted'] is True
    assert all(raw[x] is True for x in ('f1_pass', 'f3_pass', 'd_pass'))
    assert raw['d_reference_pass'] is False and raw['headline_admitted'] is False
    assert len(raw['d_reference']) == 2 and all(not x['eligible'] and x['kl'] is None for x in raw['d_reference'])
    assert amended['disclosure_required'] is True
    return amended

def worker(manifest_path, fit_id):
    from .data_io import load_split
    from .trainer import fit_fleet
    from .tuning_run_fit import code_hash
    import torch
    torch.set_num_threads(1)
    manifest = json.loads(Path(manifest_path).read_text())
    assert manifest == specs() and fit_id in {s['fit_id'] for s in manifest['fits']}
    admission()
    spec = next(s for s in manifest['fits'] if s['fit_id'] == fit_id)
    pool = ROOT / spec['pool']
    assert 'artifacts/data/headline/' in str(pool) and sha(pool) == spec['pool_sha256']
    head = json.loads(HEAD.read_text())
    data = load_split(pool, spec['n_chains'], head['reference_sha256'])
    out = FITS / fit_id
    out.mkdir(parents=True, exist_ok=True)
    start = time.time()
    result = fit_fleet(data, {k:v for k,v in spec['config'].items() if k != 'N'},
                       spec['seeds'], horizons=spec['horizons'], ckpt_dir=out)
    result.update(fit_id=fit_id, stage='headline_frozen', config_id=spec['config_id'],
                  data_id=spec['data_id'], n_chains=spec['n_chains'],
                  manifest_sha256=manifest['sha256'], freeze_sha256=manifest['freeze_sha256'],
                  headline_manifest_sha256=manifest['headline_manifest_sha256'],
                  data_sha256=spec['pool_sha256'], code_hash=code_hash(),
                  n_train_chains=data['n_train_chains'], n_val_chains=data['n_val_chains'],
                  start_unix=start, end_unix=time.time(), pid=os.getpid(),
                  env_threads={k: os.environ.get(k) for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS')})
    atomic(out / 'record.json', result)
    print(json.dumps({'fit_id':fit_id,'fit_status':result['fit_status']}), flush=True)

def other_fit_workers():
    needles = (b'experiments.fleet_r1literal.tuning_run_fit',
               b'experiments.fleet_capacity_one.tuning.run_fit',
               b'bus_rerun', b'R1LITERAL_FIT_WORKER')
    n = 0
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            cmd = (p / 'cmdline').read_bytes()
        except OSError:
            continue
        if any(x in cmd for x in needles) and b'headline_frozen_pipeline' not in cmd:
            n += 1
    return n

def run():
    from .cpu_budget import worker_budget
    if not AMENDMENT.exists():
        print(json.dumps({'STOP':'FLEET_FEASIBILITY','report':str(RESULT/'feasibility.json')}), flush=True)
        return 2
    admission()
    manifest = specs()
    RESULT.mkdir(parents=True, exist_ok=True)
    mpath = RESULT / 'manifest.json'
    if mpath.exists():
        assert json.loads(mpath.read_text()) == manifest
    else:
        atomic(mpath, manifest)
    FITS.mkdir(parents=True, exist_ok=True)
    lock = (RESULT / 'admission.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    queue_path = RESULT / 'queue.csv'
    queue = queue_path.open('a', newline='')
    writer = csv.writer(queue)
    pending = []
    for spec in manifest['fits']:
        rp = FITS / spec['fit_id'] / 'record.json'
        if rp.exists():
            rec = json.loads(rp.read_text())
            assert rec['fit_id'] == spec['fit_id'] and rec['manifest_sha256'] == manifest['sha256']
        else:
            pending.append(spec)
    active = {}
    while pending or active:
        for fid, proc in list(active.items()):
            rc = proc.poll()
            if rc is not None:
                writer.writerow([time.time(),fid,'end',rc,int((FITS/fid/'record.json').exists())]); queue.flush()
                del active[fid]
        foreign = other_fit_workers()
        budget = worker_budget(len(active), 44, 2, CAP)
        while pending and len(active) < budget:
            spec = pending.pop(0)
            fid = spec['fit_id']
            env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
                       OPENBLAS_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1',
                       PYTHONHASHSEED='0', CUDA_VISIBLE_DEVICES='')
            log = (RESULT / (fid+'.log')).open('a')
            proc = subprocess.Popen([PY, '-u', '-m', 'experiments.fleet_r1literal.frozen_headline_pipeline',
                                     'worker', str(mpath), fid], stdout=log, stderr=subprocess.STDOUT, env=env)
            active[fid] = proc
            writer.writerow([time.time(),fid,'start',proc.pid,foreign,budget]); queue.flush()
        if pending or active:
            time.sleep(15)
    rows = [json.loads((FITS/s['fit_id']/'record.json').read_text()) if (FITS/s['fit_id']/'record.json').exists() else None for s in manifest['fits']]
    account = dict(scheduled=len(rows), records=sum(r is not None for r in rows),
                   statuses=dict(Counter(r['fit_status'] if r else 'missing' for r in rows)),
                   manifest_sha256=sha(mpath), freeze_sha256=sha(FREEZE), max_workers=CAP)
    atomic(RESULT/'accounting.json', account)
    print(json.dumps(account), flush=True)
    return 0 if account['records'] == account['scheduled'] else 3

def main():
    mode = sys.argv[1]
    if mode == 'manifest':
        print(json.dumps(specs()))
    elif mode == 'ref_manifest':
        print(json.dumps(write_reference_manifest()))
    elif mode == 'gate':
        print(json.dumps(gate()))
    elif mode == 'worker':
        worker(Path(sys.argv[2]), sys.argv[3])
    elif mode == 'run':
        sys.exit(run())
    else:
        raise ValueError(mode)

if __name__ == '__main__':
    main()
