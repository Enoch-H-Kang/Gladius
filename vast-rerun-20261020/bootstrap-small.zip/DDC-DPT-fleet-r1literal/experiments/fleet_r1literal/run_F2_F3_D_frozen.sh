#!/bin/bash
set -euo pipefail
cd "$HOME/DDC-DPT-fleet-r1literal"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONHASHSEED=0 CUDA_VISIBLE_DEVICES=""
for i in $(seq 1 100000); do
  if test -f experiments/fleet_r1literal/artifacts/logs/F1_frozen.DONE; then break; fi
  sleep 30
done
test -f experiments/fleet_r1literal/artifacts/logs/F1_frozen.DONE
for stage in F2 F3 D; do
  ~/miniconda3/envs/gym/bin/python -u -m experiments.fleet_r1literal.tuning_runner \
    experiments/fleet_r1literal/results/tuning/manifests/manifest_${stage}_frozen.json \
    experiments/fleet_r1literal/artifacts/tuning/fits_${stage}_frozen \
    experiments/fleet_r1literal/results/tuning/ledger \
    > experiments/fleet_r1literal/artifacts/logs/${stage}_frozen.log 2>&1
  printf "%s\n" "$(date -u +%FT%TZ) ${stage} complete" > experiments/fleet_r1literal/artifacts/logs/${stage}_frozen.DONE
done
