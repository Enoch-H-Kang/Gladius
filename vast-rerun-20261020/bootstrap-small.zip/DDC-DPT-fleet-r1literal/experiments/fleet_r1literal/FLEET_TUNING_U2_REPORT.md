# Fleet tuning U2 stage report

Status at 2026-10-19 07:20 UTC: **STOP before F1 admission**. This is a development-data audit under the provisional adoption in `planning/final-decisions.md`; no common-protocol freeze or headline fit was released.

## Activation and source hashes

The exact copied amendment in `protocol/u2-amendment-merged.md` hashes to `215a24fb439a0dd950ea0fce33f0ff147bca9dd8edfee4d884bf4ee5a6f3f25c` on baker and matches the local planning source. All seven §8 snapshots matched: Codex `2142c2f1…7470c454e`, Claude `9e620046…fa2db5217c`, RC `e7a439f5…8b0875c`, TF `05f8bf28…df7247`, TC `aa08774a…62ab9a`, TL `953dee84…9cab`, and FD's exact pre-adoption byte prefix `63b26f00…821ba8b`. The later FD adoption entry is appended and is not the historical §8 hash. `protocol_changes.md` records provisional authority and all 16 adopted defaults; `protocol/u2_activation.json` records all full digests. The winner formula, DGP constants and tolerances were unchanged.

The bus lock's **canonical embedded hash** was recomputed and matches `3a7749e7354fd1472320f76b2d2b62259847eed682dea6379ecff7f02129619b`; the serialized JSON file itself has byte SHA256 `c53938d784b352674e42a832c4d0db8ae49ce43a062ddab7c90df416415cb2e3`. These are different hash definitions, not a failed lock integrity check. The old lock is an exploratory result under U2 because its B3 input is not confirmatory.

## Synthetic checks before truth release

`results/tuning/u2_synthetic_checks.json` records **12/12 PASS, 0 FAIL**, using baker's `gym` Python and `unittest`. Each check passed:

| Check | Result |
|---|---|
| Disjoint finalist union and B3x difference | PASS |
| Unchanged c_bus domain after fleet union | PASS |
| Persistent rescue exclusion | PASS |
| Identical B3/B3x RNG streams | PASS |
| F3 requires 10/10 eligible fits | PASS |
| Failed initialization retains score penalty and stops dispersion | PASS |
| Single independent data block stops seed dispersion | PASS |
| Invalid/missing paired references and P0* provenance stop | PASS |
| Literal zero-reference-SD inequality | PASS |
| Unsupported B1 compute prefix stops | PASS |
| Heterogeneous locks preserve the design key | PASS |
| Counts derive from manifest and finalist set | PASS |

`u2_decision.py` contains the checked decision primitives. `u2_admission.py` and the existing stage runner now require the amendment and live audit barriers before a new U2 stage can admit a worker. The attempted synthetic F1 admission returned `STOP(CONFIRMATION_EXPOSED)`.

## Bus finalist audit and exposure

The read-only audit used stored B1/B2 manifests, candidate and fit tables, and selector source hashes; it did **not open any B3 truth JSON or unexposed confirmation truth**. Detailed hashes, counts and limited comparisons are in `results/tuning/u2_audit.json`.

- B1 has 216/216 rows, 47 `ok`, 169 `anchor_fail`; B2 has 192/192 rows, 102 `ok`, 90 `anchor_fail`. **Both use only `bus_seed7000`**. Three initializations are optimization repetitions, so the adopted across-seed SD and bootstrap cannot be computed.
- The old selectors use reward-scale-normalized, clipped/floored log scores and `NLL + .01`; the adopted rule requires paired raw reward M/P0 or family-center references, `.005`, P0* variability/time comparisons and paired-data uncertainty. No provenance-verified noncircular adopted-rule P0* selection map exists.
- For a **limited descriptive comparison only**, among B2 width-10 configurations with 3/3 eligible fits and NLL within `.005`, the raw-M leaders in signed/k=1, clip0 and abs have the same config IDs as the three old non-rescue picks. Signed/k>1 has **zero** 3/3-eligible B2 candidate; replaying the old fewest-failures/NLL+A² rescue fallback returns the same flagged fourth key. Thus the **nominal four-key membership is unchanged in this partial replay**. B1's two signed families likewise have no fully eligible center. This comparison does not supply the required variability, paired references, timing branch or uncertainty.
- Therefore **whether the adopted-rule B3 membership changed is undetermined**: there is no certifiable corrected finalist set. The nominal four old keys were not redefined or retroactively validated as U2 finalists. Rescue provenance remains attached to the signed/k>1 key.
- B3 has 80 published truth files and public `B3_fits.csv`/`B3_confirmation.json`, all from before U2 activation. The published B3 winner and the 18/18 BL lock are **exploratory only** for this amendment. No corrected B3 manifest was created, no already-seen result was counted as confirmation, and no fresh seeds were invented.

## Barriers, STOPs and admissions

| STOP | Scope and evidence |
|---|---|
| `SEED_DISPERSION_UNDEFINED` | B1/B2 promotion: one independent bus data block in each manifest cannot yield sample SD or whole-data bootstrap. |
| `REFERENCE_SELECTION_UNRESOLVED` | B1/B2 and dependent rankings: no noncircular adopted-rule P0* rate-selection provenance/map. The old selector's winner cannot establish it. |
| `CONFIRMATION_EXPOSED` | B3 decision: 80 B3 truth files and published confirmation result predate U2 governing hashes; those results are exploratory. |
| `HASH_BARRIER` | Old B3 manifest lacks U2 candidate/rate/reference maps, selector, bootstrap-index and ledger hashes before its truth publication. Retroactive hashing is prohibited. Valid c_bus, BL→F1 transfer and later union maps cannot be established. |

The ordered B3→BL→F1 dependency stops at B3. F2/B3x/F3/FL decisions and the union/rate/reference barrier were never reached. `NO_BUS_WINNER` is not asserted: B3 eligibility cannot be decided confirmatorily from these exposed results. No reference substitute, dispersion waiver, additional bus dataset, rate donor, replacement seed or new confirmation allocation was used.

| Fleet stage | Scheduled fits | Newly admitted | Running | Complete in this U2 launch |
|---|---:|---:|---:|---:|
| F1 | 144 | 0 | 0 | 0 |
| F2 | 288 | 0 | 0 | 0 |
| F3 | 160 | 0 | 0 | 0 |
| FL | 108 | 0 | 0 | 0 |
| Factored lock | 18 | 0 | 0 | 0 |
| FS | 36 | 0 | 0 | 0 |
| D | 8 | 0 | 0 | 0 |
| FR diagnostic | 3 | 0 | 0 | 0 |
| AF post-freeze | 60 | 0 | 0 | 0 |
| **Total inherited schedule** | **825** | **0** | **0** | **0** |

FR was launched before this brief and is independently **3/3 complete**, with `FR.DONE` and `accounting_FR.json`; those three historical fits are not a U2-stage admission. B3x and missing-reference/exception fits would be additional to the inherited 825 and have **0 admitted**. No F1 recipe allocation or manifest was fabricated because a valid c_bus and B3 hash barrier are missing. The freeze marker was not written; AF and headline pools remain closed.

## Threads and deviations

The live baker audit in `results/tuning/u2_thread_audit.json` found **0 active known project Python processes and 0 project compute threads** across bus, fleet, four-step and oracle entrypoints; `/tmp/gladius-threads/reserved` was absent. No U2 worker was admitted, so the observed U2 maximum was 0/44. Historical FR accounting reports three completed records and a 44-thread cap. The earlier bus B1 report recorded one historical 45-thread sample due to a changing oracle reservation; this predated U2 and was not repeated by this work.

The intended 825-fit launch could not proceed because the amendment itself mandates the four STOPs above. This is the only scope deviation from the requested launch. The pre-existing untracked FR ledger and truth artifacts were preserved and were not staged or altered. No bus result files were modified, and no protected headline data were opened. No push or merge was performed.
