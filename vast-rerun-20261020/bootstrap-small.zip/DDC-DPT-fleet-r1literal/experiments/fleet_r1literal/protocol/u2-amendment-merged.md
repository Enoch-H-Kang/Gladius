# U2 amendment — executable inputs to the unchanged minimax rule

**Status:** merged proposal, ready to hash; not authorization to launch, unblind or freeze. FD requires author approval of U2. Approval of this text adopts every recommended default in §9 without a separate answer to each flag. An override requires a revised, rehashed amendment before affected truth is exposed.

**Scope:** confirmation allocation, initialization aggregation, design/lock identity and reference completion. U1, U3, the estimator, tolerances and reserved data remain unchanged. `STOP(reason)` means record the reason, retain all evidence and costs, and issue no affected promotion/winner/freeze; it is an executable outcome, not a request for an implementation choice. Descriptive reporting remains permitted. Defaults below can stop the study, notably at the single-dataset bus screens.

## 1. Authority and fixed rules

TF controls conflicts: TC supplies the finite stages, estimator, data, seeds and operational locks; TL §3.4 supplies the winner rule; RC retargets fleet tuning to the independent 32-action arm. References are local files; their verified hashes are in §8.

`M` is occupancy-weighted reward RMSE for `r_hat=Q−beta*zeta`, weighting non-anchor actions equally at each state: bus keep; fleet actions 1–31. For candidate D, stratum h, data seed s and initialization i:

```text
q[D,h,s,i] = log(M[D,h,s,i] / M_ref[h,s,i])  if the candidate fit is eligible
           = log(10)                       if the candidate fit failed
S_X(D) = mean_h mean_s mean_i q[D,h,s,i]
regret_X(D) = S_X(D) − min_E S_X(E)
common winner = argmin_D max(regret_bus(D), regret_fleet(D))
```

The reference must be valid even when the candidate fails. The minimax minima use the same non-rescue, feasible, cross-confirmed candidate set on both testbeds. No missing candidate is silently removed to manufacture that set. An empty feasible set produces `STOP(NO_FEASIBLE_COMMON_DESIGN)`.

Preserve the `.005` NLL guard, `1.5×P0*` variability inequality, `4×P0*` timing branch, `max(log(1.05),1.96*SE)` tie band, 2,000 whole-data-seed bootstrap resamples with initializations nested, and minimax ties resolved by fleet regret then fidelity. A heuristic displaces P0* only outside its tie band, with at least 5% geometric gain and a paired confidence interval excluding zero. Do not import TC's reward-scale normalization, clipping/flooring, `.01` feasibility guard or competing tie rule.

Fidelity remains lexicographic: signed < clip0 < abs; smaller k; separate < shared; plain SGD < SGD-momentum < AdamW; `c_BE=1`; `rho=1`; default batch/bias; shorter stopping policy; canonical configuration ID. Only separate networks and the permitted AdamW/plain-SGD families are admissible; the ordering adds no variants. Default batch/bias preference means both `B=256` and anchor-derived bias; other combinations tie at that position. For heterogeneous rate maps, `rho=1` is preferred only when every execution cell in the comparison uses 1. The shared stopping procedure ties on shorter stopping policy.

For a score comparison, let b minimize S among feasible candidates, with exact ties by canonical ID. Use the sample SD (`ddof=1`) of the 2,000 paired bootstrap differences `S(c)−S(b)` as SE. Resample complete data blocks, carrying all N/width/init cells together and using identical draws for every candidate. Paired gain intervals are the 2.5% and 97.5% empirical quantiles of those differences, with linear interpolation. Bootstrap minima and feasibility membership stay fixed at their observed values. For minimax ties, use the larger of the two testbed bands for the paired difference from the minimum-max-regret design; exact minimax ties before this comparison use canonical ID. Bootstrap testbeds independently. The hashed decision implementation must fix and record its RNG, seed and expanded 2,000 resample-index arrays before truth release; absent arrays produce `STOP(BOOTSTRAP_INPUT_MISSING)`.

**Mechanics choice:** paired-difference SE implements the already required paired comparisons; the NLL reference minimum in §3 includes all stability-eligible candidates, preserving TC's observable guard without changing TL's `.005` tolerance.

## 2. Confirmation allocation and rates

Let B be the four protected-family bus B2 finalists and F the four protected-family fleet F2 finalists, after the audit in §7. Membership is deduplicated by the design key in §4. Rescue provenance persists through B3/B3x/F3; a rescue is reported but cannot become a family winner, `c_bus` or a common winner. If a key has rescue provenance in either originating finalist set, it remains excluded from the common winner set.

```text
B3 candidates  = B
c_bus          = the feasible, non-rescue B3 winner over B only
F3 candidates  = C = unique(B union F)
B3x candidates = F minus B
```

Never redefine `c_bus` after B3x or replace a fleet finalist with it. Reference executions do not create extra candidates; a reference competes only if its key independently belongs to B or F. If there is no feasible non-rescue B3 winner, record transfer `NOT_ASSESSABLE` and `STOP(NO_BUS_WINNER)` for this development version.

| Block | Complete cells per design | Candidate fits |
|---|---|---:|
| B3 | width 2×10; N={5k,100k}; seeds 7200–7204; inits {0,1}; cap 50k | 80 |
| B3x | Identical B3 cells, streams and cap | `20*|F minus B|`, at most 80 |
| F3 | widths {2×10,2×64}; N={20k,100k}; seeds 9300–9304; inits {0,1}; cap 50k | `40*|C|`, 160–320 |

Complete all reference cells in §5 in addition to these candidates. Width128, superseded TL seeds/N levels, refcode and extra stopping policies are not inserted into confirmation.

**Mechanics choice:** keep TC's four protected-family candidates and add references as evidence only; Claude's fifth candidate would change the approved promotion set as well as complete its denominator.

All B3x executions use `B3` as the RNG-stage key. Confirmation references use the stage key of their paired candidates. TC's seed is the first eight bytes, big-endian, of SHA256 of UTF-8 `20261018|testbed|stage|data_id|init_index|stream_name`, modulo `2^63−1`. Candidate identity is excluded. Expand seeds before launch. Reuse a fit only when executable, data, RNG, code and selection hashes all match; design-key equality alone is insufficient.

Rate mapping is frozen before confirmation evaluation:

- Original B3 finalists retain their bus rates. Original F2 finalists have priority for F3 at their own rates.
- A bus-only F3 addition uses its exact-design, matching-width F1 rate; for `c_bus`, this is the BL transfer rate. An exact-design F2 execution, if present, takes precedence over F1. Record rate collisions and the selected source.
- Otherwise an F3 addition takes a donor from F1 with the same `(L,k,width,optimizer_family)`. B3x takes a donor from B1 with the same `(L,k,optimizer_family)`.
- A donor must have every fit eligible in its relevant cells. Order donors by median selected validation NLL, then lower median A, shorter scored horizon, `rho=1`, smaller `lr_Q`, canonical ID; use exact equality before advancing to the next field. Average initializations within data seeds first. No truth metric enters this lookup.
- If no such donor exists, `STOP(RATE_DONOR_MISSING)` for the affected admission and dependent freeze. Do not borrow another optimizer's numeric rate, broaden the matching fields, choose a rescue donor or add calibration fits.

**Mechanics choice:** use Codex's same-optimizer stop option and its deterministic observable tie order; Claude's hierarchical B1∪B2 search changes the approved donor pool and matching rule.

## 3. Fit eligibility, aggregation and undefined statistics

A fit is eligible only if it completes the requested comparison horizon without numerical failure and has a finite checkpoint with validation anchor RMSE `A≤.10`. Select minimum validation NLL within the horizon; the tie set is `NLL≤minimum+.001`, then lower A, earlier step, checkpoint hash. Checkpoints start at 5k on the 500-step grid, with the exact off-grid endpoint included only for that comparison view. No eligible checkpoint means `anchor_fail` with minimum `NLL+A²` retained for diagnosis; break diagnostic exact ties by earlier step then hash. No validation anchor rows means `unassessable`. A numerical failure before the requested horizon invalidates that horizon even if an earlier checkpoint was eligible.

Terminal statuses are `ok`, `anchor_fail`, `unassessable`, `nonfinite`, `worker_failed`; every status except `ok` is failed. `missing` is nonterminal and blocks stage completion. Infrastructure interruptions are handled by §5, not converted into algorithmic outcomes. Diagnostic checkpoints never make failed fits eligible.

| Stage | Required eligible fits in every stratum |
|---|---|
| B1/B2/F1/F2 | All scheduled fits |
| B3/B3x | At least 9/10 |
| F3 | 10/10: a data seed passes only if both inits pass, and all 5 seeds must pass |

Compute each paired initialization log ratio before averaging. Retain every scheduled initialization; never choose the better one, pool RMSEs before taking logs, or drop failures. For NLL, average selected values within each seed, then take the median across seeds. A failed fit contributes its finite diagnostic NLL, or `+infinity` if unavailable. The NLL benchmark is the lowest finite median among candidates meeting the stratum's fit-count requirement, before variability/NLL filtering; if absent, `STOP(NLL_BENCHMARK_UNDEFINED)`. Require candidate median NLL ≤ benchmark + `.005`.

For variability use `z_s=mean_i log(M_si)` and sample SD across independent data seeds (`ddof=1`), identically for candidate and P0*. Require `SD_candidate≤1.5*SD_P0*`. If a fit-count-eligible candidate has a failed initialization, its score penalty remains `log(10)`, but its seed variability is undefined: `STOP(FAILED_FIT_DISPERSION)` for the affected ranking. Do not invent a measured log M from the penalty. Candidates already failing the fit-count requirement are ineligible without further variability testing.

A zero P0* SD is defined: zero candidate SD passes and positive candidate SD fails. Missing/nonfinite SD or fewer than two independent data blocks produces `STOP(SEED_DISPERSION_UNDEFINED)`. Thus B1/B2's single archive cannot support this gate or population bootstrap uncertainty; their three initializations are optimization repetitions, not independent datasets. Promotions requiring these quantities stop under the default; no extra datasets or waiver are authorized.

**Mechanics choice:** both drafts favor 10/10 fleet eligibility; Codex's dispersion stops preserve independent-data inference, whereas imputation or substituting initialization SD would add a new statistic.

**Mechanics choice:** test a zero reference SD with the literal inequality; Claude's zero-SD stop would change a defined approved comparison.

## 4. Design identity, stopping and observable locks

The canonical design fields are `(L,k,trunk,optimizer_family,c_BE,B,bias_rule,stopping_policy)`, with nominal B and `stopping_policy="obs_lock_v1"`. This policy means the unchanged observable checkpoint selector, fixed-cap development scoring and TC's per-testbed/class deployment lock over {10k,20k,50k}. Realized rates, rho, horizon, width, N, seed and init are execution/stratum fields, not design fields. Serialize identity as UTF-8 JSON with sorted keys, compact separators, no NaN/Infinity, integers for k/B, and exact decimal strings without trailing fractional zeros for nonintegral numeric design fields; canonical ID is SHA256 of those bytes. `c_BE` is always a decimal string, including `"1"`.

Development uses TC's fixed caps: B1=20k; B2/B3/B3x/F1/F2/F3=50k, subject only to the mandatory compute branch in §6. Do not emulate a deployment lock to truth-rank horizons. Fixed-prefix sensitivity rows do not become candidates. Patience and 150k do not enter the search.

**Mechanics choice:** both drafts favor fixed-cap development and a shared stopping procedure; this preserves TC's search and TF's allowance for different observable deployment horizons.

Store `(lr_Q,rho,horizon)` by `(design_sha,testbed,class,lock_stage)`. BL/FL use AdamW `{1e-4,3e-4,1e-3}×{1,3}` or SGD `{1e-3,1e-2,1e-1}×{1,3}`, three independent lock seeds and horizons {10k,20k,50k}. Require 3/3 eligible runs per policy; minimize median NLL, form the `.001` tie set, then choose lower median A, shorter horizon, `rho=1`, smaller `lr_Q`, canonical ID. No eligible policy means no releasable lock; retain only the TC diagnostic rescue. Hash locks before evaluating their truth.

BL on `c_bus` supplies the original transfer lock. If the common winner D* has a different key, run BL′ for D*: six rate pairs × seeds 7300–7302, width10/N20k, 18 fits, using BL's paired streams. Reuse exact-hash matches only. FL applies to the design actually deployed on each fleet class.

Transfer for the original `c_bus` is CONFIRMED in both width-specific F3 tie sets, PARTIAL in one and FAILED in neither. Each width score averages its two N strata; publish all width/N cells. Undefined comparisons yield `UNRESOLVED`, never FAILED. Strong transfer claims also require beating P0* in every F3 stratum, no failure increase and NLL loss ≤ `.01`.

Only a demonstrated FAILED verdict invokes the existing separate-recipe exception: bus uses `c_bus` with BL, fleet uses its feasible non-rescue F3 winner with FL, and the common minimax design remains the sensitivity result. Any distinct design needed for that sensitivity receives its own observable lock: 18 bus fits or 108 fleet fits, minus exact-hash reuse, explicitly counted before launch. Missing sensitivity locks stop its release.

## 5. References and recovery

P0 is signed/k=1/separate/AdamW, B=256, `c_BE=1`, anchor-derived output bias, `lr_Q=3e-4`, `rho=1`. It is distinct from the 5k P0 protocol-check stage, which provides no performance denominator.

P0*_X is P0 with the best feasible rate/ratio in testbed X's screen; only rates change. It is frozen once per testbed, never selected separately by seed. A reference-rescue fallback is not admitted. The signed/k=1 family center used for refinement is recorded separately if its nuisances differ from P0*.

| Comparison | Score denominator in every paired cell | Variability/time comparator |
|---|---|---|
| B1/F1 | P0 at that stage's actual cap | P0*_X |
| B2/F2 | Frozen signed/k=1 family center entering that refinement | P0*_X |
| B3/B3x/F3 | Frozen P0*_X; B3x reuses B3's reference map | P0*_X |

Before scoring, require a provenance-verified frozen P0* rate-selection procedure and map that use the adopted feasibility/score rule without depending circularly on the P0* they select. If none exists, `STOP(REFERENCE_SELECTION_UNRESOLVED)`; neither a self-selected reference nor an arbitrary default rate closes that dependency. Do not infer such provenance from the existence of a previous winner. This amendment authorizes no substitute screen-feasibility rule.

**Mechanics choice:** preserve TL's stage-specific score denominators and default-nuisance confirmation P0*; use Codex's stop rather than Claude's rescue reference or an invented solution to the circular screen definition.

Allocate every missing score, variability and timing reference on the complete corresponding stage grid, including required compute prefixes. P0 in F1 requires at most 12 additional fits; P0* in B3 at most 20 and F3 at most 40. Those are individual component bounds, not a bound on all reference work. Reference-only fits never enter a candidate minimum or become a fifth finalist. Exact-execution matches can serve both roles without duplicate fits.

| Condition | Exact treatment |
|---|---|
| Required fit missing | Keep stage pending; complete the identical declared slot. If exact completion is impossible, `STOP(MISSING_FIT)`. |
| Infrastructure interruption | Resume identical fit/RNG/optimizer state and hashes; record elapsed and active costs. No replacement seed. |
| Metric/export absent, committed checkpoint present | Recompute the same deterministic metric at that checkpoint; no reselection. |
| Algorithmic reference failure, no anchors or anchor failure | `STOP(REFERENCE_FAILED)`; no diagnostic checkpoint denominator. |
| Reference M zero, negative or nonfinite | `STOP(REFERENCE_UNDEFINED)`; no epsilon, floor, surviving-seed mean or candidate-median substitute. |
| Candidate failed; reference valid | Preserve slot and `log(10)` score; apply §3's eligibility/dispersion rules. |
| Candidate M exactly zero | Preserve the zero and `STOP(ZERO_LOG_METRIC)` for affected log/SD/CI calculations; zero is not automatically an evaluator bug. |
| Candidate otherwise eligible but M negative/nonfinite | Re-run the read-only evaluator once at the same checkpoint; if still invalid, `STOP(EVALUATOR_UNDEFINED)`. |
| Confirmed implementation/evaluator bug | Version correction, invalidate and consistently recompute/rerun all affected records, retain original evidence and costs. No promotion on invalid metrics. |
| Reference SD undefined or time missing/nonpositive | `STOP(REFERENCE_COMPARISON_UNDEFINED)`. Zero SD follows §3. |

No numerical replacement is permitted. An algorithmic failure is not retried until successful. If both candidate and reference fail, the reference stop still applies. A failed reference initialization cannot be dropped while averaging its surviving sibling.

**Mechanics choice:** Codex's paired-reference stop preserves the specified denominator; Claude's diagnostic/surviving-init averages and cross-seed substitution change it.

**Mechanics choice:** retain invalid evaluator output as a stopped comparison; classifying it as an optimizer failure or declaring every exact zero a bug would add an unsupported rule.

## 6. Compute comparisons and counted work

Equal-Q wall time is active training plus validation seconds, excluding queue wait; compare medians over all scheduled fits in each stratum against P0* at the same horizon. Missing/nonpositive comparator time stops ranking. If a candidate exceeds `4×P0*`, its stratum is ranked using the equal-optimizer-update view, not disqualified and not left on the equal-Q view.

For stage cap H, use `U=2*H` and candidate cutoff `T=floor(U/(k+1))`; P0* has k=1 and cutoff H. Each Q update and each zeta update counts once. Select checkpoints on the 500-step grid from 5k through T, plus T if off-grid. For 50k stages, cutoffs for k={1,3,5,10} are {50000,25000,16666,9090}. Apply that view's eligibility, M, S, NLL and variability; no recursive timing branch. Report sample-row-weighted gradient counts and actual time separately.

For B1, U=40000: k=10 has T=3636, before the 5k eligibility start. If that branch is needed, `STOP(COMPUTE_SUPPORT_MISSING)`; do not extend the cap or lower the start. Every required candidate and reference prefix must exist. Recover missing prefix selections only through an identical deterministic replay, with the overlapping validation trace matching bitwise. Otherwise stop. Record replay work even though it creates no new statistical replication.

**Mechanics choice:** both drafts use TC's Q+zeta update proxy; Codex's unsupported-prefix stop preserves B1's approved cap and eligibility start.

The exact additional-fit ledger is the expanded required execution set minus exact-hash aliases, with each fit counted once:

```text
additional_fleet = 40*|B minus F| + R_fleet + L_fleet + A_fleet
additional_bus   = 20*|F minus B| + R_bus + L_bus + A_bus
fleet allocation = 1300 + additional_fleet
```

`R_X` counts missing reference-only fits across all stages. `L_bus` counts additional distinct 18-fit bus locks; `L_fleet` counts additional distinct 108-fit fleet locks beyond the original FL. `A_X` counts audit corrections requiring fresh execution, including invalidated records that cannot be aliased; affected old work remains in the cost ledger. B3 finalist replacement can require up to 80 new bus executions. Recovery replays and trajectory extensions have separate Q/zeta-update, time and thread-cost rows. No additional calibration, independent-data or compute-extension allocation is authorized by the defaults.

Candidate cross-confirmation additions alone are at most 160 fleet and 80 bus fits. Do not assert a complete 1,512-fit fleet bound: the full reference, audit and exception-lock requirements must be enumerated. The original 1,300 is not an all-in study budget; bus, engineering, oracle/reference work, four-step and counterfactual solves retain their separate ledgers. Preserve the shared 44-thread limit.

**Mechanics choice:** use Codex's set-difference accounting; Claude's fixed upper bound omits potentially missing auxiliary references and distinct exception/sensitivity locks.

## 7. Audit, blinding and activation

Audit B1 centers and B2 finalists from stored development metrics, manifests, selector code and disclosure records without opening confirmation truth. Check TL's score, `.005` guard, variability/time rules, fidelity and persistent rescue labels; FD records a prior selector mismatch. If required comparisons are undefined under this amendment, stop rather than certify those promotions.

If the adopted-rule finalists differ and confirmation truth remains unexposed, replace the candidate manifest with the corrected finalists, retain old rows as reported but unscored, and complete the corrected B3 grid on the same seeds. Reuse only valid exact-hash matches. If rescue promotion logic permits a carried rescue to become a winner, remove that logic before hashing.

If affected confirmation truth was exposed before its governing amendment/script/candidate hash, label that evidence exploratory and `STOP(CONFIRMATION_EXPOSED)` for the affected confirmatory decision. Logging a post-exposure choice or retroactive hashing does not restore blinding. A fresh confirmatory allocation is not authorized by this default.

**Mechanics choice:** both drafts favor correcting the competing promotion rule; Codex's exploratory-only stop after exposure preserves the pre-disclosure requirement that Claude's disclosure-only treatment would relax.

Activation and hash order:

- Author approves this amendment, including §9 defaults; SHA256 the exact UTF-8 file bytes externally, record approval and digest in `protocol_changes.md`, and embed the digest in downstream manifests and decision scripts. This merge itself is not that approval.
- Before B3 truth evaluation, hash the corrected B3 candidate/rate/reference maps, expanded cells/seeds, selector and B3 decision code, bootstrap inputs and exact additional-work ledger. Complete paired reference evidence before choosing `c_bus`.
- Fix/hash `c_bus` before F2 decisions are used. Preserve the B3→BL→F1 sequence.
- After F2, before any B3x/F3 truth evaluation, hash C, all rate/reference/execution maps, rescue provenance, B3x/F3 decision code, minimax code, transfer code, bootstrap inputs and updated ledger.
- Freeze final design and observable locks before fresh reporting truth is opened. Preserve protected data and panel assignments from TC/RC.

Before truth release, the decision implementation must pass synthetic checks for disjoint finalist unions, unchanged `c_bus`, persistent rescues, identical B3/B3x streams, 10/10 fleet eligibility, failed-init dispersion stops, single-dataset stops, invalid references, literal zero-SD inequality, unsupported compute prefixes, heterogeneous locks with identical design keys, and manifest-derived counts. Hashes missing or inconsistent at any barrier produce `STOP(HASH_BARRIER)`.

## 8. Source snapshot SHA256

| Key | File | SHA256 |
|---|---|---|
| Codex draft | [u2-amendment-codex.md](u2-amendment-codex.md) | `2142c2f13fe57eb3f4b44171bedbfc302c613cbbbf960d8255208037470c454e` |
| Claude draft | [u2-amendment-claude.md](u2-amendment-claude.md) | `9e62004620d9b394140920cae50f0c021d3da47a3c8f7c4d58487afa2db5217c` |
| RC | [r1literal-converged.md](r1literal-converged.md) | `e7a439f56857ba73d4099c56d1d3d43865942c7a0617ecac343a23b948b0875c` |
| TF | [tuning-final-design.md](tuning-final-design.md) | `05f8bf28808016a3a66f5b80bd4cad3180892c30e4890345d0813d7cb8df7247` |
| TC | [tuning-r2-codex.md](tuning-r2-codex.md) | `aa08774a3a3086b635a91cd47c76c4f136060a1fc83c0320c37fd2071f62ab9a` |
| TL | [tuning-r2-claude.md](tuning-r2-claude.md) | `953dee8453f01200af5aab83c08f45dd2a8f431bd435e14deb563929f05d9cab` |
| FD | [final-decisions.md](final-decisions.md) | `63b26f00df22e3b074a33cd70a4edaaa4ec76246214d4a3a610bf5c8b821ba8b` |
| CC | [r1literal-converge-codex.md](r1literal-converge-codex.md) | `5ea054610748431cee324c0dcd8d39b7d255ec44fad3b1f90e9145b95cffff21` |
| LC | [r1literal-converge-claude.md](r1literal-converge-claude.md) | `2fe870f51f8aa2b788bdd89b34d042434a83b665e2b4844de79aa341706f5deb` |

Verify source hashes at activation. A mismatch stops activation until the affected clauses are reviewed and a new amendment is hashed. Live-log observations in the drafts are historical audit leads, not assertions about current job status.

## 9. Consolidated AUTHOR-DECIDE list

Every default below is already implemented in §§1–7. Alternatives are recorded for author review and are inactive unless adopted in a revised amendment. Source IDs identify all explicit flags, including the unnamed Codex exposure flag; the last two entries close Claude's additional unflagged ambiguities.

1. **Wrong rule selected earlier bus finalists** — Claude D1; Codex promotion audit. **Situation:** correcting the score or feasibility rules may change which four designs should receive confirmation. **Options:** correct the finalists and complete B3 on the same still-blinded seeds; or keep the old finalists and disclose the deviation. **RECOMMENDED DEFAULT:** correct and complete the approved-rule set under §7; retain displaced work as unscored evidence. If correction cannot be assessed, stop promotion. This is both drafts' rule-preserving choice.

2. **Confirmation results were already seen** — Codex unnamed exposure flag; Claude P3. **Situation:** a rule or membership choice would be fixed after the relevant confirmation truth was exposed. **Options:** register and budget fresh confirmation data; or report the affected results as exploratory only. **RECOMMENDED DEFAULT:** exploratory only and `STOP(CONFIRMATION_EXPOSED)`; no new seeds are silently authorized. This preserves blinding without adding an unspecified allocation.

3. **One of the two fleet initializations fails** — Codex INIT; Claude D2. **Situation:** F3 has five data seeds and two fits per seed, while the approved fleet requirement says all five seeds must pass. **Options:** both fits must pass at every seed, giving 10/10; or at least one per seed plus at least 9/10 fits overall. **RECOMMENDED DEFAULT:** 10/10 in every width/N stratum, as both drafts recommend.

4. **A failed fit has no measured log reward error** — Codex DISPERSION; Claude §3.6. **Situation:** a candidate may pass the bus 9/10 count but lack an input to its seed variability statistic. **Options:** stop the affected ranking; or impute `log(M_ref)+log(10)` as a synthetic observation. **RECOMMENDED DEFAULT:** retain `log(10)` in S and stop the ranking if its required variability is undefined; do not impute a measurement.

5. **Bus screens have only one independent dataset** — Codex ARCHIVE; Claude D4(c). **Situation:** three initializations cannot estimate variability across independently sampled datasets. **Options:** stop promotions requiring seed variability/uncertainty; add separately specified independent blocks; waive the gate; or substitute SD across initializations. **RECOMMENDED DEFAULT:** `STOP(SEED_DISPERSION_UNDEFINED)` for those promotions, with no added fits or waiver. This preserves the finite schedule and independent-data unit.

6. **Development horizon versus deployment horizon** — Claude D3; Codex §3. **Situation:** observable locks may choose different final horizons on each testbed. **Options:** rank development at its fixed stage cap; or emulate a separate observable lock within each development stage. **RECOMMENDED DEFAULT:** fixed caps, B1=20k and B2/B3/B3x/F1/F2/F3=50k, subject to §6's required compute branch. Both drafts favor this existing procedure.

7. **An imported design has no compatible rate donor** — Codex RATES; Claude D5. **Situation:** an SGD finalist may lack a same-optimizer B1/F1 donor. **Options:** borrow a different optimizer's numeric rate; stop admission; broaden to same-optimizer B1∪B2 matches in order `(L,k,family)`, `(L,family)`, `(family)`; or add an 18-fit bus calibration lock. Donor ties may use Codex's observable sequence or Claude's smaller-rate-then-rho sequence. **RECOMMENDED DEFAULT:** same-optimizer donors in the original matching pool only; absent donor means `STOP(RATE_DONOR_MISSING)`. Exact ties use NLL, A, shorter horizon, rho=1, smaller rate, canonical ID as in §2. No new pool, calibration or cross-optimizer transfer is authorized.

8. **Rate/horizon fidelity ties span different locks** — Codex FIDELITY-MAP. **Situation:** the common design can have different numeric rates and horizons across testbeds/classes. **Options:** compare common fields, require every compared rate map to use rho=1 for that preference, and tie on the shared stopping procedure; or introduce an ordered tuple of testbed/class rates and horizons. **RECOMMENDED DEFAULT:** the first option, exactly as §1; preserve the existing fidelity order without adding a testbed priority.

9. **P0* has inconsistent labels and a circular screen dependency** — Codex P0STAR; Claude §§1.5/5.1. **Situation:** a default-nuisance screen-rate reference can differ from a later family center, and screen feasibility itself calls for P0*. **Options:** default-nuisance P0* throughout; stage-specific family centers; or preserve the explicit stage denominators and stop where no valid non-circular reference-selection provenance exists. **RECOMMENDED DEFAULT:** §5's literal stage map, default-nuisance P0* for confirmation/variability/time, and `STOP(REFERENCE_SELECTION_UNRESOLVED)` if its selection cannot be established without inventing a screen rule. Do not substitute a rescue or admit a fifth candidate.

10. **A paired reference is missing, failed or invalid** — Codex REFERENCE-FAILURE; Claude D4(a), §§5.2–5.5. **Situation:** the required denominator is unavailable, including a failed reference fit with a finite diagnostic error. **Options:** complete/recover the same evidence, then stop if still invalid; use diagnostic/surviving-init values; substitute other reference seeds' mean; substitute candidate-median log error; or specify a new alternate-reference amendment. **RECOMMENDED DEFAULT:** identical-evidence recovery only, then the applicable §5 stop; no numeric or seed replacement. This preserves the prescribed comparator.

11. **Reference variability is zero or undefined** — Claude D4(b); Codex §4.2. **Situation:** the P0* SD may be exactly zero or may be impossible to compute. **Options:** apply the literal inequality for zero and stop for undefined; block both; skip the gate; or fail every candidate. **RECOMMENDED DEFAULT:** a defined zero uses `SD_candidate≤0`; undefined stops. This changes no defined comparison and waives no gate.

12. **No bus design can win confirmation** — Claude D6. **Situation:** B3 contains no feasible non-rescue design, so there is no bus winner whose transfer can be tested. **Options:** stop this development version; or continue minimax with fleet-origin designs and call bus transfer not assessable. **RECOMMENDED DEFAULT:** `STOP(NO_BUS_WINNER)` and transfer `NOT_ASSESSABLE`, preserving the existing no-releasable-winner rule.

13. **What counts as an equal-gradient budget** — Claude D7; Codex COMPUTE. **Situation:** Q and zeta steps, batch sizes and runtime differ across candidates. **Options:** count Q+zeta optimizer updates; or count sample-row-weighted gradient evaluations. **RECOMMENDED DEFAULT:** TC's optimizer-update proxy, `U=2*stage_cap`, with §6's exact cutoffs; report sample-row counts and time separately. This is the shared, already operational definition.

14. **The compute cutoff precedes the first eligible checkpoint** — Codex COMPUTE. **Situation:** B1's 20k cap cannot support k=10 at the common 40k-update budget. **Options:** stop a ranking needing that branch; or separately authorize/count a longer run or another budget. **RECOMMENDED DEFAULT:** `STOP(COMPUTE_SUPPORT_MISSING)`; retain the 20k cap and 5k eligibility start.

15. **Which bootstrap standard error defines a tie** — Claude §9. **Situation:** TL does not explicitly distinguish a candidate's own score SE from the SE of its difference from the best candidate. **Options:** marginal score SE; or paired-difference SE. **RECOMMENDED DEFAULT:** paired-difference SE, with 2,000 whole-data-block resamples and the exact procedure in §1, preserving pairing.

16. **Which candidates set the best validation NLL** — Claude §9. **Situation:** the `.005` guard needs a comparison minimum before all feasibility filters are applied. **Options:** all candidates; those passing the fit-count requirement; or those passing every other gate. **RECOMMENDED DEFAULT:** the lowest finite seed-aggregated median among candidates passing the fit-count requirement, as in §3; absent benchmark stops. This follows TC's stability-eligible comparison without changing TL's tolerance.
