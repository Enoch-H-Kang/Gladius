"""Fleet adapter to the unchanged shared estimator semantics."""
from experiments.fleet_capacity_one.fleet.train import fit
from .models import factory,initialize

def fit_fleet(data,cfg,seeds,**kwargs):
    if data["meta"].get("arm")!="independent_r1literal":
        raise ValueError("fleet data required")
    if data["meta"].get("n_actions")!=32 or data["meta"].get("anchor_action")!=0:
        raise ValueError("32-action metadata required")
    declared=cfg.get("loss","signed")
    if declared not in ("signed","clip0","abs"):
        raise ValueError("unsupported fleet loss")
    shared={**cfg,"loss":"none" if declared=="signed" else declared}
    result=fit(data,shared,seeds,model_factory=factory,model_initializer=initialize,**kwargs)
    result["declared_loss"]=declared
    result["shared_loss_semantics"]=shared["loss"]
    return result
