"""One-time protected data freeze and independent development-pool generation."""
import hashlib
import itertools
import json
import os
import time
from pathlib import Path

import numpy as np

from .assemble import load
from .env import generate_chains
from .params import ACTION_PATH, DGP_PATH, sha256
from .schema import write_training_export
from .launcher import PROTOCOL_PATH
from .rewards import all_actions
from experiments.fleet_capacity_one.fleet.evalsets import uniform_states, face_states

ROOT = Path(__file__).resolve().parent
REFROOT = ROOT / "artifacts/reference"
PILOT = ROOT / "artifacts/pilot/acceptance_LC_C3.json"
DATA = ROOT / "artifacts/data"
EVAL = ROOT / "artifacts/eval"
NS = "r1literal_v1_" + sha256(DGP_PATH) + "_" + sha256(ACTION_PATH)
H = 100
REF_SHA = json.loads((REFROOT / "reference_manifest.json").read_text())["artifact_sha256"]

def seed(stage, data_id, stream, init=0):
    material = f"20261018|{NS}|{stage}|{data_id}|{init}|{stream}"
    value = int.from_bytes(hashlib.sha256(material.encode()).digest()[:8], "big") % (2**63 - 1)
    return value

def streams(stage, data_id):
    names = ["starts"] + [f"action_bus_{f}" for f in range(5)] + [f"increment_bus_{f}" for f in range(5)]
    values = {name: seed(stage, data_id, name) for name in names}
    return (np.random.default_rng(values["starts"]),
            [np.random.default_rng(values[f"action_bus_{f}"]) for f in range(5)],
            [np.random.default_rng(values[f"increment_bus_{f}"]) for f in range(5)]), values

def filehash(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write_json(p, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, sort_keys=True, indent=2, allow_nan=False) + "\n")

def ordered_split(data_id, stage, n):
    # Independent permanent 800/200 assignment, ordered so every nested 5-chain
    # group contains exactly four training chains and one validation chain.
    rng = np.random.default_rng(seed(stage, data_id, "permanent_split"))
    perm = rng.permutation(n)
    train, val = perm[:n*4//5], perm[n*4//5:]
    order = np.empty(n, dtype=np.int64)
    for j in range(n//5):
        order[5*j:5*j+4] = train[4*j:4*j+4]
        order[5*j+4] = val[j]
    mask = np.tile([False, False, False, False, True], n//5)
    return order, mask

def export_pool(stage, data_id, n, reference, role):
    path = DATA / role / f"{stage}_{data_id}.npz"
    if path.exists():
        raise RuntimeError(f"refusing to overwrite {path}")
    t0 = time.perf_counter()
    rngs, seeds = streams(stage, data_id)
    chains = generate_chains(n, H, reference.component_query, rngs, burn=0)
    order, is_val = ordered_split(data_id, stage, n)
    chains = {key: value[order] for key, value in chains.items()}
    ids = np.asarray([f"{stage}_{data_id}_chain{int(i):04d}" for i in order])
    stream_ids = np.asarray([f"{NS}:{stage}:{data_id}"]*n)
    write_training_export(path, chains, is_val, ids, stream_ids, REF_SHA)
    del chains
    stat = dict(stage=stage, data_id=data_id, role=role, n_chains=n,
                n_train=int((~is_val).sum()), n_val=int(is_val.sum()),
                prefixes={str(k*H): {"train":int((~is_val[:k]).sum()),
                                      "val":int(is_val[:k].sum())} for k in (10,50,200,1000) if k<=n},
                seeds=seeds, split_seed=seed(stage,data_id,"permanent_split"),
                sha256=filehash(path), bytes=path.stat().st_size,
                wall_s=time.perf_counter()-t0, path=str(path.relative_to(ROOT)))
    return stat

def cache_truth(name, states, reference):
    path = EVAL / f"{name}_truth.npz"
    if path.exists():
        raise RuntimeError(f"refusing to overwrite {path}")
    q, v, pi = reference.joint_query(states)
    reward = all_actions(states)
    comp = np.empty((len(states),5,4), dtype=np.float64)
    for f in range(5):
        comp[:,f,:] = np.stack(reference.component_query(f,states[:,f]),axis=-1)
    np.savez_compressed(path, states=states, reward=reward, Q=q, V=v, pi=pi,
                        components=comp, arm="independent_r1literal",
                        dgp_sha256=sha256(DGP_PATH), action_sha256=sha256(ACTION_PATH),
                        reference_sha256=REF_SHA)
    return dict(path=str(path.relative_to(ROOT)), sha256=filehash(path),
                bytes=path.stat().st_size, n_states=len(states),
                state_shape=list(states.shape), reward_shape=list(reward.shape))

def final_panels(reference):
    EVAL.mkdir(parents=True,exist_ok=True)
    panels = {}
    e1path = EVAL / "E1_labels.npz"
    rngs,seeds = streams("headline_E1",9999)
    ch = generate_chains(200,H,reference.component_query,rngs,burn=0)
    np.savez_compressed(e1path,s=ch["s"],sp=ch["sp"],a=ch["a"],
                        arm="independent_r1literal",reference_sha256=REF_SHA)
    panels["E1"] = cache_truth("E1",ch["s"].reshape(-1,5),reference)
    panels["E1"]["labels"] = dict(path=str(e1path.relative_to(ROOT)),
                                     sha256=filehash(e1path),bytes=e1path.stat().st_size)
    panels["E1"]["seeds"] = seeds
    s2=seed("headline_E2",9999,"uniform")
    s4=seed("headline_E4",9999,"face")
    panels["E2"]=cache_truth("E2",uniform_states(20000,5,s2,per_axis=4),reference)
    panels["E2"]["seed"]=s2
    grid=np.array(list(itertools.product((.1,.3,.5,.7,.9),repeat=5)),dtype=np.float64)
    panels["E3"]=cache_truth("E3",grid,reference)
    panels["E3"]["construction"]="lexicographic Cartesian product {0.1,0.3,0.5,0.7,0.9}^5"
    panels["E4"]=cache_truth("E4",face_states(1024,5,s4),reference)
    panels["E4"]["seed"]=s4
    panels["E4"]["construction_source"]="fleet_capacity_one/fleet/evalsets.py:face_states"
    panels["E4"]["construction_sha256"]=filehash(ROOT.parent/"fleet_capacity_one/fleet/evalsets.py")
    return panels

def main(mode):
    t0=time.perf_counter()
    acceptance=json.loads(PILOT.read_text())
    reference_manifest=json.loads((REFROOT/"reference_manifest.json").read_text())
    assert acceptance["status"]=="accepted" and acceptance["governing_set"].startswith("LC C3")
    assert reference_manifest["status"]=="certified"
    assert acceptance["dgp_sha256"]==sha256(DGP_PATH)==reference_manifest["dgp_sha256"]
    assert acceptance["action_sha256"]==sha256(ACTION_PATH)==reference_manifest["action_sha256"]
    assert reference_manifest["protocol_sha256"]==sha256(PROTOCOL_PATH)
    reference=load(REFROOT)
    if mode=="headline":
        pools=[export_pool("headline",i,1000,reference,"headline") for i in range(1000,1010)]
        panels=final_panels(reference)
    elif mode=="development":
        blocks=[("F1",i) for i in range(9100,9103)]
        blocks += [("F2",i) for i in range(9200,9203)]
        blocks += [("F3",i) for i in range(9300,9305)]
        blocks += [("FL",i) for i in range(9400,9403)]
        blocks += [("FS",i) for i in range(9450,9453)]
        blocks += [("D",i) for i in range(9700,9702)]
        blocks += [("AF",i) for i in range(12050,12055)]
        pools=[export_pool(stage,i,1000,reference,"development") for stage,i in blocks]
        panels={}
        for stage,di,n in (("screen",9997,200),("confirmation",9399,200),("D",9998,50)):
            rngs,seeds=streams("panel_"+stage,di)
            ch=generate_chains(n,H,reference.component_query,rngs,burn=0)
            panels[stage+"_occupancy"]=cache_truth(stage+"_occupancy",ch["s"].reshape(-1,5),reference)
            panels[stage+"_occupancy"]["seeds"]=seeds
            if stage!="D":
                u=seed("panel_"+stage,di,"uniform")
                panels[stage+"_uniform"]=cache_truth(stage+"_uniform",uniform_states(20000,5,u,per_axis=4),reference)
                panels[stage+"_uniform"]["seed"]=u
    else: raise ValueError(mode)
    manifest=dict(status="frozen" if mode=="headline" else "development",
                  mode=mode, namespace=NS, generated_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
                  acceptance_sha256=filehash(PILOT), pilot_sha256=acceptance["pilot_sha256"],
                  dgp_sha256=sha256(DGP_PATH),action_sha256=sha256(ACTION_PATH),
                  protocol_sha256=sha256(PROTOCOL_PATH),reference_sha256=REF_SHA,
                  source_sha256=filehash(__file__), pools=pools,panels=panels,
                  total_pools=len(pools), total_bytes=sum(x["bytes"] for x in pools),
                  wall_s=time.perf_counter()-t0,
                  no_estimator_fits=True)
    out=DATA/f"{mode}_freeze_manifest.json"
    write_json(out,manifest)
    if mode=="headline":
        for p in [DATA/"headline"/f"headline_{i}.npz" for i in range(1000,1010)]:
            p.chmod(0o444)
        for p in EVAL.glob("E[1-4]*.npz"):
            p.chmod(0o444)
        out.chmod(0o444)
    print(json.dumps(dict(mode=mode,manifest=str(out),sha256=filehash(out),
                          pools=len(pools),bytes=manifest["total_bytes"],wall_s=manifest["wall_s"])),flush=True)

if __name__=="__main__":
    import sys
    main(sys.argv[1])
