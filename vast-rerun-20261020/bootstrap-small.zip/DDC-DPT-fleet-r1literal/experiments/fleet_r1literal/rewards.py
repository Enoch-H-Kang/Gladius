"""Analytic additive rewards."""
import numpy as np
from .params import U, V, KCOST, D, decode

def maintenance(s):
    x = np.asarray(s, dtype=np.float64)
    return U*x + V*x*x

def replacement(s):
    x = np.asarray(s, dtype=np.float64)
    return KCOST + D*x*x

def component(x, b, f):
    x = np.asarray(x, dtype=np.float64)
    return -np.where(np.asarray(b) == 1, KCOST[f]+D[f]*x*x, U[f]*x+V[f]*x*x)

def all_actions(s):
    s = np.asarray(s, dtype=np.float64)
    m, c = maintenance(s), replacement(s)
    from .params import ACTIONS
    return -(m[..., None, :]*(1-ACTIONS) + c[..., None, :]*ACTIONS).sum(axis=-1)

def reward(s, a):
    s = np.asarray(s, dtype=np.float64)
    bits = decode(a)
    return -(maintenance(s)*(1-bits)+replacement(s)*bits).sum(axis=-1)

def r0(s):
    return -maintenance(s).sum(axis=-1)
