# Frozen GLADIUS headline results

All 40 protected fits are complete. The table includes every assigned block, including checkpoints flagged `anchor_fail`; validation anchor RMSE and diagnostic pass/fail are reported without excluding any fit. Each value is a mean ± standard error across 10 distinct protected data blocks. Standard error is sample standard deviation divided by √10.

| N | Complete | Anchor pass/fail (A ≤ 0.10) | Anchor RMSE | E1 reward RMSE | E1 raw Q RMSE | E1 held-out NLL | E1 joint KL |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 1,000 | 10/10 | 0/10 | 0.17206 ± 0.01438 | 2.678 ± 0.129 | 8.521 ± 0.392 | 2.16578 ± 0.01252 | 0.16431 ± 0.01292 |
| 5,000 | 10/10 | 9/1 | 0.09545 ± 0.00418 | 1.563 ± 0.069 | 9.145 ± 0.611 | 2.02967 ± 0.00141 | 0.02793 ± 0.00113 |
| 20,000 | 10/10 | 10/0 | 0.06623 ± 0.00110 | 1.376 ± 0.058 | 9.849 ± 0.616 | 2.00882 ± 0.00031 | 0.00760 ± 0.00029 |
| 100,000 | 10/10 | 10/0 | 0.06258 ± 0.00141 | 1.347 ± 0.045 | 10.168 ± 0.535 | 2.00416 ± 0.00018 | 0.00293 ± 0.00009 |

## Definitions and provenance

The selected 50,000-step horizon checkpoint is used for each fit. The frozen checkpoint selector records `status=ok` if validation anchor RMSE is at most 0.10 after step 5,000. Otherwise it retains an `anchor_fail` checkpoint. Under the author's 2026-10-20 13:58 PDT ruling, both statuses remain in all result denominators; the 0.10 check is a reported diagnostic. The selection/reporting change is post-hoc and is recorded in the follow-ups release amendment.

E1 reward RMSE is `sqrt(mean((Qhat − 0.95 Zhat − true_reward)^2))` over the 31 non-anchor actions and 20,000 E1 occupancy states. Raw Q RMSE covers all 32 actions on those states. Held-out NLL is the negative mean log predicted probability of the 20,000 E1 observed joint actions. Joint KL is the E1 state average of the truth joint policy KL to the fitted softmax Q policy. These are the pipeline evaluator definitions (`tuning_evaluate.metrics`) plus the identical E1 label NLL used by the four-step comparator. The record's `horizons['50000']['nll']` is validation NLL and is separately present in the per-fit CSV.

Frozen manifest: `c0df9e599c99f663190f6aff31450f4bda17172c0cae24e9bfe3fe7d24a42c39`; fit manifest SHA256: `18f0f8aaa0bb4ee865b7afc6ac4194c2456c4aff4a30d0f2e072daa1d5551ce7`; E1 truth SHA256: `8426b6ed47ba97161277b625b1e3982acca0c3b4b1f9bccb44508175e07ec5fe`; E1 labels SHA256: `e51729bd450548a19c4516acf9f70363c0e2971000bcf59aadf522e26441fc8d`; fit code SHA256: `400580a1a40d4fb983f2f4e74abb3428f777659ee63382867d77d40f03f1cc12`. Individual checkpoint file hashes are in the per-fit CSV.

The four-step `primary` results contain the same 40 `(N, data_id)` cells and use the same E1 truth and label hashes, so descriptive paired differences can now be computed for all 40 cells. The historical 10/10 anchor-eligibility comparison would have excluded all N=1,000 pairs and one N=5,000 pair. The author has removed that exclusion for follow-up reporting; all 40 pairs remain in the denominator with their anchor diagnostics visible. The four-step report’s older “GLADIUS not present” sentence is stale.

CSV files: `HEADLINE_RESULTS.csv` contains these four summary rows; `HEADLINE_FITS.csv` contains the 40 selected-checkpoint rows, statuses, validation metrics, E1 metrics, and checkpoint hashes.
