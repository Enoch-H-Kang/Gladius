# Coupled K31 extension (EX) results

All 45 scheduled EX fits completed: three classes × N = 5,000, 20,000, and 100,000 × five paired pools (IDs 1000–1004). The separate EL stage locked each class's rate, rho, and horizon before EX reporting. Every fit contributes one selected checkpoint at its locked horizon; earlier horizon rows are not counted again. No fit is dropped for an anchor failure.

## Results

Entries are mean ± standard error across the five pools (sample SD / √5). Reward RMSE compares implied rewards `Q̂ − 0.95 ζ̂` with true rewards on the five non-anchor actions. Advantage RMSE compares `Q̂(s,a) − Q̂(s,0)` with K31 oracle advantages on those actions. Raw Q RMSE compares all six fitted Q actions with K31 oracle Q; see the **K31 absolute-Q level caveat** below. All three metrics use the existing 10,000-state K31 oracle occupancy panel. Anchor RMSE is the mean selected-checkpoint validation diagnostic, and the pass count uses the unchanged ≤0.10 threshold.

| Class | N | Reward RMSE | Advantage RMSE | Raw Q RMSE† | Anchor RMSE | Anchor ≤0.10 |
|:--|--:|--:|--:|--:|--:|--:|
| additive | 5,000 | 0.7637 ± 0.0768 | 0.2047 ± 0.0080 | 7.0466 ± 0.4574 | 0.0770 | 5/5 |
| additive | 20,000 | 0.7133 ± 0.0529 | 0.1431 ± 0.0018 | 7.0500 ± 0.6851 | 0.0422 | 5/5 |
| additive | 100,000 | 0.6571 ± 0.0446 | 0.1114 ± 0.0015 | 7.0664 ± 0.7399 | 0.0256 | 5/5 |
| mlp2x10 | 5,000 | 0.7426 ± 0.0325 | 0.2569 ± 0.0100 | 7.3833 ± 1.2014 | 0.1192 | 1/5 |
| mlp2x10 | 20,000 | 0.8482 ± 0.0935 | 0.2019 ± 0.0038 | 7.5790 ± 1.1670 | 0.0899 | 4/5 |
| mlp2x10 | 100,000 | 0.9046 ± 0.0826 | 0.1867 ± 0.0077 | 7.9885 ± 1.3162 | 0.0843 | 4/5 |
| mlp2x64 | 5,000 | 0.6348 ± 0.0232 | 0.2171 ± 0.0036 | 8.1843 ± 0.3092 | 0.1352 | 0/5 |
| mlp2x64 | 20,000 | 0.6106 ± 0.0184 | 0.1441 ± 0.0037 | 8.8910 ± 0.3835 | 0.0707 | 5/5 |
| mlp2x64 | 100,000 | 0.5691 ± 0.0223 | 0.1003 ± 0.0046 | 8.2458 ± 0.4476 | 0.0408 | 5/5 |

## K31 absolute-Q level caveat

† **Raw Q caveat:** Historical K31 absolute-Q acceptance FAIL: V4 forward returns had 8/20 starts outside 3SE+.01. Raw Q comparisons have empirical 0.086-0.095 level-floor sensitivity; advantages 0.001-0.0024. These are not global bounds. Policy is relative to the K31 expert. Raw Q RMSE is therefore a descriptive comparison with this K31 reference, not an absolute-Q accuracy claim. The much smaller oracle advantage sensitivity supports interpreting advantage errors separately. The 0.086–0.095 raw-Q level floor and 0.001–0.0024 advantage sensitivity are empirical reference sensitivities, not corrections to subtract from the fitted errors.

## Selection and provenance

The EL locks were additive: rate 0.001, rho 1, horizon 20,000; mlp2x10: rate 0.0003, rho 1, horizon 50,000; mlp2x64: rate 0.0003, rho 1, horizon 10,000. These were selected from three development pools (9400–9402) using validation observables. EX metrics use oracle truth only after checkpoint selection. The same five protected pools are paired across classes and N; these are descriptive within-cell means and standard errors.

Source accounting: `accounting_EX_followup.json` (45/45 complete); selected-fit validation diagnostics: `table_EX_followup.csv`; locks: `locks_EL_followup.json`. Each selected checkpoint's hash, panel hash, K31 Q-reference hash, and metrics are in `eval_EX_followup/*.json` and `EXTENSION_FITS.csv`. The nine class × N rows are in `EXTENSION_RESULTS.csv`. The source K31 V and DGP hashes are checked in the frozen EX manifest; the historical V4 acceptance failure stays attached to raw-Q interpretation.

EX manifest file SHA256: `dc143a709fd0852b5c14125f0a06897c4e2eff1fd55643c74f1547e8e78ef78f`; EL locks file SHA256: `719e61eaa1b911a0603d0758242df9d9670bea68fe4425b6a36a845cca821e77`; occupancy panel SHA256: `95500665a3e3332affe74631ebecc49020ade4bbb91278de1617dd14919425e0`; K31 Q-reference SHA256: `5190e8904b7761b0bc1656b37024e49b5da6e3c233e0c667047ae079dbf1bbf9`.
