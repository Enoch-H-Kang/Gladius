# Frozen six-class GLADIUS reporting matrix

All 240 assigned fits are complete: 200 M1 follow-up fits (linear, mlp1x5, additive, mlp2x64, mlp2x128) plus 40 frozen headline mlp2x10 fits. Each class × N row contains 10 distinct protected data blocks (IDs 1000–1009). Every fit contributes exactly one checkpoint from its final prespecified horizon (10,000, 20,000, or 50,000 steps, depending on class); earlier horizon rows are not additional fits.

## Six-class results

Values are mean ± standard error across the 10 blocks (sample SD / √10). Reward RMSE covers the 31 non-anchor actions on the 20,000 E1 occupancy states; Q RMSE covers all 32 actions; advantage RMSE uses differences from action 0 on the 31 non-anchor actions. Held-out NLL uses 20,000 E1 joint-choice labels; joint KL averages true-policy KL to fitted softmax Q over the E1 states. Anchor RMSE is the selected checkpoint's validation diagnostic.

| Class | N | Reward RMSE | Q RMSE | Advantage RMSE | Held-out NLL | Joint KL | Anchor RMSE | Anchor ≤0.10 |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| linear | 1,000 | 2.622 ± 0.087 | 7.198 ± 0.311 | 2.748 ± 0.350 | 2.1496 ± 0.0064 | 0.1464 ± 0.0064 | 0.1953 ± 0.0101 | 0/10 |
| linear | 5,000 | 1.703 ± 0.045 | 7.011 ± 0.109 | 1.591 ± 0.173 | 2.0323 ± 0.0019 | 0.0296 ± 0.0013 | 0.1149 ± 0.0014 | 0/10 |
| linear | 20,000 | 1.381 ± 0.015 | 6.863 ± 0.042 | 0.615 ± 0.010 | 2.0120 ± 0.0005 | 0.0101 ± 0.0004 | 0.1043 ± 0.0009 | 1/10 |
| linear | 100,000 | 1.320 ± 0.006 | 6.889 ± 0.027 | 0.554 ± 0.006 | 2.0082 ± 0.0001 | 0.0062 ± 0.0001 | 0.1061 ± 0.0006 | 0/10 |
| mlp1x5 | 1,000 | 2.278 ± 0.114 | 8.220 ± 0.561 | 2.035 ± 0.138 | 2.1481 ± 0.0085 | 0.1458 ± 0.0083 | 0.1699 ± 0.0068 | 0/10 |
| mlp1x5 | 5,000 | 2.273 ± 0.235 | 9.342 ± 0.688 | 2.333 ± 0.337 | 2.0516 ± 0.0099 | 0.0488 ± 0.0093 | 0.1033 ± 0.0053 | 7/10 |
| mlp1x5 | 20,000 | 1.562 ± 0.058 | 9.264 ± 0.823 | 0.662 ± 0.093 | 2.0201 ± 0.0053 | 0.0186 ± 0.0051 | 0.0941 ± 0.0052 | 9/10 |
| mlp1x5 | 100,000 | 1.430 ± 0.024 | 9.426 ± 0.817 | 0.408 ± 0.036 | 2.0151 ± 0.0057 | 0.0137 ± 0.0055 | 0.0929 ± 0.0032 | 9/10 |
| additive | 1,000 | 2.499 ± 0.100 | 7.070 ± 0.343 | 3.337 ± 0.156 | 2.1874 ± 0.0077 | 0.1865 ± 0.0083 | 0.1160 ± 0.0094 | 5/10 |
| additive | 5,000 | 1.422 ± 0.032 | 7.863 ± 0.099 | 1.167 ± 0.045 | 2.0309 ± 0.0018 | 0.0288 ± 0.0012 | 0.0665 ± 0.0032 | 10/10 |
| additive | 20,000 | 1.160 ± 0.025 | 8.136 ± 0.202 | 0.520 ± 0.025 | 2.0089 ± 0.0002 | 0.0074 ± 0.0002 | 0.0386 ± 0.0027 | 10/10 |
| additive | 100,000 | 1.033 ± 0.017 | 8.009 ± 0.118 | 0.265 ± 0.008 | 2.0037 ± 0.0001 | 0.0022 ± 0.0000 | 0.0290 ± 0.0012 | 10/10 |
| mlp2x10 | 1,000 | 2.678 ± 0.129 | 8.521 ± 0.392 | 2.890 ± 0.206 | 2.1658 ± 0.0125 | 0.1643 ± 0.0129 | 0.1721 ± 0.0144 | 0/10 |
| mlp2x10 | 5,000 | 1.563 ± 0.069 | 9.145 ± 0.611 | 1.414 ± 0.152 | 2.0297 ± 0.0014 | 0.0279 ± 0.0011 | 0.0954 ± 0.0042 | 9/10 |
| mlp2x10 | 20,000 | 1.376 ± 0.058 | 9.849 ± 0.616 | 0.614 ± 0.076 | 2.0088 ± 0.0003 | 0.0076 ± 0.0003 | 0.0662 ± 0.0011 | 10/10 |
| mlp2x10 | 100,000 | 1.347 ± 0.045 | 10.168 ± 0.535 | 0.277 ± 0.014 | 2.0042 ± 0.0002 | 0.0029 ± 0.0001 | 0.0626 ± 0.0014 | 10/10 |
| mlp2x64 | 1,000 | 2.132 ± 0.044 | 8.796 ± 0.311 | 2.023 ± 0.130 | 2.1262 ± 0.0064 | 0.1238 ± 0.0062 | 0.2683 ± 0.0099 | 0/10 |
| mlp2x64 | 5,000 | 1.626 ± 0.063 | 9.661 ± 0.205 | 0.863 ± 0.051 | 2.0268 ± 0.0013 | 0.0248 ± 0.0011 | 0.1048 ± 0.0042 | 4/10 |
| mlp2x64 | 20,000 | 1.257 ± 0.027 | 9.815 ± 0.223 | 0.438 ± 0.023 | 2.0084 ± 0.0003 | 0.0069 ± 0.0002 | 0.0578 ± 0.0019 | 10/10 |
| mlp2x64 | 100,000 | 1.228 ± 0.022 | 9.770 ± 0.239 | 0.269 ± 0.008 | 2.0041 ± 0.0001 | 0.0023 ± 0.0001 | 0.0391 ± 0.0007 | 10/10 |
| mlp2x128 | 1,000 | 2.465 ± 0.086 | 9.070 ± 0.355 | 1.530 ± 0.097 | 2.1100 ± 0.0054 | 0.1055 ± 0.0050 | 0.1761 ± 0.0083 | 0/10 |
| mlp2x128 | 5,000 | 1.731 ± 0.083 | 9.835 ± 0.115 | 0.833 ± 0.083 | 2.0265 ± 0.0012 | 0.0239 ± 0.0009 | 0.0910 ± 0.0044 | 8/10 |
| mlp2x128 | 20,000 | 1.288 ± 0.019 | 9.958 ± 0.173 | 0.431 ± 0.018 | 2.0079 ± 0.0003 | 0.0065 ± 0.0002 | 0.0521 ± 0.0015 | 10/10 |
| mlp2x128 | 100,000 | 1.254 ± 0.017 | 9.984 ± 0.156 | 0.263 ± 0.006 | 2.0037 ± 0.0002 | 0.0021 ± 0.0001 | 0.0337 ± 0.0007 | 10/10 |

## Paired GLADIUS versus four-step

Each difference is GLADIUS mlp2x10 reward RMSE minus four-step reward RMSE for the same `(N, data_id)`; negative favors GLADIUS. These are descriptive paired means ± standard errors over 10 blocks. The primary four-step floor is ε=1/n₁; the other floors are prespecified sensitivity roles.

| N | Four-step floor | Mean paired difference | GLADIUS lower |
|--:|:--|--:|--:|
| 1,000 | primary | -114.169 ± 13.610 | 9/10 |
| 1,000 | fixed_1e-6 | -114.219 ± 13.469 | 10/10 |
| 1,000 | eps_over_10 | -114.031 ± 13.647 | 9/10 |
| 5,000 | primary | -75.081 ± 20.286 | 10/10 |
| 5,000 | fixed_1e-6 | -75.144 ± 20.263 | 10/10 |
| 5,000 | eps_over_10 | -75.540 ± 20.106 | 9/10 |
| 20,000 | primary | -78.569 ± 18.229 | 10/10 |
| 20,000 | fixed_1e-6 | -77.832 ± 18.538 | 10/10 |
| 20,000 | eps_over_10 | -77.852 ± 18.529 | 10/10 |
| 100,000 | primary | -39.877 ± 17.490 | 9/10 |
| 100,000 | fixed_1e-6 | -39.624 ± 17.539 | 9/10 |
| 100,000 | eps_over_10 | -39.876 ± 17.490 | 9/10 |

## Selection, diagnostics, and provenance

The 0.10 anchor check is diagnostic. Fits with `anchor_fail` remain in every mean, standard error, and paired difference. This follows the author's 2026-10-20 post-hoc ruling in `planning/final-decisions.md` and the follow-ups release amendment. Checkpoint selection used validation observables; E1 truth was used only for evaluation. The separate 2026-10-20 gate amendment removed the fleet signed/k=1 D-reference gate leg after its failure; the frozen design's F1, F3, and D legs passed. These post-hoc changes must accompany any paper use of this matrix.

The four-step comparator is a fixed 2×64 implementation with its stated floor sensitivity, not a tuned best-of-pool comparison. Large four-step reward errors and signed corrected-residual behavior are documented in `experiments/fourstep_r1literal/results.md`; no truth-based reselection or fit dropping was applied here.

Frozen protocol SHA256: `dcba37006a1ef6747671f03fc4e9a88f388ad2f4261086c45a32656788d7afba`; headline data manifest SHA256: `c0df9e599c99f663190f6aff31450f4bda17172c0cae24e9bfe3fe7d24a42c39`; M1 manifest file SHA256: `9eba9bc65145e0838bacf1277e62564867e9ac3230bcddc449b6c24b705f8d7d`; headline fit manifest file SHA256: `18f0f8aaa0bb4ee865b7afc6ac4194c2456c4aff4a30d0f2e072daa1d5551ce7`; E1 truth SHA256: `8426b6ed47ba97161277b625b1e3982acca0c3b4b1f9bccb44508175e07ec5fe`; E1 labels SHA256: `e51729bd450548a19c4516acf9f70363c0e2971000bcf59aadf522e26441fc8d`. Individual selected checkpoint file hashes and fit provenance are in `MATRIX_FITS.csv`. Recomputed headline metrics and checkpoint hashes match all 40 previously reported `HEADLINE_FITS.csv` rows.

Machine-readable files: `MATRIX_FITS.csv` (240 selected fits), `MATRIX_SUMMARY.csv` (24 class × N rows), `MATRIX_FOURSTEP_PAIRED.csv` (40 data-ID pairs for each of three floor roles), and `MATRIX_FOURSTEP_SUMMARY.csv` (12 paired summaries).
