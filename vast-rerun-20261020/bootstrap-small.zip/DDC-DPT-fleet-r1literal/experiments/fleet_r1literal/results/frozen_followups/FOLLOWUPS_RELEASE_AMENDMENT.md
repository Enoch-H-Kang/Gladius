# Frozen follow-ups release amendment — author ruling 2026-10-20 13:58 PDT

This record is appended beside `status.json`. The prior held status is preserved verbatim as `status.original_held_error.json` (SHA256 `24391d91833f61f263f4e6e4ee8f1ed82880acd3e1b0ed50a172c85dc575c5fa`), and `LINEAR_LOCK_DIAGNOSIS.md` remains unchanged (SHA256 `d12c185eb3ab1fd91ad9d354350f52760dafd7738feb4004c2923713f6574e4b`). The release follows the author's decision in `planning/final-decisions.md`: anchor error is a reported diagnostic, not a fit, class, or row disqualification. This is a **post-hoc reporting/selection amendment** and must be disclosed with every matrix report.

The frozen protocol SHA256 remains `dcba37006a1ef6747671f03fc4e9a88f388ad2f4261086c45a32656788d7afba`; the completed 108-fit FL manifest SHA256 remains `f344c29a8eb3a612cdf20591b3a9427135c534da8bb4d04a44c88d87a380aee3`. The original 0.10 anchor tolerance stays in every fit configuration and appears as a diagnostic threshold in output tables. No DGP constant or protected pool is changed.

## Selection and reporting rule

For a class with a successful three-block observable lock, keep the original lock, including its 0.001 median-validation-NLL tie band and original tie ordering. If no such lock exists, select among configurations with finite saved validation NLL and anchor RMSE on all three development blocks, using the lowest median validation NLL, then median anchor RMSE, shorter horizon, rho=1, and smaller learning rate. This fallback is validation-observable; headline truth is never used. It does not relabel `anchor_fail` as `ok`. A class with no three-block observable configuration remains an explicit hold for investigation; missing records are never invented.

Every scheduled fit remains in stage accounting and the per-fit diagnostic CSV, including optimizer failures, anchor failures, and missing records. Each saved horizon row has numeric validation anchor RMSE when measured, the unchanged 0.10 threshold, explicit pass/fail, fit status, checkpoint status, and validation NLL. An unmeasured anchor is labeled `unmeasured` while its fit still counts in the denominator. The M1 table combines its 200 new fits with the 40 existing 2x10 headline fits. Coupled EL and EX tables carry the K31 reference caveat in each row.

## FL decisions from the completed 108 fits

| Class | Selection | lr_q | rho | Horizon | Median validation NLL | Block 9400/9401/9402 anchor RMSE | Anchor diagnostic |
|---|---|---:|---:|---:|---:|---|---|
| linear | observable fallback | 0.001 | 1 | 50,000 | 2.019440 | 0.104125 / 0.106581 / 0.102100 | fail / fail / fail |
| mlp1x5 | original successful lock | 0.001 | 3 | 50,000 | 2.022233 | 0.081441 / 0.091050 / 0.093746 | pass / pass / pass |
| additive | original successful lock | 0.001 | 1 | 10,000 | 2.012377 | 0.034891 / 0.032688 / 0.039788 | pass / pass / pass |
| mlp2x10 | original successful lock | 0.001 | 1 | 20,000 | 2.015668 | 0.075034 / 0.078505 / 0.058221 | pass / pass / pass |
| mlp2x64 | original successful lock | 0.0003 | 3 | 10,000 | 2.011890 | 0.061468 / 0.056742 / 0.051985 | pass / pass / pass |
| mlp2x128 | original successful lock | 0.0001 | 1 | 20,000 | 2.013301 | 0.058486 / 0.050998 / 0.051095 | pass / pass / pass |

The pre-existing protected 2x10 headline row retains its author-frozen `lr_q=0.001`, `rho=1`, 50,000-step cap; it is not refit at the diagnostic FL 20,000-step lock. The five new M1 rows use their FL selections above. The lock record is `locks_FL_followup.json` (SHA256 `f9b6d47bfef4efe5f6b812aac452d8315db76668a2e436d53aafe8e6778b7c6c`).

## Released chain

Resume the existing detached controller after verifying the 40/40 headline and integrity gate: M1, 200 fits (five classes × four N × ten protected blocks), then coupled data and pilot preparation, EL 54 lock fits, and EX 45 reporting fits. Each fit uses one compute thread; the existing admission controller limits this pool to 36 workers and samples shared baker load under the 44-thread total cap. Accounting and DONE markers are written only after all scheduled slots have terminal records. The extension's K31 DGP/source hash checks, pilot acceptance, and data artifact integrity checks remain gates. Its historical absolute-Q acceptance is **FAIL** (8/20 V4 starts outside 3SE+.01); the empirical raw-Q level sensitivity 0.086–0.095 and advantage sensitivity 0.001–0.0024 remain attached to extension outputs and are not global bounds.

Basis: baker `fleet-r1literal` HEAD `e1dcab8da30a3ea887b2aeee08d3c87b18c65919` before this amendment; no FL fit was rerun for this selection.
