# Linear-class observable rate-lock diagnosis

Frozen follow-up status: `held_error`; `RuntimeError: linear: no 3/3 eligible observable rate lock`. The 108-slot FL accounting is complete; all 18 linear fits (six `(lr_q, rho)` pairs × blocks 9400–9402) have complete fit records. The lock chooser checks the three saved horizon checkpoints for each rate pair and requires all three blocks to have `status=ok` at the same horizon.

Every cell below is `checkpoint status; validation anchor RMSE / validation NLL @ selected step`. Validation metrics are observable and are not E1 truth scores.

| lr_q | rho | block | 10k | 20k | 50k |
|---:|---:|---:|---|---|---|
| 0.0001 | 1 | 9400 | anchor_fail; 1.708943 / 2.674151 @ 10000 | anchor_fail; 1.272079 / 2.509406 @ 20000 | anchor_fail; 0.943900 / 2.356672 @ 50000 |
| 0.0001 | 1 | 9401 | anchor_fail; 1.755611 / 2.665900 @ 10000 | anchor_fail; 1.291885 / 2.487561 @ 20000 | anchor_fail; 0.950996 / 2.332810 @ 50000 |
| 0.0001 | 1 | 9402 | anchor_fail; 1.737276 / 2.682406 @ 10000 | anchor_fail; 1.267249 / 2.501517 @ 20000 | anchor_fail; 0.931670 / 2.331408 @ 50000 |
| 0.0001 | 3 | 9400 | anchor_fail; 1.726235 / 2.686424 @ 10000 | anchor_fail; 1.282797 / 2.511166 @ 20000 | anchor_fail; 0.949680 / 2.357425 @ 50000 |
| 0.0001 | 3 | 9401 | anchor_fail; 1.772623 / 2.679475 @ 10000 | anchor_fail; 1.302367 / 2.489038 @ 20000 | anchor_fail; 0.956933 / 2.333353 @ 50000 |
| 0.0001 | 3 | 9402 | anchor_fail; 1.755265 / 2.696726 @ 10000 | anchor_fail; 1.278212 / 2.503128 @ 20000 | anchor_fail; 0.937612 / 2.332149 @ 50000 |
| 0.0003 | 1 | 9400 | anchor_fail; 0.953979 / 2.337170 @ 10000 | anchor_fail; 0.668287 / 2.194724 @ 20000 | anchor_fail; 0.327389 / 2.093219 @ 50000 |
| 0.0003 | 1 | 9401 | anchor_fail; 0.960765 / 2.313446 @ 10000 | anchor_fail; 0.665036 / 2.177735 @ 20000 | anchor_fail; 0.322730 / 2.079915 @ 50000 |
| 0.0003 | 1 | 9402 | anchor_fail; 0.943043 / 2.311564 @ 10000 | anchor_fail; 0.658774 / 2.156402 @ 20000 | anchor_fail; 0.329243 / 2.047923 @ 50000 |
| 0.0003 | 3 | 9400 | anchor_fail; 0.968559 / 2.340643 @ 10000 | anchor_fail; 0.677408 / 2.197102 @ 20000 | anchor_fail; 0.333879 / 2.094374 @ 50000 |
| 0.0003 | 3 | 9401 | anchor_fail; 0.975620 / 2.316840 @ 10000 | anchor_fail; 0.674297 / 2.180084 @ 20000 | anchor_fail; 0.330056 / 2.081033 @ 50000 |
| 0.0003 | 3 | 9402 | anchor_fail; 0.958086 / 2.315590 @ 10000 | anchor_fail; 0.668507 / 2.158978 @ 20000 | anchor_fail; 0.336233 / 2.049102 @ 50000 |
| 0.001 | 1 | 9400 | anchor_fail; 0.354862 / 2.091605 @ 10000 | anchor_fail; 0.158559 / 2.041576 @ 20000 | anchor_fail; 0.104125 / 2.022375 @ 50000 |
| 0.001 | 1 | 9401 | anchor_fail; 0.355047 / 2.077461 @ 10000 | anchor_fail; 0.160871 / 2.032581 @ 20000 | anchor_fail; 0.106581 / 2.019440 @ 50000 |
| 0.001 | 1 | 9402 | anchor_fail; 0.359614 / 2.046074 @ 10000 | anchor_fail; 0.161758 / 2.001822 @ 20000 | anchor_fail; 0.102100 / 1.989228 @ 49000 |
| 0.001 | 3 | 9400 | anchor_fail; 0.363135 / 2.094226 @ 10000 | anchor_fail; 0.159165 / 2.042162 @ 20000 | anchor_fail; 0.103996 / 2.022432 @ 50000 |
| 0.001 | 3 | 9401 | anchor_fail; 0.363238 / 2.080062 @ 10000 | anchor_fail; 0.161691 / 2.033065 @ 20000 | anchor_fail; 0.107135 / 2.019599 @ 47000 |
| 0.001 | 3 | 9402 | anchor_fail; 0.369784 / 2.048887 @ 10000 | anchor_fail; 0.163889 / 2.002306 @ 20000 | anchor_fail; 0.102678 / 1.989258 @ 49000 |

## Why no lock exists

The selector defines `ok` only when at least one finite validation checkpoint at or after step 5,000 has anchor RMSE ≤ 0.10. Otherwise it saves an `anchor_fail` checkpoint by the frozen fallback score NLL + A². All 54 horizon selections above are `anchor_fail`, so there is no candidate for the later 0.001 NLL tie band or anchor-error ordering. This is an eligibility failure, not a tie-break edge case.

- `lr_q=0.0001, rho=1` at 50k: 0/3 eligible; anchor RMSE 0.943900, 0.950996, 0.931670; median validation NLL 2.332810.
- `lr_q=0.0001, rho=3` at 50k: 0/3 eligible; anchor RMSE 0.949680, 0.956933, 0.937612; median validation NLL 2.333353.
- `lr_q=0.0003, rho=1` at 50k: 0/3 eligible; anchor RMSE 0.327389, 0.322730, 0.329243; median validation NLL 2.079915.
- `lr_q=0.0003, rho=3` at 50k: 0/3 eligible; anchor RMSE 0.333879, 0.330056, 0.336233; median validation NLL 2.081033.
- `lr_q=0.001, rho=1` at 50k: 0/3 eligible; anchor RMSE 0.104125, 0.106581, 0.102100; median validation NLL 2.019440.
- `lr_q=0.001, rho=3` at 50k: 0/3 eligible; anchor RMSE 0.103996, 0.107135, 0.102678; median validation NLL 2.019599.

The closest tested pair is `lr_q=0.001, rho=1` at 50k: anchor errors 0.104125, 0.106581, 0.102100. Even the smallest error exceeds 0.10 by 0.002100; all three blocks need an eligible checkpoint. Inspecting every saved validation trace at or after step 5,000 gives the same minimum errors for this pair (at steps 50,000, 50,000, and 49,000). `rho=3` is similarly ineligible (best 0.102678). No threshold equality, rounding, or checkpoint-selection edge case explains the hold.

## Smallest protocol-consistent next steps

Preserve the hold and report the linear class as unselectable under the frozen 3/3 rule. The existing 50k cap, rate grid, and 0.10 anchor tolerance contain no eligible linear lock; the other five classes cannot be promoted by the current fail-closed controller while this required class has none. If a full six-class comparison is required, an explicit prospective protocol amendment is needed before any additional fit: for example a predeclared longer horizon or changed linear model/rate grid, with fresh development pools and the same observable 3/3 gate. Relaxing the tolerance, relabeling `anchor_fail` as eligible, or picking the lowest-NLL ineligible rate would change the frozen rule and is not a remedy under the current protocol. No fit was launched or rule changed for this diagnosis.

Provenance: FL manifest SHA256 `f344c29a8eb3a612cdf20591b3a9427135c534da8bb4d04a44c88d87a380aee3`; freeze SHA256 `dcba37006a1ef6747671f03fc4e9a88f388ad2f4261086c45a32656788d7afba`; baker worktree HEAD `1ae1382f8bf57da65b771d8755fc81ba13590f3e`.
