"""Conditionally truncated exponential with the specified mean."""
import numpy as np
from scipy.optimize import brentq
from .params import MU

T = float(brentq(lambda t: 1/t - 5/np.expm1(5*t) - 1, .1, 2, xtol=5e-16))
RHO = T/MU
L = 5*MU
Z = -np.expm1(-RHO*L)

def draw(u, f):
    u = np.asarray(u, dtype=np.float64)
    if np.any((u < 0) | (u > 1)):
        raise ValueError("uniform outside [0,1]")
    return -np.log1p(-u*Z[f])/RHO[f]

def cdf(d, f):
    d = np.asarray(d, dtype=np.float64)
    return np.clip(-np.expm1(-RHO[f]*d)/Z[f], 0, 1)

def mass(l, u, f):
    l, u = np.asarray(l), np.asarray(u)
    return np.exp(-RHO[f]*l)*(-np.expm1(-RHO[f]*(u-l)))/Z[f]

def first_moment(l, u, f):
    p = mass(l, u, f)
    return (l+1/RHO[f])*p - (u-l)*np.exp(-RHO[f]*u)/Z[f]

def cap_mass(x, f):
    c = 1-np.asarray(x)
    return np.where(c <= 0, 1., np.where(c >= L[f], 0., mass(np.maximum(c, 0), L[f], f)))
