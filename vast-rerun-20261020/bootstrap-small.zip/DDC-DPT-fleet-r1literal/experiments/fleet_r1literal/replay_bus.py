"""Three original-bus P0 replays against base trainer and injected-default trainer."""
import hashlib
import json
import os
import platform
import subprocess
import time
from pathlib import Path
import numpy as np
import torch
from experiments.fleet_capacity_one.fleet import train as newtrain
from experiments.fleet_capacity_one.tuning.data_io import load_bus

ROOT=Path(__file__).resolve().parents[2]
OLD_PATH="experiments/fleet_capacity_one/fleet/train.py"
BASE="5c6cfcfa3bb449239a4386473e3214f42093111d"

def hashfile(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def run(export,output):
    start=time.perf_counter()
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    source=subprocess.check_output(["git","show",BASE+":"+OLD_PATH],cwd=ROOT).decode()
    oldsha=hashlib.sha256(source.encode()).hexdigest()
    ns={"__name__":"experiments.fleet_capacity_one.fleet.train_base",
        "__package__":"experiments.fleet_capacity_one.fleet"}
    exec(compile(source,OLD_PATH,"exec"),ns)
    manifest=json.loads((ROOT/"experiments/fleet_capacity_one/results/tuning/manifests/manifest_P0.json").read_text())
    rows=[]
    for spec in manifest["fits"][:3]:
        data=load_bus(export,spec["n_chains"])
        cfg={k:v for k,v in spec["config"].items() if k!="N"}
        pair=[]
        for label,fn in (("base",ns["fit"]),("new",newtrain.fit)):
            ck=output/spec["fit_id"]/label
            rec=fn(data,cfg,spec["seeds"],horizons=spec["horizons"],ckpt_dir=str(ck))
            pair.append((rec,ck))
        old,new=pair[0][0],pair[1][0]
        trace_equal=old["trace"]==new["trace"]
        array_checks={}
        for checkpoint in ("ckpt_h5000.pt","ckpt_final.pt"):
            a=torch.load(pair[0][1]/checkpoint,weights_only=False)
            b=torch.load(pair[1][1]/checkpoint,weights_only=False)
            for net in ("q","z"):
                for key in a[net]:
                    x=a[net][key].detach().cpu().numpy()
                    y=b[net][key].detach().cpu().numpy()
                    array_checks[checkpoint+":"+net+":"+key]=bool(np.array_equal(x,y))
        result=dict(fit_id=spec["fit_id"],trace_equal=trace_equal,
                    array_count=len(array_checks),arrays_equal=all(array_checks.values()),
                    array_checks=array_checks,base_trace=old["trace"],new_trace=new["trace"],
                    base_final_hash=old["horizons"][5000]["hash"],
                    new_final_hash=new["horizons"][5000]["hash"])
        rows.append(result)
        print(json.dumps({k:v for k,v in result.items() if k not in ("array_checks","base_trace","new_trace")}),flush=True)
    record=dict(base_commit=BASE,old_train_sha256=oldsha,new_train_sha256=hashfile(ROOT/OLD_PATH),
                export_sha256=hashfile(export),export_path=str(export),
                manifest_sha256=hashfile(ROOT/"experiments/fleet_capacity_one/results/tuning/manifests/manifest_P0.json"),
                env=dict(python=platform.python_version(),torch=torch.__version__,numpy=np.__version__,
                         threads={x:os.getenv(x) for x in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS")}),
                command="python -m experiments.fleet_r1literal.replay_bus EXPORT OUTPUT",
                fits=rows,passed=all(r["trace_equal"] and r["arrays_equal"] for r in rows),
                wall_s=time.perf_counter()-start)
    (output/"replay.json").write_text(json.dumps(record,indent=2)+"\n")
    print(json.dumps(dict(passed=record["passed"],fits=len(rows),wall_s=record["wall_s"])),flush=True)
if __name__=="__main__":
    import sys
    run(*sys.argv[1:])
