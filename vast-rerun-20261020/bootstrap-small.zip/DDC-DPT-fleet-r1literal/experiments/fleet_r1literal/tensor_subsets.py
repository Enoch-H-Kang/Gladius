"""Subset-action Bellman continuation, with replaced axes fixed at zero."""
import numpy as np
from scipy.special import logsumexp

def apply_axes(array,kernels):
    out=array
    for axis,P in enumerate(kernels):
        out=np.moveaxis(np.tensordot(P,out,axes=([1],[axis])),0,axis)
    return out

def bellman(values,kernels,rewards,beta):
    F=len(kernels); q=[]
    for action in range(1<<F):
        out=values
        # Fix axes before contraction, in descending order to retain indices.
        keep=[f for f in range(F) if not (action>>f)&1]
        for f in reversed(range(F)):
            if f not in keep: out=np.take(out,0,axis=f)
        cont=apply_axes(out,[kernels[f] for f in keep]) if keep else np.asarray(out)
        shape=[values.shape[f] if f in keep else 1 for f in range(F)]
        q.append(rewards[action]+beta*np.asarray(cont).reshape(shape))
    return logsumexp(np.stack(np.broadcast_arrays(*q),axis=0),axis=0)
