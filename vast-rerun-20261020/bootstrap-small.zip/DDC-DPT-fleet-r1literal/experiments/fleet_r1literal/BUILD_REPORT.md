# R1-literal build chunk 1: reference and descriptive pilot

Base commit: 5c6cfcfa3bb449239a4386473e3214f42093111d. Worktree: `~/DDC-DPT-fleet-r1literal` on baker.
Protocol SHA-256: `e7a439f56857ba73d4099c56d1d3d43865942c7a0617ecac343a23b948b0875c`.
DGP SHA-256: `6dbaaa5168f052e9bbd96530cba04c19de1239a09547cb938ea9279a72e0e40d`; action table SHA-256: `da7a59f317f4c3ca70e4a83ceb1666985a06d1c935dadffab8fb6a82f8c610a3`.
Reference artifact SHA-256: `5a96631a2d78ca28e80e1ae0916f99ae6d261963d57014b1085b44be218daaef`.

## Built

Independent five-bus truncated-exponential simulator, analytic rewards, 32-action map, five component solvers, joint query/assembly, subset-action tensor controls, truth-stripped 32-action loader/export, seven model classes, trainer injection, fleet evaluator reload, fail-closed launcher, and evaluator-only scoring interface.
Original-bus trainer default path was replayed bitwise. No merge, production data freeze, estimator fits, or pilot acceptance was performed.

## Continuous reference certification

All five components use K=4001 saved value nodes after solving K=1001, 2001, 4001 and 8001. The positive truncated-exponential root is `0.9602015099445036`. The per-bus defects enclose the continuous residual on every grid interval using a global analytic second-derivative bound, 16 subdivisions per cell, and a 1e-9 arithmetic allowance. Shifted knots and the truncation junction coincide with original nodes for the frozen decimal support values and these grids.

| Bus | Saved-grid residual | Continuous defect upper bound | K2001→4001 max Q | K4001→8001 max Q | K4001 solve wall s |
|---:|---:|---:|---:|---:|---:|
| 1 | 9.47e-12 | 9.05e-08 | 2.18e-06 | 5.46e-07 | 0.508 |
| 2 | 9.44e-12 | 1.16e-07 | 2.8e-06 | 7e-07 | 0.517 |
| 3 | 9.15e-12 | 5.46e-08 | 1.22e-06 | 3.04e-07 | 0.492 |
| 4 | 9.33e-12 | 1.3e-07 | 3.32e-06 | 8.31e-07 | 0.501 |
| 5 | 9.44e-12 | 1e-07 | 2.21e-06 | 5.52e-07 | 0.498 |

Joint absolute-Q bound: `9.33573322508e-06` = 19 × sum of the five enclosed defects + `1e-08` separate query allowance. Target: at most 1e-4. Numerical reference status: **certified**. Total four-grid solve/check wall time: 13.913 s.
The query allowance covers suffix-sum and elementary-function roundoff in the float64 implementation; observed independent direct-hat errors were at most 3.2e-14. Its value is a conservative arithmetic allowance, not the observed difference.
Composite Gauss–Legendre order-20 maximum discrepancy: 2.84e-14; kernel row-sum maximum: 2.22e-16; minimum weight: 0. K=9 five-axis tensor fixed-point residual: 4.63e-11; off-grid tensor/additive Q gap: 2.84e-14. Two-bus K=401 tensor residual: 1.89e-11, off-grid same-grid gap: 2.84e-14, K401 versus fine K4001 max difference: 0.000164.
Successive-grid RMS order estimates by bus: 1.999997, 1.999998, 1.999999, 1.999997, 1.999999. K4001 leading-error max estimates: 7.28e-07, 9.34e-07, 4.06e-07, 1.11e-06, 7.37e-07. These are diagnostics, not corrections to the continuous bound.
One million independent increment draws per bus and one million categorical/product draws were checked with fixed streams. Maximum categorical-versus-product share gap: 0.000557. The 20 × 2,000 × 450 component and 20 × 1,000 × 450 joint forward checks were inside all 120 simultaneous intervals (critical 3.529296); forward wall time 52.184 s.
Float32 training-state copies are separate from the float64 reference. On a 10,000-state panel, the observed maximum Q change from state rounding was 6.66e-07; this is a panel result, not a uniform bound.

## Descriptive pilot (no acceptance declaration)

Final stream protocol: 10,000 chains × 100 retained rows = 1,000,000 transitions; burn-in 0 because the largest early/late KS statistic was 0.027175 (threshold 0.1). Pilot wall time 6.201 s.
| Criterion | Observed | CC D3 hybrid | LC C3 |
|---|---:|---|---|
| Anchor action 0 share | 0.393975 | [.25,.95] | [.25,.95] |
| Per-bus replacement share | 0.157050, 0.164848, 0.190992, 0.154421, 0.183871 | ≥.02 each, with keep ≥.02 | [.03,.30] each |
| Per-bus keep share | 0.842950, 0.835152, 0.809008, 0.845579, 0.816129 | ≥.02 each | Descriptive |
| Singleton action shares | 0.072915, 0.077162, 0.092793, 0.071534, 0.088323 | Descriptive | ≥.01 each |
| Per-bus p95−p05 mileage span | 0.377804, 0.407166, 0.456462, 0.393967, 0.406893 | ≥.25 each | ≥.25 each |
| Minimum of all 32 action shares | 0.000144 | Descriptive | Descriptive |

Both proposed sets are met by the observed pilot, but neither is approved. The currently approved rule fails: anchor share is below .50 and the minimum action share is below .02. The approved 32-action rule is mathematically impossible together with anchor share ≥.50.
Counts by number of replacements 0–5: 393975, 402727, 165258, 34365, 3531, 144.
All 32 action counts/shares, cap mass, quantiles, replacement mileages, tails, early/late occupancy, correlations and chain-clustered SEs are in `artifacts/pilot/pilot_recording.json`.

## Compatibility and stopping points

Three P0 original-bus default-path fits: all three loss traces and all 72 checkpoint arrays matched bitwise; replay wall time 235.800 s. The replay archive records input/code hashes, commands, environment, arrays and selected checkpoint hashes.
Fleet-specific unittest suite: 21 passed. Existing suite: 60 run, 59 passed, one skipped. The bus fixture was reconstructed from immutable `review:bus/Zurcher_collect_data.py` (SHA-256 `9cc9257513c42302b78c5ff0cb922ecee5465bab552984d3d595a4933dd64b7c`) rather than copied from the mutable live checkout.
Maximum observed project compute allocation while the 40-worker bus B2 runner was active: its 40 fit workers, controller/evaluator reservation of 2, plus at most 2 one-thread R1-literal jobs = 44 tokens. The existing bus runner was not wired to a new atomic shared ledger; this remains an operational deviation for later work.
The first pilot run used an incorrect stream-key field layout; its files are retained with `preseedfix` suffix. The final report uses a corrected six-field seed expansion in `pilot_recording.json`. No DGP constant or tolerance was changed.
Full source hashes are in `source_inventory.json`. No pilot PASS/data freeze, fleet estimator fits, comparator build, push, or merge was performed. U1, U2 and U3 remain at the spec's stated stop points.
