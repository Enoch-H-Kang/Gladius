"""Component and joint 32-action lookahead queries."""
import numpy as np
from .params import ACTIONS,F

class Reference:
    def __init__(self,components):
        if len(components)!=F: raise ValueError("five components required")
        self.components=components
    def component_query(self,f,x):
        return self.components[f].query(x)
    def joint_query(self,states):
        s=np.atleast_2d(np.asarray(states,dtype=np.float64))
        if s.shape[1]!=F: raise ValueError("expected five-dimensional states")
        binary=np.empty((len(s),F,2))
        val=np.empty((len(s),F))
        for f,c in enumerate(self.components):
            q0,q1,v,_=c.query(s[:,f])
            binary[:,f,0]=q0; binary[:,f,1]=q1; val[:,f]=v
        Q=np.zeros((len(s),32))
        for f in range(F): Q+=binary[:,f,ACTIONS[:,f]]
        V=val.sum(1)
        pi=np.exp(Q-V[:,None])
        return Q,V,pi
