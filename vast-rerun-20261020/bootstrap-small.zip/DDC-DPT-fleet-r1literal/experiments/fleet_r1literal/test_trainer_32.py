"""32-action rerun of the inherited trainer contract controls."""
import tempfile
import unittest
import numpy as np
import torch
from experiments.fleet_capacity_one.fleet import losses,train
from .trainer import fit_fleet
from .models import factory,initialize

def fixture(no_val_anchor=False):
    rng=np.random.default_rng(43)
    def part(n):
        a=np.arange(n,dtype=np.int64)%32
        if no_val_anchor:a[a==0]=1
        return dict(s=rng.random((n,5)).astype(np.float32),
                    sp=rng.random((n,5)).astype(np.float32),
                    a=a,r0=-rng.random(n).astype(np.float32))
    tr=part(128);va=part(64)
    if not no_val_anchor:tr["a"][0]=0
    return dict(train=tr,val=va,meta=dict(n_actions=32,anchor_action=0,
                state_scale=1.,arm="independent_r1literal"))

def cfg(**kw):
    return dict(architecture="mlp2x10",loss="signed",k=1,bias="zero",batch=16,
                cap_q=3,val_every=1,elig_start=1,anchor_tol=100.,**kw)

SEEDS=dict(qinit=101,zinit=102,ce=103,extrazeta=104,anchor=105)

class Trainer32Tests(unittest.TestCase):
    def test_shape_and_mask(self):
        x=torch.zeros(4,dtype=torch.float64)
        with self.assertRaises(AssertionError):
            losses.be_term(x[:,None],x,x,x,x>0,.95,"none")
        a=torch.tensor([0,1,31,0]);u=losses.u_product(x+2,x,x+.2,x,.95)
        self.assertAlmostEqual(float(losses.be_term(x+2,x,x+.2,x,a==0,.95,"none")),
                               float(u[[0,3]].sum()/4),places=12)
        self.assertEqual(float(losses.be_term(x,x,x,x,a==32,.95,"none")),0.)
    def test_signed_clip_abs_gradients(self):
        r=torch.zeros(2,dtype=torch.float64)
        v=torch.tensor([0.,3.],dtype=torch.float64)
        z=r.clone()
        grads=[]
        for loss in ("none","clip0","abs"):
            q=torch.tensor([2.,.1],dtype=torch.float64,requires_grad=True)
            losses.be_term(q,r,v,z,torch.ones(2,dtype=torch.bool),.95,loss).backward()
            grads.append(q.grad.detach().clone())
        self.assertAlmostEqual(float(grads[1][1]),0.)
        self.assertAlmostEqual(float(grads[0][1]),-float(grads[2][1]),places=12)
    def test_two_successor_signed_identity(self):
        v=torch.tensor([.2,2.6],dtype=torch.float64,requires_grad=True)
        z=v.mean().detach()
        q=torch.tensor([1.3,1.3],dtype=torch.float64,requires_grad=True)
        r=torch.full((2,),-.4,dtype=torch.float64)
        val=losses.be_term(q,r,v,z.expand(2),torch.ones(2,dtype=torch.bool),.95,"none")
        self.assertAlmostEqual(float(val),(1.3+.4-.95*float(z))**2,places=12)
        val.backward();self.assertTrue(torch.isfinite(v.grad).all())
    def test_update_counts_and_paired_batches(self):
        probes={};records={}
        for k in (1,3,5,10):
            probe=[];settings=cfg();settings["k"]=k
            records[k]=fit_fleet(fixture(),settings,SEEDS,probe=probe)
            probes[k]=probe
            c=records[k]["counts"]
            self.assertEqual((c["q_updates"],c["z_updates"],c["draws"]),(3,3*k,3*(k+1)))
        self.assertEqual([x for x in probes[1] if x[0]=="ce"],
                         [x for x in probes[10] if x[0]=="ce"])
        self.assertEqual([x for x in probes[1] if x[0]=="anchor"],
                         [x for x in probes[10] if x[0]=="anchor"])
    def test_fresh_start_and_parameter_isolation(self):
        data=fixture()
        rec1=fit_fleet(data,cfg(),SEEDS)
        torch.manual_seed(999);np.random.seed(999)
        rec2=fit_fleet(data,cfg(),SEEDS)
        self.assertEqual([x["hash"] for x in rec1["trace"]],[x["hash"] for x in rec2["trace"]])
        self.assertNotEqual(rec1["trace"][-1]["hash"],
                            fit_fleet(data,cfg(),{**SEEDS,"qinit":999})["trace"][-1]["hash"])
        q=initialize(factory(cfg(),data["meta"]),7,0.)
        z=initialize(factory(cfg(),data["meta"]),8,0.)
        self.assertFalse({id(p) for p in q.parameters()} & {id(p) for p in z.parameters()})
    def test_checkpoint_and_anchor_free_failure(self):
        with tempfile.TemporaryDirectory() as td:
            rec=fit_fleet(fixture(),cfg(),SEEDS,ckpt_dir=td)
            ck=torch.load(td+"/ckpt_final.pt",weights_only=False)
            self.assertEqual(ck["hash"],rec["trace"][-1]["hash"])
        no=fit_fleet(fixture(no_val_anchor=True),cfg(),SEEDS)
        self.assertEqual(no["horizons"][3]["status"],"failed")
        self.assertEqual(no["trace"][-1]["n_anchor"],0)
    def test_anchor_only_and_anchor_free_batches(self):
        for action in (0,17):
            data=fixture()
            data["train"]["a"][:]=action
            rec=fit_fleet(data,cfg(),SEEDS)
            self.assertEqual(rec["counts"]["q_updates"],3)
            self.assertTrue(all(np.isfinite(x["nll"]) for x in rec["trace"]))
    def test_truth_unavailable_import_path(self):
        import inspect
        source=inspect.getsource(train)+inspect.getsource(__import__(
            "experiments.fleet_r1literal.trainer",fromlist=["fit_fleet"]))
        self.assertNotIn("from .oracle",source)
        self.assertNotIn("import rewards",source)
        self.assertNotIn("bus_truth",source)

if __name__=="__main__":unittest.main()
