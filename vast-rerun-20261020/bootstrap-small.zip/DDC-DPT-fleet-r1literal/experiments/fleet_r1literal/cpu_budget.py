"""Measure baker CPU use before admitting new one-thread fit processes."""
import math
import time
from pathlib import Path

STAT = Path('/proc/stat')

def _sample():
    fields = [int(x) for x in STAT.read_text().splitlines()[0].split()[1:9]]
    return sum(fields), fields[3] + fields[4]

def busy_cores(interval=.5):
    """Current CPU cores busy across all baker users, including our own fits."""
    total0, idle0 = _sample()
    time.sleep(interval)
    total1, idle1 = _sample()
    delta = total1 - total0
    if delta <= 0:
        return 64.0
    return max(0., (delta - (idle1 - idle0)) / delta * 64)

def worker_budget(active, cap=44, reserve=2, max_workers=36):
    """Keep active workers plus measured baker load within the user cap."""
    return min(max_workers, active + max(0, math.floor(cap - reserve - busy_cores())))
