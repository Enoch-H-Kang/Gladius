"""Detached, fail-closed follow-ups to the author-frozen fleet headline."""
import csv
import fcntl
import hashlib
import json
import math
import os
import resource
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOG = ROOT / "artifacts/logs"
OUT = ROOT / "results/frozen_followups"
FITS = ROOT / "artifacts/frozen_followups"
FREEZE = ROOT / "protocol/common_protocol_freeze.json"
HEAD = ROOT / "artifacts/data/headline_freeze_manifest.json"
DEV = ROOT / "artifacts/data/development_freeze_manifest.json"
HRESULT = ROOT / "results/headline_frozen"
SOURCE = Path.home() / "DDC-DPT-fleet/experiments/fleet_capacity_one"
PY = sys.executable
FROZEN_SHA = "dcba37006a1ef6747671f03fc4e9a88f388ad2f4261086c45a32656788d7afba"
HEAD_SHA = "c0df9e599c99f663190f6aff31450f4bda17172c0cae24e9bfe3fe7d24a42c39"
CLASSES = ("linear", "mlp1x5", "additive", "mlp2x10", "mlp2x64", "mlp2x128")
RATES = ((1e-4, 1), (1e-4, 3), (3e-4, 1), (3e-4, 3), (1e-3, 1), (1e-3, 3))
STREAMS = ("qinit", "zinit", "ce", "anchor", "eval", "extrazeta")
HORIZONS = (10000, 20000, 50000)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, sort_keys=True, indent=2, allow_nan=False) + "\n")
    os.replace(tmp, path)


def status(stage, state, **kw):
    old = json.loads((OUT / "status.json").read_text()) if (OUT / "status.json").exists() else {}
    old.pop("reason", None)
    old.update(stage=stage, state=state, updated_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), **kw)
    save(OUT / "status.json", old)
    print(json.dumps(old), flush=True)


def frozen():
    assert sha(FREEZE) == FROZEN_SHA and sha(HEAD) == HEAD_SHA
    fr = json.loads(FREEZE.read_text())
    assert fr["headline_manifest_sha256"] == HEAD_SHA
    assert fr["design"] == dict(architecture="mlp2x10", batch=1024, bias="anchor",
                               c_be=1.0, horizon=50000, k=10, loss="signed",
                               lr_q=.001, optimizer="adamw", rho=1.0)
    return fr


def headline_ready():
    gate = HRESULT / "feasibility.json"
    amendment = HRESULT / "feasibility_amendment.json"
    if not gate.exists():
        return "waiting" if headline_controller_live() else "held_headline_failure"
    if not amendment.exists():
        return "held_feasibility"
    from .frozen_headline_pipeline import admission
    admission()
    if not (LOG / "H_frozen.DONE").exists():
        return "waiting" if headline_controller_live() else "held_headline_failure"
    m = json.loads((HRESULT / "manifest.json").read_text())
    a = json.loads((HRESULT / "accounting.json").read_text())
    assert m["n_fits"] == a["scheduled"] == a["records"] == 40
    assert a["manifest_sha256"] == sha(HRESULT / "manifest.json")
    assert a["freeze_sha256"] == FROZEN_SHA
    for s in m["fits"]:
        r = FITS.parent / "headline_frozen/fits" / s["fit_id"] / "record.json"
        assert r.exists() and json.loads(r.read_text())["manifest_sha256"] == m["sha256"]
    return "ready"


def headline_controller_live():
    for p in Path("/proc").iterdir():
        if not p.name.isdigit():
            continue
        try:
            cmd = (p / "cmdline").read_bytes()
        except OSError:
            continue
        if b"run_frozen_headline.sh" in cmd or b"frozen_headline_pipeline\x00run" in cmd:
            return True
    return False


def base_config(arch, lr=.001, rho=1.0, horizon=50000):
    widths = {"linear": 0, "mlp1x5": 5, "additive": 16, "mlp2x10": 10,
              "mlp2x64": 64, "mlp2x128": 128}
    return dict(anchor_tol=.1, architecture=arch, batch=1024, beta=.95,
                bias="anchor", c_be=1., cap_q=horizon, depth=1 if arch == "mlp1x5" else 2,
                elig_start=5000, grad_clip=1., k=10, loss="signed",
                lr_decay=10000., lr_q=lr, opt="adamw", rho=rho,
                val_every=500, wd=.0001, width=widths[arch])


def fit_spec(stage, arch, pool, n, cfg, data_id, pool_stage, namespace):
    from .freeze_data import seed
    from .tuning_manifest import config_id
    fid = f"{stage}_{arch}_{data_id}_{n}"
    if stage in ("FL_followup", "EL_followup"):
        fid += f"_{cfg['lr_q']:.4g}_{cfg['rho']:g}"
    c = dict(cfg, N=n)
    return dict(fit_id=fid, config=c, config_id=config_id(c),
                architecture=arch, pool=pool["path"], pool_sha256=pool["sha256"],
                data_id=data_id, pool_stage=pool_stage, n_chains=n//100,
                seeds={x: seed(namespace, data_id, x, 0) for x in STREAMS},
                horizons=[h for h in HORIZONS if h <= cfg["cap_q"]])


def make_manifest(stage, fits, **extra):
    ids = [x["fit_id"] for x in fits]
    assert len(ids) == len(set(ids))
    body = json.dumps(fits, sort_keys=True, separators=(",", ":")).encode()
    m = dict(stage=stage, n_fits=len(fits), fits=fits,
             sha256=hashlib.sha256(body).hexdigest(),
             freeze_sha256=FROZEN_SHA, headline_manifest_sha256=HEAD_SHA, **extra)
    path = OUT / f"manifest_{stage}.json"
    if path.exists():
        assert json.loads(path.read_text()) == m, f"manifest changed: {stage}"
    else:
        save(path, m)
    return m


def primary_lock_manifest():
    dev = json.loads(DEV.read_text())
    pools = {p["data_id"]: p for p in dev["pools"] if p["stage"] == "FL"}
    assert sorted(pools) == [9400, 9401, 9402]
    fits = []
    for arch in CLASSES:
        for lr, rho in RATES:
            for di in sorted(pools):
                fits.append(fit_spec("FL_followup", arch, pools[di], 20000,
                                     base_config(arch, lr, rho), di, "FL", "FL_followup"))
    assert len(fits) == 108
    return make_manifest("FL_followup", fits, development_manifest_sha256=sha(DEV))


def eligible(r, h):
    x = r.get("horizons", {}).get(str(h), {})
    return r.get("fit_status") == "complete" and x.get("status") == "ok" and x.get("hash")


def observable(r, h):
    x = r.get("horizons", {}).get(str(h), {})
    return (r.get("fit_status") == "complete" and x.get("hash") and
            x.get("status") in ("ok", "anchor_fail") and
            all(isinstance(x.get(k), (int, float)) and math.isfinite(x[k])
                for k in ("nll", "anchor_rmse")))


def choose_locks(stage, classes, ids):
    m = json.loads((OUT / f"manifest_{stage}.json").read_text())
    chosen = {}
    for arch in classes:
        candidates = []
        observable_candidates = []
        for lr, rho in RATES:
            specs = [s for s in m["fits"] if s["architecture"] == arch
                     and s["config"]["lr_q"] == lr and s["config"]["rho"] == rho]
            assert sorted(x["data_id"] for x in specs) == ids
            records = [json.loads((FITS / stage / s["fit_id"] / "record.json").read_text()) for s in specs]
            for h in HORIZONS:
                if all(observable(r, h) for r in records):
                    vals = [r["horizons"][str(h)] for r in records]
                    observable_candidates.append(dict(lr_q=lr, rho=rho, horizon=h,
                        median_nll=sorted(v["nll"] for v in vals)[1],
                        median_anchor=sorted(v["anchor_rmse"] for v in vals)[1],
                        anchor_errors={str(s["data_id"]): v["anchor_rmse"]
                                       for s, v in zip(specs, vals)},
                        anchor_pass={str(s["data_id"]): v["anchor_rmse"] <= .10
                                     for s, v in zip(specs, vals)},
                        fit_ids=[s["fit_id"] for s in specs]))
                if all(eligible(r, h) for r in records):
                    vals = [r["horizons"][str(h)] for r in records]
                    candidates.append(dict(lr_q=lr, rho=rho, horizon=h,
                                           median_nll=sorted(v["nll"] for v in vals)[1],
                                           median_anchor=sorted(v["anchor_rmse"] for v in vals)[1],
                                           fit_ids=[s["fit_id"] for s in specs]))
        if candidates:
            best_nll = min(c["median_nll"] for c in candidates)
            tied = [c for c in candidates if c["median_nll"] <= best_nll + .001]
            winner = min(tied, key=lambda c: (c["median_anchor"], c["horizon"],
                                              c["rho"] != 1, c["lr_q"]))
            winner["selection"] = "succeeded_original_lock"
        else:
            if not observable_candidates:
                raise RuntimeError(f"{arch}: no 3/3 validation-observable configuration")
            # The diagnostic threshold does not filter candidates. The minimum
            # observable median NLL identifies the fallback before tie breaks.
            winner = min(observable_candidates,
                         key=lambda c: (c["median_nll"], c["median_anchor"],
                                        c["horizon"], c["rho"] != 1, c["lr_q"]))
            winner["selection"] = "author_amendment_observable_fallback"
        if "anchor_errors" not in winner:
            match = next(c for c in observable_candidates if all(
                c[k] == winner[k] for k in ("lr_q", "rho", "horizon")))
            winner["anchor_errors"] = match["anchor_errors"]
            winner["anchor_pass"] = match["anchor_pass"]
        chosen[arch] = winner
    out = dict(stage=stage, rule="Author 2026-10-20 13:58 PDT: preserve successful 3/3 locks and original 0.001 NLL tie rule; otherwise choose minimum 3/3 validation-observable median NLL, then anchor, horizon, rho=1, rate. Anchor 0.10 is a reported diagnostic only; no fit or row discarded.",
               choices=chosen, source_manifest_sha256=sha(OUT / f"manifest_{stage}.json"))
    save(OUT / f"locks_{stage}.json", out)
    return out


def primary_matrix_manifest():
    head = json.loads(HEAD.read_text())
    pools = {p["data_id"]: p for p in head["pools"]}
    assert sorted(pools) == list(range(1000, 1010))
    locks = json.loads((OUT / "locks_FL_followup.json").read_text())
    fits = []
    for arch in CLASSES:
        if arch == "mlp2x10":
            continue  # 40 already queued in the protected headline.
        lock = locks["choices"][arch]
        for di, pool in sorted(pools.items()):
            for n in (1000, 5000, 20000, 100000):
                fits.append(fit_spec("M1_followup", arch, pool, n,
                                     base_config(arch, lock["lr_q"], lock["rho"], lock["horizon"]),
                                     di, "headline", "headline"))
    assert len(fits) == 200
    return make_manifest("M1_followup", fits, lock_sha256=sha(OUT / "locks_FL_followup.json"),
                         inherited_headline_fit_count=40, full_matrix_fit_count=240)


def record_code_hash():
    from .tuning_run_fit import code_hash
    return code_hash()


def primary_worker(m, s):
    from .data_io import load_split
    from .trainer import fit_fleet
    import torch
    torch.set_num_threads(1)
    dev = json.loads(DEV.read_text())
    ref = dev["reference_sha256"]
    path = ROOT / s["pool"]
    assert sha(path) == s["pool_sha256"]
    if m["stage"] == "FL_followup":
        assert "artifacts/data/development/" in str(path)
    else:
        assert "artifacts/data/headline/" in str(path)
        assert headline_ready() == "ready"
    data = load_split(path, s["n_chains"], ref)
    out = FITS / m["stage"] / s["fit_id"]
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    r = fit_fleet(data, {k:v for k,v in s["config"].items() if k != "N"},
                  s["seeds"], horizons=s["horizons"], ckpt_dir=out)
    r.update(fit_id=s["fit_id"], stage=m["stage"], config_id=s["config_id"],
             manifest_sha256=m["sha256"], freeze_sha256=FROZEN_SHA,
             data_sha256=s["pool_sha256"], code_hash=record_code_hash(),
             data_id=s["data_id"], architecture=s["architecture"],
             n_chains=s["n_chains"], start_unix=t0, end_unix=time.time(),
             peak_rss_kb=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    save(out / "record.json", r)


def write_diagnostic_table(m):
    """One row per scheduled fit and saved horizon, including failed fits."""
    stage = m["stage"]
    specs = list(m["fits"])
    if stage == "M1_followup":
        headline = json.loads((HRESULT / "manifest.json").read_text())
        assert len(headline["fits"]) == 40
        specs += [dict(s, architecture="mlp2x10", _headline=True)
                  for s in headline["fits"]]
    columns = ("stage", "fit_id", "architecture", "data_id", "N", "lr_q", "rho",
               "horizon", "fit_status", "checkpoint_status", "validation_nll",
               "anchor_rmse", "anchor_threshold", "anchor_pass", "selected_step",
               "record_present", "reference_caveat")
    path = OUT / f"table_{stage}.csv"
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns, lineterminator="\n")
        writer.writeheader()
        for s in specs:
            record_path = ((ROOT / "artifacts/headline_frozen/fits" / s["fit_id"] / "record.json")
                           if s.get("_headline") else
                           (FITS / stage / s["fit_id"] / "record.json"))
            r = json.loads(record_path.read_text()) if record_path.exists() else {}
            for h in s["horizons"]:
                x = r.get("horizons", {}).get(str(h), {})
                anchor = x.get("anchor_rmse")
                measured = isinstance(anchor, (int, float)) and math.isfinite(anchor)
                writer.writerow(dict(stage="H_frozen" if s.get("_headline") else stage,
                    fit_id=s["fit_id"], architecture=s["architecture"],
                    data_id=s["data_id"], N=s["config"]["N"],
                    lr_q=s["config"]["lr_q"], rho=s["config"]["rho"],
                    horizon=h, fit_status=r.get("fit_status", "missing"),
                    checkpoint_status=x.get("status", "missing"),
                    validation_nll=x.get("nll", ""),
                    anchor_rmse=anchor if measured else "",
                    anchor_threshold=s["config"]["anchor_tol"],
                    anchor_pass=("pass" if anchor <= s["config"]["anchor_tol"] else "fail")
                                if measured else "unmeasured",
                    selected_step=x.get("step", ""), record_present=bool(r),
                    reference_caveat=m.get("reference_caveat", "")))
    return path


def run_fits(m, worker):
    from .cpu_budget import worker_budget
    stage = m["stage"]
    stage_dir = FITS / stage
    stage_dir.mkdir(parents=True, exist_ok=True)
    lock = (OUT / f"{stage}.admission.lock").open("a+")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    queue = (OUT / f"queue_{stage}.csv").open("a", newline="")
    w = csv.writer(queue)
    pending = []
    for s in m["fits"]:
        p = stage_dir / s["fit_id"] / "record.json"
        if p.exists():
            r = json.loads(p.read_text())
            assert r["fit_id"] == s["fit_id"] and r["manifest_sha256"] == m["sha256"]
        else:
            pending.append(s)
    active = {}
    while pending or active:
        for fid, proc in list(active.items()):
            rc = proc.poll()
            if rc is not None:
                w.writerow([time.time(), fid, "end", rc, int((stage_dir/fid/"record.json").exists())])
                queue.flush()
                del active[fid]
        budget = worker_budget(len(active), 44, 2, 36)
        while pending and len(active) < budget:
            s = pending.pop(0)
            fid = s["fit_id"]
            env = dict(os.environ, OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
                       OPENBLAS_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1",
                       PYTHONHASHSEED="0", CUDA_VISIBLE_DEVICES="")
            log = (OUT / (fid+".log")).open("a")
            proc = subprocess.Popen(["nice", "-n", "10", PY, "-u", "-m",
                                     "experiments.fleet_r1literal.frozen_followups",
                                     "worker", stage, fid], stdout=log,
                                    stderr=subprocess.STDOUT, env=env)
            active[fid] = proc
            w.writerow([time.time(), fid, "start", proc.pid, budget])
            queue.flush()
        if pending or active:
            time.sleep(15)
    rows = [json.loads((stage_dir/s["fit_id"]/"record.json").read_text())
            if (stage_dir/s["fit_id"]/"record.json").exists() else None for s in m["fits"]]
    a = dict(stage=stage, scheduled=len(rows), records=sum(x is not None for x in rows),
             missing=[s["fit_id"] for s,r in zip(m["fits"], rows) if r is None],
             statuses=dict(Counter(r["fit_status"] if r else "missing" for r in rows)),
             manifest_sha256=sha(OUT / f"manifest_{stage}.json"),
             thread_cap=44, max_workers=36, controller_reservation=2)
    save(OUT / f"accounting_{stage}.json", a)
    if a["missing"]:
        raise RuntimeError(f"{stage}: missing fit records; slots retained")
    table = write_diagnostic_table(m)
    a["diagnostic_table"] = str(table.relative_to(ROOT))
    a["diagnostic_table_sha256"] = sha(table)
    save(OUT / f"accounting_{stage}.json", a)
    (LOG / f"{stage}.DONE").write_text(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())+"\n")
    return a


def wait_headline():
    while True:
        state = headline_ready()
        if state == "ready":
            return
        if state == "held_feasibility":
            status("all", "held_feasibility",
                   reason="headline feasibility failed; no reporting or coupled fits admitted")
            return False
        if state == "held_headline_failure":
            status("all", "held_headline_failure",
                   reason="headline controller stopped without DONE; no reporting or coupled fits admitted")
            return False
        time.sleep(30)


def run():
    frozen()
    status("all", "waiting_headline")
    if wait_headline() is False:
        return 2
    amendment = OUT / "FOLLOWUPS_RELEASE_AMENDMENT.md"
    assert amendment.is_file(), "author amendment record missing"
    status("all", "released", release_state="released",
           amendment_sha256=sha(amendment), original_status="status.original_held_error.json")
    for stage, build in (("FL_followup", primary_lock_manifest),
                         ("M1_followup", primary_matrix_manifest)):
        status(stage, "running")
        m = build()
        run_fits(m, primary_worker)
        if stage == "FL_followup":
            choose_locks(stage, CLASSES, [9400, 9401, 9402])
    status("extension", "pending")
    from .frozen_extension import run_extension
    run_extension()
    status("all", "complete")
    return 0


def main():
    mode = sys.argv[1]
    if mode == "run":
        try:
            sys.exit(run())
        except Exception as e:
            status("all", "held_error", reason=f"{type(e).__name__}: {e}")
            raise
    if mode == "worker":
        stage, fid = sys.argv[2:4]
        m = json.loads((OUT / f"manifest_{stage}.json").read_text())
        s = next(x for x in m["fits"] if x["fit_id"] == fid)
        if stage in ("EL_followup", "EX_followup"):
            from .frozen_extension import worker as extension_worker
            extension_worker(m, s)
        else:
            primary_worker(m, s)
        return
    if mode == "status":
        print((OUT / "status.json").read_text())
        return
    raise ValueError(mode)


if __name__ == "__main__":
    main()
