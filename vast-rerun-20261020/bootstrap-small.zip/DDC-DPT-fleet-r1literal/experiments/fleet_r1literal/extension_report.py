"""Post-fit, truth-only report for the frozen coupled K31 extension."""
import csv
import hashlib
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

from experiments.fleet_r1literal import frozen_extension as ex


ROOT = Path(__file__).resolve().parents[2]
FLEET = ROOT / "experiments/fleet_r1literal"
OUT = FLEET / "results/frozen_followups"
FITS = FLEET / "artifacts/frozen_followups/EX_followup"
EVAL = OUT / "eval_EX_followup"
ORACLE = ex.SOURCE / "artifacts/oracle"
CLASSES = ex.CLASSES
NS = (5000, 20000, 100000)
IDS = tuple(range(1000, 1005))
CAVEAT = ex.CAVEAT


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")


def save_csv(path, rows):
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def mean_se(values):
    assert len(values) == 5 and all(math.isfinite(v) for v in values)
    return statistics.mean(values), statistics.stdev(values) / math.sqrt(5)


def predict(ck, states):
    q = ex.model_factory(ck["cfg"], ck["meta"])
    z = ex.model_factory(ck["cfg"], ck["meta"])
    q.load_state_dict(ck["q"])
    z.load_state_dict(ck["z"])
    q.eval()
    z.eval()
    qhat = np.empty((len(states), 6), dtype=np.float64)
    rhat = np.empty_like(qhat)
    with torch.no_grad():
        for start in range(0, len(states), 2048):
            x = torch.from_numpy(states[start:start + 2048].astype(np.float32))
            qv = q(x).double().numpy()
            zv = z(x).double().numpy()
            end = start + len(qv)
            qhat[start:end] = qv
            rhat[start:end] = qv - ck["cfg"]["beta"] * zv
    return qhat, rhat


def main():
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    manifest_path = OUT / "manifest_EX_followup.json"
    accounting_path = OUT / "accounting_EX_followup.json"
    table_path = OUT / "table_EX_followup.csv"
    locks_path = OUT / "locks_EL_followup.json"
    panel_path = ORACLE / "evalsets.npz"
    qref_path = ORACLE / "Qeval_K31.npy"
    m = json.loads(manifest_path.read_text())
    a = json.loads(accounting_path.read_text())
    locks = json.loads(locks_path.read_text())
    assert m["stage"] == a["stage"] == "EX_followup"
    assert a["scheduled"] == a["records"] == len(m["fits"]) == 45
    assert a["statuses"] == {"complete": 45} and not a["missing"]
    assert a["manifest_sha256"] == sha(manifest_path)
    assert a["diagnostic_table_sha256"] == sha(table_path)
    assert m["lock_sha256"] == sha(locks_path)
    assert m["reference_caveat"] == CAVEAT
    assert set(locks["choices"]) == set(CLASSES)
    with table_path.open(newline="") as f:
        table_rows = list(csv.DictReader(f))
    table = {(r["fit_id"], int(r["horizon"])): r for r in table_rows}
    assert len(table) == len(table_rows) == 90
    with np.load(panel_path, allow_pickle=False) as z:
        assert tuple(z.files) == ("occ", "uni", "face")
        states = z["occ"]
    qref_all = np.load(qref_path, mmap_mode="r")
    assert states.shape == (10000, 5) and qref_all.shape == (21024, 6)
    qref = np.asarray(qref_all[:len(states)])
    from experiments.fleet_capacity_one.fleet.params import Params
    from experiments.fleet_capacity_one.fleet.rewards import reward_all
    p = Params.from_json(ex.source_paths()["dgp"])
    reward_ref = reward_all(states, p)
    assert reward_ref.shape == qref.shape
    assert m["source_hashes"]["dgp"] == sha(ex.source_paths()["dgp"])
    panel_sha, qref_sha = sha(panel_path), sha(qref_path)
    EVAL.mkdir(parents=True, exist_ok=True)
    per_fit = []
    for spec in m["fits"]:
        fit_id = spec["fit_id"]
        selected_horizon = int(locks["choices"][spec["architecture"]]["horizon"])
        t = table[(fit_id, selected_horizon)]
        rec_path = FITS / fit_id / "record.json"
        rec = json.loads(rec_path.read_text())
        arch, n, di = spec["architecture"], int(spec["config"]["N"]), int(spec["data_id"])
        assert arch in CLASSES and n in NS and di in IDS
        assert rec["fit_id"] == fit_id and rec["fit_status"] == "complete"
        assert rec["config_id"] == spec["config_id"]
        assert rec["manifest_sha256"] == m["sha256"]
        assert rec["data_sha256"] == spec["pool_sha256"]
        assert rec["reference_caveat"] == CAVEAT
        assert int(t["N"]) == n and int(t["data_id"]) == di and t["architecture"] == arch
        assert t["fit_status"] == "complete" and t["record_present"] == "True"
        assert t["reference_caveat"] == CAVEAT
        assert selected_horizon == max(spec["horizons"])
        h = rec["horizons"][str(selected_horizon)]
        assert h["status"] in ("ok", "anchor_fail") and h["hash"]
        anchor_rmse = float(h["anchor_rmse"])
        assert math.isclose(anchor_rmse, float(t["anchor_rmse"]), abs_tol=1e-12)
        assert h["status"] == t["checkpoint_status"]
        assert int(t["horizon"]) == selected_horizon and int(t["selected_step"]) == h["step"]
        anchor_pass = int(anchor_rmse <= 0.10)
        assert ("pass" if anchor_pass else "fail") == t["anchor_pass"]
        ck_path = FITS / fit_id / f"ckpt_h{selected_horizon}.pt"
        ck = torch.load(ck_path, map_location="cpu", weights_only=False)
        assert ck["hash"] == h["hash"] and ck["step"] == h["step"]
        assert ck["cfg"]["architecture"] == "ext_" + arch
        assert ck["meta"]["arm"] == "capacity_coupled_K31"
        qhat, rhat = predict(ck, states)
        advantage_error = (qhat[:, 1:] - qhat[:, :1]) - (qref[:, 1:] - qref[:, :1])
        result = dict(stage="EX_followup", fit_id=fit_id, architecture=arch, N=n, data_id=di,
                      selected_horizon=selected_horizon, selected_step=int(h["step"]),
                      checkpoint_sha256=sha(ck_path), record_sha256=sha(rec_path),
                      panel="K31_oracle_occupancy", panel_states=len(states),
                      panel_sha256=panel_sha, q_reference_sha256=qref_sha,
                      reward_rmse=float(np.sqrt(np.mean((rhat[:, 1:] - reward_ref[:, 1:]) ** 2))),
                      advantage_rmse=float(np.sqrt(np.mean(advantage_error ** 2))),
                      raw_q_rmse=float(np.sqrt(np.mean((qhat - qref) ** 2))),
                      validation_anchor_rmse=anchor_rmse, anchor_pass=anchor_pass,
                      checkpoint_status=h["status"], raw_q_reference_caveat=CAVEAT)
        save_json(EVAL / f"{fit_id}.json", result)
        per_fit.append(result)
    per_fit.sort(key=lambda r: (CLASSES.index(r["architecture"]), r["N"], r["data_id"]))
    expected = {(arch, n, di) for arch in CLASSES for n in NS for di in IDS}
    assert {(r["architecture"], r["N"], r["data_id"]) for r in per_fit} == expected
    assert len(per_fit) == len(expected) == 45
    save_csv(OUT / "EXTENSION_FITS.csv", per_fit)

    cells = defaultdict(list)
    for row in per_fit:
        cells[(row["architecture"], row["N"])].append(row)
    summary = []
    for arch in CLASSES:
        for n in NS:
            cell = cells[(arch, n)]
            assert [r["data_id"] for r in cell] == list(IDS)
            item = dict(architecture=arch, N=n, count=5, pool_ids="1000-1004")
            for metric in ("reward_rmse", "advantage_rmse", "raw_q_rmse"):
                item[metric + "_mean"], item[metric + "_se"] = mean_se([r[metric] for r in cell])
            item["anchor_rmse_mean"] = statistics.mean(r["validation_anchor_rmse"] for r in cell)
            item["anchor_pass_count"] = sum(r["anchor_pass"] for r in cell)
            item["anchor_threshold"] = 0.10
            item["raw_q_reference_caveat"] = CAVEAT
            summary.append(item)
    save_csv(OUT / "EXTENSION_RESULTS.csv", summary)

    def fmt(row, metric):
        return f"{row[metric + '_mean']:.4f} ± {row[metric + '_se']:.4f}"

    lines = [
        "# Coupled K31 extension (EX) results", "",
        "All 45 scheduled EX fits completed: three classes × N = 5,000, 20,000, and 100,000 × five paired pools (IDs 1000–1004). The separate EL stage locked each class's rate, rho, and horizon before EX reporting. Every fit contributes one selected checkpoint at its locked horizon; earlier horizon rows are not counted again. No fit is dropped for an anchor failure.", "",
        "## Results", "",
        "Entries are mean ± standard error across the five pools (sample SD / √5). Reward RMSE compares implied rewards `Q̂ − 0.95 ζ̂` with true rewards on the five non-anchor actions. Advantage RMSE compares `Q̂(s,a) − Q̂(s,0)` with K31 oracle advantages on those actions. Raw Q RMSE compares all six fitted Q actions with K31 oracle Q; see the **K31 absolute-Q level caveat** below. All three metrics use the existing 10,000-state K31 oracle occupancy panel. Anchor RMSE is the mean selected-checkpoint validation diagnostic, and the pass count uses the unchanged ≤0.10 threshold.", "",
        "| Class | N | Reward RMSE | Advantage RMSE | Raw Q RMSE† | Anchor RMSE | Anchor ≤0.10 |",
        "|:--|--:|--:|--:|--:|--:|--:|",
    ]
    for row in summary:
        lines.append(f"| {row['architecture']} | {row['N']:,} | {fmt(row, 'reward_rmse')} | {fmt(row, 'advantage_rmse')} | {fmt(row, 'raw_q_rmse')} | {row['anchor_rmse_mean']:.4f} | {row['anchor_pass_count']}/5 |")
    lines += [
        "", "## K31 absolute-Q level caveat", "",
        "† **Raw Q caveat:** " + CAVEAT + " Raw Q RMSE is therefore a descriptive comparison with this K31 reference, not an absolute-Q accuracy claim. The much smaller oracle advantage sensitivity supports interpreting advantage errors separately. The 0.086–0.095 raw-Q level floor and 0.001–0.0024 advantage sensitivity are empirical reference sensitivities, not corrections to subtract from the fitted errors.", "",
        "## Selection and provenance", "",
        "The EL locks were additive: rate 0.001, rho 1, horizon 20,000; mlp2x10: rate 0.0003, rho 1, horizon 50,000; mlp2x64: rate 0.0003, rho 1, horizon 10,000. These were selected from three development pools (9400–9402) using validation observables. EX metrics use oracle truth only after checkpoint selection. The same five protected pools are paired across classes and N; these are descriptive within-cell means and standard errors.", "",
        "Source accounting: `accounting_EX_followup.json` (45/45 complete); selected-fit validation diagnostics: `table_EX_followup.csv`; locks: `locks_EL_followup.json`. Each selected checkpoint's hash, panel hash, K31 Q-reference hash, and metrics are in `eval_EX_followup/*.json` and `EXTENSION_FITS.csv`. The nine class × N rows are in `EXTENSION_RESULTS.csv`. The source K31 V and DGP hashes are checked in the frozen EX manifest; the historical V4 acceptance failure stays attached to raw-Q interpretation.", "",
        f"EX manifest file SHA256: `{sha(manifest_path)}`; EL locks file SHA256: `{sha(locks_path)}`; occupancy panel SHA256: `{panel_sha}`; K31 Q-reference SHA256: `{qref_sha}`.", "",
    ]
    (OUT / "EXTENSION_RESULTS.md").write_text("\n".join(lines))
    print(f"Scored {len(per_fit)} selected checkpoints; wrote {len(summary)} summary rows")
    for row in summary:
        print(row["architecture"], row["N"], fmt(row, "reward_rmse"),
              fmt(row, "advantage_rmse"), fmt(row, "raw_q_rmse"),
              row["anchor_pass_count"])


if __name__ == "__main__":
    main()
