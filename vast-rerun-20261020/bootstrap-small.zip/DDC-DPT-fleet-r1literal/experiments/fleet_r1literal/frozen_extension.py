"""Capacity-coupled K31 extension: fixed data, observable locks, retained failures."""
import hashlib
import json
import math
import os
import resource
import time
from pathlib import Path

import numpy as np

from . import frozen_followups as q

SOURCE = q.SOURCE
EXT = q.ROOT / "artifacts/frozen_followups/extension_data"
CLASSES = ("additive", "mlp2x10", "mlp2x64")
CAVEAT = ("Historical K31 absolute-Q acceptance FAIL: V4 forward returns had "
          "8/20 starts outside 3SE+.01. Raw Q comparisons have empirical "
          "0.086-0.095 level-floor sensitivity; advantages 0.001-0.0024. "
          "These are not global bounds. Policy is relative to the K31 expert.")
SOURCE_HASHES = {
    "dgp": "043d2b511ae82222d2024a620b0a3b010485ebb013233648f6830c8acbc6671c",
    "V_K31": "57ba2aaf00d3613be62d74b30527a43c999d6e67a1e6442d5d8e75f0d7a38e89",
    "meta_K31": "1bdb175f75b77b756140128ee7e2728a67ea0b4a3020b2f60913bb0ccf1f4fbe",
    "v4": "37c5c08ae64a123c3e2f69d1948c2adc7ca061c088a9b7d99d9fe535196928ea",
    "code_params.py": "c6f7fac51e4048124aa1b471ca512a2e52181240be6871280b75a064de68b231",
    "code_env.py": "d8ea1e6db16a106c67bfe0e56b208159c2479398365418f9d2af9f1ed8b717f5",
    "code_oracle.py": "b392d6a712aa13d2845c2c5b5064a86583d0a14ee0561b374dff92c30749a0c3",
    "code_kernels.py": "6944c17f2b372657c28002b674bdcd19224e8e716d90a9e412c5efe7ebdb4529",
    "code_rewards.py": "fa3d0b1a8ee68d9c3f154deaf54f891bfd84b8fba19208565b44309dc9c0fb0b",
    "code_anchor.py": "1bdb7108ce40040de6b8127521a65079436bd7511299ebee9bf24c8ab09e876c",
}


def source_paths():
    return {
        "dgp": SOURCE / "configs/dgp.json",
        "V_K31": SOURCE / "artifacts/oracle/V_K31.npy",
        "meta_K31": SOURCE / "artifacts/oracle/meta_K31.json",
        "v4": SOURCE / "results/gates/oracle_diagnostics/v4_forward_return_K31.json",
    }


def check_source():
    paths = source_paths()
    for p in paths.values():
        assert p.is_file(), p
    for name in ("params.py", "env.py", "oracle.py", "kernels.py", "rewards.py", "anchor.py"):
        original = SOURCE / "fleet" / name
        local = q.ROOT.parent / "fleet_capacity_one/fleet" / name
        assert q.sha(original) == q.sha(local), f"capacity source differs: {name}"
    from experiments.fleet_capacity_one.fleet.params import Params
    p = Params.from_json(paths["dgp"])
    meta = json.loads(paths["meta_K31"].read_text())
    assert p.F == 5 and p.n_actions == 6 and p.shape == 2 and p.kcost_scale == 1
    assert meta["K"] == 31 and meta["dgp_id"] == p.dgp_id
    assert meta["converged"] and meta["residual_ok"]
    assert np.load(paths["V_K31"], mmap_mode="r").shape == (31,)*5
    v4 = json.loads(paths["v4"].read_text())
    assert len(v4["diff"]) == 20 and sum(abs(d) > 3*se+.01 for d,se in zip(v4["diff"],v4["se"])) == 8
    hashes = {k: q.sha(v) for k,v in paths.items()}
    hashes.update({f"code_{name}": q.sha(SOURCE / "fleet" / name) for name in
                   ("params.py", "env.py", "oracle.py", "kernels.py", "rewards.py", "anchor.py")})
    assert hashes == SOURCE_HASHES, "original K31 source hash mismatch"
    return p, hashes


def ext_seed(stage, data_id, stream):
    dgp = q.sha(source_paths()["dgp"])
    material = f"20261018|capacity_K31|{dgp}|{stage}|{data_id}|0|{stream}"
    return int.from_bytes(hashlib.sha256(material.encode()).digest()[:8], "big") % (2**63-1)


def expert(p):
    from scipy.special import softmax
    from experiments.fleet_capacity_one.fleet.oracle import lookahead_Q
    V = np.load(source_paths()["V_K31"], mmap_mode="r")
    def policy(s):
        return softmax(lookahead_Q(s, V, p), axis=1)
    return policy


def generate(stage, di, chains, p, policy, source_hashes):
    from experiments.fleet_capacity_one.fleet.env import simulate_chains
    from experiments.fleet_capacity_one.fleet.anchor import r0_np
    EXT.mkdir(parents=True, exist_ok=True)
    path = EXT / f"{stage}_{di}.npz"
    if path.exists():
        with np.load(path, allow_pickle=False) as z:
            assert str(z["dgp_sha256"]) == source_hashes["dgp"]
            assert str(z["oracle_sha256"]) == source_hashes["V_K31"]
            assert len(z["is_val"]) == chains
        return dict(stage=stage, data_id=di, path=str(path.relative_to(q.ROOT)),
                    sha256=q.sha(path), n_chains=chains)
    # Deterministic, stage-specific streams and permanent 800/200 partitions.
    rng = [np.random.default_rng(ext_seed(stage, di, x)) for x in ("starts","action","increments")]
    ch = simulate_chains(policy, chains, p, *rng, H=100, burn_in=0)
    order_rng = np.random.default_rng(ext_seed(stage, di, "permanent_split"))
    perm = order_rng.permutation(chains)
    train, val = perm[:chains*4//5], perm[chains*4//5:]
    order = np.empty(chains, dtype=np.int64)
    for j in range(chains//5):
        order[5*j:5*j+4] = train[4*j:4*j+4]
        order[5*j+4] = val[j]
    s, sp, a = (ch[x][order] for x in ("s","sp","a"))
    r0 = r0_np(s, p.arr("u"), p.arr("v"))
    np.savez_compressed(path, s=s.astype(np.float32), sp=sp.astype(np.float32),
                        a=a.astype(np.int8), r0=r0.astype(np.float32),
                        is_val=np.tile([False,False,False,False,True], chains//5),
                        chain_id=np.asarray([f"{stage}_{di}_chain{int(i):04d}" for i in order]),
                        arm="capacity_coupled_K31", n_actions=6, anchor_action=0,
                        beta=p.beta, state_scale=1.0, dgp_sha256=source_hashes["dgp"],
                        oracle_sha256=source_hashes["V_K31"])
    return dict(stage=stage, data_id=di, path=str(path.relative_to(q.ROOT)),
                sha256=q.sha(path), n_chains=chains)


def acceptance(p, policy, hashes):
    path = q.OUT / "extension_pilot_acceptance.json"
    if path.exists():
        x = json.loads(path.read_text())
        assert x["dgp_sha256"] == hashes["dgp"] and x["oracle_sha256"] == hashes["V_K31"]
        return x
    from experiments.fleet_capacity_one.fleet.env import simulate_chains
    rng = [np.random.default_rng(ext_seed("pilot", 9990, x)) for x in ("starts","action","increments")]
    ch = simulate_chains(policy, 10000, p, *rng, H=100, burn_in=0)
    a = ch["a"].reshape(-1)
    s = ch["s"].reshape(-1,5)
    shares = np.bincount(a, minlength=6)/len(a)
    spans = np.percentile(s,95,axis=0)-np.percentile(s,5,axis=0)
    passed = bool(.25 <= shares[0] <= .95 and np.all(shares >= .02) and np.all(spans >= .25))
    record = dict(status="accepted" if passed else "failed",
                  threshold={"anchor":[.25,.95],"each_action_min":.02,"span_min":.25},
                  n_chains=10000, H=100, action_shares=shares.tolist(),
                  coordinate_spans=spans.tolist(), dgp_sha256=hashes["dgp"],
                  oracle_sha256=hashes["V_K31"], reference_caveat=CAVEAT)
    q.save(path, record)
    return record


def freeze_data():
    path = q.OUT / "extension_data_manifest.json"
    p, hashes = check_source()
    if path.exists():
        m = json.loads(path.read_text())
        assert m["source_hashes"] == hashes and m["pilot"]["status"] == "accepted"
        for item in m["pools"]:
            assert q.sha(q.ROOT/item["path"]) == item["sha256"]
        return m
    # One thread of reference work; wait for measured headroom.
    from .cpu_budget import worker_budget
    while worker_budget(0,44,2,1) < 1:
        time.sleep(15)
    pol = expert(p)
    pilot = acceptance(p, pol, hashes)
    if pilot["status"] != "accepted":
        raise RuntimeError("extension pilot failed unchanged acceptance thresholds")
    pools = [generate("FL_ext", di, 1000, p, pol, hashes) for di in (9400,9401,9402)]
    pools += [generate("headline_ext", di, 1000, p, pol, hashes) for di in range(1000,1005)]
    m = dict(status="frozen", arm="capacity_coupled_K31", source_repo=str(SOURCE),
             source_hashes=hashes, pilot=pilot, pools=pools,
             reference_caveat=CAVEAT, no_DGP_or_tolerance_change=True)
    q.save(path, m)
    return m


def ext_base(arch, lr=.001, rho=1, horizon=50000):
    c = q.base_config(arch, lr, rho, horizon)
    c["architecture"] = "ext_"+arch
    return c


def ext_fit_spec(stage, arch, pool, n, cfg, di):
    from .tuning_manifest import config_id
    name = f"{stage}_{arch}_{di}_{n}"
    if stage == "EL_followup":
        name += f"_{cfg['lr_q']:.4g}_{cfg['rho']:g}"
    c = dict(cfg,N=n)
    return dict(fit_id=name, architecture=arch, config=c,
                config_id=config_id(c), data_id=di, n_chains=n//100,
                pool=pool["path"], pool_sha256=pool["sha256"],
                seeds={x: ext_seed(stage,di,x) for x in q.STREAMS},
                horizons=[h for h in q.HORIZONS if h <= cfg["cap_q"]])


def lock_manifest(data):
    pools = {x["data_id"]:x for x in data["pools"] if x["stage"] == "FL_ext"}
    assert sorted(pools) == [9400,9401,9402]
    fits = [ext_fit_spec("EL_followup", arch, pools[di], 20000, ext_base(arch, lr, rho), di)
            for arch in CLASSES for lr,rho in q.RATES for di in sorted(pools)]
    assert len(fits) == 54
    return q.make_manifest("EL_followup", fits, extension_data_sha256=q.sha(q.OUT/"extension_data_manifest.json"),
                           source_hashes=data["source_hashes"], reference_caveat=CAVEAT)


def matrix_manifest(data):
    pools = {x["data_id"]:x for x in data["pools"] if x["stage"] == "headline_ext"}
    locks = json.loads((q.OUT/"locks_EL_followup.json").read_text())
    assert sorted(pools) == list(range(1000,1005))
    fits = []
    for arch in CLASSES:
        c = locks["choices"][arch]
        for di in sorted(pools):
            for n in (5000,20000,100000):
                fits.append(ext_fit_spec("EX_followup", arch, pools[di], n,
                                         ext_base(arch,c["lr_q"],c["rho"],c["horizon"]),di))
    assert len(fits) == 45
    return q.make_manifest("EX_followup",fits,
                           extension_data_sha256=q.sha(q.OUT/"extension_data_manifest.json"),
                           lock_sha256=q.sha(q.OUT/"locks_EL_followup.json"),
                           source_hashes=data["source_hashes"],reference_caveat=CAVEAT)


def load_data(spec, source_hashes):
    path = q.ROOT/spec["pool"]
    assert q.sha(path) == spec["pool_sha256"]
    z = np.load(path, allow_pickle=False)
    assert str(z["arm"]) == "capacity_coupled_K31"
    assert str(z["dgp_sha256"]) == source_hashes["dgp"]
    assert str(z["oracle_sha256"]) == source_hashes["V_K31"]
    assert int(z["n_actions"]) == 6 and int(z["anchor_action"]) == 0
    n = spec["n_chains"]
    mask = z["is_val"][:n].astype(bool)
    def part(which):
        return dict(s=z["s"][:n][which].reshape(-1,5),
                    sp=z["sp"][:n][which].reshape(-1,5),
                    a=z["a"][:n][which].reshape(-1).astype(np.int64),
                    r0=z["r0"][:n][which].reshape(-1))
    return dict(train=part(~mask),val=part(mask),
                meta=dict(n_actions=6,anchor_action=0,beta=.95,state_scale=1.,
                          arm="capacity_coupled_K31"),
                n_train_chains=int((~mask).sum()),n_val_chains=int(mask.sum()))


def model_factory(cfg, meta):
    import torch
    from torch import nn
    from experiments.fleet_capacity_one.fleet.models import MLP
    assert meta["n_actions"] == 6 and meta["anchor_action"] == 0
    arch=cfg["architecture"]
    if arch == "ext_mlp2x10":
        return MLP(5,6,10,2)
    if arch == "ext_mlp2x64":
        return MLP(5,6,64,2)
    if arch == "ext_additive":
        class Additive(nn.Module):
            def __init__(self):
                super().__init__()
                self.g=nn.ModuleList([nn.Sequential(nn.Linear(1,16),nn.ReLU(),
                    nn.Linear(16,16),nn.ReLU(),nn.Linear(16,6,bias=False)) for _ in range(5)])
                self.bias=nn.Parameter(torch.zeros(6))
            def forward(self,x):
                return self.bias+sum(g(x[:,i:i+1]) for i,g in enumerate(self.g))
        return Additive()
    raise ValueError(arch)


def model_init(net, seed, bias):
    import torch
    from torch import nn
    gen=torch.Generator().manual_seed(int(seed))
    with torch.no_grad():
        for layer in net.modules():
            if isinstance(layer,nn.Linear):
                out,inn=layer.weight.shape
                layer.weight.copy_(torch.randn(layer.weight.shape,generator=gen)*math.sqrt(2/(inn+out)))
                if layer.bias is not None:
                    layer.bias.zero_()
        if hasattr(net,"bias"):
            net.bias.fill_(float(bias))
        else:
            net.layers[-1].bias.fill_(float(bias))
    return net


def worker(m,s):
    import torch
    from experiments.fleet_capacity_one.fleet.train import fit
    torch.set_num_threads(1)
    data=load_data(s,m["source_hashes"])
    out=q.FITS/m["stage"]/s["fit_id"]
    out.mkdir(parents=True,exist_ok=True)
    cfg={k:v for k,v in s["config"].items() if k!="N"}
    cfg["loss"]="none"  # signed bracket in the shared, unchanged estimator
    t0=time.time()
    r=fit(data,cfg,s["seeds"],horizons=s["horizons"],ckpt_dir=out,
          model_factory=model_factory,model_initializer=model_init)
    r.update(fit_id=s["fit_id"],stage=m["stage"],config_id=s["config_id"],
             manifest_sha256=m["sha256"],freeze_sha256=q.FROZEN_SHA,
             data_sha256=s["pool_sha256"],data_id=s["data_id"],
             architecture=s["architecture"],n_chains=s["n_chains"],
             declared_loss="signed",shared_loss_semantics="none",
             start_unix=t0,end_unix=time.time(),
             peak_rss_kb=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
             source_hashes=m["source_hashes"],reference_caveat=CAVEAT)
    q.save(out/"record.json",r)


def run_extension():
    q.status("extension", "preparing_K31_data", reference_caveat=CAVEAT)
    data=freeze_data()
    q.status("extension", "running_rate_locks")
    m=lock_manifest(data)
    q.run_fits(m, worker)
    q.choose_locks("EL_followup", CLASSES, [9400,9401,9402])
    q.status("extension", "running_45_reporting_fits")
    m=matrix_manifest(data)
    q.run_fits(m, worker)
    q.status("extension", "complete", reference_caveat=CAVEAT)
