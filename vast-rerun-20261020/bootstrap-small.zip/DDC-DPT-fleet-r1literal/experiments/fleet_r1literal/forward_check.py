"""Independent forward soft-return checks; fixed seeds and simultaneous intervals."""
import json
import math
import time
from pathlib import Path
import numpy as np
from scipy.special import ndtri
from .assemble import load
from .params import F,BETA,U,V,KCOST,D,encode
from .rewards import reward,component
from .texp import draw
from .env import step

CRIT=float(ndtri(1-.05/(2*120)))
T=450
STARTS=np.linspace(0.,1.,20)

def summarize(samples,truth,tail,numeric):
    means=samples.mean(axis=1);se=samples.std(axis=1,ddof=1)/np.sqrt(samples.shape[1])
    diff=means-truth
    ok=np.abs(diff)<=CRIT*se+tail+numeric
    return dict(mean=means.tolist(),se=se.tolist(),signed_difference=diff.tolist(),
                within_interval=ok.tolist(),n_within=int(ok.sum()),critical=CRIT,
                tail_bound=tail,numeric_allowance=numeric)

def run(refroot,outroot):
    t0=time.perf_counter();ref=load(refroot)
    manifest=json.loads((Path(refroot)/"reference_manifest.json").read_text())
    result=dict(component=[],joint=None)
    for f,c in enumerate(ref.components):
        rng_a=np.random.default_rng(20262000+f)
        rng_d=np.random.default_rng(20263000+f)
        x=np.repeat(STARTS[:,None],2000,axis=1)
        ret=np.zeros_like(x);disc=1.
        for t in range(T):
            q0,q1,v,_=c.query(x)
            p1=np.exp(q1-v)
            bits=(rng_a.random(x.shape)<p1)
            ent=-(p1*np.log(np.maximum(p1,1e-300))+
                  (1-p1)*np.log(np.maximum(1-p1,1e-300)))
            ret+=disc*(component(x,bits,f)+ent)
            x=np.where(bits,0.,np.minimum(1.,x+draw(rng_d.random(x.shape),f)))
            disc*=BETA
        truth=c.query(STARTS)[2]
        tail=BETA**T/(1-BETA)*(max(U[f]+V[f],KCOST[f]+D[f])+math.log(2))
        numeric=manifest["buses"][f]["certificate"]["bound"]/(1-BETA)
        result["component"].append(dict(bus=f+1,**summarize(ret,truth,tail,numeric)))
    rng_a=[np.random.default_rng(20264000+f) for f in range(F)]
    rng_d=[np.random.default_rng(20265000+f) for f in range(F)]
    starts=np.stack([np.mod(STARTS+.127*f,1.) for f in range(F)],axis=1)
    s=np.repeat(starts[:,None,:],1000,axis=1)
    ret=np.zeros((20,1000));disc=1.
    for t in range(T):
        bits=np.empty(s.shape,dtype=np.int8)
        inc=np.empty(s.shape)
        entropy=np.zeros(s.shape[:2])
        for f,c in enumerate(ref.components):
            q0,q1,v,_=c.query(s[:,:,f])
            p1=np.exp(q1-v)
            bits[:,:,f]=rng_a[f].random(s.shape[:2])<p1
            inc[:,:,f]=draw(rng_d[f].random(s.shape[:2]),f)
            entropy-=p1*np.log(np.maximum(p1,1e-300))+(1-p1)*np.log(np.maximum(1-p1,1e-300))
        action=encode(bits)
        ret+=disc*(reward(s,action)+entropy)
        s=step(s,bits,inc)
        disc*=BETA
    truth=ref.joint_query(starts)[1]
    tail=BETA**T/(1-BETA)*sum(max(U[f]+V[f],KCOST[f]+D[f])+math.log(2) for f in range(F))
    numeric=sum(b["certificate"]["bound"] for b in manifest["buses"])/(1-BETA)
    result["joint"]=summarize(ret,truth,tail,numeric)
    result["wall_s"]=time.perf_counter()-t0
    out=Path(outroot);out.mkdir(parents=True,exist_ok=True)
    (out/"forward_checks.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(dict(component_counts=[x["n_within"] for x in result["component"]],
                          joint_count=result["joint"]["n_within"],critical=CRIT,wall_s=result["wall_s"])),flush=True)
if __name__=="__main__":
    import sys
    run(*sys.argv[1:])
