"""Descriptive million-transition pilot. No acceptance decision is made here."""
import hashlib
import json
import time
from pathlib import Path
import numpy as np
from scipy.stats import ks_2samp
from .assemble import load
from .env import generate_chains
from .params import F,ACTIONS,DGP_PATH,ACTION_PATH,sha256

def seed(stage,stream):
    testbed="r1literal_v1_"+sha256(DGP_PATH)+"_"+sha256(ACTION_PATH)
    material="20261018|"+testbed+"|"+stage+"|0|0|"+stream
    return int.from_bytes(hashlib.sha256(material.encode()).digest()[:8],"big")%(2**63-1)

def streams(stage):
    start=np.random.default_rng(seed(stage,"starts"))
    act=[np.random.default_rng(seed(stage,"action_bus_%d"%f)) for f in range(F)]
    inc=[np.random.default_rng(seed(stage,"increment_bus_%d"%f)) for f in range(F)]
    return start,act,inc

def report(data,burn,ks=None):
    s=data["s"];a=data["a"];bits=ACTIONS[a]
    n=s.size//F;counts=np.bincount(a.ravel(),minlength=32)
    shares=counts/n
    marg=bits.mean(axis=(0,1))
    spans=np.quantile(s,.95,axis=(0,1))-np.quantile(s,.05,axis=(0,1))
    singleton=[shares[1<<f] for f in range(F)]
    quant=np.quantile(s,[.05,.5,.95],axis=(0,1))
    repl=[dict(mean=float(s[:,:,f][bits[:,:,f]==1].mean()),
               near_new=float(np.mean(s[:,:,f][bits[:,:,f]==1]<.1))) for f in range(F)]
    cent=s.mean(axis=1)
    chain_se=dict(anchor=float((a==0).mean(axis=1).std(ddof=1)/np.sqrt(len(a))),
                  replacement=[float(bits[:,:,f].mean(axis=1).std(ddof=1)/np.sqrt(len(a))) for f in range(F)])
    old=dict(anchor_range=[.50,.95],all_action_min=.02,span_min=.25)
    cc=dict(anchor_range=[.25,.95],keep_replace_min=.02,span_min=.25)
    lc=dict(anchor_range=[.25,.95],replace_range=[.03,.30],singleton_min=.01,span_min=.25)
    flags=dict(
      existing=bool(.50<=shares[0]<=.95 and np.min(shares)>=.02 and np.min(spans)>=.25),
      CC_D3_hybrid=bool(.25<=shares[0]<=.95 and np.min(np.minimum(marg,1-marg))>=.02 and np.min(spans)>=.25),
      LC_C3=bool(.25<=shares[0]<=.95 and np.min(marg)>=.03 and np.max(marg)<=.30 and np.min(singleton)>=.01 and np.min(spans)>=.25))
    return dict(status="descriptive_only_U1_open",burn=burn,ks=ks,nchains=len(a),horizon=a.shape[1],rows=n,
                action_counts=counts.tolist(),action_shares=shares.tolist(),
                by_replacement_count=np.bincount(bits.sum(2).ravel(),minlength=6).tolist(),
                replace_marginal=marg.tolist(),keep_marginal=(1-marg).tolist(),
                quantiles_05_50_95=quant.tolist(),span_95_05=spans.tolist(),
                cap_mass=np.mean(s==1,axis=(0,1)).tolist(),replacement_mileage=repl,
                tail_gt_07=np.mean(s>.7,axis=(0,1)).tolist(),
                early_occupancy=np.mean(s[:,:20],axis=(0,1)).tolist(),
                late_occupancy=np.mean(s[:,50:],axis=(0,1)).tolist(),
                pooled_correlation=np.corrcoef(s.reshape(-1,F).T).tolist(),
                fixed_time_correlation=np.corrcoef(s[:,50,:].T).tolist(),
                chain_se=chain_se,criteria=dict(existing=old,CC_D3_hybrid=cc,LC_C3=lc),
                comparisons=flags,dgp_sha256=sha256(DGP_PATH),action_sha256=sha256(ACTION_PATH))

def run(refroot,outroot):
    t0=time.perf_counter();out=Path(outroot);out.mkdir(parents=True,exist_ok=True)
    ref=load(refroot)
    query=ref.component_query
    # Preliminary zero-burn run includes t<20 and t>=50 for the KS rule.
    data=generate_chains(10000,100,query,streams("pilot_zero"),burn=0)
    ks=[float(ks_2samp(data["s"][:,:20,f].ravel(),data["s"][:,50:,f].ravel(),
                        method="asymp").statistic) for f in range(F)]
    zero=report(data,0,ks)
    (out/"pilot_zero.json").write_text(json.dumps(zero,indent=2)+"\n")
    burn=50 if max(ks)>.1 else 0
    if burn:
        del data
        data=generate_chains(10000,100,query,streams("pilot_burn50"),burn=50)
    final=report(data,burn,ks)
    final["wall_s"]=time.perf_counter()-t0
    (out/"pilot_recording.json").write_text(json.dumps(final,indent=2)+"\n")
    print(json.dumps(dict(burn=burn,ks=ks,anchor=final["action_shares"][0],
         replace=final["replace_marginal"],singleton=[final["action_shares"][1<<f] for f in range(F)],
         spans=final["span_95_05"],comparisons=final["comparisons"],wall_s=final["wall_s"])))
    return final
if __name__=="__main__":
    import sys
    run(*sys.argv[1:])
