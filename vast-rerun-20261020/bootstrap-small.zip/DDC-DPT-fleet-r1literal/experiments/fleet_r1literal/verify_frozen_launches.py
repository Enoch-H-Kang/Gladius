"""Detached live verification of each frozen development stage launch."""
import json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
LED=ROOT/'results/tuning/ledger'
OUT=ROOT/'results/tuning/live_verification.json'
STAGES=('F1','F2','F3','D')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def processes(stage):
    found=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='ignore')
        except OSError:continue
        if ('experiments.fleet_r1literal.tuning_run_fit' in cmd and f'manifest_{stage}_frozen.json' in cmd and 'R1LITERAL_FIT_WORKER' in cmd):found.append(int(p.name))
    return found
result={}
for stage in STAGES:
    man=json.loads((ROOT/f'results/tuning/manifests/manifest_{stage}_frozen.json').read_text())
    fit_ids={x['fit_id'] for x in man['fits']}
    first_pids=[];first_record=None
    while True:
        if not first_pids:first_pids=processes(stage)
        fits=ROOT/f'artifacts/tuning/fits_{stage}_frozen'
        for p in fits.glob('*/record.json'):
            rec=json.loads(p.read_text())
            if rec['fit_id'] in fit_ids and rec['manifest_sha256']==man['sha256'] and rec['data_sha256'] and rec['code_hash']:
                first_record={'fit_id':rec['fit_id'],'record_sha256':sha(p),'fit_status':rec['fit_status'],'pid':rec['pid']};break
        if first_pids and first_record:break
        time.sleep(10)
    result[stage]={'verified_unix':time.time(),'manifest_sha256':sha(ROOT/f'results/tuning/manifests/manifest_{stage}_frozen.json'),'observed_worker_pids':first_pids,'first_record':first_record,'admitted':len(fit_ids)}
    OUT.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
