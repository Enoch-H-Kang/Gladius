"""One fleet released-code diagnostic fit on truth-stripped development data."""
import json
import os
import resource
import socket
import sys
import time
from pathlib import Path

import torch

from .refcode_fit import fit
from .data_io import load_split
from .tuning_run_fit import ROOT, DEV_MANIFEST, code_hash, hashfile

def main(manifest_path, fit_id, fits_root):
    torch.set_num_threads(1)
    m=json.loads(Path(manifest_path).read_text())
    assert m["stage"] == "FR" and m["development_manifest_sha256"] == hashfile(DEV_MANIFEST)
    spec=next(s for s in m["fits"] if s["fit_id"] == fit_id)
    dev=json.loads(DEV_MANIFEST.read_text())
    source=next(p for p in dev["pools"] if p["stage"] == "F1" and p["data_id"] == spec["data_id"])
    path=ROOT/source["path"]
    assert "headline" not in str(path) and hashfile(path) == source["sha256"]
    data=load_split(path,spec["n_chains"],dev["reference_sha256"])
    out=Path(fits_root)/fit_id
    out.mkdir(parents=True,exist_ok=True)
    start=time.time()
    cfg={k:v for k,v in spec["config"].items() if k != "N"}
    result=fit(data,cfg,spec["seeds"],horizons=spec["horizons"],ckpt_dir=out)
    result.update(fit_id=fit_id,stage="FR",config_id=spec["config_id"],
                  data_id=spec["data_id"],init_index=0,n_chains=spec["n_chains"],
                  manifest_sha256=m["sha256"],development_manifest_sha256=hashfile(DEV_MANIFEST),
                  data_sha256=source["sha256"],code_hash=code_hash("FR"),
                  host=socket.gethostname(),pid=os.getpid(),start_unix=start,
                  end_unix=time.time(),peak_rss_kb=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  refcode_adapter=m["adapter"],
                  env_threads={k:os.environ.get(k) for k in
                               ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS")})
    temp=out/"record.json.tmp"
    temp.write_text(json.dumps(result,allow_nan=False))
    os.replace(temp,out/"record.json")
    print(json.dumps(dict(fit_id=fit_id,status=result["fit_status"],
                          time_s=result["time"]["total"])),flush=True)

if __name__ == "__main__":
    main(*sys.argv[1:4])
