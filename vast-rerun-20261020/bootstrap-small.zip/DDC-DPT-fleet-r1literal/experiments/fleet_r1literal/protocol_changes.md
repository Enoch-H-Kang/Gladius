# U2 protocol activation and changes

## Provisional activation — 2026-10-19 UTC

Authority: `planning/final-decisions.md`, entry “2026-10-19 00:06 PDT — U2 amendment PROVISIONALLY ADOPTED,” under the user's overnight development-work instruction. This activates the 16 recommended defaults in `u2-amendment-merged.md` only for reversible development work. No headline truth or estimator fit is authorized here. The exact amendment bytes are copied to `protocol/u2-amendment-merged.md` and have SHA256 `215a24fb439a0dd950ea0fce33f0ff147bca9dd8edfee4d884bf4ee5a6f3f25c` on both local and baker copies.

The seven §8 source snapshots were verified against the local planning files before activation. The FD hash is the exact pre-adoption prefix, ending with its prior newline; the current FD has the later adoption entry appended.

| Source | Verified SHA256 |
|---|---|
| Codex U2 draft | `2142c2f13fe57eb3f4b44171bedbfc302c613cbbbf960d8255208037470c454e` |
| Claude U2 draft | `9e62004620d9b394140920cae50f0c021d3da47a3c8f7c4d58487afa2db5217c` |
| RC | `e7a439f56857ba73d4099c56d1d3d43865942c7a0617ecac343a23b948b0875c` |
| TF | `05f8bf28808016a3a66f5b80bd4cad3180892c30e4890345d0813d7cb8df7247` |
| TC | `aa08774a3a3086b635a91cd47c76c4f136060a1fc83c0320c37fd2071f62ab9a` |
| TL | `953dee8453f01200af5aab83c08f45dd2a8f431bd435e14deb563929f05d9cab` |
| FD pre-adoption | `63b26f00df22e3b074a33cd70a4edaaa4ec76246214d4a3a610bf5c8b821ba8b` |

Adopted defaults, with the amendment's numbering:

1. Correct wrong-rule bus finalists only while confirmation truth is still blinded; retain displaced work as unscored evidence.
2. Already exposed confirmation evidence is exploratory only; stop affected confirmatory use and add no new seeds.
3. Fleet confirmation requires both initializations at every seed, 10/10 per stratum.
4. Failed fits retain `log(10)` in score; undefined measured dispersion stops ranking.
5. Single-dataset bus screens cannot pass seed dispersion or uncertainty gates; add no data and waive no gate.
6. Rank development at B1 20k and other screens 50k caps; lock deployment horizons separately.
7. Imported rates require same-optimizer donors in the prescribed screen; absent donor stops admission.
8. Fidelity uses common design fields across heterogeneous locks; rho preference applies only if every compared cell uses rho 1.
9. Use stage-specific P0/P0* denominators; unresolved noncircular P0* provenance stops ranking.
10. Recover a failed/missing/invalid paired reference only as identical evidence; otherwise stop.
11. Apply `SD_candidate <= 1.5*SD_P0*` literally when P0* SD is zero; undefined SD stops.
12. No feasible non-rescue B3 winner stops this development version and makes transfer not assessable.
13. Equal compute counts Q plus zeta updates; report row counts and wall time separately.
14. Unsupported compute prefix before 5k stops the affected ranking.
15. Tie SE is paired-difference sample SD over 2,000 whole-data bootstrap resamples.
16. NLL benchmark is the lowest finite median among fit-count-eligible candidates; absent benchmark stops.

The winner formula, `.005` NLL guard, reference/variability/timing rules, DGP constants and protected headline pools are unchanged. No tolerance was loosened.

## Audit outcome

`results/tuning/u2_audit.json` records the development-only bus audit. B1 and B2 each have a single `bus_seed7000` data block. Their selected rows cannot be certified under default 5, and no noncircular adopted-rule P0* selection map exists under default 9. In the limited raw-M/.005/full-fit comparison, the three families with complete B2 candidates retain their old raw-M leaders; signed/k>1 has no complete B2 candidate and its old rescue fallback retains the fourth key. Nominal membership is unchanged in that partial replay. This is descriptive, not an adopted-rule finalist set, so certifiable B3 membership under U2 remains **undetermined**.

The old B3 has 80 published per-fit truth files and a published `B3_confirmation.json`. Its truth was exposed before the U2 candidate, reference, selector and bootstrap hashes existed. Its reported winner and subsequent BL lock are exploratory only for U2 confirmation. No corrected B3 map or retroactive hash was created. The old bus result files were not modified.

Affected STOP outcomes: `SEED_DISPERSION_UNDEFINED` (B1/B2 promotions); `REFERENCE_SELECTION_UNRESOLVED` (P0* selection and dependent rankings); `CONFIRMATION_EXPOSED` (B3 confirmatory decision); `HASH_BARRIER` (pre-B3 U2 map/selector/bootstrap hashes absent). These stop valid c_bus, F1 admission and downstream ranking/freeze. No new confirmation seeds, reference substitutes, donor choices or waivers were added.

## Author common-protocol freeze — 2026-10-19 19:48 PDT

Authority: the appended author decision in `planning/final-decisions.md`, captured byte-for-byte at `protocol/final-decisions-2026-10-19.md` (SHA256 `0705da789152181f9c6e3fd362a2b2c22b5f4b40c9ae0e3707dac82c1346393b`). The author chose to freeze the exploratory bus lock and disclose its status rather than seek pristine reconfirmation. The frozen lock has embedded SHA256 `3a7749e7354fd1472320f76b2d2b62259847eed682dea6379ecff7f02129619b`. The common protocol is signed loss, k=10, lr_Q=0.001, rho=1, batch 1024, c_BE=1, separate 2x10 networks, anchor bias, AdamW, 50,000 Q updates. The frozen record is `protocol/common_protocol_freeze.json` (SHA256 `dcba37006a1ef6747671f03fc4e9a88f388ad2f4261086c45a32656788d7afba`). The protected headline manifest is `c0df9e599c99f663190f6aff31450f4bda17172c0cae24e9bfe3fe7d24a42c39` and has not been opened for training.

The prior U2 audit remains accurate: old B3 confirmation truth was exposed before the amendment hashes, and the bus lock is exploratory. The author decision closes common-protocol design selection with that disclosure. It does not relabel old B3 evidence as confirmatory or change a DGP, tolerance, loss, or fit failure rule. The frozen-design F1/F2/F3 manifests use only development pools. F1 runs the frozen signed/k10 recipe in all four F1 width/N strata (12 fits); F2 runs the exact 12 nuisance rows around that fixed family on the F2 pools (72 fits), for sensitivity only; F3 confirms the frozen recipe on its five seeds and two initializations in all four strata (40 fits). D has its eight declared width/N/seed cells and remains a pre-headline policy gate. These are a scoped transfer/feasibility subset of the inherited 144/288/160 candidate search. No F2 or F3 outcome may change the author-frozen common protocol. All failed records retain their original slots.

Headline launch remains conditional on the fleet feasibility requirements, including the F3 10/10 per-stratum rule and joint D KL <=0.02. The inherited U2 reference and comparative gates have not yet been certified for this frozen subset; an absent reference is reported as unresolved, not filled by a substitute. The capacity-coupled extension remains behind headline work.
