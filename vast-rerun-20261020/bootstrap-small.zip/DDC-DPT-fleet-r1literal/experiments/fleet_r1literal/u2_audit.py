"""Audit disclosed bus development tables without opening confirmation truth files."""
import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

EMBEDDED_AMENDMENT_SHA256 = "215a24fb439a0dd950ea0fce33f0ff147bca9dd8edfee4d884bf4ee5a6f3f25c"

from .u2_decision import AMENDMENT_SHA256, Stop, require_p0star
assert AMENDMENT_SHA256 == EMBEDDED_AMENDMENT_SHA256

BUS = Path.home() / "DDC-DPT-fleet/experiments/fleet_capacity_one"
OUT = Path(__file__).resolve().parent / "results/tuning/u2_audit.json"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def family(c):
    if c["loss"] == "none":
        return "none_k1" if int(c["k"]) == 1 else "none_k3_5_10"
    return c["loss"] + "_anyk"


def inspect_stage(stage):
    base = BUS / "results/tuning"
    manifest_path = base / f"manifests/manifest_{stage}.json"
    candidates_path = base / f"{stage}_candidates.csv"
    fits_path = base / f"{stage}_fits.csv"
    manifest = json.loads(manifest_path.read_text())
    candidates = read_csv(candidates_path)
    fits = read_csv(fits_path)
    assert len(manifest["fits"]) == manifest["n_fits"] == len(fits)
    ids = sorted({str(x["data_id"]) for x in manifest["fits"]})
    return dict(manifest=manifest, candidates=candidates, fits=fits,
                data_ids=ids, statuses=dict(Counter(x["status"] for x in fits)),
                hashes={"manifest_file": sha(manifest_path), "candidates": sha(candidates_path),
                        "fits": sha(fits_path)})


def limited_comparison(stage, stage_data, original):
    """Descriptive raw-M screen only. This is never a certified promotion."""
    by = defaultdict(list)
    for r in stage_data["fits"]:
        by[r["config_id"]].append(r)
    out = {}
    for fam, orig in original.items():
        eligible = []
        family_rows = []
        for c in stage_data["candidates"]:
            if family(c) != fam or stage == "B2" and c["width"] != "10":
                continue
            family_rows.append(c)
            rr = by[c["config_id"]]
            if len(rr) != 3 or any(x["status"] != "ok" for x in rr):
                continue
            try:
                nll = float(c["med_nll"])
                score = sum(math.log(float(x["truth_nonanchor_rmse"])) for x in rr) / 3
            except (TypeError, ValueError, KeyError):
                continue
            if math.isfinite(nll) and math.isfinite(score):
                eligible.append((nll, score, c["config_id"]))
        best_nll = min((x[0] for x in eligible), default=None)
        nll_eligible = sorted((x for x in eligible if x[0] <= best_nll + .005),
                              key=lambda x: (x[1], x[2])) if best_nll is not None else []
        fallback = None
        if not nll_eligible and family_rows:
            fallback = min(family_rows,
                           key=lambda c: (int(c["n"])-int(c["n_ok"]),
                                          float(c["med_nll_plus_a2"]), c["config_id"]))["config_id"]
        nominal = nll_eligible[0][2] if nll_eligible else fallback
        out[fam] = dict(original_config_id=orig["config_id"],
                        limited_fallback_best=fallback,
                        limited_nominal_best=nominal,
                        limited_nominal_matches_original=(nominal == orig["config_id"]),
                        original_rescue=bool(orig["info"]["rescue"]),
                        full_fit_candidates=len(eligible), nll_005_candidates=len(nll_eligible),
                        limited_raw_M_best=nll_eligible[0][2] if nll_eligible else None,
                        limited_best_matches_original=bool(nll_eligible and nll_eligible[0][2] == orig["config_id"]))
    return out


def main():
    b1, b2 = inspect_stage("B1"), inspect_stage("B2")
    base = BUS / "results/tuning"
    centers_path, finalists_path = base / "B1_family_centers.json", base / "B2_family_finalists.json"
    centers, finalists = json.loads(centers_path.read_text()), json.loads(finalists_path.read_text())
    b3_manifest_path = base / "manifests/manifest_B3.json"
    b3_manifest = json.loads(b3_manifest_path.read_text())
    published = base / "B3_confirmation.json"
    disclosure = dict(published_confirmation_exists=published.exists(),
                      published_fits_table_exists=(base / "B3_fits.csv").exists(),
                      published_truth_file_count=len(list((base / "truth_B3").glob("*.json"))),
                      # No B3 truth JSON or confirmation result is opened here.
                      published_confirmation_sha256=sha(published) if published.exists() else None,
                      confirmation_mtime=published.stat().st_mtime if published.exists() else None)
    pretruth = dict(amendment_in_B3_manifest=b3_manifest.get("amendment_sha256"),
                    candidate_map_sha256=b3_manifest.get("candidate_map_sha256"),
                    rate_map_sha256=b3_manifest.get("rate_map_sha256"),
                    reference_map_sha256=b3_manifest.get("reference_map_sha256"),
                    selector_sha256=b3_manifest.get("selector_sha256"),
                    bootstrap_indices_sha256=b3_manifest.get("bootstrap_indices_sha256"))
    stops = []
    if len(b1["data_ids"]) < 2 or len(b2["data_ids"]) < 2:
        stops.append(dict(reason="SEED_DISPERSION_UNDEFINED", scope="B1/B2 promotions",
                          evidence="Both archives contain only bus_seed7000; three initializations are not independent data blocks."))
    p0star_provenance = b1["manifest"].get("p0star_provenance") or b2["manifest"].get("p0star_provenance")
    try:
        require_p0star(p0star_provenance)
    except Stop as e:
        stops.append(dict(reason=e.reason, scope="B1/B2 rankings and paired references",
                          evidence="No provenance-verified, noncircular adopted-rule P0* selection map is present."))
    if disclosure["published_confirmation_exists"] or disclosure["published_truth_file_count"]:
        stops.append(dict(reason="CONFIRMATION_EXPOSED", scope="B3 confirmatory decision",
                          evidence="B3 confirmation/fits publication and truth_B3 files predate U2 activation; existing B3 result is exploratory only."))
    if any(v is None for v in pretruth.values()):
        stops.append(dict(reason="HASH_BARRIER", scope="B3 truth-release barrier and dependent F1/F2/F3 freeze",
                          evidence="Pre-U2 B3 manifest lacks amendment and pre-truth candidate/rate/reference/selector/bootstrap hashes; cannot repair retroactively."))
    result = dict(amendment_sha256=AMENDMENT_SHA256,
                  stage_summaries={s:dict(n_fits=d["manifest"]["n_fits"],data_ids=d["data_ids"],
                                          statuses=d["statuses"],hashes=d["hashes"])
                                   for s,d in (("B1",b1),("B2",b2))},
                  source_hashes={"B1_selector":sha(BUS / "tuning/analyze.py"),
                                 "B2_selector":sha(BUS / "tuning/chunk2_analysis.py"),
                                 "B1_centers":sha(centers_path),"B2_finalists":sha(finalists_path),
                                 "B3_manifest":sha(b3_manifest_path)},
                  B1_limited=limited_comparison("B1",b1,centers),
                  B2_limited=limited_comparison("B2",b2,finalists),
                  original_B3_families=sorted(finalists),
                  adopted_rule_membership="undetermined: no certifiable B1/B2 promotions",
                  limited_membership="all four nominal B2 picks match in a partial raw-M/.005 and old rescue-fallback replay; no adopted-rule membership can be certified",
                  p0star_provenance_in_screen_manifests=p0star_provenance,
                  B3_pretruth_fields=pretruth,disclosure=disclosure,stops=stops,
                  confirmation_use="exploratory_only",corrected_B3_manifest_created=False)
    OUT.parent.mkdir(parents=True,exist_ok=True)
    OUT.write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+"\n")
    print(OUT)
    print(json.dumps({"stops":[x["reason"] for x in stops],"membership":result["adopted_rule_membership"],
                      "disclosed_B3_truth_files":disclosure["published_truth_file_count"]}))

if __name__ == "__main__":
    main()
