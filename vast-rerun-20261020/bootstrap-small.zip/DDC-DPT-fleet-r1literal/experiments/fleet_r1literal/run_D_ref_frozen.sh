#!/bin/bash
set -euo pipefail
cd "$HOME/DDC-DPT-fleet-r1literal"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONHASHSEED=0 CUDA_VISIBLE_DEVICES=""
for i in $(seq 1 100000); do
  if test -f experiments/fleet_r1literal/artifacts/logs/D_frozen.DONE; then break; fi
  sleep 30
done
test -f experiments/fleet_r1literal/artifacts/logs/D_frozen.DONE
~/miniconda3/envs/gym/bin/python -u -m experiments.fleet_r1literal.tuning_runner \
  experiments/fleet_r1literal/results/tuning/manifests/manifest_D_ref_frozen.json \
  experiments/fleet_r1literal/artifacts/tuning/fits_D_ref_frozen \
  experiments/fleet_r1literal/results/tuning/ledger_D_ref \
  > experiments/fleet_r1literal/artifacts/logs/D_ref_frozen.log 2>&1
cp experiments/fleet_r1literal/results/tuning/ledger_D_ref/accounting_D.json \
  experiments/fleet_r1literal/results/tuning/ledger/accounting_D_ref.json
printf '%s\n' "$(date -u +%FT%TZ) D reference complete" > experiments/fleet_r1literal/artifacts/logs/D_ref_frozen.DONE
