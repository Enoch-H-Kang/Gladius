"""Per-stage evidence table with every scheduled fit slot retained."""
import csv
import json
import statistics
import sys
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"results/tuning"

def report(stage):
    manifest=json.loads((OUT/"manifests"/f"manifest_{stage}.json").read_text())
    if len(manifest["fits"])!=manifest["n_fits"]:
        raise ValueError("manifest count mismatch")
    rows=[]
    for spec in manifest["fits"]:
        fid=spec["fit_id"]
        rp=ROOT/"artifacts/tuning"/f"fits_{stage}"/fid/"record.json"
        tp=OUT/f"truth_{stage}"/(fid+".json")
        rec=json.loads(rp.read_text()) if rp.is_file() else None
        truth=json.loads(tp.read_text()) if tp.is_file() else None
        if rec is not None and (rec["fit_id"]!=fid or rec["manifest_sha256"]!=manifest["sha256"]):
            raise ValueError("record provenance mismatch "+fid)
        if truth is not None and truth["fit_id"]!=fid:
            raise ValueError("truth provenance mismatch "+fid)
        for horizon in spec["horizons"]:
            hr=rec["horizons"].get(str(horizon),{}) if rec else {}
            th=truth["horizons"].get(str(horizon)) if truth else None
            cfg=spec["config"]
            row=dict(stage=stage,fit_id=fid,config_id=spec["config_id"],
                     data_id=spec["data_id"],init_index=spec["init_index"],
                     N=spec["n_chains"]*100,horizon=horizon,
                     architecture=cfg.get("architecture"),loss=cfg["loss"],k=cfg["k"],
                     lr_q=cfg["lr_q"],rho=cfg["rho"],batch=cfg["batch"],
                     c_be=cfg["c_be"],bias=cfg["bias"],opt=cfg["opt"],
                     status=hr.get("status","missing_record"),fit_status=rec["fit_status"] if rec else "missing_record",
                     nll=hr.get("nll"),anchor_rmse=hr.get("anchor_rmse"),top1=hr.get("top1"),
                     selected_step=hr.get("step"),checkpoint_hash=hr.get("hash"),
                     reward_rmse=th.get("nonanchor_rmse") if th else None,
                     q_rmse=th.get("q_rmse") if th else None,
                     policy_kl=th.get("kl") if th else None,
                     uniform_reward_rmse=th.get("uniform_nonanchor_rmse") if th else None,
                     total_seconds=rec["time"]["total"] if rec else None,
                     q_seconds=rec["time"]["q"] if rec else None,
                     z_seconds=rec["time"]["z"] if rec else None,
                     validation_seconds=rec["time"]["val"] if rec else None,
                     q_updates=rec["counts"]["q_updates"] if rec else None,
                     z_updates=rec["counts"]["z_updates"] if rec else None,
                     peak_rss_kb=rec.get("peak_rss_kb") if rec else None,
                     start_unix=rec.get("start_unix") if rec else None,
                     end_unix=rec.get("end_unix") if rec else None)
            rows.append(row)
    OUT.mkdir(parents=True,exist_ok=True)
    csvpath=OUT/f"{stage}_fits.csv"
    with csvpath.open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        w.writeheader();w.writerows(rows)
    latest=max(s["horizons"][-1] for s in manifest["fits"])
    terminal=[r for r in rows if r["horizon"]==latest]
    recorded=[r for r in terminal if r["fit_status"]!="missing_record"]
    timed=[r for r in terminal if r["start_unix"] is not None]
    numeric=lambda key:[r[key] for r in terminal if r[key] is not None]
    summary=dict(stage=stage,scheduled=len(terminal),records=len(recorded),
                 truth_rows=sum(r["reward_rmse"] is not None for r in terminal),
                 statuses=dict(Counter(r["status"] for r in terminal)),
                 fit_statuses=dict(Counter(r["fit_status"] for r in terminal)),
                 median_reward_rmse=statistics.median(numeric("reward_rmse")) if numeric("reward_rmse") else None,
                 median_nll=statistics.median(numeric("nll")) if numeric("nll") else None,
                 median_anchor_rmse=statistics.median(numeric("anchor_rmse")) if numeric("anchor_rmse") else None,
                 active_fit_core_seconds=sum(numeric("total_seconds")),
                 elapsed_fit_wall_seconds=(max(r["end_unix"] for r in timed)-min(r["start_unix"] for r in timed)) if timed else 0,
                 manifest_sha256=manifest["sha256"])
    (OUT/f"{stage}_summary.json").write_text(json.dumps(summary,indent=2,allow_nan=False)+"\n")
    print(json.dumps(summary,allow_nan=False))

if __name__=="__main__":
    report(sys.argv[1])
