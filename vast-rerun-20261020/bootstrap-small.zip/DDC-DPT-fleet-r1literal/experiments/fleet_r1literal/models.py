"""Fleet architectures. Unrestricted classes receive only the full state."""
import math
import torch
from torch import nn
from ..fleet_capacity_one.fleet.models import MLP

class Linear(nn.Module):
    def __init__(self):
        super().__init__(); self.linear=nn.Linear(5,32)
    def forward(self,x): return self.linear(x)

class Additive(nn.Module):
    def __init__(self):
        super().__init__()
        self.g=nn.ModuleList([
            nn.Sequential(nn.Linear(1,16),nn.ReLU(),nn.Linear(16,16),
                          nn.ReLU(),nn.Linear(16,32,bias=False))
            for _ in range(5)])
        self.bias=nn.Parameter(torch.zeros(32))
    def forward(self,x):
        return self.bias+sum(g(x[:,f:f+1]) for f,g in enumerate(self.g))

class Factored(nn.Module):
    def __init__(self,bits):
        super().__init__()
        b=torch.as_tensor(bits,dtype=torch.int64)
        if b.shape!=(32,5): raise ValueError("factored bit map must be 32 by 5")
        self.register_buffer("bits",b)
        self.g=nn.ModuleList([MLP(1,2,16,2) for _ in range(5)])
    def forward(self,x):
        return sum(g(x[:,f:f+1])[:,self.bits[:,f]] for f,g in enumerate(self.g))

def build(arch,structure_info=None):
    if arch != "factored" and structure_info is not None:
        raise ValueError("structure_info forbidden for this class")
    if arch=="linear": return Linear()
    if arch=="mlp1x5": return MLP(5,32,5,1)
    if arch=="mlp2x10": return MLP(5,32,10,2)
    if arch=="mlp2x64": return MLP(5,32,64,2)
    if arch=="mlp2x128": return MLP(5,32,128,2)
    if arch=="additive": return Additive()
    if arch=="factored":
        if structure_info is None or set(structure_info)!={"bits"}:
            raise ValueError("factored requires declared bit map")
        return Factored(structure_info["bits"])
    raise ValueError("unknown architecture")

def initialize(net,seed,out_bias):
    gen=torch.Generator().manual_seed(int(seed))
    with torch.no_grad():
        for layer in net.modules():
            if not isinstance(layer,nn.Linear): continue
            fan_out,fan_in=layer.weight.shape
            layer.weight.copy_(torch.randn(layer.weight.shape,generator=gen)*
                               math.sqrt(2/(fan_in+fan_out)))
            if layer.bias is not None: layer.bias.zero_()
        if isinstance(net,Linear): net.linear.bias.fill_(float(out_bias))
        elif isinstance(net,Additive): net.bias.fill_(float(out_bias))
        elif isinstance(net,Factored):
            for g in net.g: g.layers[-1].bias.fill_(float(out_bias)/5)
        else: net.layers[-1].bias.fill_(float(out_bias))
    return net

def factory(cfg,meta):
    arch=cfg.get("architecture")
    info=cfg.get("structure_info")
    if arch!="factored" and info is not None: raise ValueError("structure_info forbidden for this class")
    if meta["n_actions"]!=32 or meta["anchor_action"]!=0: raise ValueError("fleet action metadata mismatch")
    return build(arch,info)
