"""Independent five-bus scalability experiment."""
