"""Save and load the independent component reference."""
import json
from pathlib import Path
import numpy as np
from .oracle1d import Component
from .query import Reference

def save(root,comps,manifest):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    for f,c in enumerate(comps): np.save(root/("v_bus%d.npy"%(f+1)),c.values)
    (root/"reference_manifest.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")

def load(root):
    root=Path(root)
    return Reference([Component(f,np.load(root/("v_bus%d.npy"%(f+1)))) for f in range(5)])
