# Author-frozen fleet transfer run

Common-protocol freeze: `protocol/common_protocol_freeze.json`, SHA256 `dcba37006a1ef6747671f03fc4e9a88f388ad2f4261086c45a32656788d7afba`; bus lock embedded SHA256 `3a7749e7354fd1472320f76b2d2b62259847eed682dea6379ecff7f02129619b`. The author decision is the 2026-10-19 19:48 PDT entry of `planning/final-decisions.md`, copied to `protocol/final-decisions-2026-10-19.md`.

Frozen transfer manifests (development only): F1 12, F2 72, F3 40, D 8. The original multi-recipe tuning matrix is not used to select a common protocol; the author already froze it. F2 nuisance rows are descriptive. All pools, RNG streams, checkpoints and failure slots are fixed in the manifests before training. The F1 server runner writes `artifacts/logs/F1_frozen.DONE`; the queued sequential runner writes F2, F3 and D DONE markers after each accounting record. Logs are in `artifacts/logs`, per-fit records in `artifacts/tuning`, and launch/usage ledgers in `results/tuning/ledger`.

The headline manifest remains sealed as `c0df9e599c99f663190f6aff31450f4bda17172c0cae24e9bfe3fe7d24a42c39`. Headline fitting is pending fleet feasibility, including the 10/10 F3 count and joint D KL <=0.02. The U2 reference/variability/timing comparisons are not yet established and cannot be called passed. Coupled extension is queued after headline capacity.
