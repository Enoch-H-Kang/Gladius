# GLADIUS scalability redesign — final synthesis

This is the implementation contract for the independent primary scalability arm and the retained capacity-constrained extension. The original discrete Zurcher bus remains the paper's main experiment. This document specifies work; it does not certify results, change a running lock, or authorize a tolerance relaxation. Build the settled portions below; stop only the dependent stages identified in **UNRESOLVED**.

## Sources and precedence

Both convergence documents were read in full. References below use these local sources; a citation at the end of a paragraph or table heading supplies its numerical constants as well as its design rules.

| Key | Source |
|---|---|
| CC | [Codex convergence](r1literal-converge-codex.md) |
| LC | [Claude convergence](r1literal-converge-claude.md) |
| CS | [Codex source spec](r1literal-spec-codex.md) |
| LS | [Claude source spec](r1literal-spec-claude.md) |
| FD | [User-approved final decisions](final-decisions.md) |
| TF | [Tuning final design](tuning-final-design.md) |
| TC | [Tuning Codex specification](tuning-r2-codex.md) |
| TL | [Tuning Claude specification](tuning-r2-claude.md) |
| R2 | [Earlier executable specification](r2-claude.md) |
| AG | [Workspace AGENTS.md](/home/hatch/AGENTS.md), GLADIUS R1-literal convergence entry |

FD's latest experiment-design decision supersedes its older coupled-primary arrangement. TF controls the tuning study: TC supplies estimator/data/stages and operational locks; TL §3.4 supplies the development winner rule, as TF explicitly directs. Do not substitute TC's competing development score or separate-testbed default. The shared-code restriction in AG and the existing prohibition on loosening tolerances remain binding. The latter is recorded in LC F9 and in the [launch instruction](/home/hatch/workspace/cron.d/runonce/gladius-midnight-headline-launch__runonce@2026-10-19T00:00:00.md).

## Decisions between the convergence documents

Agreements are implemented in the sections that follow. Each disagreement resolved here has one stated evidentiary reason; unresolved authority or missing protocol choices remain below.

| Issue | Decision and one-line justification |
|---|---|
| Truncation | **CC: support `L_f=5 μ_f`.** This completes the earlier S1 support; LC F2 finds no material policy advantage for its alternative, and its stronger-truncation rationale is presentational rather than identifying evidence. [CC D1; LC C1; CS §2.2] |
| Burn-in | **LC: retain the existing KS rule.** The rule is explicitly specified in R2 §d.7; LC F3 predicts zero under it, whereas CC's unconditional zero changes the approved recording rule. [LC C2; CC D2] |
| Pilot size | **LC: primary pilot has 1,000,000 retained transitions.** Its rare-action-count calculation supports a larger coverage diagnostic than CC's 200,000; use chain-based uncertainty rather than treating those rows as independent. [LC C16; CC D3/M9] |
| Pilot thresholds and failure remedy | **Author decision required for threshold changes; retain the existing frozen-constant rule.** Neither document can authorize a looser acceptance rule, and FD explicitly limits the existing rescale exception. [LC F9/C3–C4; CC D3–D4; U1 below] |
| Reference acceptance | **CC: continuous interval enclosure required for certified release.** A finite residual panel cannot bound a supremum, and the contraction bound sums all component defects. [CC R2; LC C6; CS §3.3] |
| Richardson order | **CC: diagnostic, not an independent veto when the certificate passes.** CC R3 identifies the finite-endpoint ratio error; successive-grid estimates do not replace the continuous bound. |
| Forward validation | **CC: component rollouts plus the smaller joint check.** These detect simulation/convention bugs; neither proposed Monte Carlo budget certifies the requested uniform accuracy. [CC R4/§4.2; LC C6] |
| Singleton reward labels | **CC terminology; retain both measurements.** A raw singleton joint reward includes other buses' maintenance and therefore is not a recovered component reward. [CC E4; LC C9] |
| Coupled positive control | **Recompute the new diagnostics.** CC M3 checks the actual V7 implementation and shows its multivariate projection is not LC's own-mileage-only S2 regression. |
| Action permutation | **Semantic equivariance, not bitwise retraining after label permutation.** Initialization rows, optimizer state and reduction order must be accounted for; default-path bus replay remains independently bitwise. [CC M5; LC G4] |
| Counterfactual accuracy | **CC's refinement contract, with the agreed K=21 production candidate.** Matching truth and estimate grids does not bound the learned-reward discretization error. [CC X8/§4.7; LC C11] |
| Optional larger sample | **CC: separately disclosed follow-up, not automatic headline expansion.** A trigger based on opened headline truth must not alter the primary study or its selection. [CC D6; LC B6; LS §3.2] |
| Runtime | **Measure the new workload before forecasting.** LC's one-thread inspection establishes scheduling, but neither document has measured the new full training and counterfactual workload. [LC F7/G8; CC X7–X8] |
| Tail-coverage gate | **CC: descriptive.** FD expressly makes the extra coverage statistics nongating, superseding the older tail requirement cited by LC G7. |
| Scheduler | **LC's inspected state plus CC's fail-closed requirements.** LC F9 says it was already repointed; there is no basis to cancel it merely because LS's older scheduler description is stale. |

## Implementation isolation and resource admission

Build on baker in a **separate git worktree**, branch `fleet-r1literal`, starting from the inspected commit `5c6cfcfa3bb449239a4386473e3214f42093111d`. Create `experiments/fleet_r1literal/` beside the historical coupled package. Record the full base commit and actual source hashes. Both source inspections found uncommitted tuning work in the live checkout: do not stash, commit, overwrite, or import mutable live files as a shortcut. Bring needed uncommitted dependencies into the isolated build only as an owner-reviewed, hash-recorded snapshot. [LC G1; CC X6/evidence snapshot]

The necessary shared integration is explicit:

- `fleet/train.py` constructs `MLP` directly, calls a `.layers`-specific initializer, and sets one Torch thread. Add optional factory/initializer injection whose **default path preserves the original MLP construction, initialization, RNG consumption, loss, update order and selector**.
- `tuning/evaluate.py` constructs `MLP(1, ...)`. Add an architecture-aware fleet evaluator that reloads the actual model specification and preserves the bus default.
- `tuning/data_io.load_bus` reshapes to one dimension and imports the bus anchor. Add a separate fleet loader preserving `(n,5)`, with `n_actions=32`, `anchor_action=0`, `state_scale=1`.
- A new component solver may reuse `bellman(..., Ps, ...)`; it must not call the existing Gamma-specific `solve_vi` or `lookahead_Q` as if they accepted a new law. Use explicit kernel/query injection or a new wrapper. [AG; LC F6–F8/G1; CC X4–X5]

**Before any merge**, run the **three P0 default-path replay fits** on the old and new implementations with identical input bytes, seeds, environment and resource settings. Require bitwise-identical loss traces and final Q/ζ weights; archive per-fit array comparisons, hashes, environment, commands and pass/fail results. Compare numeric content, not timestamp-bearing serialized-container bytes. A failed replay blocks merge. Merge only after bus BL completes, with the replay proof and both code-hash sets recorded in the common-protocol freeze. Existing bus manifests retain their original hashes; never silently rewrite them to the new code. [LC G1; AG]

**Baker limit: `<=44` actual compute threads across ALL concurrent project work.** Keep fitting at one thread. The maximum fit allocation is **42 one-thread workers plus 2 tokens for controller/evaluators**, reduced by any bus, reference, test, simulation or other project reservation. Use one atomic admission ledger; bound Torch/BLAS/OpenMP consistently and use no data-loader subprocesses. Larger evaluator/reference jobs reserve their actual thread demand by displacing fit workers; the two-token reservation is not an unlimited evaluator allowance. Count our project tokens, not other users' load average. [TF resources; FD RESOURCE RULE; LC G2; CS §6.3; AG]

## Frozen primary DGP

Save canonical `configs/dgp_r1literal.json`, the action table, and their full hashes before production data generation. Freeze the following values at cost scale **1.0**. These are the source constants, not tuning variables. [CC §1; CS §2.1; LC §1]

| Bus | u | v | Kcost | d | Mean increment μ | Support L=5μ |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 1.0 | 2.0 | 3.0 | 0.15 | 0.040 | 0.200 |
| 2 | 1.2 | 2.6 | 3.4 | 0.35 | 0.050 | 0.250 |
| 3 | 0.9 | 1.7 | 2.7 | 0.25 | 0.060 | 0.300 |
| 4 | 1.3 | 2.3 | 3.5 | 0.40 | 0.045 | 0.225 |
| 5 | 1.1 | 3.0 | 3.1 | 0.20 | 0.055 | 0.275 |

State is `[0,1]^5`; action bits are `a_f∈{0,1}`, encoded as `Σ_f a_f 2^(f−1)` with bus 1 least significant. All **32** actions are feasible; **0** is replace-none and the known anchor, **31** replaces all. Set `β=.95`, entropy temperature `1`, retained chain length `H=100`, and independent start coordinates `U[0,.5]`. There is no capacity constraint, common transition shock, shared charge, or cross-bus cost. [CC §1; LC §1]

```
m_f(x) = u_f*x + v_f*x²
C_f(x) = Kcost_f + d_f*x²
r_f(x,b) = -(1-b)*m_f(x) - b*C_f(x)
r(s,a) = sum_f r_f(x_f,a_f)
r0(s) = -sum_f m_f(x_f)
x'_f = 0                      if a_f=1
x'_f = min(1, x_f+D_f)         otherwise
```

Replacement pays replacement cost only and resets exactly to zero with no same-period increment. Restarts are recording operations, not transitions or terminals; retain the actual successor of the final row. The cap at one creates an atom. [CS §2.1]

Use **conditional** exponential truncation, not clipping an exponential draw and not conditioning on remaining mileage:

```
1/t - 5/expm1(5*t) = 1             # positive root
rho_f = t/mu_f
L_f = 5*mu_f
Z_f = -expm1(-rho_f*L_f)
p_f(d) = rho_f*exp(-rho_f*d)/Z_f   # 0 <= d <= L_f
D_f = -log1p(-U*Z_f)/rho_f
```

Solve and store full float64 precision; `t≈.9602015099445034` is only a displayed check. For `c=1-x`, cap mass is `(exp(-rho*c)-exp(-rho*L))/Z` when `0<c<L`, zero when `c>=L`, and one at `x=1`. Starts, per-bus action uniforms and per-bus increments use distinct named streams. The means match the frozen Gamma means; variances and realized capped increments do not. [CS §2.2; CC §4.1]

Use independent per-bus/action `Gumbel(-γ,1)` utility shocks. Their joint-action sums are correlated and are not independent Gumbels. Under additive truth, maximizing separates and yields the same joint softmax and centered soft value as the product of binary logits. Save Q/V with no Euler constant; entropy is summed once across buses. This equivalence is not asserted for nonadditive learned rewards. [CC D5; CS §2.3; LC C12]

**Frozen-constants rule:** do not change DGP constants outside this specification, never tune them on estimator results, and never change them silently. Preserve FD's existing exception exactly: **Kcost only**, multiplier grid **`{0.8,1.25,1.5,2.0}`**, **at most one rescale plus rerun, then escalate**. The default here remains scale 1.0. The unresolved pilot amendment does not activate an automatic DGP search. Any permitted rescale must be recorded, must invalidate/rebuild the affected reference, data and truth/lock hashes, and must finish before statistical ranking. For the retained extension, changing costs would contradict reuse of its existing K31 reference and therefore requires the author to reconcile scope first. [FD pilot; CS §6.2; CC D4; U1]

## Reference, queries and acceptance

Implement `params.py`, `texp.py`, `rewards.py`, `env.py`, `oracle1d.py`, `query.py`, `assemble.py`, `tensor_subsets.py`, `validate_reference.py`, and tests in the new package. Follow the existing integrated-hat/lookahead numerical contract with the new exponential kernel. [CC §4.2; LC B1]

For each heterogeneous bus:

```
q_f(x,0) = -m_f(x) + beta*E[v_f(min(1,x+D_f))]
q_f(x,1) = -C_f(x) + beta*v_f(0)
v_f(x) = logsumexp(q_f(x,:))
Q(s,a) = sum_f q_f(x_f,a_f)
V(s) = sum_f v_f(x_f)
pi(a|s) = product_f softmax(q_f(x_f,:))[a_f]
```

The algebraic decomposition is exact; the saved functions are numerical. Zero reward must give `V=log(32)/(1−β)`. Do not divide temperature by the bus count or add another entropy term. [CS §3.1; LC §1]

Solve all five components at **K={1001,2001,4001,8001}**, float64, with **4001** the initial release candidate. Interpolate saved V linearly, `vtilde=I_K V`, and integrate its hats using clipped support intervals and the cap atom:

```
P(l,u) = (exp(-rho*l)-exp(-rho*u))/Z
M(l,u) = ((l+1/rho)*exp(-rho*l)-(u+1/rho)*exp(-rho*u))/Z
```

Use stable differences. At continuous x, compute analytic reward plus integrated `vtilde`, then `v_soft=logsumexp(q)`; never interpolate Q corners for production queries. Expose `component_query(f,x)->(q0,q1,v_soft,v_interp)` and `joint_query(S)->(Q,V,pi)`, with joint shapes `(n,32)`, `(n,)`, `(n,32)`. Validate cumulative-integral acceleration against direct hat rows. Simulation states and references stay float64; training copies are float32. Evaluate reward at the actual stored states and disclose input-rounding error in numerical-accuracy claims. [CC R1/M8/§4.2; CS §3.2]

Required numerical checks and release status [CC R1–R5/§4.2; CS §3.3; LC §1 item 9]:

| Check | Contract |
|---|---|
| Kernel | Row sum error `<=1e-12`; weights `>=−1e-13`; record roundoff clipping. Independent composite Gauss–Legendre path splits at interpolation/support/cap breakpoints, increases order `10→20`, and agrees within `1e-10`. |
| Iteration | Reload V and recompute `||T_K V−V||∞<=1e-11` per bus; cap at **2,000** sweeps; nonconvergence/nonfinite values fail explicitly. |
| Empirical panels | Per bus: **20,001** uniform points, **10,000** independent random points, grid midpoints, reset/cap neighborhoods and `1−L_f`. Preserve an independent cross-implementation panel. |
| Cross-grid | K2001→4001 maximum q change `<=2e-5` per bus; report RMS/max separately and the K4001→8001 comparison. |
| Continuous defect | Enclose `δ_f=||T_f vtilde_f−vtilde_f||∞<=1e-6` over every interval, including arithmetic/integration allowance. A dense-panel maximum alone is not this quantity. |
| Joint bound | `epsilon_Q = beta/(1−beta)*sum_f δ_f + query allowance <=1e-4`; component targets give `9.5e-5`, leaving **5e-6** for separately bounded query error. Store measured terms. |
| Algebra | Explicit 32-way lse/product-softmax identities within `1e-12` on ordinary-scale float64 fixtures; β=0, zero reward/log32, reset/cap and encode/decode controls. |
| Direct tensor | K=9 five-dimensional subset-action solve versus the sum of **same-grid** 1-D solves within `1e-10`, including lookahead on both sides off-grid. This checks the discretized algebra, not continuum accuracy. |
| Two-bus control | Explicit four-action enumeration; F=2 K401 tensor versus fine K4001 components as a measured discretization diagnostic, not an assumed uniform certificate. |

Implement the interval enclosure from CS §3.3: split at original and shifted interpolation knots and the truncation junction; on each interval bound the second derivative of `T vtilde`, combine endpoint residual bounds with `M h²/8`, and bisect loose intervals. Include floating-point allowances. If K4001 fails, promote/refine and recertify; an unresolved failure remains a reference-development failure. Empirical-only artifacts may support engineering, but cannot satisfy this certified release contract or carry a uniform-bound claim. [CC R2/§4.2]

Report successive-grid order and Richardson estimates with their target resolution. `(Q4001−Q8001)/(2^p−1)` estimates the K8001 leading error; multiply by `2^p` for K4001. Do not use the disputed `[1.5,2.5]` order window as a separate veto if the continuous certificate passes; do not subtract estimated errors from targets. Advantage error has bound `2*epsilon_Q`; policy comparisons need their own reported bound or measured stability. [CC R3/M11]

Use **10^6 independent increment draws per bus** for sampler support/moment/CDF/cap checks and **10^6 rows** for the joint categorical-versus-product generation check. Freeze streams before running; statistical checks are diagnostics, not repeated-until-pass experiments. Forward soft returns use **20 starts × 2,000 rollouts × 450 steps per component**, plus **20 × 1,000 × 450 joint rollouts**. Across the **100 component + 20 joint** start checks use the CC simultaneous normal interval with critical value `Phi^-1(1−.05/(2*120))`, adding numerical-reference and discounted-tail bounds. Report means, SEs and signed differences. The reward bound is `max(u_f+v_f,Kcost_f+d_f)` per bus and entropy bound `log 2`; these determine the discounted tail. The larger LS A′6/A′7 Monte Carlo suite is not an additional release requirement. [CC R4/§4.2; CS §3.3; LC B1]

Archive values, query implementation hash, `reference_manifest.json`, all check arrays and actual bound terms, and `reference_status.md`. Status is either certified with the measured bound, empirically validated/uncertified, or failed; never print “dense-panel bound” as a global certificate. [CC R2/§4.2]

## Pilot, recording and data isolation

Run the primary pilot at the fixed DGP: **10,000 chains × 100 retained transitions = 1,000,000**. The preliminary zero-burn run determines the inherited rule: use burn-in **50** iff any bus's KS distance between `t<20` and `t>=50` marginals exceeds **0.1**; otherwise use **0**. Freeze that result once before data pools; if it chooses 50, regenerate the recording-protocol pilot at that burn-in and report both. Prototype predictions are not a substitute for the production check. [LC C2/C16/B3; R2 §d.7]

Report all action counts and shares, counts by number replaced, per-bus decisions, quantiles/span, cap mass, replacement mileages, near-new replacements (`x_f<.1`), `P(x_f>.7)`, early/late occupancy, and pooled plus fixed-time cross-bus dependence. Use uncertainty clustered by chain. Publish the proposed and currently approved acceptance criteria separately; the pilot cannot be marked accepted until U1 is resolved. Tail, noise and congestion statistics are descriptive under FD. [CC D3/M9; LC B3; FD pilot]

After pilot acceptance, create **1,000 chains per protected replication**, data IDs **1000–1009**, with permanent **800/200** train/validation partitions established before nesting. Use nested prefixes within each partition: **8/2**, **40/10**, **160/40**, **800/200** chains for N **1,000/5,000/20,000/100,000**. N counts joint transitions, never per-bus decisions. Generate actions with independent binary draws and encode the joint categorical label. No balancing, rare-action resampling or replacement of failed seeds. [CC §4.3; CS §4.3]

Namespace streams with `r1literal_v1` and DGP/action-map hashes. Preserve TC §4 seed expansion: first eight bytes, big-endian, of SHA256 of UTF-8 `20261018|testbed|stage|data_id|init_index|stream_name`, modulo `2^63−1`; incorporate the new namespace in `testbed`. Store expanded integers and lineage. Candidate/loss/k stay out of paired stream keys. Q init, ζ init, CE, extra ζ, anchor and evaluation have separate stream names; factored initialization has its own namespace while data IDs remain paired. [TC §4; LC G9; CC §4.3]

Training exports contain only `s,sp:(chains,100,5)`, `a:(chains,100)`, total scalar `r0` per row, chain IDs, permanent split flags, stream IDs, dimension/anchor metadata, and arm/DGP/action-map/reference hashes. They exclude component rewards, cost/kernel parameters, action-bit features and truth sidecars. Evaluator truth lives separately in `artifacts/eval`. Reject any six-action or hash-mismatched input. [CC M10; LC G5/§1]

Final panels, all regenerated under the new DGP in separate **9999** streams [CC §4.3; CS §4.4; R2 §d.6]:

| Panel | Contents |
|---|---|
| E1 | **200** independent occupancy chains, **20,000** transitions, retaining labels and successors for untouched test NLL/top-1/calibration. |
| E2 | **20,000** jittered-stratified uniform states using the inherited construction. |
| E3 | `{.1,.3,.5,.7,.9}^5`, **3,125** states. |
| E4 | **1,024** face/boundary states; reuse and hash the existing construction, not a builder-chosen replacement. |

Cache all **32** reward/Q/probability columns and component reference queries in evaluator-only artifacts. Keep final panels disjoint from development **9997** (screen/refine), **9399** (confirmation), and **9998** (D only, **50 H100** chains). Projection fitting gets a separate **20,000-state** uniform panel and, for occupancy diagnostics, a separately generated occupancy fit panel. Never score a projection on its fitting states. Validation-chain fit statistics and untouched E1 test statistics have different fields. [CC M1/§4.3; TC §4; CS §4.5]

## Estimator and architecture contract

Use independent Q/ζ networks and disjoint optimizers. All unrestricted classes receive the full state and one categorical label, produce all action heads and train with one joint softmax. They receive no product features, component labels/anchors, transition kernel, additive initialization or separability penalty. `rhat=Q−βζ`. [CC §1/§4.4; LC §1]

Preserve the TC §3 estimator exactly: for anchor-batch rows, all operands shape `(B,)`,

```
v = logsumexp(Q(sp,:))
u = (Q(s,a)-r0(s)-beta*v)^2 - beta^2*(v-stopgrad(zeta(s,a)))^2
L_Q = CE_on_B2 + c_BE*mean_B1(1{a=anchor}*f(u))
L_zeta = mean((zeta(s,a)-stopgrad(logsumexp(Q(sp,:))))^2)
```

The **12** variants are rowwise `signed/clip0/abs × k∈{1,3,5,10}`. Clip0 and abs have zero derivative at zero; they transform the bracket before the whole-batch mean, not CE or the total loss. Each Q cycle has k fresh ζ batches, with the final ζ batch equal to the common CE batch across k arms, and a separately drawn anchor batch. Q is fixed in ζ steps; ζ is fixed in the Q step; Q gradients include current and successor states. Keep gradient-value clipping **1.0**, learning-rate decay `lr0/(1+t/10000)`, fixed Q-update clocks, fresh processes/models/optimizers, and no terminal polish unless adopted by the existing tuning protocol. [TC §3; TF]

Default centers, optimizer grids and initialization follow TC §3 exactly: ReLU/Xavier-normal, zero hidden biases; tuned choice of zero versus training-anchor-derived output bias; AdamW `(betas=.9,.999; eps=1e-8; decay=1e-4)` versus plain SGD without momentum/decay; `B_eff=min(B,ceil(N_train/8))`. Float32 CPU fits and float64 identity fixtures. Validation every **500** Q updates; checkpoint eligibility begins at **5,000**; horizons **10k/20k/50k** are prefixes of one trajectory, not extra fits. [TC §3]

| Class | Q and ζ architecture | Role |
|---|---|---|
| linear | affine `5→32` | Restricted comparator |
| mlp1x5 | `5→5→32`, ReLU | Small-capacity comparator |
| additive | `b_a+Σ_f g_f(x_f)_a`, `g:1→16→16→32`, no component output biases | State-additive informed comparator |
| mlp2x10 | `5→10→10→32` | Unrestricted |
| mlp2x64 | `5→64→64→32` | Unrestricted |
| mlp2x128 | `5→128→128→32` | Unrestricted |
| factored | `Σ_f g_f(x_f)[a_f]`, `g:1→16→16→2` | Product-structure informed benchmark |

[CC §4.4; CS §4.2; LC C5]

Additive and factored are structurally appropriate, not guaranteed exact realizations of smooth truth by finite ReLU nets. Neither is eligible for the selected-method row, whose pool is only **2x10/2x64/2x128**. Factored receives the bit map only through whitelisted `structure_info`; MLP/linear/additive schemas reject it. It trains on the same joint transitions, joint loss and total anchor, never five separately supervised tasks. Use one global output bias for additive and distribute the intended total bias across factored components as `b/5`. Do not score ungauged component Q levels. Publish parameter counts and cost with MLP/factored error ratios; the ratio also reflects architecture/capacity/optimization. [CC E1–E3/E8/M6/M12; LC G5]

Rerun inherited trainer controls T1–T16 for the new action space, including shape/mask, signed/clip0/abs gradients, parameter isolation, fresh starts, checkpoint reload, anchor-only/anchor-free batches, missing-validation-anchor failure, frozen-Q/tabular controls, import-graph isolation and truth-unavailable replay. Add encode/decode, multi-reset, all-action rewards, sampler, joint-generation, centering and total-output-bias controls. [CC §4.4; LC B1/B4; TC §5]

For action permutation, permute labels, anchor index, Q/ζ output rows/biases and any optimizer state, hold batches fixed, unpermute outputs and check losses/gradients/updates on float64 fixtures at **1e-10**. Factored is exempt from arbitrary-label symmetry and instead validates its declared bit map. This test does not replace truth-isolation tests or the bitwise bus replay. [CC M5; LC G4]

The plug-in test distinguishes `zeta_interp=E[vtilde(sp)]`, for which `Qref−β*zeta_interp=r` by construction, from `E[logsumexp Qref(sp)]`, which differs by the continuous defect. Check the first recovery identity at **1e-6**, report the second with its residual budget, and run the independent two-successor signed-loss/gradient test. ζ lag means deviation from the continuation of the **current learned Q**, not the reference Q. [CC M4; LC B4; TC §3/§6]

## Tuning winner and operational locks — unchanged protocol

The tuning winner is promoted to the headline; signed/k=1 remains the compulsory appendix reference; shared-trunk released-code behavior is an ablation. Development truth ranks **observable-selected** checkpoints. Headline data and final truth never select a design, class, initialization, checkpoint, rate or horizon. One common design is selected across the original bus and independent fleet; the coupled arm is not a third tuning testbed. [TF; CC §1; LC §1]

The following winner rules are carried from **TL §3.4**, as required by TF; the only action-domain substitution is fleet non-anchor actions **1–31** instead of the old **1–5**:

- Primary M: occupancy-state non-anchor reward RMSE, equal weight to each non-anchor action at each state; bus keep action, fleet all non-anchor joint actions. Do not replace it by policy weighting.
- Stage score: `S(c)=mean_strata mean_data_seeds log(M_c/M_ref)`, paired by seed and equally weighted across strata. B1/F1 reference is P0 in the same cell; B2/F2 reference is family (i)'s centre P0* in the same cell; B3/F3 reference is P0*. Failed fits score `log 10`. Compute the score separately per stopping policy; multiple policy results from one fit are not replications.
- Feasibility: at least **90%** eligible per stratum; screens require all, confirmation requires **9/10 on bus** and **5/5 on fleet**, with **4/5 only for 2x128**; seed SD of log M at most **1.5×** P0*; median validation NLL at most stratum best **+0.005**; equal-Q wall time at most **4×** P0*, otherwise rank on the equal-gradient-evaluation curve.
- Tie set: feasible candidates within `max(log 1.05,1.96*SE)` of minimum S; SE uses **2,000** cluster bootstrap resamples over data seeds with initializations nested.
- Fidelity order: signed < clip0 < abs; smaller k; separate < shared trunk; plain SGD < SGD-momentum < AdamW; `c_BE=1`; `rho=1`; default batch/bias; shorter stopping policy; config ID. The present estimator contract still restricts candidates to its permitted separate-network optimizer families; the ordering does not add variants.
- A heuristic displaces P0* only outside its tie band, with at least **5%** geometric gain and a paired CI excluding zero.
- Hash the confirmation decision script and candidate list before exposing confirmation truth.
- Common-design candidates must have confirmation scores on **both** testbeds, excluding refcode/rescues. `regret_X(D)=S_X(D)−min_D' S_X(D')`; choose the design minimizing `max(regret_bus,regret_fleet)`. Ties within the larger testbed tie band prefer fleet regret, then fidelity.
- Preserve TL's design identity `(loss,k,trunk,optimizer family,c_BE,B,bias rule,stopping policy)`; learning rates are excluded. Preserve TF's observable per-testbed/class lr/horizon locks. Their unresolved interface with the stage schedule is U2, not permission to silently redefine design identity.
- Transfer verdict for the bus-only B3 winner: CONFIRMED if in the F3 tie set for both widths **2x10/2x64**, PARTIAL for one, FAILED otherwise. Only FAILED permits the existing per-testbed-winner exception, disclosed with the minimax design as sensitivity. Strong heuristic-transfer claims additionally require beating P0* in every F3 stratum, no failure increase and NLL loss at most **0.01/transition**.
- Report observable versus reward-best winner and their gap, plus rank correlation; if correlation is below **0.3**, do not claim practitioners can recover the choice from observables.

These rules are not replaced by TC's reward-scale-normalized score, **+0.01** feasibility threshold, alternative bootstrap tie test, or separate-recipe default. Missing denominators/cross-testbed confirmations or ambiguity in nesting feasibility counts block the affected ranking/freeze as U2; do not invent them.

Operational checkpoint selection remains finite predictions and observed-anchor reward RMSE **A<=.10**, then minimum validation NLL with **.001** tie band, lower A, earlier step, hash. With no eligible checkpoint keep minimum `NLL+A²` only for diagnosis and flag failure; no anchor validation rows means unassessable/failed, without redraw. Failed fits retain their slots and denominators. [TC §6; TL §3.4; CC §4.4]

Rate locks use TC's six optimizer-specific `(lr_Q,rho)` pairs: AdamW **`{1e-4,3e-4,1e-3}×{1,3}`**, SGD **`{1e-3,1e-2,1e-1}×{1,3}`**, at **10k/20k/50k** prefixes. Require **3/3** eligible runs per policy; minimize median selected NLL with **.001** tie band, then median A, shorter horizon, rho=1, smaller lr_Q, ID. Freeze before evaluating lock truth. Ineligible restricted/informed rows remain labeled failures; flexible locks and FS/D must pass their existing requirements. Headline selected-class ties use A, fewer parameters, class ID after the NLL tie band. [TC §§5–6; CC E3/§4.5]

**D stays joint `KL(pi_ref||pi_hat)<=.02`**, at width64/N100k on **both** D seeds and reserved panel **9998**. Evaluate signed/k=1 reference checkpoints separately; a heuristic pass does not imply signed passed. Failure stops headline launch and records a failed development version; no same-data tolerance relaxation. Marginal KL is not a substitute. [CC E7; LC C13; TC §6]

## Stages, seeds and counted work

Preserve bus P0/B1/B2/B3/BL/BR/AB under their existing locks. All fleet F stages below move to the independent DGP. Archive old coupled development manifests without counting them as new fleet results. F1 requires bus BL transfer inputs, new reference acceptance, accepted/frozen pilot data, and fleet trainer controls. [CC §4.5; LC B5; TF]

| Stage | Exact inherited allocation | Data IDs/panel | Fits |
|---|---|---|---:|
| F1 | 12 loss/k recipes × widths10/64 × N20k/100k × 3 data seeds | 9100–9102 / 9997 | 144 |
| F2 | 4 protected family centres × 12 nuisance rows × widths10/64 × 3 seeds, N20k | 9200–9202 / 9997 | 288 |
| F3 | 4 family finalists × widths10/64 × N20k/100k × 5 seeds × 2 inits | 9300–9304 / 9399 | 160 |
| FL | 6 classes × 6 rate pairs × 3 seeds, N20k | 9400–9402 | 108 |
| Factored lock | 6 rate pairs × 3 seeds, N20k; separate init namespace | Same FL data blocks | 18 |
| FS | 6 locked classes × N1k/5k × 3 seeds | 9450–9452 | 36 |
| D | widths10/64 × N20k/100k × 2 seeds | 9700–9701 / 9998 | 8 |
| FR | refcode width64, N20k × 3 F1 seeds | 9100–9102 | 3 |
| AF | 12 variants × 5 fresh reporting seeds, width64/N20k | 12050–12054 / 12998 | 60 |

[CC §4.5; CS §6.2; TC §§4–5; LC G9]

F1/F2/F3/FL/FR run to **50k** Q updates; FS/D use their locked cap, at most **50k**. AF retains its equal-budget prefix reporting. Keep all four protected families: signed/k1; signed/k3,5,10; clip0; abs. F1 transfers all twelve recipes, including bus losers, with the bus winner evaluated at its BL-locked horizon as well. Follow TC §5's exact mapping from B3/B1 and its exact F2 rows: centre; eta divided/multiplied by **3**; rho divided/multiplied by **3**; the other two batches in **{64,256,1024}**; the other two weights in **{.3,1,3}**; bias toggle; optimizer switch to SGD rates **{3e-3,3e-2}** or AdamW **{1e-4,1e-3}**, preserving rho. No truth-driven grid expansion or removal of protected families. [TC §5; TF]

The inherited fleet subtotal is **807**, including AF; the factored lock makes it **825**. Factored does not join common-design ranking or silently expand FS/D. Do not add obsolete P5a/P5b. U2 may require an explicit additional confirmation/reference allocation; these numbers must not be represented as a complete cost for a minimax freeze while U2 is open. [CC §4.5; LC C17]

Reporting allocation [CC §4.5/§4.7; LC B6/X; R2 §d.8]:

| Block | Fixed matrix | Fits |
|---|---|---:|
| M1 | 6 inherited classes × 4 N × 10 protected data blocks | 240 |
| M1b | factored × same 4 N × same 10 data blocks | 40 |
| M2 | compound refcode widths10/64 × 4 N × first 5 protected blocks | 40 |
| M2b | BC width64 × 4 N × first 5 protected blocks | 20 |
| M3 | width64/N20k; lr `{1e-4,3e-4,1e-3,3e-3}` × batch `{64,256,1024}` × first 3 protected blocks | 36 |
| FL-ext | additive/2x10/2x64 × 6 rate pairs × 3 development blocks | 54 |
| Extension | additive/2x10/2x64 × N5k/20k/100k × 5 paired blocks | 45 |
| **Known fleet fit allocation** | **825+240+40+40+20+36+54+45** | **1,300** |

Use new extension-namespaced streams with the inherited FL data IDs and the first five headline data IDs; numeric ID reuse is not shared data across different DGPs. M2 is the existing compound shared-trunk/overlapping-optimizer/anchor-row-mean abs diagnostic; M2b is CE-only with its ζ step. They do not replace AF or the signed reference. M3 changes only its declared sensitivity knobs around the frozen recipe, never selects a new headline recipe. [TC §§3–5; R2 §d.5/§d.8; CC X1]

The known allocation excludes bus fits, engineering/reference tests, four-step estimator work, U2 additions, and counterfactual solves. A timing-based trim from **10 to 5 paired replications** remains only FD's contingency, decided before headline outcomes and recorded consistently across paired blocks and derived solve counts. Optional **N300k, widths64/128 × 5 = 10 fits**, and optional fleet-size expansion are outside the allocation; no automatic launch based on headline RMSE. [FD data protocol; CC D6/§4.5; LS §3.2]

## Metrics and discovery reporting

Primary reward endpoint is `sqrt(mean_E1 mean_{a!=0}(rhat-r)^2)` with equal action weight. Co-report reference-policy-weighted error without changing selection. Include all-action/anchor errors, per-action reward errors and non-anchor MAPE; do not apply MAPE to zero-capable anchor/component rewards. Report raw Q and anchor-relative advantage RMSE with their relevant reference uncertainty, joint NLL/top-1/excess NLL, expert-argmax agreement, joint KL/TV, marginal Brier/KL/calibration and replacement-count calibration. Test E1 and selection-validation metrics remain distinct. [CC §4.6; CS §4.4; LC §1 item 13/G3]

For every fit save `observed_in_train[32]`, training action counts, and reward/Q metrics split by observed versus unobserved actions and replacement count **0–5**. The combinatorial equal-action weights persist even when a head has no data; report actual coverage next to them. LC F10's prototype illustrates the imbalance but is not a measured result for the chosen DGP. Empty cells are NA with counts, never zero error. [LC G3; CC M9]

For bus f, report both raw singleton **joint-action** error and `Dhat_f=rhat(s,e_f)−rhat(s,0)` against `m_f−C_f`. An attributed replacement component `−m_f+Dhat_f` uses known maintenance truth; label it accordingly. Plot Dhat at varying other-coordinate profiles against the true curve, with nuisance-coordinate SD; an additional `rhat(e_f)−r0` plot includes learned-anchor error and is labeled separately. [CC E4/E6; CS §4.4]

Compute these discovery diagnostics on scored occupancy and uniform panels separately [CC E5–E6/M2–M3; CS §4.5; LS §3.3]:

- Walsh coefficients `c_S(s)=mean_a Qhat(s,a)*product_{f∈S}(2a_f−1)`; higher-order share `sqrt(mean_s sum_|S|>=2 c_S²)/sqrt(mean_s sum_|S|>=1 c_S²)`, plus raw interaction RMS. Repeat for reward and advantages. Zero/near-zero denominators are NA.
- Singleton interaction residual `Qhat(s,a)−Qhat(s,0)−Σ_f a_f[Qhat(s,e_f)−Qhat(s,0)]`, and reward counterpart: RMS/max and per-action maps by replacement count.
- Own-mileage-only cubic-spline prediction of singleton incentives, held-out R² shortfall, and fixed-own-mileage SD over other coordinates on E3. Also report nuisance-coordinate SD of marginal replacement probabilities.
- Conditional total correlation `mean_s KL(pi_hat || product_f pi_hat_f)` over all joint actions.
- Per-action state-additive projections `c_a+Σ_j g_aj(x_j)` of Q, reward and advantages, plus state-additive projections of V and the common action level. Fit cubic B-splines with **8 interior knots `j/9`**, endpoints repeated **4** times, centered components and deterministic least squares. Report residual RMSE and `SSE/SST`; run **16-interior-knot** sensitivity without selecting a favorable basis.
- Product state/action projections `c+Σ_f h_f(x_f,a_f)` of Q/reward with the same basis and disjoint fitting/scoring panels.

Evaluate every projection on analytic reward/numerical truth too; finite-basis truth residuals are measured baselines, not assumed zero. Recompute the new own-mileage and additive diagnostics on the coupled reference as positive controls. Preserve legacy V7 with its original basis/name; its **.02951006** multivariate-additive shortfall is not the new own-mileage shortfall. Existing fixed-own-mileage SDs **.640312–.851980** are a distinct diagnostic. Use mixed-coordinate rectangle differences and basis refinement to substantiate state interactions. [CC M3]

Include mutation fixtures: adding `c(s)=x1*x2` to every Q head leaves action/policy diagnostics unchanged but must be detected by state-value/common-level diagnostics; a constant predictor must show bad recovery despite low interaction. For widths64/128 report paired N1k→N100k changes and exploratory sign-test evidence across the **10** data blocks; the **.05** interaction-share target is descriptive, never a gate. Do not claim monotonicity across all N from endpoint comparisons or formal multiple-test significance without a separate multiplicity plan. [CC E6/M2; LC C8]

Report own/max-mileage bins **`[0,.2),[.2,.4),[.4,.6),[.6,.8),[.8,1]`**, x=1 separately, number of buses above **.5**, tails **x>.7** and **x>.8**, training-density and training-action-frequency deciles using the inherited evaluator definitions, plus counts. Do not pool uniform/tail/boundary extrapolation into occupancy accuracy. Report all seed-level statuses, mean/SD and paired whole-data-block intervals, selected hashes, wall seconds, thread reservations/core seconds, peak RSS and Q/ζ/validation time. [CC §4.6; CS §4.4; LS §3.3; R2 §d.8]

## Capacity-constrained extension

Retain the existing Gamma(shape=**2**) DGP, **6** actions, costs and **K31 lookahead** reference with original hashes. No K37 and no V4 top-up are scheduled. Historical absolute-Q acceptance remains **FAIL**; narrowing the extension claim does not relabel it. Prepare adapters/data checks while primary tuning proceeds, but extension rate locks and reporting wait for the common-design freeze and resolved extension pilot acceptance. Give primary dependencies priority; optional common-shock work has no new dependency on extension completion. [CC X1–X3/§4.7; LC §1/X; FD]

V4 is a completed reduced-scale result: **20 starts × 2,000 rollouts × 450**, mean MC−reference **−.09409995**, mean SE **.00745172**, max absolute difference **.14195198**, **8/20** starts outside its **3SE+.01** criterion. Report it as failed. Show raw Q with empirical **.086–.095** level-floor sensitivity, advantages with **.001–.0024** floor sensitivity, policy relative to the specified K31 expert, and reward against analytic truth. Flag comparisons within **five times** the relevant reference floor; empirical floors are not global bounds. Correct V5 Q/advantage names and V3 covariance qualifications. [CC §4.7; CS §5]

Transfer the frozen common design without truth-based retuning; FL-ext locks only rate/horizon using the operational observable rule. Run the **54+45** allocation above, keep transfer failures, and recompute comparable interaction diagnostics. Add untouched labeled policy-test chains if historical evaluation exports lack them. The two arms differ in increment shape as well as capacity, so this is not a one-factor causal comparison. Capacity coupling is decision interdependence, not an exogenous common transition shock. [CC X1/M1/M3/§4.7; LC X]

## Required counterfactual package

This package follows M1 and does not block its execution; experiment completion still requires it or an explicit scope amendment. Select the observable-selected raw reward checkpoints for **widths10/64 × N20k/100k × 10 replications = 40** learned rewards. Apply

```
CF1: rhat_CF(s,a) = rhat(s,a) - a_1       # Kcost_1 + 1.0
CF2: rhat_CF(s,a) = rhat(s,a) + .5*a_3    # Kcost_3 - .5
```

Apply the same interventions to true reward; transitions, temperature and all-zero anchor stay fixed. Re-solve the affected true components in 1-D with the primary reference accuracy checks. Raw learned reward is generally nonadditive: never project it to an additive reward before the primary CF solve. Describe the learned solver as an entropy-regularized MDP, without claiming the additive-truth buswise-shock equivalence for arbitrary learned utilities. [CC M7/§4.7; LC B7]

Implement subset-action tensor continuation by slicing replaced axes at zero and integrating unreplaced axes; stream all **32** actions into logsumexp. Benchmark one solve before admitting the batch, including reward-node evaluation, iteration, queries, simulation, RAM and thread use. Use **K21** as production candidate, **K17** for development/coarse checks and **K25** refinement. Do not extrapolate six-action timings into a completion promise. [CC X8/§4.7; LC C11]

Freeze the CC §4.7 empirical numerical contract before protected evaluation:

- For the winning recipe's four F3 cells, widths10/64 × N20k/100k, data seed **9300**, first initialization, solve both interventions at **K17/21/25**: **24 development solves**.
- Compare continuous lookahead policies on **2,000** fixed states, half baseline occupancy and half uniform. Require K21/K25 mean TV **<=.005**, p95 TV **<=.01**; check same-grid truth against its fine component reference at the same tolerances. Reloaded node VI residual must be **<=1e-8**.
- No favorable replacement seeds for failed fixtures. Refine or record unresolved accuracy. If K21 is rejected, version the resolution and ledger before production.
- Production has **80** intervention solves plus **80 K17 companions**, with the same empirical TV stability tolerances; refine flagged fits without changing learned rewards. Initial allocation is **184 = 24+80+80** solves, excluding truth/refinement solves and policy simulations.

Report per-fit grid changes, pointwise CCP errors and simulated replacement-rate/occupancy differences from the same fixed start law, with Monte Carlo uncertainty. These checks establish empirical stability, not certified continuum optimality. Do not call matched-grid discrepancies pure estimation error. [CC §4.7]

## Build order and completion evidence

1. Record source/config hashes and protocol changes; create the isolated worktree and resource ledger. Implement a fail-closed fleet launcher checking arm, DGP, action map, reference and protocol hashes plus required acceptance statuses. Existing original-bus jobs remain independently admissible. [CC X9/§4.8; LC F9/G1]
2. Build simulator/kernel, component reference, subset-action controls, data schemas and trainer adapters. Complete independent numerical checks, trainer tests and the default-path bitwise replay. These tasks do not depend on the unresolved pilot thresholds. [CC §4.8; LC B1–B4]
3. Run and report the pilot; resolve U1 before declaring data accepted or admitting F1. Freeze recording, reference and data hashes. Provide `load_split` and `score(pred_fn)` interfaces for the already authorized four-step comparison on the new data. U3 controls its probability inversion, not the GLADIUS build. [R2 §c scope; LC G6]
4. After bus BL and new fleet prerequisites, execute the prescribed development stages. Resolve U2 before any affected ranking/common freeze. Record first-wave Q/ζ/validation timing for widths10/64 and a width128 engineering probe; reforecast from actual one-thread work, including stage barriers. [CC X7/§4.8; LC G8]
5. Freeze through the unchanged tuning protocol; pass D; execute fresh M1/M1b/M2/M2b/M3/AF and eligible extension work within the same thread pool. Preserve all failure rows. [TF; CC §4.5]
6. Complete counterfactual validation/reporting, truth/projection baselines, coverage/calibration/discovery figures and the extension limitations. Publish one ledger separating fits, reference work, tests, solves and simulations, plus replay evidence, protocol changes and every selected/checkpoint/data hash. [CC M10/§4.8]

The primary release needs its certified reference, resolved prerequisites and completed locked reporting. Overall experiment completion additionally needs the retained extension/counterfactual/comparison obligations or a recorded author scope amendment. Use “exact additive decomposition with the reported numerical bound,” never “exact continuous oracle” or “all errors are estimation errors.” Discovery is established only by accurate unrestricted recovery together with structural diagnostics; informed-comparator success alone is insufficient. [CC §4.8; LC C7]

## UNRESOLVED — author decisions, with precise stop points

### U1. Pilot acceptance amendments and the inherited rescale exception

**Blocks:** primary pilot PASS/data freeze/F1 and extension pilot PASS/extension fits. Simulator, reference, adapters, replay and descriptive pilot work may proceed.

The approved rule is anchor share **[.50,.95]**, every action share **>=.02**, and each coordinate's p95−p05 span **>=.25**. For the primary arm, `.50+31*.02=1.12`, so it is impossible. Existing extension V6 measures anchor share **.3035**; that is evidence of the conflict, not a full accepted pilot. The no-loosening rule prevents adopting either proposal automatically. [FD pilot; CC D3/X2; LC F5/F9]

Author must approve a replacement primary acceptance set. The documented alternatives are:

| Proposal | Primary acceptance |
|---|---|
| CC D3 hybrid | Anchor **[.25,.95]**; each bus's keep and replace marginal **>=.02**; span **>=.25**; singleton and upper replacement shares descriptive. |
| LC C3 / LS §1.6 | Anchor **[.25,.95]**; each bus's replace marginal **[.03,.30]**; each singleton action **>=.01**; span **>=.25**. |

Both converge on the extension proposal: anchor **[.25,.95]**, existing six-action **>=.02** and span **>=.25** criteria retained. Both primary proposals were informed by prototype coverage; neither documents an identification argument resolving the competing marginal/singleton cutoffs. Record the author's choice before acceptance and call it pre-estimation, not blind preregistration. [CC D3/X2; LC C3–C4]

Preserve the exact FD Kcost-only grid/one-rerun limit stated above; the author must reconcile whether that exception is exercised after a failed amended pilot or the current frozen-DGP version stops. CC's stop/version recommendation and LC's automatic-rescale recommendation conflict. Neither permits repeated DGP searches, post-estimator rescaling, or reuse of stale reference hashes. The extension's K31-as-is requirement particularly precludes silently exercising the rescale exception. Tail coverage is already descriptive under FD and is **not** an additional unresolved relaxation.

### U2. Executable inputs to the unchanged minimax winner rule

**Blocks:** any ranking whose reference/comparison is missing and the common-design freeze; no permission to change the winner formula or hide additional fits.

TF adopts TC's finite stage schedule and TL §3.4's winner rule. The documents leave these interface conflicts unresolved:

- TL requires candidates confirmed on both testbeds, including B3x when needed; TF/TC's stage list contains no B3x and F3 confirms only four fleet finalists, which need not equal the bus finalists. It does not guarantee F3 membership for the bus winner needed for TL's transfer verdict.
- TL's paired P0/P0* denominators, variability reference and equal-gradient comparisons are not guaranteed in every TC stage/cell. A failed/missing/zero denominator has no adopted replacement rule. TC identifies this gap, but its competing normalized score was not adopted.
- TL's fleet feasibility is expressed as **5/5 seeds** (with a width128 exception); TC F3 schedules **5 seeds × 2 initializations**, widths10/64 only. The adopted documents do not say how initialization eligibility maps to that seed-level feasibility test.
- TL includes stopping policy in common-design identity, while TF/TC prescribe per-testbed/class observable horizon locks. The exact manifest identity/comparison policy must be fixed without changing the already approved winner or exposing confirmation truth first.

Author must supply the missing confirmation/reference allocation, seed/candidate mapping, feasibility aggregation and design/horizon mapping in a hashed protocol amendment, or identify an existing locked implementation that already settles them with provenance. Until then **1,300 is the known fleet allocation, not a proved complete minimax-study budget**. Preserve every source rule above; do not synthesize a new score, choose an arbitrary intersection of finalists, revive all superseded TL stages, or waive cross-testbed evidence. [TF; TC §2 item 3/§§5–6; TL §3.4; CC §4.5; LC B5]

### U3. Four-step comparator probability inversion

**Blocks:** the four-step comparator's log-odds inversion/training brief, not GLADIUS reference/data/estimator work.

The comparison is still authorized against the frozen 32-action data/evaluation interface. LC G6 requires a strictly positive probability floor or smoothing policy for unseen actions before that builder sees data. Neither convergence document supplies its value or algorithm. The author must pin that policy and its manifest field; this synthesis does not invent a numeric floor or add smoothing to GLADIUS CE. [LC G6; FD O3; R2 scope]
