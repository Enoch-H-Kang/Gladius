"""Build the fixed, diagnostic FR slots without using development truth."""
import hashlib
import json
from pathlib import Path

from .freeze_data import seed
from .tuning_run_fit import hashfile

ROOT = Path(__file__).resolve().parent
DEV = ROOT / "artifacts/data/development_freeze_manifest.json"
OUT = ROOT / "results/tuning/manifests/manifest_FR.json"
STREAMS = ("qinit", "zinit", "ce", "extrazeta", "anchor", "eval")

def config_id(cfg):
    return hashlib.sha256(json.dumps(cfg, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

def build_fr():
    dev = json.loads(DEV.read_text())
    assert dev["mode"] == "development" and dev["status"] == "development"
    assert {p["data_id"] for p in dev["pools"] if p["stage"] == "F1"} == {9100, 9101, 9102}
    cfg = dict(loss="refcode", k=1, lr_q=3e-4, rho=1.0, batch=256, c_be=1.0,
               width=64, depth=2, architecture="mlp2x64", opt="adamw", wd=1e-4,
               bias="anchor", beta=.95, cap_q=50000, N=20000, val_every=500,
               elig_start=5000, anchor_tol=.10, grad_clip=1.0, lr_decay=10000.0)
    cid = config_id(cfg)
    fits = []
    for data_id in (9100, 9101, 9102):
        fits.append(dict(fit_id=f"FR_{cid[:10]}_{data_id}_i0", config=cfg,
                         config_id=cid, stage="FR", pool_stage="F1", data_id=data_id,
                         n_chains=200, init_index=0, horizons=[10000,20000,50000],
                         seeds={s:seed("FR",data_id,s,0) for s in STREAMS}))
    body = json.dumps(fits, sort_keys=True, separators=(",", ":")).encode()
    return dict(stage="FR", n_fits=3, sha256=hashlib.sha256(body).hexdigest(),
                development_manifest_sha256=hashfile(DEV), fits=fits,
                diagnostic="shared trunk; overlapping optimizers; anchor-row-mean abs",
                adapter="one zeta then one Q step per cycle; historical parity skips omitted")

if __name__ == "__main__":
    m=build_fr()
    OUT.parent.mkdir(parents=True,exist_ok=True)
    OUT.write_text(json.dumps(m,indent=2,sort_keys=True)+"\n")
    print(str(OUT),hashfile(OUT),m["sha256"])

def build_f1(recipe_allocation_path, amendment_path):
    """Expand 12 author-approved transferred recipes; never choose a recipe here."""
    pairs={(loss,k) for loss in ("signed","clip0","abs") for k in (1,3,5,10)}
    allocation_path=Path(recipe_allocation_path)
    amendment=Path(amendment_path)
    if not amendment.is_file():
        raise RuntimeError("U2 amendment required before F1 recipe allocation")
    mapping=json.loads(allocation_path.read_text())
    if mapping.get("stage")!="F1" or len(mapping.get("recipes",[]))!=12:
        raise ValueError("F1 requires exactly 12 frozen transferred recipes")
    if mapping.get("amendment_sha256")!=hashfile(amendment):
        raise ValueError("U2 amendment hash mismatch")
    if {(r["loss"],int(r["k"])) for r in mapping["recipes"]}!=pairs:
        raise ValueError("F1 loss/k grid incomplete")
    dev=json.loads(DEV.read_text())
    assert dev["mode"]=="development"
    fits=[]
    for recipe in mapping["recipes"]:
        base=dict(recipe["config"])
        if base["loss"] not in (recipe["loss"],"none" if recipe["loss"]=="signed" else recipe["loss"]):
            raise ValueError("recipe loss mismatch")
        if int(base["k"])!=int(recipe["k"]):
            raise ValueError("recipe k mismatch")
        for width in (10,64):
            for n,chains in ((20000,200),(100000,1000)):
                cfg=dict(base,loss=recipe["loss"],k=int(recipe["k"]),width=width,
                         depth=2,architecture=f"mlp2x{width}",N=n,cap_q=50000)
                cid=config_id(cfg)
                for data_id in (9100,9101,9102):
                    fit_id=f"F1_{cid[:10]}_{data_id}_i0"
                    fits.append(dict(fit_id=fit_id,stage="F1",config=cfg,config_id=cid,
                                     pool_stage="F1",data_id=data_id,n_chains=chains,
                                     init_index=0,horizons=[10000,20000,50000],
                                     recipe_origin=recipe["origin"],
                                     seeds={s:seed("F1",data_id,s,0) for s in STREAMS}))
    ids=[s["fit_id"] for s in fits]
    if len(fits)!=144 or len(set(ids))!=144:
        raise ValueError("F1 fit slots must be unique and total 144")
    body=json.dumps(fits,sort_keys=True,separators=(",",":")).encode()
    return dict(stage="F1",n_fits=144,sha256=hashlib.sha256(body).hexdigest(),
                development_manifest_sha256=hashfile(DEV),
                allocation_sha256=hashfile(allocation_path),
                amendment_sha256=hashfile(amendment),fits=fits)
