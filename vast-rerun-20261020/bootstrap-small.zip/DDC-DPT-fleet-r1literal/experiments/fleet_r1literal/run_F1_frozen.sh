#!/bin/bash
set -euo pipefail
cd "$HOME/DDC-DPT-fleet-r1literal"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONHASHSEED=0 CUDA_VISIBLE_DEVICES=""
~/miniconda3/envs/gym/bin/python -u -m experiments.fleet_r1literal.tuning_runner experiments/fleet_r1literal/results/tuning/manifests/manifest_F1_frozen.json experiments/fleet_r1literal/artifacts/tuning/fits_F1_frozen experiments/fleet_r1literal/results/tuning/ledger
printf "%s\n" "$(date -u +%FT%TZ) F1 complete" > experiments/fleet_r1literal/artifacts/logs/F1_frozen.DONE
