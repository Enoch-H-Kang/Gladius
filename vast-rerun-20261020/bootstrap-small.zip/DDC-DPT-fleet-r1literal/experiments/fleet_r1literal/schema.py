"""Truth-stripped future data export; use only after pilot acceptance."""
import json
from pathlib import Path
import numpy as np
from .params import DGP_PATH,ACTION_PATH,sha256
from .launcher import PROTOCOL_PATH

def write_training_export(path,chains,is_val,chain_ids,stream_ids,reference_sha256):
    s=np.asarray(chains["s"],dtype=np.float64)
    sp=np.asarray(chains["sp"],dtype=np.float64)
    a=np.asarray(chains["a"],dtype=np.int8)
    r0=np.asarray(chains["r0"],dtype=np.float64)
    n=len(s)
    if s.shape!=(n,100,5) or sp.shape!=s.shape or a.shape!=(n,100) or r0.shape!=(n,100):
        raise ValueError("invalid training export shape")
    if np.any((a<0)|(a>31)):raise ValueError("invalid joint action")
    if len(is_val)!=n or len(chain_ids)!=n or len(stream_ids)!=n:
        raise ValueError("chain metadata length mismatch")
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(path,s=s.astype(np.float32),sp=sp.astype(np.float32),
         a=a,r0=r0.astype(np.float32),is_val=np.asarray(is_val,dtype=bool),
         chain_id=np.asarray(chain_ids),stream_id=np.asarray(stream_ids),
         arm="independent_r1literal",dgp_sha256=sha256(DGP_PATH),
         action_sha256=sha256(ACTION_PATH),protocol_sha256=sha256(PROTOCOL_PATH),
         reference_sha256=reference_sha256,
         n_actions=32,anchor_action=0,state_scale=1.0,beta=.95)
    return path
