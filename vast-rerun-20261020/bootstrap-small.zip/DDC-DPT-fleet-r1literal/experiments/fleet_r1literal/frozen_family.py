"""Frozen bus-lock transfer manifests; development evidence only, no design selection."""
import hashlib, json
from pathlib import Path
from .freeze_data import seed
from .tuning_manifest import config_id, STREAMS
from .tuning_run_fit import hashfile
ROOT=Path(__file__).resolve().parent
PROTO=ROOT/'protocol'
OUT=ROOT/'results/tuning/manifests'
LOCK=Path.home()/'DDC-DPT-fleet/experiments/fleet_capacity_one/results/tuning/bus_locked_protocol.json'
DEV=ROOT/'artifacts/data/development_freeze_manifest.json'
HEAD=ROOT/'artifacts/data/headline_freeze_manifest.json'
FD=PROTO/'final-decisions-2026-10-19.md'
AMEND=PROTO/'u2-amendment-merged.md'
LOCK_SHA='3a7749e7354fd1472320f76b2d2b62259847eed682dea6379ecff7f02129619b'
HEAD_SHA='c0df9e599c99f663190f6aff31450f4bda17172c0cae24e9bfe3fe7d24a42c39'
AMEND_SHA='215a24fb439a0dd950ea0fce33f0ff147bca9dd8edfee4d884bf4ee5a6f3f25c'

def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+'\n')

def freeze():
    assert hashfile(HEAD)==HEAD_SHA
    assert hashfile(AMEND)==AMEND_SHA
    fd=FD.read_text()
    assert '2026-10-19 19:48 PDT — AUTHOR DECISION' in fd and 'freeze k=10 as the common protocol' in fd
    lock=json.loads(LOCK.read_text())
    assert lock['sha256']==LOCK_SHA
    d=lock['design']; p=lock['policy']
    assert (d['loss'],d['k'],d['lr_q'],d['rho'],d['batch'],d['cap_q'],d['width'],d['depth'])==('none',10,.001,1.0,1024,50000,10,2)
    assert p['horizon']==50000
    record=dict(status='author_frozen_exploratory',author_decision='planning/final-decisions.md 2026-10-19 19:48 PDT: freeze k=10 as common protocol',decision_snapshot_sha256=hashfile(FD),bus_lock_embedded_sha256=LOCK_SHA,bus_lock_file_sha256=hashfile(LOCK),u2_amendment_sha256=AMEND_SHA,headline_manifest_sha256=HEAD_SHA,development_manifest_sha256=hashfile(DEV),design={'loss':'signed','k':10,'lr_q':.001,'rho':1.0,'batch':1024,'c_be':1.0,'architecture':'mlp2x10','optimizer':'adamw','bias':'anchor','horizon':50000},selection_status='exploratory; prior U2 confirmation was exposed; author accepted disclosure',role='common protocol frozen; F1-F3 are transfer and feasibility evidence, never design selection')
    path=PROTO/'common_protocol_freeze.json'
    if path.exists():
        assert json.loads(path.read_text())==record
    else: dump(path,record)
    return hashfile(path),d

def cfg_for(base,width,n):
    c=dict(base);c.update(loss='signed',architecture='mlp2x'+str(width),width=width,depth=2,N=n,cap_q=50000)
    return c

def manifest(stage,freeze_sha,base):
    fits=[]
    if stage=='F1':
        rows=[('frozen',base)]
        cells=[(w,n,range(9100,9103),(0,)) for w in (10,64) for n in (20000,100000)]
    elif stage=='F2':
        rows=[('center',base)]
        def add(label,**kw):rows.append((label,dict(base,**kw)))
        add('lr_div3',lr_q=base['lr_q']/3)
        add('lr_mul3',lr_q=base['lr_q']*3)
        add('rho_div3',rho=base['rho']/3)
        add('rho_mul3',rho=base['rho']*3)
        add('batch64',batch=64);add('batch256',batch=256)
        add('cbe03',c_be=.3);add('cbe3',c_be=3.0)
        add('bias_zero',bias='zero')
        add('sgd003',opt='sgd',lr_q=.003,wd=0.0)
        add('sgd03',opt='sgd',lr_q=.03,wd=0.0)
        assert len(rows)==12
        cells=[(w,20000,range(9200,9203),(0,)) for w in (10,64)]
    elif stage=='F3':
        rows=[('frozen',base)]
        cells=[(w,n,range(9300,9305),(0,1)) for w in (10,64) for n in (20000,100000)]
    elif stage=='D':
        rows=[('frozen',base)]
        cells=[(w,n,range(9700,9702),(0,)) for w in (10,64) for n in (20000,100000)]
    else:raise ValueError(stage)
    for row,raw in rows:
        for width,n,data_ids,inits in cells:
            c=cfg_for(raw,width,n); cid=config_id(c)
            for data_id in data_ids:
                for init in inits:
                    fid=f'{stage}_{row}_{cid[:10]}_{data_id}_i{init}'
                    fits.append(dict(fit_id=fid,stage=stage,config=c,config_id=cid,pool_stage=stage,data_id=data_id,n_chains=n//100,init_index=init,horizons=[10000,20000,50000],family='signed_k10',row=row,seeds={s:seed(stage,data_id,s,init) for s in STREAMS}))
    body=json.dumps(fits,sort_keys=True,separators=(',',':')).encode()
    return dict(stage=stage,n_fits=len(fits),sha256=hashlib.sha256(body).hexdigest(),development_manifest_sha256=hashfile(DEV),amendment_sha256=AMEND_SHA,frozen_evidence=True,freeze_sha256=freeze_sha,bus_lock_sha256=LOCK_SHA,c_bus_sha256=LOCK_SHA,design_selection='closed_by_author',fits=fits)

def main():
    freeze_sha,base=freeze()
    base=dict(base);base['loss']='signed'
    for stage in ('F1','F2','F3','D'):
        m=manifest(stage,freeze_sha,base)
        path=OUT/f'manifest_{stage}_frozen.json'
        if path.exists():assert json.loads(path.read_text())==m
        else:dump(path,m)
        print(stage,m['n_fits'],hashfile(path))
    print('freeze',freeze_sha)
if __name__=='__main__':main()
