# R1-literal chunk 2 — PASS and data freeze; fleet tuning dependency status

Recorded 2026-10-19 04:49 UTC on baker in branch `fleet-r1literal`.
Binding design: `planning/r1literal-converged.md`; execution brief: `planning/brief-builder-r1literal-2.md`.

## Pilot decision and numerical reference

The author adopted the **strict LC C3** primary acceptance set on 2026-10-18 at approximately 21:38 PDT, in `planning/final-decisions.md` under “U1(a) GOVERNING SET DECIDED.” The unchanged 1,000,000-transition production pilot **PASSES**: anchor 0.393975 in [0.25,0.95]; per-bus replacement shares 0.157050, 0.164848, 0.190992, 0.154421, 0.183871 in [0.03,0.30]; singleton shares 0.072915, 0.077162, 0.092793, 0.071534, 0.088323 at least 0.01; p95−p05 mileage spans 0.377804, 0.407166, 0.456462, 0.393967, 0.406893 at least 0.25. Burn-in remained zero by the inherited KS rule. No cost rescale was exercised. This is a pre-estimation author decision.

The acceptance record is `artifacts/pilot/acceptance_LC_C3.json`, SHA-256 `9c36e41b0d88ff9d16f18d2a03b48ada823b490f46dbed21b50b9c0e20a48424`. It binds unchanged pilot SHA-256 `e3b0e2a728ac3a67e567eb7d741f3a37f046cbb81c674d451c0cee544e0c342b`. Commit `be6f390fe7f59b582b093c6a89740aaeb14c9859` records this PASS before data generation. The prior certified numerical reference remains unchanged, with artifact SHA-256 `5a96631a2d78ca28e80e1ae0916f99ae6d261963d57014b1085b44be218daaef` and enclosed joint absolute-Q error `9.33573322508e-06`.

## Headline freeze

The protected data are **generated, hashed, and mode-locked read-only** on baker. No headline file was passed to the fit adapter, development truth evaluator, stage selector, or engineering probes. Ten protected pools each contain 1,000 independent 100-transition chains. Permanent partitions are 800 training and 200 validation chains, with nested prefixes 8/2, 40/10, 160/40 and 800/200 at N=1k/5k/20k/100k. Final evaluation panels contain E1 20,000 occupancy states with untouched labels/successors, E2 20,000 jittered-stratified uniform states, E3 3,125 grid states and E4 1,024 states from the inherited face construction. Truth/Q/policy caches are evaluator-only. Binary pools and caches are stored on baker, outside Git; the tracked manifest contains their full hashes, stream seeds, lineage, source/config/reference hashes and byte counts.

Headline manifest: `artifacts/data/headline_freeze_manifest.json`, SHA-256 **`c0df9e599c99f663190f6aff31450f4bda17172c0cae24e9bfe3fe7d24a42c39`**. Full protected-pool SHA-256 values:

| ID | SHA-256 |
|---:|---|
| 1000 | `64d25f2acd3a0e992a5c96c1612b112ae7769ad9ec3b3c32f169f1dc342edde0` |
| 1001 | `93ab154306fb7e69c7b7654e9c3908fb22b8f10cd7ec669f19eee4243d68bf9b` |
| 1002 | `c2803caf72bfdb0339462aa069cb434f2e929d8899aeffe501ac8084934c3fa4` |
| 1003 | `ea7534054b174a5ef0a2ca985b4b69be7d8f2e7d421ed0fceba7c6f87c6f09f0` |
| 1004 | `ef3a7ddedb6406e61109a535b2209a42b94b0642b9168107b94b090c32658f9a` |
| 1005 | `52cfd256c5210b35cfed76cf9deb514e1df78ca093ef6fd0e99f0f364b544b99` |
| 1006 | `a65d88b17ed7f0c94fb0235572fd54c3cfcc6b256c92ef83b45555410fc9dff3` |
| 1007 | `8f1e1f911489997ccb8fdb324a85b08c2855dff328bb1d26a1371c952e20850f` |
| 1008 | `e54b9a80145107c42e089920e73d6093b925b5ca61311add7a837f68603165ad` |
| 1009 | `39aa8ebcd8b5aa2ac4ca06d38df01eaef7757e8b958353eac6a5767df3159618` |

Final truth-cache SHA-256: E1 `8426b6ed47ba97161277b625b1e3982acca0c3b4b1f9bccb44508175e07ec5fe`; E2 `2a14d323f7523889bde18c659eca786499bcb1fa96c4337892594a71072c0775`; E3 `73f6df862c45101f391363d8dffd301ee3b9350a08eabfef63011db78fe31938`; E4 `18e92a48ce353c1a2b3ccf84f48b764f9a9cdda74b5ed46e55ec983f50d81eff`. E1 label/successor SHA-256 and the exact reused E4 source SHA-256 are in the manifest.

The DGP SHA-256 is `6dbaaa5168f052e9bbd96530cba04c19de1239a09547cb938ea9279a72e0e40d`; action map `da7a59f317f4c3ca70e4a83ceb1666985a06d1c935dadffab8fb6a82f8c610a3`; protocol `e7a439f56857ba73d4099c56d1d3d43865942c7a0617ecac343a23b948b0875c`. All files were rehashed and all nested split sizes verified after generation.

## Development data and engineering timings

Nineteen disjoint 1,000-chain development pools were generated for F1, F2, F3, FL, FS and D; five AF reporting pools were generated in the same namespaced batch but reserved untouched until the common freeze. FR reuses F1 data IDs as prescribed; the factored lock reuses FL data IDs with its separate initialization namespace when scheduled. All 24 data files are read-only. The AF fit adapter also requires a common-protocol freeze marker before it will open an AF pool. The separate screening, confirmation, D-only occupancy and screening/confirmation uniform panels were generated under IDs 9997, 9399 and 9998. Their data and truth arrays are separate from all protected headline streams. Development manifest: `artifacts/data/development_freeze_manifest.json`, SHA-256 **`cb141942a9b8e11e89e86f13308953fae0e031dd445ddfc887692655736c17e7`**. All 24 pool hashes, five panel hashes and nested split counts were checked. The manifest carries every individual hash and expanded seed.

Three separate signed/k1, N20k, 5,000-update engineering probes on development pool F1/9100 finished. They are **not scheduled F1 fits** and did not enter a ranking:

| Width | Observable checkpoint | NLL | Anchor RMSE | Total wall s | Q / ζ / validation s | Peak RSS KiB |
|---:|---|---:|---:|---:|---|---:|
| 10 | anchor_fail | 2.17213 | 0.27911 | 41.683 | 22.686 / 14.694 / 0.064 | 480680 |
| 64 | eligible | 2.02072 | 0.06289 | 48.059 | 27.016 / 16.680 / 0.120 | 488880 |
| 128 | anchor_fail | 2.02205 | 0.10127 | 66.750 | 38.953 / 22.786 / 0.413 | 499616 |

The width-10 probe's separate development evaluator reported non-anchor reward RMSE 2.23554, raw-Q RMSE 9.47990 and policy KL 0.17018 at 5,000 updates. These probe metrics are timing/integration diagnostics, not tuning outcomes. Width 128 is an engineering probe outside the F1 grid. The full 50,000-update stage and larger-k timings have not been measured; no completion-time forecast is claimed from these three prefixes.

## Stage outcomes and accounting at this checkpoint

| Stage | Scheduled fits | Completed scheduled fits | Outcome |
|---|---:|---:|---|
| F1 transfer | 144 | 0 | Awaiting bus B3 finalists, BL observable lock, and resolved recipe/reference mapping. |
| F2 refinement | 288 | 0 | Depends on F1 family-center ranking. |
| F3 confirmation | 160 | 0 | Depends on F2 family finalists. |
| FL and factored locks | 108 + 18 | 0 | Depends on confirmed fleet/common design. |
| FS, D, FR | 36 + 8 + 3 | 0 | Dependencies not met. |
| AF | 60 | 0 | Post-freeze reporting; common-design freeze remains blocked by U2. |
| **Fleet subtotal** | **825** | **0** | **No scheduled slot silently dropped or relabeled as an engineering fit.** |

There are 3 completed engineering fits, 0 scheduled fleet fits, 0 headline estimator fits and 0 counterfactual solves in this chunk. The known fleet tuning allocation is 825 including AF and the 18 factored-lock fits; 1,300 is the known wider fleet allocation including later reporting and extension fits, not a complete minimax cost while U2 is unresolved.

## Resource, wall time, and deviations

One-thread data generation took 12.088 seconds for headline pools/panels and 27.701 seconds for development pools/panels. Each probe was a detached one-thread baker job with a log and DONE marker. During active bus B2 work, the bus occupied up to 40 one-thread fit workers; its existing controller/evaluator reservation is 2 tokens. At most one R1-literal compute job ran at a time, giving at most 43 of 44 project compute-thread tokens. The bus runner is not wired to the new atomic admission ledger, an inherited operational deviation; the new fleet stage runner waits for the bus queue to clear before admitting fits. No DGP constant, winner rule or tolerance was changed.

The first headline-freeze process generated and locked all outputs, then its final log line failed due to a Python `print` keyword typo. The generated files were rehashed, their shapes and nested splits checked, and the DONE marker written only after verification; the data were not regenerated. The tracked generator was repaired after generation, so the manifest records the exact pre-repair source hash; the repair changed only that final log line. The original failure log remains on baker.

**Blocking inherited state:** at the checkpoint time, the bus B2 queue was still active (136/192 records), with no B3 finalist or BL lock. In addition, binding-spec U2 leaves the executable paired references, cross-testbed confirmation allocation, seed/initialization feasibility aggregation and design/horizon identity unresolved. A missing or failed denominator has no adopted replacement rule. No F1 recipe list or truth-driven stage ranking has been fabricated from the older competing tuning score. The author was asked for an existing hashed amendment or the missing decisions. The report and manifests will be updated when those dependencies are actually resolved.

No push, merge, headline estimator fit, or use of protected headline data for tuning occurred.

## Resumed chunk-2 execution checkpoint — 2026-10-19 05:07 UTC

The pre-existing PASS and data freeze were verified rather than regenerated. Rehashing all 10 protected pools and all 24 development pools against their tracked manifests found zero mismatches. The headline and development manifest hashes remain `c0df9e599c99f663190f6aff31450f4bda17172c0cae24e9bfe3fe7d24a42c39` and `cb141942a9b8e11e89e86f13308953fae0e031dd445ddfc887692655736c17e7`. Sampled protected and development data files have mode 0444. No headline data were opened for a fit or tuning evaluation.

The original-bus B2 finisher reached 192/192 fit records and handed off an 80-slot B3 manifest. B3 launched with 40 one-thread workers. The existing B2 analysis chose its B3 inputs using a reward-scale-normalized score and validation NLL +0.01. The binding R1-literal synthesis instead requires TL section 3.4's paired P0/P0* score and validation NLL +0.005, and its U2 explicitly blocks rankings without the missing denominators and mapping. The B3 evidence is preserved, but these finalists are not accepted as the approved fleet F1 recipe allocation. The author has been asked for a hashed U2 amendment or an instruction to stop at the affected ranking boundary.

A fixed three-slot FR released-code diagnostic manifest is recorded at `results/tuning/manifests/manifest_FR.json`, SHA-256 `68712940575fd879bf69ab8f6ff97be23d911ca532019362af892309aca3e04a`. It uses F1 development data IDs 9100–9102, width64, N20k, 50k Q updates, separate one-thread processes, and the historical compound shared-trunk/overlapping-optimizer/anchor-row-mean-abs behavior with one zeta then one Q step per cycle. The source trainer was copied from the live bus checkout into this isolated worktree after review; `refcode_snapshot.json` records source SHA-256 `da5ca06daa47a8724701a2bb58efd09a960bb6ff1b6936ddc1675b8071798d70` and adapted snapshot SHA-256 `f9da5fc965394d286ce54796bc2218ef5b597dd3e063bcd59ad8e4d140c3a821`. Only import paths changed. A one-update smoke check completed one Q and one zeta update in 0.162 fit seconds; it is an engineering check, not a scheduled fit.

The detached FR runner (PID 4089468 at launch) waits for the bus BL validation-only lock and then for the active bus tuning queue to clear before admitting any of its three fits. Its log is `artifacts/logs/FR.log`; it will write `artifacts/logs/FR.DONE` only after records and development truth evaluation finish. F1's manifest builder now fails closed without a hashed U2 amendment and a complete 12-recipe allocation. At this checkpoint, scheduled fleet fits remain 0/825; engineering fits/checks are the earlier three timing probes plus the one-update FR smoke check. No fleet finalist or common protocol was selected.

At the 2026-10-19 05:12 UTC verification point, B3 was still occupying 40 one-thread bus slots, with 0/80 fit records yet complete; the fleet FR runner remained parked, with no scheduled fleet fit admitted. A stage evidence writer now emits one row per declared horizon and fit slot, preserving missing/failed slots. Its pre-run audit of the FR manifest reported 3 scheduled, 0 records and 3 explicitly missing records; these placeholder tables will be replaced by the detached FR job after it finishes.
