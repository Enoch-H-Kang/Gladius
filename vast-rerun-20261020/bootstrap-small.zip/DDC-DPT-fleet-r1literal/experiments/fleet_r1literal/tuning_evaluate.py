"""Read-only development truth evaluator. Never called from the fit process."""
import hashlib
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch

from .models import factory

ROOT=Path(__file__).resolve().parent

def hashfile(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def metrics(ck, truth):
    q,z=factory(ck["cfg"],ck["meta"]),factory(ck["cfg"],ck["meta"])
    q.load_state_dict(ck["q"]);z.load_state_dict(ck["z"])
    q.eval();z.eval()
    s=truth["states"]
    Qh=np.empty((len(s),32),dtype=np.float64)
    Zh=np.empty_like(Qh)
    with torch.no_grad():
        for i in range(0,len(s),2048):
            x=torch.as_tensor(s[i:i+2048].astype(np.float32))
            Qh[i:i+2048]=q(x).double().numpy()
            Zh[i:i+2048]=z(x).double().numpy()
    rh=Qh-.95*Zh
    R=truth["reward"]; Qt=truth["Q"]; pt=truth["pi"]
    err=rh-R
    lse=np.logaddexp.reduce(Qh,axis=1)
    ph=np.exp(Qh-lse[:,None])
    out=dict(nonanchor_rmse=float(np.sqrt(np.mean(err[:,1:]**2))),
             anchor_rmse=float(np.sqrt(np.mean(err[:,0]**2))),
             q_rmse=float(np.sqrt(np.mean((Qh-Qt)**2))),
             adv_rmse=float(np.sqrt(np.mean(((Qh-Qh[:,0,None])-(Qt-Qt[:,0,None]))[:,1:]**2))),
             kl=float(np.mean(np.sum(pt*(np.log(pt)-np.log(np.maximum(ph,1e-300))),axis=1))),
             tv=float(np.mean(.5*np.sum(np.abs(ph-pt),axis=1))),
             reward_scale=float(np.sqrt(np.mean(R[:,1:]**2))),
             per_action_rmse=np.sqrt(np.mean(err**2,axis=0)).tolist(),
             observed_states=len(s))
    return out

def panel(name):
    p=ROOT/"artifacts/eval"/(name+"_truth.npz")
    with np.load(p,allow_pickle=False) as z:
        return {k:z[k] for k in ("states","reward","Q","pi")},hashfile(p)

def main(manifest_path,fits_root,truth_root,primary,secondary):
    torch.set_num_threads(1)
    m=json.loads(Path(manifest_path).read_text())
    p,ph=panel(primary)
    u,uh=panel(secondary)
    outroot=Path(truth_root);outroot.mkdir(parents=True,exist_ok=True)
    for spec in m["fits"]:
        fid=spec["fit_id"]; rp=Path(fits_root)/fid/"record.json"
        o=dict(fit_id=fid,stage=m["stage"],panel=primary,panel_sha256=ph,
               secondary_panel=secondary,secondary_sha256=uh,horizons={})
        if rp.exists():
            rec=json.loads(rp.read_text())
            for h,hr in rec["horizons"].items():
                if hr.get("hash") is None:
                    o["horizons"][h]=None
                    continue
                ckpath=Path(fits_root)/fid/f"ckpt_h{h}.pt"
                ck=torch.load(ckpath,map_location="cpu",weights_only=False)
                if ck["hash"]!=hr["hash"]:
                    raise ValueError("checkpoint hash mismatch "+fid)
                x=metrics(ck,p)
                xu=metrics(ck,u)
                x["uniform_nonanchor_rmse"]=xu["nonanchor_rmse"]
                x["uniform_q_rmse"]=xu["q_rmse"]
                x["checkpoint_sha256"]=hashfile(ckpath)
                o["horizons"][h]=x
        tmp=outroot/(fid+".json.tmp")
        tmp.write_text(json.dumps(o,allow_nan=False))
        os.replace(tmp,outroot/(fid+".json"))
    print(json.dumps(dict(stage=m["stage"],fits=len(m["fits"]),primary=primary)),flush=True)

if __name__=="__main__":
    main(*sys.argv[1:6])
