"""Run one manifest-declared development fit with no evaluator imports."""
import hashlib
import json
import os
import resource
import socket
import sys
import time
from pathlib import Path

from .data_io import load_split
from .trainer import fit_fleet

ROOT = Path(__file__).resolve().parent
DEV_MANIFEST = ROOT / "artifacts/data/development_freeze_manifest.json"
SHARED = ROOT.parent / "fleet_capacity_one/fleet"

def hashfile(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def code_hash(stage=None):
    names = [Path(__file__), ROOT/"trainer.py", ROOT/"models.py", ROOT/"data_io.py",
             ROOT/"schema.py", SHARED/"train.py", SHARED/"losses.py", SHARED/"models.py",
             SHARED/"select.py", SHARED/"seeds.py"]
    if stage == "FR":
        names += [ROOT/"tuning_run_refcode.py", ROOT/"tuning_manifest.py",
                  ROOT/"refcode_fit.py"]
    h=hashlib.sha256()
    for p in names:
        h.update(p.name.encode()); h.update(p.read_bytes())
    return h.hexdigest()

def main(manifest_path, fit_id, fits_root):
    import torch
    torch.set_num_threads(1)
    m=json.loads(Path(manifest_path).read_text())
    assert m["stage"] in ("F1","F2","F3","FL","FS","D","FR","AF","FACTORED")
    spec=next(x for x in m["fits"] if x["fit_id"]==fit_id)
    if m["stage"] == "AF" and not (ROOT / "configs/common_protocol_freeze.json").exists():
        raise RuntimeError("AF reporting fits require the common protocol freeze")
    dev=json.loads(DEV_MANIFEST.read_text())
    assert dev["mode"]=="development"
    assert m["development_manifest_sha256"]==hashfile(DEV_MANIFEST)
    source=next(x for x in dev["pools"] if x["stage"]==spec["pool_stage"] and x["data_id"]==spec["data_id"])
    path=ROOT/source["path"]
    assert "headline" not in str(path)
    assert hashfile(path)==source["sha256"]
    data=load_split(path,spec["n_chains"],dev["reference_sha256"])
    cfg={k:v for k,v in spec["config"].items() if k!="N"}
    out=Path(fits_root)/fit_id
    out.mkdir(parents=True,exist_ok=True)
    start=time.time()
    result=fit_fleet(data,cfg,spec["seeds"],horizons=spec["horizons"],ckpt_dir=out)
    result.update(fit_id=fit_id,stage=m["stage"],config_id=spec["config_id"],
                  family=spec.get("family"),row=spec.get("row"),
                  data_id=spec["data_id"],init_index=spec["init_index"],
                  n_chains=spec["n_chains"],manifest_sha256=m["sha256"],
                  development_manifest_sha256=m["development_manifest_sha256"],
                  data_sha256=source["sha256"],code_hash=code_hash(),
                  n_train_chains=data["n_train_chains"],n_val_chains=data["n_val_chains"],
                  host=socket.gethostname(),pid=os.getpid(),
                  start_unix=start,end_unix=time.time(),
                  peak_rss_kb=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  env_threads={k:os.environ.get(k) for k in
                               ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS")})
    tmp=out/"record.json.tmp"
    tmp.write_text(json.dumps(result,allow_nan=False))
    os.replace(tmp,out/"record.json")
    print(json.dumps(dict(fit_id=fit_id,status=result["fit_status"],
                          time_s=result["time"]["total"],peak_rss_kb=result["peak_rss_kb"])),flush=True)

if __name__=="__main__":
    main(*sys.argv[1:4])
