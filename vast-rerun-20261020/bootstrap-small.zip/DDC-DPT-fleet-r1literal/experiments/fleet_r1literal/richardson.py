"""Successive-grid order and target-resolution Richardson diagnostics."""
import json,math,time
from pathlib import Path
import numpy as np
from .oracle1d import solve

def run(root):
    t0=time.perf_counter();out=[]
    x=np.linspace(0.,1.,20001)
    for f in range(5):
        cs={K:solve(f,K)[0] for K in (1001,2001,4001,8001)}
        q={K:np.stack(cs[K].q(x)) for K in cs}
        d1=q[2001]-q[4001];d2=q[4001]-q[8001]
        rms1=float(np.sqrt(np.mean(d1*d1)));rms2=float(np.sqrt(np.mean(d2*d2)))
        p=math.log2(rms1/rms2)
        denom=2**p-1
        rec=dict(bus=f+1,p_rms=p,delta_2001_4001_rms=rms1,
                 delta_4001_8001_rms=rms2,
                 K8001_leading_error_max=float(np.max(np.abs(d2/denom))),
                 K4001_leading_error_max=float(np.max(np.abs(d2*2**p/denom))))
        out.append(rec)
    result=dict(buses=out,wall_s=time.perf_counter()-t0,
                note="diagnostic only; the continuous enclosure controls release")
    Path(root,"richardson.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result))
if __name__=="__main__":
    import sys
    run(sys.argv[1])
