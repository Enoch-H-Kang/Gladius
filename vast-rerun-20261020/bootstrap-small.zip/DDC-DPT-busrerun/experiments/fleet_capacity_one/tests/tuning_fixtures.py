"""Truth-free synthetic fixtures for the tuning tests (numpy only)."""
import numpy as np


def make_export(path, n_chains=40, H=100, seed=0):
    rng = np.random.default_rng(seed)
    s = np.empty((n_chains, H), np.int64)
    a = np.empty_like(s)
    sp = np.empty_like(s)
    for c in range(n_chains):
        x = 1
        for t in range(H):
            act = int(rng.random() < min(0.05 + 0.1 * (x - 1), 0.9))
            nx = 1 if act else min(x + int(rng.integers(1, 5)), 10)
            s[c, t], a[c, t], sp[c, t] = x, act, nx
            x = nx
    np.savez_compressed(path, s=s, a=a, sp=sp, chain_hash=np.array([f"{c:08d}" for c in range(n_chains)]),
                        is_val=(np.arange(n_chains) % 5 == 4))
    return path


def small_cfg(**kw):
    cfg = dict(loss="none", k=1, cap_q=40, val_every=10, elig_start=10, batch=32)
    cfg.update(kw)
    return cfg


def fixed_seeds():
    from experiments.fleet_capacity_one.fleet.seeds import expand_seeds
    return expand_seeds("bus", "TEST", "fix", 0)
