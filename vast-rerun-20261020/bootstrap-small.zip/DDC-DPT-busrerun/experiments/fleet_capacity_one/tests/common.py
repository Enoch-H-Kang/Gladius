import os
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "")
from experiments.fleet_capacity_one.fleet.params import Params

HERE = os.path.dirname(os.path.abspath(__file__))
P = Params.from_json(os.path.join(HERE, "..", "configs", "dgp.json"))
