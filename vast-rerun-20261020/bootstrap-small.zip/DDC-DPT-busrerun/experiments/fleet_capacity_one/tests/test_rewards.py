import unittest

import numpy as np

from experiments.fleet_capacity_one.fleet import anchor
from experiments.fleet_capacity_one.fleet.rewards import reward, reward_all, maintenance, replacement
from .common import P


class TestRewards(unittest.TestCase):
    def test_structure(self):
        rng = np.random.default_rng(1)
        s = rng.uniform(size=(50, 5))
        R = reward_all(s, P)
        r0 = anchor.r0_np(s, P.arr("u"), P.arr("v"))
        self.assertTrue(np.array_equal(R[:, 0], r0))
        for f in range(5):
            m = P.u[f] * s[:, f] + P.v[f] * s[:, f] ** 2
            C = P.Kcost[f] + P.d[f] * s[:, f] ** 2
            self.assertLess(np.abs(R[:, f + 1] - (r0 + m - C)).max(), 1e-13)

    def test_hand_values(self):
        s = np.array([[1, 0, 0, 0, 0.0]])
        R = reward_all(s, P)[0]
        self.assertAlmostEqual(R[0], -3.0)            # -(1*1+2*1)
        self.assertAlmostEqual(R[1], -(3.0 + 0.15))   # replace bus 1: pay C_1(1); no maintenance anywhere
        self.assertAlmostEqual(R[2], -3.0 + 0.0 - 3.4)  # bus 2 at 0: r0 + 0 - K_2
        self.assertEqual(reward(s, np.array([1]), P)[0], R[1])

    def test_kcost_scale_only_touches_replacement(self):
        s = np.full((1, 5), 0.3)
        q = P.replace(kcost_scale=1.5)
        R1, R2 = reward_all(s, P)[0], reward_all(s, q)[0]
        self.assertEqual(R1[0], R2[0])
        self.assertTrue(np.allclose(R1[1:] - R2[1:], 0.5 * np.asarray(P.Kcost)))
