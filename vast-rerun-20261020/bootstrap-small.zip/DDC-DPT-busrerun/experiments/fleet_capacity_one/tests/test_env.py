import unittest

import numpy as np

from experiments.fleet_capacity_one.fleet import env
from experiments.fleet_capacity_one.fleet.kernels import gammaincc
from .common import P


class TestEnv(unittest.TestCase):
    def test_fixed_increment_reset_and_cap(self):
        s = np.array([[0.5, 0.5, 0.95, 1.0, 0.2]] * 6)
        D = np.array([[0.1, 0.2, 0.3, 0.4, 0.05]] * 6)
        out = env.step(s, np.arange(6), D, P)
        base = np.minimum(1.0, s + D)
        self.assertEqual(base[0, 2], 1.0)  # cap, exactly
        self.assertTrue(np.array_equal(out[0], base[0]))
        for f in range(1, 6):
            exp = base[f].copy()
            exp[f - 1] = 0.0  # exactly 0, no same-period increment
            self.assertTrue(np.array_equal(out[f], exp), f)

    def test_reset_ignores_increment(self):
        s = np.full((2, 5), 0.4)
        a = np.array([3, 3])
        D = np.array([[0.1] * 5, [0.9] * 5])
        out = env.step(s, a, D, P)
        self.assertEqual(out[0, 2], 0.0)
        self.assertEqual(out[1, 2], 0.0)

    def test_chains_record_h_transitions_no_restart_rows(self):
        rs, ra, ri = (np.random.default_rng(i) for i in (1, 2, 3))
        pol = lambda s: np.full((s.shape[0], 6), 1 / 6)
        ch = env.simulate_chains(pol, 7, P, rs, ra, ri)
        self.assertEqual(ch["s"].shape, (7, 100, 5))
        # within a chain, s_{t+1} == sp_t: no restart transition anywhere, last sp is its real successor
        self.assertTrue(np.array_equal(ch["s"][:, 1:], ch["sp"][:, :-1]))
        self.assertTrue(ch["s"][:, 0].max() <= 0.5)
        self.assertTrue(ch["sp"].max() <= 1.0 and ch["sp"].min() >= 0.0)

    def test_cap_atom_frequency(self):
        x = 0.9
        n = 400000
        rng = np.random.default_rng(5)
        s = np.full((n, 5), x)
        sp = env.step(s, np.zeros(n, dtype=int), env.sample_increments(rng, n, P), P)
        for j in range(5):
            q = gammaincc(P.shape, (1 - x) / P.scale[j])
            freq = (sp[:, j] == 1.0).mean()
            se = np.sqrt(q * (1 - q) / n)
            self.assertLess(abs(freq - q), 3 * se + 1e-12, j)
