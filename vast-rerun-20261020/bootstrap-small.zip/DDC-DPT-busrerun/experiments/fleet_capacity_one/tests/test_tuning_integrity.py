import ast
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest

import numpy as np

from experiments.fleet_capacity_one.tests.tuning_fixtures import make_export

PKG = "experiments.fleet_capacity_one"
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
TRAIN_PATH = ["fleet.train", "fleet.select", "fleet.losses", "fleet.models", "fleet.seeds",
              "tuning.run_fit", "tuning.data_io", "tuning.bus_anchor"]
FORBIDDEN = ["fleet.oracle", "fleet.kernels", "fleet.env", "fleet.params", "fleet.evalsets", "fleet.rewards", "fleet.anchor",
             "tuning.bus_truth", "tuning.bus_data", "tuning.evaluate", "tuning.analyze", "tuning.runner"]
FORBIDDEN_THIRD_PARTY = {"scipy", "pickle"}


def mod_path(name):
    return os.path.join(ROOT, *PKG.split("."), *name.split(".")) + ".py"


def imports_of(name):
    tree = ast.parse(open(mod_path(name)).read())
    pkg = (PKG + "." + name).rsplit(".", 1)[0]
    out = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            out += [(a.name, ()) for a in n.names]
        elif isinstance(n, ast.ImportFrom):
            if n.level:
                base = pkg.split(".")[: len(pkg.split(".")) - (n.level - 1)]
                full = ".".join(base + ([n.module] if n.module else []))
            else:
                full = n.module
            out.append((full, tuple(a.name for a in n.names)))
    return out


def closure(entries):
    seen, todo, third = set(), list(entries), set()
    while todo:
        m = todo.pop()
        if m in seen:
            continue
        seen.add(m)
        for full, names in imports_of(m):
            if full.startswith(PKG):
                rel = full[len(PKG) + 1:]
                cands = [rel] + [rel + "." + n for n in names]
                for c in cands:
                    if c and os.path.exists(mod_path(c)):
                        todo.append(c)
            else:
                third.add(full.split(".")[0])
    return seen, third


class TestImportGraph(unittest.TestCase):
    def test_training_path_has_no_truth_modules(self):
        seen, third = closure(TRAIN_PATH)
        self.assertTrue(set(TRAIN_PATH) <= seen)
        self.assertEqual(sorted(seen & set(FORBIDDEN)), [])
        self.assertEqual(sorted(third & FORBIDDEN_THIRD_PARTY), [])

    def test_graph_check_is_not_vacuous(self):
        seen, _ = closure(["tuning.evaluate"])
        self.assertIn("tuning.bus_truth", seen)       # the walker does find truth imports when they exist
        seen2, _ = closure(["tuning.bus_data"])
        self.assertIn("tuning.bus_truth", seen2)

    def test_evaluator_is_not_imported_by_trainer_or_runner_children(self):
        for m in ("fleet.train", "fleet.select", "tuning.run_fit"):
            self.assertNotIn("tuning.evaluate", closure([m])[0])


POISON = "import sys\nfor name in %(forbidden)r:\n    sys.modules[name] = None\nsys.modules['scipy'] = None\n"
RUN = ("from experiments.fleet_capacity_one.tuning import run_fit\n"
       "run_fit.main(%(manifest)r, %(fid)r, %(root)r, %(export)r)\n")


class TestTruthUnavailableReplay(unittest.TestCase):
    def test_replay_bitwise_with_truth_modules_poisoned(self):
        from experiments.fleet_capacity_one.fleet.seeds import expand_seeds
        with tempfile.TemporaryDirectory() as d:
            export = make_export(os.path.join(d, "e.npz"), 40, 100, 5)
            cfg = dict(loss="clip0", k=3, cap_q=60, val_every=20, elig_start=20, batch=64, lr_q=1e-3, N=4000, beta=0.95)
            spec = dict(fit_id="T_a", config=cfg, config_id="x", init_index=0, seeds=expand_seeds("bus", "T", "d", 0),
                        data_id="d", n_chains=40, horizons=[60], stage="T")
            man = os.path.join(d, "m.json")
            json.dump(dict(stage="T", n_fits=1, sha256="s", fits=[spec]), open(man, "w"))
            outs = {}
            for tag, poison in (("plain", False), ("poisoned", True)):
                root = os.path.join(d, tag)
                forb = [f"{PKG}.{m}" for m in FORBIDDEN if m != "tuning.runner"]
                code = (POISON % dict(forbidden=forb) if poison else "") + RUN % dict(manifest=man, fid="T_a", root=root, export=export)
                r = subprocess.run([sys.executable, "-I", "-c", "import sys; sys.path.insert(0, %r)\n" % ROOT + code],
                                   capture_output=True, text=True, cwd=d, env=dict(os.environ, OMP_NUM_THREADS="1"))
                self.assertEqual(r.returncode, 0, r.stderr[-2000:])
                outs[tag] = json.load(open(os.path.join(root, "T_a", "record.json")))
            a, b = outs["plain"], outs["poisoned"]
            self.assertEqual([x["hash"] for x in a["trace"]], [x["hash"] for x in b["trace"]])
            self.assertEqual(a["horizons"], b["horizons"])
            self.assertEqual(a["counts"], b["counts"])

    def test_poison_actually_blocks_truth_import(self):
        code = ("import sys\nsys.path.insert(0, %r)\nsys.modules[%r] = None\n"
                "try:\n    import %s\nexcept ImportError:\n    print('blocked')\n") % (
            ROOT, PKG + ".tuning.bus_truth", PKG + ".tuning.bus_truth")
        r = subprocess.run([sys.executable, "-I", "-c", code], capture_output=True, text=True)
        self.assertEqual(r.stdout.strip(), "blocked")

    def test_trainer_output_schema_has_no_truth_fields(self):
        from experiments.fleet_capacity_one.fleet import train
        from experiments.fleet_capacity_one.tuning.data_io import load_bus
        from experiments.fleet_capacity_one.tests.tuning_fixtures import small_cfg, fixed_seeds
        with tempfile.TemporaryDirectory() as d:
            data = load_bus(make_export(os.path.join(d, "e.npz"), 20, 100, 1), 20)
        rec = train.fit(data, small_cfg(), fixed_seeds())
        blob = json.dumps(rec, default=str).lower()
        for bad in ("true_q", "truth", "rmse_true", "oracle", "kl"):
            self.assertNotIn(bad, blob)


class TestBusPoolAudit(unittest.TestCase):
    RAW = os.path.join(ROOT, "experiments/fleet_capacity_one/artifacts/tuning/raw_review")

    @unittest.skipUnless(os.path.exists(os.path.join(RAW, "n1000_train.pkl")), "raw review archives not extracted")
    def test_review_archives_fail_dgp_identity_and_are_nested(self):
        from experiments.fleet_capacity_one.tuning import bus_data
        with tempfile.TemporaryDirectory() as d:
            res = bus_data.audit_archives(self.RAW, os.path.join(d, "a.json"))
        self.assertEqual(res["pool_1000_distinct"], 1000)
        self.assertEqual(res["n10000_train_test_overlap"], 0)
        self.assertTrue(res["all_archives_subset_of_one_10000_stream"])
        self.assertFalse(res["dgp_matches_brief_maxMileage10"])       # states above 10 exist -> fallback pool
        self.assertFalse(res["lineage_established"])

    def test_generated_pool_audit_export_and_panel_disjointness(self):
        from experiments.fleet_capacity_one.tuning import bus_data, bus_truth
        with tempfile.TemporaryDirectory() as d:
            tr, te = bus_data.generate_pool(7000, 50, os.path.join(d, "g"))
            res = bus_data.audit_pool(tr, te, os.path.join(d, "a.json"), 7000)
            self.assertEqual(res["dgp_issue_count"], 0, res["dgp_issues"])
            self.assertLessEqual(res["max_state"], 10)
            self.assertEqual((res["n_train"], res["n_test"], res["distinct"]), (40, 10, 50))
            p = bus_data.export_pool(tr, te, os.path.join(d, "pool.npz"))
            z = np.load(p, allow_pickle=False)
            self.assertEqual(sorted(z.files), ["a", "chain_hash", "is_val", "s", "sp"])       # no truth fields
            self.assertEqual(list(z["chain_hash"]), sorted(z["chain_hash"]))
            self.assertEqual(int(z["is_val"].sum()), 10)
            panel = bus_data.generate_chains(7199, 20)
            ph = set(bus_data.chain_hashes(panel))
            self.assertEqual(len(ph & set(z["chain_hash"])), 0)
            sol = bus_truth.vfi()
            self.assertAlmostEqual(sol["Q"][3, 1], -5 + 0.95 * sol["V"][1], places=6)
            # the generator wrapper is deterministic
            self.assertEqual(bus_data.chain_hashes(bus_data.generate_chains(7199, 5)), bus_data.chain_hashes(panel[:5]))


if __name__ == "__main__":
    unittest.main()
