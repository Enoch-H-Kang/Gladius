import unittest

import numpy as np
from scipy import integrate, stats

from experiments.fleet_capacity_one.fleet import kernels
from .common import P

XS = np.array([0.0, 0.013, 0.2, 0.5, 0.9, 0.97, 0.999, 1.0 - 1e-6, 1.0])


def hat(y, k, K):
    h = 1.0 / (K - 1)
    return np.maximum(0.0, 1.0 - np.abs(y - k * h) / h)


def quad_row(x, K, shape, scale):
    dist = stats.gamma(shape, scale=scale)
    c = 1.0 - x
    row = np.zeros(K)
    h = 1.0 / (K - 1)
    for k in range(K):
        pts = sorted({t - x for t in (max(0, k - 1) * h, k * h, min(K - 1, k + 1) * h) if 0 < t - x < c})
        f = lambda D: hat(x + D, k, K) * dist.pdf(D)
        row[k], _ = integrate.quad(f, 0.0, c, points=pts or None, epsabs=1e-14, epsrel=1e-13, limit=400)
    row[K - 1] += dist.sf(c)
    return row


class TestKernels(unittest.TestCase):
    def test_row_sums_and_nonneg(self):
        for K in (3, 7, 31):
            for j in range(5):
                P_ = kernels.kernel_matrix(K, P.shape, P.scale[j])
                self.assertLess(np.abs(P_.sum(1) - 1).max(), 1e-12)
                self.assertGreaterEqual(P_.min(), -1e-13)
                self.assertEqual(P_[-1, -1], 1.0)  # at x=1 the row is the last unit vector
        rows = kernels.hat_rows(np.random.default_rng(0).uniform(size=5000), 31, P.shape, P.scale[2])
        self.assertLess(np.abs(rows.sum(1) - 1).max(), 1e-12)

    def test_mean_identity(self):
        for K in (7, 31):
            g = np.linspace(0, 1, K)
            for j in (0, 4):
                x = np.concatenate([XS, np.random.default_rng(1).uniform(size=200)])
                w = kernels.hat_rows(x, K, P.shape, P.scale[j])
                got = w @ g
                want = kernels.expected_next(x, P.shape, P.scale[j])
                self.assertLess(np.abs(got - want).max(), 1e-12)
        # closed form E[min(1,x+D)] itself against quad
        dist = stats.gamma(P.shape, scale=P.scale[1])
        for x in XS[:-1]:
            val = integrate.quad(lambda D: (x + D) * dist.pdf(D), 0, 1 - x, epsabs=1e-14, epsrel=1e-13)[0] + dist.sf(1 - x)
            self.assertLess(abs(val - kernels.expected_next(x, P.shape, P.scale[1])), 1e-12)

    def test_quad_agreement_including_near_cap(self):
        worst = 0.0
        for K in (5, 11, 31):
            for j in (0, 2, 4):
                w = kernels.hat_rows(XS, K, P.shape, P.scale[j])
                for i, x in enumerate(XS):
                    worst = max(worst, np.abs(w[i] - quad_row(x, K, P.shape, P.scale[j])).max())
        self.assertLess(worst, 1e-10)

    def test_monte_carlo_within_3se(self):
        K, j, n = 11, 3, 2_000_000
        rng = np.random.default_rng(11)
        D = rng.gamma(P.shape, P.scale[j], size=n)
        for x in (0.0, 0.37, 0.94):
            y = np.minimum(1.0, x + D)
            phi = np.stack([hat(y, k, K) for k in range(K)], 1)
            mc, se = phi.mean(0), phi.std(0, ddof=1) / np.sqrt(n)
            w = kernels.hat_rows([x], K, P.shape, P.scale[j])[0]
            tol = 3.5 * np.maximum(se, np.sqrt(w / n)) + 1e-12
            self.assertTrue(np.all(np.abs(w - mc) <= tol), x)
