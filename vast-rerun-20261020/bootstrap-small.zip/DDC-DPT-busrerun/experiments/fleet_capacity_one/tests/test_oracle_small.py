import itertools
import unittest

import numpy as np
from scipy.special import logsumexp

from experiments.fleet_capacity_one.fleet import oracle, kernels
from experiments.fleet_capacity_one.fleet.rewards import reward_all
from .common import P


class TestControls(unittest.TestCase):
    def test_beta_zero_gives_Q_equals_r(self):
        p = P.replace(beta=0.0)
        K = 5
        res = oracle.solve_vi(p, K, tol=1e-14)
        Q = oracle.node_Q(res["V"], p, K)
        g = oracle.grid(K)
        S = np.array(list(itertools.product(g, repeat=5)))
        R = reward_all(S, p).reshape((K,) * 5 + (6,))
        self.assertLess(np.abs(Q - R).max(), 1e-12)

    def test_zero_reward_value(self):
        K = 4
        res = oracle.solve_vi(P, K, tol=1e-13, reward_mult=0.0)
        want = np.log(6.0) / (1 - P.beta)
        self.assertLess(np.abs(res["V"] - want).max(), 1e-9)

    def test_kronecker_fixture_F2_K3(self):
        p = P.subset(2)
        K = 3
        Ps = oracle.kernel_list(p, K)
        rng = np.random.default_rng(3)
        V = rng.normal(size=(K, K))
        cont = oracle.continuation(V, Ps, 2)
        T0 = np.kron(Ps[0], Ps[1])                         # dense 9x9, state index i*K+j
        self.assertLess(np.abs(cont[0].reshape(-1) - T0 @ V.reshape(-1)).max(), 1e-12)
        e0 = np.zeros((K, K)); e0[:, 0] = 1                # reset bus 1 -> node 0
        T1 = np.kron(e0, Ps[1])
        self.assertLess(np.abs(np.broadcast_to(cont[1][None, :], (K, K)).reshape(-1) - T1 @ V.reshape(-1)).max(), 1e-12)
        T2 = np.kron(Ps[0], e0)
        self.assertLess(np.abs(np.broadcast_to(cont[2][:, None], (K, K)).reshape(-1) - T2 @ V.reshape(-1)).max(), 1e-12)
        # whole Bellman operator vs fully dense formulation
        r0, delta = oracle.reward_grids(p, K)
        Vn, Qs = oracle.bellman(V, p, Ps, r0, delta)
        S = np.array(list(itertools.product(oracle.grid(K), repeat=2)))
        R = reward_all(S, p)
        Qd = np.stack([R[:, 0] + p.beta * T0 @ V.reshape(-1), R[:, 1] + p.beta * T1 @ V.reshape(-1),
                       R[:, 2] + p.beta * T2 @ V.reshape(-1)], 1)
        self.assertLess(np.abs(np.stack(Qs, -1).reshape(-1, 3) - Qd).max(), 1e-12)
        self.assertLess(np.abs(Vn.reshape(-1) - logsumexp(Qd, axis=1)).max(), 1e-12)

    def test_reset_continuation_independent_of_own_mileage(self):
        K = 5
        V = np.random.default_rng(4).normal(size=(K,) * 5)
        Ps = oracle.kernel_list(P, K)
        cont = oracle.continuation(V, Ps, 5)
        for f in range(5):
            self.assertEqual(cont[f + 1].ndim, 4)  # axis f removed entirely

    def test_lookahead_matches_node_Q(self):
        p = P.subset(3)
        K = 7
        res = oracle.solve_vi(p, K, tol=1e-12)
        Qn = oracle.node_Q(res["V"], p, K)
        g = oracle.grid(K)
        S = np.array(list(itertools.product(g, repeat=3)))
        Q = oracle.lookahead_Q(S, res["V"], p).reshape((K,) * 3 + (4,))
        self.assertLess(np.abs(Q - Qn).max(), 1e-11)
        self.assertLess(np.abs(logsumexp(Qn, axis=-1) - res["V"]).max(), 1e-10)

    def test_lookahead_f1_against_dense_formulas_and_float32(self):
        p = P.subset(1)
        K = 9
        res = oracle.solve_vi(p, K, tol=1e-13)
        x = np.random.default_rng(0).uniform(size=(50, 1))
        Q = oracle.lookahead_Q(x, res["V"], p)
        rows = kernels.hat_rows(x[:, 0], K, p.shape, p.scale[0])
        self.assertLess(np.abs(Q[:, 0] - (reward_all(x, p)[:, 0] + p.beta * rows @ res["V"])).max(), 1e-12)
        Q32 = oracle.lookahead_Q(x, res["V"], p, dtype=np.float32)
        self.assertLess(np.abs(Q32 - Q).max(), 1e-4)

    def test_vi_stops_and_saved_residual_small(self):
        K = 5
        res = oracle.solve_vi(P, K)
        self.assertTrue(res["converged"])
        self.assertLess(oracle.residual(res["V"], P, K), 1e-6)
