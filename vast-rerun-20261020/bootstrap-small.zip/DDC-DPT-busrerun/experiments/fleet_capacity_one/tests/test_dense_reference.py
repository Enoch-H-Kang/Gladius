import unittest

import numpy as np

from experiments.fleet_capacity_one.fleet import kernels, oracle
from experiments.fleet_capacity_one.scripts import validate_oracle as vo
from .common import P


class TestDenseReference(unittest.TestCase):
    def test_independent_toeplitz_kernel_matches_closed_form(self):
        p1 = P.subset(1)
        n = 201
        Pm, _ = vo.dense_1d_solver(p1, n)
        ref = kernels.kernel_matrix(n, p1.shape, p1.scale[0])
        self.assertLess(np.abs(Pm - ref).max(), 1e-10)

    def test_dense_offgrid_lookahead_matches_tensor_code(self):
        p1 = P.subset(1)
        K = 11
        res = oracle.solve_vi(p1, K, tol=1e-12)
        x = np.array([0.0, 0.123, 0.5, 0.95, 1.0])
        # dense_Q_at interpolates V linearly on its own grid: feed it the K=11 grid
        A = vo.dense_Q_at(x, res["V"], p1, n=K)
        B = oracle.lookahead_Q(x[:, None], res["V"], p1)
        self.assertLess(np.abs(A - B).max(), 1e-9)
