import ast
import os
import unittest

import numpy as np
import torch

from experiments.fleet_capacity_one.fleet import anchor
from .common import P


class TestAnchor(unittest.TestCase):
    def test_endpoints(self):
        u, v = P.arr("u"), P.arr("v")
        self.assertEqual(anchor.r0_np(np.zeros(5), u, v), 0.0)
        self.assertAlmostEqual(float(anchor.r0_np(np.ones(5), u, v)), -17.1, places=12)

    def test_torch_twin_float64_and_float32(self):
        rng = np.random.default_rng(0)
        s = rng.uniform(size=(100000, 5))
        ref = anchor.r0_np(s, P.arr("u"), P.arr("v"))
        t64 = anchor.r0_torch(torch.from_numpy(s), P.u, P.v).numpy()
        self.assertLess(np.abs(t64 - ref).max(), 1e-12)
        t32 = anchor.r0_torch(torch.from_numpy(s).float(), P.u, P.v).numpy()
        self.assertLess(np.abs(t32 - ref).max(), 1e-5)

    def test_module_sees_only_u_v(self):
        with open(anchor.__file__) as fh:
            tree = ast.parse(fh.read())
        names = set()
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                names |= {a.name for a in node.names} | ({node.module} if isinstance(node, ast.ImportFrom) else set())
            elif isinstance(node, ast.Name):
                names.add(node.id)
            elif isinstance(node, ast.Attribute):
                names.add(node.attr)
            elif isinstance(node, ast.arg):
                names.add(node.arg)
        for forbidden in ("Kcost", "d", "mean", "shape", "scale", "params", "rewards", "p"):
            self.assertNotIn(forbidden, names, forbidden)
