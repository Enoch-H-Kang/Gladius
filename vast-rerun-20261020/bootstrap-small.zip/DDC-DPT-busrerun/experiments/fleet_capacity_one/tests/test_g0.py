import os
import unittest


class TestEnvironment(unittest.TestCase):
    def test_no_cuda_in_use(self):
        os.environ.setdefault("CUDA_VISIBLE_DEVICES", "")
        import torch
        self.assertEqual(torch.__version__.split("+")[0], "2.5.1")

    def test_dgp_config_loads(self):
        from experiments.fleet_capacity_one.fleet.params import Params
        here = os.path.dirname(os.path.abspath(__file__))
        p = Params.from_json(os.path.join(here, "..", "configs", "dgp.json"))
        self.assertEqual((p.F, p.beta, p.H), (5, 0.95, 100))
        self.assertEqual(len(p.dgp_id), 64)
