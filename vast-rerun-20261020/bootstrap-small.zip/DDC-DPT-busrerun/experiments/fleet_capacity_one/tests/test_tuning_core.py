import math
import os
import tempfile
import unittest

import numpy as np
import torch

from experiments.fleet_capacity_one.fleet import losses, train
from experiments.fleet_capacity_one.fleet.models import MLP, init_mlp
from experiments.fleet_capacity_one.fleet.select import select_checkpoint
from experiments.fleet_capacity_one.fleet.seeds import derive_seed, expand_seeds
from experiments.fleet_capacity_one.tuning.data_io import load_bus
from experiments.fleet_capacity_one.tests.tuning_fixtures import make_export, small_cfg, fixed_seeds

D = torch.float64
BETA = 0.95


def t(x, grad=False):
    return torch.tensor(x, dtype=D, requires_grad=grad)


class TestLosses(unittest.TestCase):
    def test_product_form_equals_square_form_float64(self):
        g = torch.Generator().manual_seed(1)
        q, r, v, z = (torch.randn(500, generator=g, dtype=D) * 3 for _ in range(4))
        self.assertTrue(torch.allclose(losses.u_product(q, r, v, z, BETA), losses.u_square(q, r, v, z, BETA), atol=1e-10, rtol=1e-12))

    def test_shape_asserts(self):
        b = torch.zeros(4, dtype=D)
        with self.assertRaises(AssertionError):
            losses.be_term(b[:, None], b, b, b, b > 0, BETA, "none")
        with self.assertRaises(AssertionError):
            losses.be_term(b, b, b[:3], b, b > 0, BETA, "none")
        with self.assertRaises(AssertionError):
            losses.ce_term(torch.zeros(4, dtype=D), torch.zeros(4, dtype=torch.long))
        with self.assertRaises(AssertionError):
            losses.zeta_term(b[:, None], b[:, None])
        with self.assertRaises(ValueError):
            losses.f_of_u(b, "huber")

    def test_mask_and_whole_batch_mean(self):
        q, r, v, z = t([1., 2., 3., 4.]), t([0.] * 4), t([.5] * 4), t([.2] * 4)
        m = torch.tensor([True, False, True, False])
        u = losses.u_product(q, r, v, z, BETA)
        got = losses.be_term(q, r, v, z, m, BETA, "none")
        self.assertAlmostEqual(float(got), float((u[m]).sum() / 4), places=12)       # divided by B, not by #anchor rows
        self.assertAlmostEqual(float(losses.be_term(q, r, v, z, torch.zeros(4, dtype=torch.bool), BETA, "abs")), 0.0)

    def test_loss_values_and_signs(self):
        # row 1: u > 0 ; row 2: u < 0 (v far from z makes the correction dominate)
        q, r, v, z = t([2., 0.1]), t([0., 0.]), t([0., 3.]), t([0., 0.])
        u = losses.u_product(q, r, v, z, BETA)
        self.assertGreater(float(u[0]), 0)
        self.assertLess(float(u[1]), 0)
        m = torch.tensor([True, True])
        self.assertAlmostEqual(float(losses.be_term(q, r, v, z, m, BETA, "none")), float(u.mean()), places=12)
        self.assertAlmostEqual(float(losses.be_term(q, r, v, z, m, BETA, "clip0")), float(torch.clamp(u, min=0).mean()), places=12)
        self.assertAlmostEqual(float(losses.be_term(q, r, v, z, m, BETA, "abs")), float(u.abs().mean()), places=12)

    def test_gradient_signs_per_row(self):
        for loss, expect_neg_row in (("none", +1.0), ("clip0", 0.0), ("abs", -1.0)):
            q = t([2., 0.1], True)
            r, v, z = t([0., 0.]), t([0., 3.]), t([0., 0.])
            l = losses.be_term(q, r, v, z, torch.tensor([True, True]), BETA, loss)
            l.backward()
            qq = q.detach().clone().requires_grad_()
            u = losses.u_product(qq, r, v, z, BETA)
            u.sum().backward()
            # row 1 (u>0): every variant uses +du/dq ; row 2 (u<0): +du (none), 0 (clip0), -du (abs)
            self.assertAlmostEqual(float(q.grad[0]), float(qq.grad[0]) / 2, places=12)
            self.assertAlmostEqual(float(q.grad[1]), expect_neg_row * float(qq.grad[1]) / 2, places=12)

    def test_zero_subgradient_at_u_zero(self):
        # beta = 0.5 and dyadic numbers: q = r + beta z gives u = 0 exactly; signed has a nonzero gradient, clip0/abs zero
        beta = 0.5
        r, z, v = t([0.25]), t([0.5]), t([1.75])
        for loss, zero in (("none", False), ("clip0", True), ("abs", True)):
            q = (r + beta * z).clone().requires_grad_()
            self.assertEqual(float(losses.u_product(q, r, v, z, beta)), 0.0)
            vv = v.clone().requires_grad_()
            losses.be_term(q, r, vv, z, torch.tensor([True]), beta, loss).backward()
            gq, gv = float(q.grad[0]), float(vv.grad[0])
            if zero:
                self.assertEqual((gq, gv), (0.0, 0.0))
            else:
                self.assertNotEqual(gq, 0.0)

    def test_two_successor_identity_and_clip_abs_break_it(self):
        # (s,a0) with two equally likely successors; zeta = exact E[v]. Signed: E[u] = (q - r - beta E v)^2.
        ones = torch.tensor([True, True])

        def three(q, r, vs):
            z = vs.mean()
            e = lambda x: x.expand(2)
            out = {l: float(losses.be_term(e(q), e(r), vs, e(z), ones, BETA, l)) for l in ("none", "clip0", "abs")}
            return out, float((q - r - BETA * z) ** 2), z

        # u_i = c (c + 2 beta (z - v_i)), c = q - r - beta z: sign flips across successors when |c| is small
        out, target, z = three(t(1.3), t(-0.4), t([0.2, 2.6]))
        u = losses.u_product(t(1.3).expand(2), t(-0.4).expand(2), t([0.2, 2.6]), z.expand(2), BETA)
        self.assertTrue(float(u.min()) < 0 < float(u.max()))
        self.assertAlmostEqual(out["none"], target, places=12)
        self.assertGreater(abs(out["clip0"] - target), 1e-3, "clip0 must NOT reproduce the conditional squared Bellman error")
        self.assertGreater(abs(out["abs"] - target), 1e-3, "abs must NOT reproduce the conditional squared Bellman error")
        # also the identity for the signed variant at a second point (|c| large: all u > 0, where all three coincide)
        out2, target2, _ = three(t(-0.8), t(0.5), t([0.2, 2.6]))
        self.assertAlmostEqual(out2["none"], target2, places=12)
        self.assertAlmostEqual(out2["clip0"], target2, places=12)
        self.assertAlmostEqual(out2["abs"], target2, places=12)

    def test_gradient_flows_through_s_and_sprime(self):
        q, r, v, z = t([1.0], True), t([0.1]), t([0.8], True), t([0.2])
        losses.be_term(q, r, v, z, torch.tensor([True]), BETA, "none").backward()
        self.assertNotEqual(float(q.grad), 0.0)
        self.assertNotEqual(float(v.grad), 0.0)   # successor-side Q gets a gradient
        zz = t([0.2], True)
        l = losses.be_term(t([1.0]), r, v.detach(), zz.detach(), torch.tensor([True]), BETA, "none")
        self.assertFalse(l.requires_grad and zz.grad is not None)  # zeta enters detached


def _data(n_chains=40, seed=0):
    with tempfile.TemporaryDirectory() as d:
        p = make_export(os.path.join(d, "e.npz"), n_chains, 100, seed)
        return load_bus(p, n_chains)


class TestTrainerContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = _data()

    def test_update_counts_for_each_k(self):
        for k in (1, 3, 5, 10):
            rec = train.fit(self.data, small_cfg(k=k), fixed_seeds())
            c = rec["counts"]
            self.assertEqual((c["q_updates"], c["z_updates"], c["draws"]), (40, 40 * k, 40 * (k + 1)))

    def test_parameter_isolation_and_disjoint_optimizers(self):
        made, log = [], []
        orig = train._make_opt

        def spy(params, cfg, lr):
            opt = orig(params, cfg, lr)
            made.append(list(params))
            idx = len(made) - 1
            real_step = opt.step

            def step(*a, **kw):
                other = made[1 - idx] if len(made) == 2 else []
                before_other = [p.detach().clone() for p in other]
                before_own = [p.detach().clone() for p in params]
                out = real_step(*a, **kw)
                log.append(("Q" if idx == 0 else "Z",
                            all(torch.equal(b, p) for b, p in zip(before_other, other)),
                            any(not torch.equal(b, p) for b, p in zip(before_own, params))))
                return out
            opt.step = step
            return opt
        train._make_opt = spy
        try:
            train.fit(self.data, small_cfg(k=3, cap_q=12, val_every=6, elig_start=6), fixed_seeds())
        finally:
            train._make_opt = orig
        self.assertEqual(len(made), 2)
        self.assertFalse({id(p) for p in made[0]} & {id(p) for p in made[1]})
        self.assertEqual(sum(1 for x in log if x[0] == "Q"), 12)
        self.assertEqual(sum(1 for x in log if x[0] == "Z"), 36)
        self.assertTrue(all(x[1] and x[2] for x in log))          # other net untouched, own net moved
        # cycle order: k zeta steps then one Q step
        self.assertEqual([x[0] for x in log[:8]], ["Z", "Z", "Z", "Q", "Z", "Z", "Z", "Q"])

    def test_ce_batch_common_across_k_and_streams_distinct(self):
        probes = {}
        for k in (1, 3, 10):
            probes[k] = []
            train.fit(self.data, small_cfg(k=k, cap_q=6, val_every=3, elig_start=3), fixed_seeds(), probe=probes[k])
        ce = {k: [x for x in p if x[0] == "ce"] for k, p in probes.items()}
        an = {k: [x for x in p if x[0] == "anchor"] for k, p in probes.items()}
        ex = {k: [x for x in p if x[0] == "extrazeta"] for k, p in probes.items()}
        self.assertEqual(ce[1], ce[3])
        self.assertEqual(ce[1], ce[10])
        self.assertEqual(an[1], an[10])
        self.assertEqual(len(ex[1]), 0)
        self.assertEqual(len(ex[3]), 6 * 2)
        self.assertEqual(len(ex[10]), 6 * 9)
        # k = 3's extra zeta batches are a prefix of k = 10's (same (t, j) streams)
        e3 = {(x[1]): x[2] for x in ex[3]}
        e10 = {(x[1]): x[2] for x in ex[10]}
        self.assertTrue(all(e10[key] == v for key, v in e3.items()))
        self.assertNotEqual(ce[1][0][2], an[1][0][2])
        self.assertNotEqual(ce[1][0][2], ex[3][0][2])

    def test_batch_clamped_to_ntrain_over_8(self):
        small = _data(n_chains=10)
        rec = train.fit(small, small_cfg(batch=256), fixed_seeds())
        self.assertEqual(rec["batch_eff"], math.ceil(small["train"]["s"].shape[0] / 8))

    def test_fresh_start_determinism_and_isolation_from_global_rng(self):
        r1 = train.fit(self.data, small_cfg(k=3), fixed_seeds())
        torch.manual_seed(999)
        np.random.seed(999)
        r2 = train.fit(self.data, small_cfg(k=3), fixed_seeds())
        self.assertEqual([x["hash"] for x in r1["trace"]], [x["hash"] for x in r2["trace"]])
        s2 = expand_seeds("bus", "TEST", "fix", 1)
        r3 = train.fit(self.data, small_cfg(k=3), s2)
        self.assertNotEqual(r1["trace"][-1]["hash"], r3["trace"][-1]["hash"])

    def test_init_scheme(self):
        net = init_mlp(MLP(1, 2, 10, 2), 123, out_bias=-7.5)
        for layer in net.layers[:-1]:
            self.assertTrue(torch.all(layer.bias == 0))
        self.assertTrue(torch.all(net.layers[-1].bias == -7.5))
        w = net.layers[1].weight
        self.assertLess(abs(float(w.std()) - math.sqrt(2 / 20)), 0.08)
        # trainer initial output bias = mean_train r0 / (1 - beta) = -5 / .05 = -100 (bus)
        rec = train.fit(self.data, small_cfg(cap_q=10, val_every=10, elig_start=10), fixed_seeds())
        self.assertAlmostEqual(self.data["train"]["r0"].mean() / (1 - BETA), -100.0, places=3)

    def test_anchor_rmse_definition_and_reload(self):
        with tempfile.TemporaryDirectory() as d:
            rec = train.fit(self.data, small_cfg(cap_q=20, val_every=10, elig_start=10), fixed_seeds(), ckpt_dir=d)
            h = rec["horizons"][20]
            ck = torch.load(os.path.join(d, "ckpt_h20.pt"), weights_only=False)
            q, z = MLP(1, 2, 10, 2), MLP(1, 2, 10, 2)
            q.load_state_dict(ck["q"])
            z.load_state_dict(ck["z"])
            self.assertEqual(train._hash_params(q, z), ck["hash"])
            self.assertEqual(ck["hash"], h["hash"])
            val = train._tensors(self.data["val"], 10.0)
            r = train.validate(q, z, val, self.data["meta"], BETA)
            self.assertAlmostEqual(r["nll"], h["nll"], places=9)
            self.assertAlmostEqual(r["anchor_rmse"], h["anchor_rmse"], places=9)
            m = val["a"] == 1
            with torch.no_grad():
                manual = torch.sqrt(((q(val["x"][m])[:, 1] - BETA * z(val["x"][m])[:, 1] - val["r0"][m]) ** 2).mean())
            self.assertAlmostEqual(float(manual), r["anchor_rmse"], places=6)

    def test_divergence_keeps_slot_and_status(self):
        bad = _data()
        bad["train"]["r0"] = bad["train"]["r0"] * np.nan
        rec = train.fit(bad, small_cfg(cap_q=20), fixed_seeds())
        self.assertEqual(rec["fit_status"], "diverged")
        self.assertEqual(rec["horizons"][20]["status"], "failed_diverged")
        self.assertIsNone(rec["horizons"][20]["hash"])

    def test_gradient_clip_activation_logged(self):
        rec = train.fit(self.data, small_cfg(grad_clip=1e-9), fixed_seeds())
        self.assertGreater(rec["q_clip_rate"], 0.99)
        self.assertGreater(rec["z_clip_rate"], 0.99)
        rec = train.fit(self.data, small_cfg(grad_clip=1e9), fixed_seeds())
        self.assertEqual((rec["q_clip_rate"], rec["z_clip_rate"]), (0.0, 0.0))

    def test_all_twelve_variants_run(self):
        for loss in ("none", "clip0", "abs"):
            for k in (1, 3, 5, 10):
                rec = train.fit(self.data, small_cfg(loss=loss, k=k, cap_q=10, val_every=5, elig_start=5), fixed_seeds())
                self.assertEqual(rec["fit_status"], "complete")


def R(t_, nll, a, fin=True, h=None):
    return dict(t=t_, nll=nll, anchor_rmse=a, finite=fin, hash=h or f"h{t_}")


class TestSelection(unittest.TestCase):
    def test_eligibility_then_min_nll_then_tiebreaks(self):
        recs = [R(5000, 1.0, 0.20), R(5500, 0.9, 0.05), R(6000, 0.95, 0.04), R(6500, 0.9005, 0.03), R(7000, 0.8, 0.5)]
        st, ch = select_checkpoint(recs, 10000)
        self.assertEqual((st, ch["t"]), ("ok", 6500))        # tie set {5500, 6500}; lowest A wins
        recs = [R(5000, 0.9, 0.05, h="b"), R(5500, 0.9, 0.05, h="a")]
        self.assertEqual(select_checkpoint(recs, 9999)[1]["t"], 5000)   # equal A: earliest step
        recs = [R(6000, 0.9, 0.05, h="b"), R(6000, 0.9, 0.05, h="a")]
        self.assertEqual(select_checkpoint(recs, 9999)[1]["hash"], "a")  # then hash

    def test_no_pairwise_chain_tolerance(self):
        # NLLs 0.9, 0.9009, 0.9018: only those within 0.001 of the MIN are tied
        recs = [R(5000, 0.9, 0.09), R(5500, 0.9009, 0.02), R(6000, 0.9018, 0.01)]
        self.assertEqual(select_checkpoint(recs, 9999)[1]["t"], 5500)

    def test_horizon_and_elig_start_respected(self):
        recs = [R(4500, 0.1, 0.01), R(5000, 0.5, 0.05), R(7000, 0.4, 0.05)]
        self.assertEqual(select_checkpoint(recs, 6000)[1]["t"], 5000)
        self.assertEqual(select_checkpoint(recs, 7000)[1]["t"], 7000)

    def test_anchor_fail_fallback_and_failed(self):
        recs = [R(5000, 1.0, 0.5), R(5500, 0.9, 0.3), R(6000, 0.8, 1.2)]
        st, ch = select_checkpoint(recs, 9999)
        self.assertEqual((st, ch["t"]), ("anchor_fail", 5500))      # min NLL + A^2: 1.25, 0.99, 2.24
        self.assertEqual(select_checkpoint([R(5000, float("nan"), 0.01, fin=False)], 9999), ("failed", None))
        self.assertEqual(select_checkpoint([R(5000, 0.5, float("nan"))], 9999), ("failed", None))  # no anchor rows
        self.assertEqual(select_checkpoint([R(1000, 0.5, 0.01)], 9999), ("failed", None))


class TestSeeds(unittest.TestCase):
    def test_derivation_matches_spec_and_excludes_candidate(self):
        import hashlib
        key = "20261018|bus|B1|review1000|2|ce"
        want = int.from_bytes(hashlib.sha256(key.encode()).digest()[:8], "big") % (2 ** 63 - 1)
        self.assertEqual(derive_seed("bus", "B1", "review1000", 2, "ce"), want)
        s = expand_seeds("bus", "B1", "review1000", 0)
        self.assertEqual(len(set(s.values())), 6)

    def test_manifests(self):
        from experiments.fleet_capacity_one.tuning import manifest
        p0, b1 = manifest.build("P0"), manifest.build("B1")
        self.assertEqual((p0["n_fits"], b1["n_fits"]), (24, 216))
        self.assertEqual(len({f["fit_id"] for f in b1["fits"]}), 216)
        by_init = {}
        for f in b1["fits"]:
            by_init.setdefault(f["init_index"], set()).add(tuple(sorted(f["seeds"].items())))
        self.assertTrue(all(len(v) == 1 for v in by_init.values()))     # seeds paired across loss / k / rates
        self.assertEqual(len(by_init), 3)
        self.assertEqual({(f["config"]["loss"], f["config"]["k"]) for f in b1["fits"]}.__len__(), 12)
        self.assertEqual(manifest.build("B1")["sha256"], b1["sha256"])


class TestBusExport(unittest.TestCase):
    def test_loader_nested_prefix_and_no_truth_keys(self):
        with tempfile.TemporaryDirectory() as d:
            p = make_export(os.path.join(d, "e.npz"), 100, 100, 3)
            self.assertEqual(sorted(np.load(p).files), ["a", "chain_hash", "is_val", "s", "sp"])
            small, big = load_bus(p, 50), load_bus(p, 100)
            self.assertEqual((small["n_train_chains"], small["n_val_chains"]), (40, 10))
            self.assertEqual((big["n_train_chains"], big["n_val_chains"]), (80, 20))
            # nested: the small train partition is a prefix of the big train partition
            self.assertTrue(np.array_equal(small["train"]["s"], big["train"]["s"][:small["train"]["s"].shape[0]]))
            self.assertTrue(np.array_equal(small["val"]["a"], big["val"]["a"][:small["val"]["a"].shape[0]]))
            self.assertEqual(set(small["train"]), {"s", "a", "sp", "r0"})
            self.assertTrue(np.all(small["train"]["r0"] == -5.0))


class TestEvaluatorSanity(unittest.TestCase):
    def test_exact_networks_score_zero_error(self):
        from experiments.fleet_capacity_one.tuning import evaluate, bus_truth as bt
        sol = bt.vfi()
        Qt, Ez = torch.tensor(sol["Q"], dtype=torch.float32), torch.tensor(sol["expV"], dtype=torch.float32)

        class Tab(torch.nn.Module):
            def __init__(self, tab):
                super().__init__()
                self.tab = tab

            def forward(self, x):
                return self.tab[torch.round(x[:, 0] * 10).long()]
        ck = dict(cfg=dict(beta=0.95, width=10, depth=2), meta=dict(n_actions=2, state_scale=10.0))
        orig = evaluate._nets
        evaluate._nets = lambda ck_: (Tab(Qt), Tab(Ez), ck_["cfg"], ck_["meta"])
        try:
            occ = np.array([1, 1, 2, 3, 5, 1, 4, 2, 1])
            m = evaluate.metrics(ck, sol, occ)
        finally:
            evaluate._nets = orig
        for key in ("nonanchor_rmse", "q_rmse", "adv_rmse", "err_replace_rmse", "kl", "zeta_lag_rmse"):
            self.assertLess(m[key], 1e-4, key)
        self.assertAlmostEqual(sum(m["occupancy"]), 1.0, places=9)


class TestDevelopmentRanking(unittest.TestCase):
    def test_failed_fit_gets_fixed_penalty_even_with_truth_metric(self):
        from experiments.fleet_capacity_one.tuning.analyze import fit_score
        row = dict(status="anchor_fail", truth_nonanchor_rmse=0.1, truth_reward_scale=1.0)
        self.assertAlmostEqual(fit_score(row), math.log(10.0))
        row["status"] = "ok"
        self.assertAlmostEqual(fit_score(row), math.log(0.1))
        del row["truth_nonanchor_rmse"]
        self.assertAlmostEqual(fit_score(row), math.log(10.0))


if __name__ == "__main__":
    unittest.main()
