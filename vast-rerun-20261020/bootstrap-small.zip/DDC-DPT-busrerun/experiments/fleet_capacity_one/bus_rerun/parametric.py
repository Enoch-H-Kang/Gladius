"""Exact cap-10 structural scalar bus estimators. Only observed training s,a enter fits."""
import time
import numpy as np
from scipy.optimize import minimize
from scipy.special import expit, logsumexp

BETA = .95
STATES = np.arange(1, 11, dtype=np.float64)
P0 = np.zeros((10, 10), dtype=np.float64)
for i in range(10):
    for jump in (1, 2, 3, 4):
        P0[i, min(i + jump, 9)] += .25
P1 = np.zeros((10, 10), dtype=np.float64)
P1[:, 0] = 1.0


def solve(c, rc=5.0, tol=1e-10):
    r = np.column_stack((-float(c) * STATES, -float(rc) * np.ones(10)))
    q = np.zeros((10, 2), dtype=np.float64)
    for it in range(1, 100001):
        v = logsumexp(q, axis=1)
        q1 = np.column_stack((r[:, 0] + BETA * (P0 @ v), r[:, 1] + BETA * (P1 @ v)))
        delta = float(np.max(np.abs(q1-q)))
        q = q1
        if delta <= tol:
            break
    else:
        raise RuntimeError("inner VI failed to converge")
    v = logsumexp(q, axis=1)
    residual = float(np.max(np.abs(q - np.column_stack((r[:, 0]+BETA*(P0@v), r[:, 1]+BETA*(P1@v))))))
    pi = np.exp(q-v[:, None])
    return dict(q=q, pi=pi, residual=residual, sweeps=it)


def nfxp_value_grad(x, counts, rc_fixed=5.0):
    x = np.asarray(x, dtype=np.float64)
    out = solve(x[0], x[1] if len(x)==2 else rc_fixed)
    q, pi = out["q"], out["pi"]
    n = np.asarray(counts, dtype=np.float64)
    w = n/n.sum()
    nll = -float(np.sum(w * (q-logsumexp(q,axis=1)[:,None])))
    dp = np.column_stack((-STATES, np.zeros(10)))
    if len(x)==2:
        dp = np.stack((dp, np.column_stack((np.zeros(10), -np.ones(10)))))
    else:
        dp = dp[None]
    m = pi[:,0,None]*P0 + pi[:,1,None]*P1
    inv = np.eye(10)-BETA*m
    grads = []
    for dr in dp:
        dv = np.linalg.solve(inv, np.sum(pi*dr,axis=1))
        dq = dr + BETA*np.column_stack((P0@dv,P1@dv))
        dlpi = dq-np.sum(pi*dq,axis=1)[:,None]
        grads.append(-np.sum(w*dlpi))
    return nll, np.array(grads,dtype=np.float64), out


def ccp_first_stage(counts):
    n = np.asarray(counts,dtype=np.float64)
    m = n.sum()
    visits = n.sum(axis=1)
    raw = np.divide(n[:,1], visits, out=np.full(10,1/m), where=visits>0)
    p1 = np.clip(raw,1/m,1-1/m)
    return p1, dict(m=int(m), visits=visits.astype(int).tolist(),
                    action_counts=n.astype(int).tolist(), bound_fraction=float(np.mean(p1!=raw)))


def ccp_value_grad(x, counts, p1=None, rc_fixed=5.0):
    n = np.asarray(counts,dtype=np.float64)
    if p1 is None:
        p1,_ = ccp_first_stage(n)
    l = np.log(p1)
    d = -float(x[0])*STATES + rc_fixed + BETA*(l[0]-P0@l)
    prob = expit(d)
    m = n.sum()
    loss = float(np.sum(n[:,0]*np.logaddexp(0,-d)+n[:,1]*np.logaddexp(0,d))/m)
    grad = float(np.sum((n[:,0]*(prob-1)+n[:,1]*prob)*(-STATES))/m)
    return loss, np.array([grad]), dict(policy_keep=prob, p1=p1)


def fit(arm, s, a, rc_fixed=5.0):
    s=np.asarray(s,dtype=np.int64).reshape(-1)
    a=np.asarray(a,dtype=np.int64).reshape(-1)
    if len(s)!=len(a) or len(s)==0 or np.any((s<1)|(s>10)) or np.any((a<0)|(a>1)):
        raise ValueError("invalid observed training arrays")
    counts=np.zeros((10,2),dtype=np.int64)
    np.add.at(counts,(s-1,a),1)
    t0=time.perf_counter()
    if arm=="CCP-c":
        p1,first=ccp_first_stage(counts)
        fun=lambda x: ccp_value_grad(x,counts,p1,rc_fixed)
        dim=1
    elif arm in ("NFXP-c","NFXP-2p"):
        fun=lambda x: nfxp_value_grad(x,counts,rc_fixed)
        first=None
        dim=2 if arm=="NFXP-2p" else 1
    else:
        raise ValueError(arm)
    def objective(x):
        val,grad,_=fun(x)
        return val,grad
    try:
        res=minimize(objective, np.zeros(dim), jac=True, method="BFGS", options=dict(gtol=1e-8,maxiter=1000))
        val,grad,extra=fun(res.x)
        sol=solve(res.x[0],res.x[1] if dim==2 else rc_fixed)
        ok=bool(res.success and np.all(np.isfinite(res.x)) and np.isfinite(val) and
                np.max(np.abs(grad))<=1e-6 and sol["residual"]<=1e-9)
        return dict(arm=arm,status="ok" if ok else "optimizer_fail",native_status=str(res.message),
                    c_hat=float(res.x[0]),RC_hat=float(res.x[1]) if dim==2 else None,RC_fixed=None if dim==2 else float(rc_fixed),
                    nll=float(val),gradient=grad.tolist(),gradient_inf=float(np.max(np.abs(grad))),
                    bellman_residual=sol["residual"],vi_sweeps=sol["sweeps"],
                    optimizer_success=bool(res.success),nit=int(res.nit),nfev=int(res.nfev),
                    first_stage=first,training_counts=counts.tolist(),elapsed_wall=time.perf_counter()-t0)
    except Exception as exc:
        return dict(arm=arm,status="optimizer_fail",native_status=repr(exc),
                    training_counts=counts.tolist(),elapsed_wall=time.perf_counter()-t0)
