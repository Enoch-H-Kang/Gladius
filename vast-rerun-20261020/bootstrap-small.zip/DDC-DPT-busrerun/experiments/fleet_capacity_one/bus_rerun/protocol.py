"""Hash-sealed RR scheduling and lock checks. No truth or generator imports."""
import hashlib
import json
from pathlib import Path
from ..fleet.seeds import expand_seeds
from ..tuning.run_fit import code_hash

ROOT=Path.home()/"DDC-DPT-busrerun"
RESULT=ROOT/"results/bus_rerun"
DATA=ROOT/"artifacts/bus_rerun/data"
ARMS=("G-L","G-A1","NFXP-c","CCP-c","NFXP-2p")
SIZES=(50,250,500,1000,2500,5000)
EXPECTED_LOCK="3a7749e7354fd1472320f76b2d2b62259847eed682dea6379ecff7f02129619b"
EXPECTED_CODE="d925d15b69206db6fb391738eafbe1b1fd9391ff5046041b7db3bfed734f9eab"


def canonical(x):
    return json.dumps(x,sort_keys=True,separators=(",",":"),allow_nan=False).encode()


def sha(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1<<20),b""):h.update(chunk)
    return h.hexdigest()


def verify_seal(obj):
    declared=obj.get("sha256")
    actual=hashlib.sha256(canonical({k:v for k,v in obj.items() if k!="sha256"})).hexdigest()
    if declared!=actual:raise ValueError(f"seal mismatch: {declared} != {actual}")
    return actual


def seal(obj):
    obj=dict(obj)
    obj["sha256"]=hashlib.sha256(canonical(obj)).hexdigest()
    return obj


def lock():
    obj=json.loads((RESULT/"lock_ref.json").read_text())
    if verify_seal(obj)!=EXPECTED_LOCK: raise ValueError("BL lock mismatch")
    if obj["selection_input"]!="validation records only" or len(obj["all_policies"])!=18:
        raise ValueError("incomplete BL policy evidence")
    if obj["policy"]["n_ok"]!=3 or obj["policy"]["n"]!=3:
        raise ValueError("ineligible BL policy")
    if code_hash()!=EXPECTED_CODE: raise ValueError("lock-bound shared code changed")
    return obj


def freeze_state():
    """Only an explicit valid study common-protocol artifact can clear this gate."""
    fleet=Path.home()/"DDC-DPT-fleet-r1literal/experiments/fleet_r1literal/results/tuning"
    candidates=list(fleet.glob("*common*freeze*.json"))+list(fleet.glob("*protocol*freeze*.json"))
    if not candidates:
        return dict(state="WAIT_COMMON_FREEZE",missing="valid common-protocol D* freeze artifact; no frozen shared design key or applicable BL/BL-prime evidence")
    return dict(state="WAIT_COMMON_FREEZE",missing="candidate present but design-key and BL/BL-prime eligibility verification not implemented",candidates=[str(p) for p in candidates])


def build_manifest():
    l=lock()
    data=json.loads((RESULT/"data_freeze.json").read_text())
    verify_seal(data)
    if data["n_pools"]!=20 or data["source_transitions"]!=10200000:raise ValueError("data count mismatch")
    by_seed={p["seed"]:p for p in data["pools"]}
    slots=[]
    for arm in ARMS:
        for n in SIZES:
            for r in range(20):
                seed=11000+r
                pool=by_seed[seed]
                path=DATA/f"bus_seed{seed}.npz"
                if sha(path)!=pool["sha256"]:raise ValueError("export hash mismatch")
                cfg=dict(l["design"])
                cfg["N"]=100*n
                if arm=="G-A1":cfg["k"]=1
                slot=dict(fit_id=f"RR_{arm.replace('-','_')}_n{n}_r{r:02d}",stage="RR",arm=arm,n=n,r=r,
                          init_index=0,data_id=f"bus_seed{seed}",n_chains=n,
                          export_sha256=pool["sha256"],data_manifest_sha256=data["sha256"],
                          config=cfg if arm.startswith("G-") else None,
                          config_id=hashlib.sha256(canonical(cfg if arm.startswith("G-") else
                          dict(arm=arm,beta=.95,RC=5 if arm!="NFXP-2p" else None,inner_tol=1e-10,
                               optimizer="BFGS",gtol=1e-8,maxiter=1000))).hexdigest(),
                          seeds=expand_seeds("bus","RR",f"bus_seed{seed}",0),
                          horizons=[l["policy"]["horizon"]] if arm.startswith("G-") else [],
                          code_hash=code_hash() if arm.startswith("G-") else sha(Path(__file__).with_name("parametric.py")),
                          lock_sha256=l["sha256"] if arm.startswith("G-") else None,
                          status="pending")
                slots.append(slot)
    assert len(slots)==600 and len({s["fit_id"] for s in slots})==600
    body=dict(stage="RR",n_fits=600,arms=list(ARMS),sizes=list(SIZES),data_manifest_sha256=data["sha256"],
              lock_sha256=l["sha256"],code_hash=code_hash(),adapter_diff={"N":"100*n","n_chains":"n","excluded_by_run_fit":["N"]},
              freeze=freeze_state(),fits=slots)
    return seal(body)


def write_manifest():
    obj=build_manifest()
    path=RESULT/"manifest_RR.json"
    path.write_text(json.dumps(obj,indent=2)+"\n")
    seeds=seal(dict(stage="RR",streams={f"bus_seed{11000+r}":expand_seeds("bus","RR",f"bus_seed{11000+r}",0) for r in range(20)}))
    (RESULT/"seeds.json").write_text(json.dumps(seeds,indent=2)+"\n")
    return path,obj


def load_manifest(path):
    m=json.loads(Path(path).read_text())
    verify_seal(m)
    if m["n_fits"]!=600 or len(m["fits"])!=600:raise ValueError("slot count")
    if len({x["fit_id"] for x in m["fits"]})!=600:raise ValueError("duplicate fit id")
    if sha(RESULT/"data_freeze.json") is None:raise ValueError("missing data")
    data=json.loads((RESULT/"data_freeze.json").read_text())
    verify_seal(data)
    if m["data_manifest_sha256"]!=data["sha256"]:raise ValueError("data seal mismatch")
    return m
