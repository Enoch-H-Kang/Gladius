"""Post-evaluation rendering entry point. No pre-seal truth output is opened."""
from pathlib import Path


def render(results):
    root=Path(results)
    if not (root/"selections.json").exists():
        raise RuntimeError("WAIT_COMMON_FREEZE: render requires sealed selections and completed evaluation")
    raise NotImplementedError("post-freeze table and figure renderer requires completed evaluation")
