"""Detached scalar runner with flock admission ledger and 15-second /proc sampling."""
import csv
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from .protocol import load_manifest,ROOT,RESULT

CAP=44
OTHER_FLEET_MAX=38  # fleet tuning runner FIT_MAX=36 plus CTRL_RESERVATION=2


def proc_start(pid):
    try:return (Path("/proc")/str(pid)/"stat").read_text().split()[21]
    except OSError:return None


def project_processes():
    out=[]
    for p in Path("/proc").iterdir():
        if not p.name.isdigit():continue
        try:
            cmd=(p/"cmdline").read_bytes().replace(b"\0",b" ").decode(errors="replace")
            if "DDC-DPT" not in cmd and "experiments.fleet_" not in cmd:continue
            if "python" not in cmd:continue
            out.append((int(p.name),cmd))
        except (OSError,PermissionError):continue
    return out


def other_reservation():
    engineering=0
    oracle=False
    live=[]
    for pid,cmd in project_processes():
        if "bus_rerun.proofs.e5" in cmd or "bus_rerun.proofs.dev_smoke" in cmd or "bus_rerun.generate_data" in cmd:
            engineering+=1;live.append(dict(pid=pid,kind="engineering",tokens=1))
        if "run_oracle" in cmd or "validate_oracle" in cmd:
            oracle=True;live.append(dict(pid=pid,kind="oracle",tokens=44))
    return (44 if oracle else OTHER_FLEET_MAX)+engineering,live


def usage_snapshot():
    procs=[]
    for pid,cmd in project_processes():
        try:
            tasks=list((Path("/proc")/str(pid)/"task").iterdir())
            procs.append(dict(pid=pid,nlwp=len(tasks),cmd=cmd[:200]))
        except OSError:pass
    return procs


def run(manifest,ledger):
    m=load_manifest(manifest)
    required=json.loads((RESULT/"proofs/E1.json").read_text())
    audit=json.loads((RESULT/"audit/seed_collision.json").read_text())
    if not required["pass_"] or not audit["pass_"]:raise RuntimeError("required scalar admission checks failed")
    led=Path(ledger);led.mkdir(parents=True,exist_ok=True)
    lock=led/"admission.lock"
    roster=led/"reservations.json"
    usage=led/"usage_RR.csv"
    events=led/"events_RR.csv"
    fits=ROOT/"artifacts/bus_rerun/fits"
    slots=[s for s in m["fits"] if s["arm"] in ("NFXP-c","CCP-c","NFXP-2p")]
    pending=[s for s in slots if not (fits/s["fit_id"]/"record.json").exists()]
    running={}
    t0=time.time()
    with usage.open("a",newline="") as uf,events.open("a",newline="") as ef:
        uw=csv.writer(uf);ew=csv.writer(ef)
        if usage.stat().st_size==0:uw.writerow(["unix","controller","bus_workers","external_reserved","total_reserved","project_processes","sum_nlwp","pending"])
        if events.stat().st_size==0:ew.writerow(["unix","event","fit_id","pid","pid_start","total_reserved","detail"])
        ew.writerow([time.time(),"controller_start","",os.getpid(),proc_start(os.getpid()),1,""]);ef.flush()
        while pending or running:
            with lock.open("a+") as lf:
                fcntl.flock(lf,fcntl.LOCK_EX)
                for fid,(p,started,st) in list(running.items()):
                    rc=p.poll()
                    if rc is not None:
                        exists=(fits/fid/"record.json").exists()
                        ew.writerow([time.time(),"release",fid,p.pid,st,"",f"rc={rc};record={int(exists)}"])
                        del running[fid]
                ext,live=other_reservation()
                while pending and ext+1+len(running)+1<=CAP and len(running)<5:
                    spec=pending.pop(0)
                    fid=spec["fit_id"]
                    log=(led/(fid+".log")).open("a")
                    env=dict(os.environ,OMP_NUM_THREADS="1",MKL_NUM_THREADS="1",
                             OPENBLAS_NUM_THREADS="1",NUMEXPR_NUM_THREADS="1",
                             PYTHONHASHSEED="0",CUDA_VISIBLE_DEVICES="")
                    cmd=["nice","-n","10",sys.executable,"-m",
                         "experiments.fleet_capacity_one.bus_rerun.scalar_worker",str(manifest),fid]
                    p=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
                    st=proc_start(p.pid)
                    running[fid]=(p,time.time(),st)
                    ew.writerow([time.time(),"admit",fid,p.pid,st,ext+1+len(running),""])
                body=dict(unix=time.time(),controller=dict(pid=os.getpid(),start=proc_start(os.getpid()),tokens=1),
                          external_fixed_reservation=ext,external_live=live,
                          workers=[dict(fit_id=fid,pid=p.pid,pid_start=st,tokens=1) for fid,(p,_,st) in running.items()],
                          total_reserved=ext+1+len(running),cap=CAP)
                if body["total_reserved"]>CAP:raise RuntimeError("thread cap exceeded")
                tmp=roster.with_suffix(".json.tmp")
                tmp.write_text(json.dumps(body,indent=2)+"\n");os.replace(tmp,roster)
                ef.flush()
                fcntl.flock(lf,fcntl.LOCK_UN)
            procs=usage_snapshot()
            uw.writerow([time.time(),1,len(running),ext,ext+1+len(running),len(procs),
                         sum(p["nlwp"] for p in procs),len(pending)]);uf.flush()
            if pending or running:time.sleep(15)
        ew.writerow([time.time(),"controller_end","",os.getpid(),proc_start(os.getpid()),0,""]);ef.flush()
    records=[fits/s["fit_id"]/"record.json" for s in slots]
    statuses={}
    for path in records:
        if path.exists():
            rec=json.loads(path.read_text())
            statuses[rec["status"]]=statuses.get(rec["status"],0)+1
    result=dict(scheduled=360,terminal=sum(statuses.values()),missing=360-sum(statuses.values()),
                statuses=statuses,elapsed_wall=time.time()-t0,cap=CAP,external_fixed_max=OTHER_FLEET_MAX,
                controller_token=1,max_bus_workers=5,ledger=str(led))
    (led/"accounting_RR.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result),flush=True)


if __name__=="__main__":run(*sys.argv[1:3])
