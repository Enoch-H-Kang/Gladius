"""One immutable RR scalar slot; observations only, no truth or panel imports."""
import json
import os
from pathlib import Path
import resource
import sys
import time
import numpy as np
from ..tuning.data_io import load_bus
from .parametric import fit
from .protocol import load_manifest,sha,ROOT,DATA

def main(manifest,fit_id):
    m=load_manifest(manifest)
    spec=next(x for x in m["fits"] if x["fit_id"]==fit_id)
    if spec["arm"] not in ("NFXP-c","CCP-c","NFXP-2p"):raise ValueError("not a scalar slot")
    path=DATA/(spec["data_id"]+".npz")
    if sha(path)!=spec["export_sha256"]:raise ValueError("export hash mismatch")
    t0=time.time()
    data=load_bus(str(path),spec["n_chains"])
    rec=fit(spec["arm"],data["train"]["s"],data["train"]["a"])
    rec.update(fit_id=fit_id,n=spec["n"],r=spec["r"],init_index=0,data_id=spec["data_id"],
               n_train_chains=data["n_train_chains"],n_val_chains=data["n_val_chains"],
               n_train_rows=len(data["train"]["a"]),manifest_sha256=m["sha256"],
               export_sha256=spec["export_sha256"],code_hash=spec["code_hash"],
               start_unix=t0,end_unix=time.time(),pid=os.getpid(),
               rss_kb=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
               env_threads={k:os.environ.get(k) for k in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS","NUMEXPR_NUM_THREADS")})
    out=ROOT/"artifacts/bus_rerun/fits"/fit_id
    out.mkdir(parents=True,exist_ok=True)
    tmp=out/"record.json.tmp"
    tmp.write_text(json.dumps(rec,indent=2)+"\n")
    os.replace(tmp,out/"record.json")
    done=out/"DONE"
    done_tmp=out/"DONE.tmp"
    done_tmp.write_text(json.dumps(dict(fit_id=fit_id,status=rec["status"],record_sha256=sha(out/"record.json")))+"\n")
    os.replace(done_tmp,done)
    print(json.dumps(dict(fit_id=fit_id,status=rec["status"],elapsed=rec["elapsed_wall"])),flush=True)

if __name__=="__main__":main(*sys.argv[1:3])
