"""Run one sealed bus rerun GLADIUS slot in a fresh process."""
import json
import os
from pathlib import Path
import resource
import socket
import sys
import time
import traceback

from experiments.fleet_capacity_one.bus_rerun import protocol
from experiments.fleet_capacity_one.tuning.data_io import load_bus
from experiments.fleet_capacity_one.tuning.run_fit import code_hash


def atomic_json(path, value):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=True) + "\n")
    os.replace(tmp, path)


def main(manifest, fit_id):
    m = protocol.load_manifest(manifest)
    spec = next(s for s in m["fits"] if s["fit_id"] == fit_id)
    if spec["arm"] not in ("G-L", "G-A1"):
        raise ValueError("not a GLADIUS slot")
    lock = protocol.lock()
    if spec["lock_sha256"] != lock["sha256"] or spec["code_hash"] != code_hash():
        raise ValueError("lock or shared code mismatch")
    expected = dict(lock["design"])
    expected["N"] = 100 * spec["n"]
    if spec["arm"] == "G-A1":
        expected["k"] = 1
    if spec["config"] != expected or spec["horizons"] != [lock["policy"]["horizon"]]:
        raise ValueError("sealed configuration differs from lock")
    export = protocol.DATA / (spec["data_id"] + ".npz")
    if protocol.sha(export) != spec["export_sha256"]:
        raise ValueError("frozen export hash mismatch")
    out = protocol.ROOT / "artifacts/bus_rerun/fits" / fit_id
    out.mkdir(parents=True, exist_ok=True)
    if (out / "record.json").exists() or (out / "DONE").exists():
        raise RuntimeError("slot already terminal")
    started = time.time()
    base = dict(fit_id=fit_id, arm=spec["arm"], n=spec["n"], r=spec["r"],
                init_index=spec["init_index"], data_id=spec["data_id"],
                manifest_sha256=m["sha256"], data_manifest_sha256=m["data_manifest_sha256"],
                export_sha256=spec["export_sha256"], code_hash=spec["code_hash"],
                lock_sha256=spec["lock_sha256"], config_id=spec["config_id"],
                config=spec["config"], seeds=spec["seeds"], host=socket.gethostname(),
                pid=os.getpid(), start_unix=started,
                env_threads={k: os.environ.get(k) for k in
                             ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS")})
    try:
        from experiments.fleet_capacity_one.fleet.train import fit
        data = load_bus(str(export), spec["n_chains"])
        cfg = {k: v for k, v in spec["config"].items() if k != "N"}
        result = fit(data, cfg, spec["seeds"], horizons=spec["horizons"], ckpt_dir=str(out))
        choice = result["horizons"][spec["horizons"][-1]]
        status = {"failed_diverged": "nonfinite"}.get(choice["status"], choice["status"])
        rec = {**base, **result, "status": status, "native_status": choice["status"],
               "n_train_chains": data["n_train_chains"], "n_val_chains": data["n_val_chains"],
               "n_train_rows": len(data["train"]["a"])}
    except Exception as exc:
        traceback.print_exc()
        rec = {**base, "status": "resource_fail", "native_status": type(exc).__name__,
               "error": str(exc), "traceback": traceback.format_exc()}
    rec.update(end_unix=time.time(), elapsed_wall=time.time() - started,
               rss_kb=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    atomic_json(out / "record.json", rec)
    atomic_json(out / "DONE", dict(fit_id=fit_id, status=rec["status"],
                                   record_sha256=protocol.sha(out / "record.json")))
    print(json.dumps(dict(fit_id=fit_id, status=rec["status"],
                          elapsed_wall=rec["elapsed_wall"])), flush=True)


if __name__ == "__main__":
    main(*sys.argv[1:3])
