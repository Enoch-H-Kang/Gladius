"""Reconcile immutable scalar records, per-slot DONE markers and admission trace."""
import csv
import json
import os
from collections import Counter
from . import protocol


def audit():
    m=protocol.load_manifest(protocol.RESULT/"manifest_RR.json")
    root=protocol.ROOT/"artifacts/bus_rerun/fits"
    led=protocol.RESULT/"ledger"
    cells=Counter();statuses=Counter();missing=[];errors=[];done_backfilled=0
    scalars=[x for x in m["fits"] if x["arm"] in ("NFXP-c","CCP-c","NFXP-2p")]
    for spec in scalars:
        fid=spec["fit_id"]
        directory=root/fid
        path=directory/"record.json"
        if not path.exists():missing.append(fid);continue
        r=json.loads(path.read_text())
        for key,expected in (("fit_id",fid),("arm",spec["arm"]),("n",spec["n"]),("r",spec["r"]),
                             ("manifest_sha256",m["sha256"]),("export_sha256",spec["export_sha256"]),
                             ("code_hash",spec["code_hash"]),("n_train_rows",80*spec["n"])):
            if r.get(key)!=expected:errors.append("{}: {} mismatch".format(fid,key))
        if any(r.get("env_threads",{}).get(k)!="1" for k in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS","NUMEXPR_NUM_THREADS")):
            errors.append(fid+": thread environment")
        if r.get("status") not in ("ok","optimizer_fail","nonfinite","resource_fail"):
            errors.append(fid+": nonterminal status")
        digest=protocol.sha(path)
        done=directory/"DONE"
        if not done.exists():
            temp=directory/"DONE.audit.tmp"
            temp.write_text(json.dumps(dict(fit_id=fid,status=r["status"],record_sha256=digest,backfilled_from_record=True))+"\n")
            os.replace(temp,done)
            done_backfilled+=1
        d=json.loads(done.read_text())
        if d.get("fit_id")!=fid or d.get("status")!=r["status"] or d.get("record_sha256")!=digest:
            errors.append(fid+": DONE mismatch")
        if not (led/(fid+".log")).exists():errors.append(fid+": log missing")
        cells[(spec["arm"],spec["n"],r["status"])]+=1
        statuses[(spec["arm"],r["status"])]+=1
    other=[str(p) for p in root.glob("RR_G_*/record.json")]
    if other:errors.append("GLADIUS records exist")
    usage=list(csv.DictReader((led/"usage_RR.csv").open()))
    events=list(csv.DictReader((led/"events_RR.csv").open()))
    admitted=Counter(x["fit_id"] for x in events if x["event"]=="admit")
    released=Counter(x["fit_id"] for x in events if x["event"]=="release")
    for spec in scalars:
        fid=spec["fit_id"]
        if admitted[fid]!=1 or released[fid]!=1:errors.append(fid+": admission/release count")
    max_reserved=max(int(x["total_reserved"]) for x in usage)
    max_nlwp=max(int(x["sum_nlwp"]) for x in usage)
    trace_duration=float(usage[-1]["unix"])-float(usage[0]["unix"])
    if max_reserved>44 or trace_duration<300:errors.append("resource trace failed")
    result=dict(pass_=not missing and not errors,scheduled=360,records=360-len(missing),missing=missing,errors=errors,
                statuses={"{}:{}".format(*k):v for k,v in sorted(statuses.items())},
                cells={"{}:n{}:{}".format(*k):v for k,v in sorted(cells.items())},
                done_backfilled=done_backfilled,admissions=sum(admitted.values()),releases=sum(released.values()),
                usage_samples=len(usage),trace_seconds=trace_duration,max_reserved=max_reserved,max_project_nlwp=max_nlwp,
                no_gladius_records=not other)
    path=protocol.RESULT/"audit/scalar_fits.json"
    path.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result))
    if not result["pass_"]:raise SystemExit(1)

if __name__=="__main__":audit()
