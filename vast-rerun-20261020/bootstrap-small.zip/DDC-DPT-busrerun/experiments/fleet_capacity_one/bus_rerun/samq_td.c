#include <math.h>
#include <stddef.h>

static inline double lse(double x, double y) {
    double m = x > y ? x : y;
    return m + log1p(exp(-fabs(x-y)));
}

void samq_td(int n, int k, int steps, double alpha, double beta,
             double b, double theta, const int *state, const int *action,
             const int *next, const double *mileage, double *q) {
    for (int i=0; i<2*k; ++i) q[i] = 1.0;
    for (int t=0; t<steps; ++t) {
        for (int i=0; i<n; ++i) {
            int s=state[i], a=action[i], sn=next[i];
            double reward = a == 0 ? 0.0 : b-theta*mileage[i];
            double v = lse(q[2*sn], q[2*sn+1]);
            int j=2*s+a;
            q[j] += alpha*(reward + beta*v - q[j]);
        }
    }
}

double samq_nll(int n, const int *state, const int *action, const double *q) {
    double out=0.0;
    for (int i=0; i<n; ++i) {
        int j=2*state[i];
        out += lse(q[j],q[j+1]) - q[j+action[i]];
    }
    return out/n;
}
