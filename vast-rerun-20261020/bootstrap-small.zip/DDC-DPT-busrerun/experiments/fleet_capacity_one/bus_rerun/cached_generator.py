"""Audited generator with immutable, keyed VI tables; no changes to its RNG calls."""
import hashlib
import json
import random
import threading
import numpy as np
from ..tuning import bus_data

_LOCK = threading.RLock()
_CACHE = {}
_SOLVES = 0


def key(env, tol=1e-8, source=None, transition="equiprobable_1_2_3_4_cap_replace_1",
        update="review_vfi_l2_Q_change_ordered", dtype="float64"):
    body = dict(source=source or bus_data.generator_sha(), beta=env.beta, theta=list(env.theta),
                type=int(env.type), xmax=int(env.xmax), states=env.states.tolist(),
                transition=transition, tol=tol,
                update=update, dtype=dtype, numpy=np.__version__)
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _module():
    mod = bus_data._gen_module()
    original = mod.ZurcherEnv.calculate_EP_Q
    def cached(self):
        global _SOLVES
        k = key(self)
        with _LOCK:
            if k not in _CACHE:
                tabs = original(self)
                for tab in tabs:
                    tab.flags.writeable = False
                _CACHE[k] = tabs
                _SOLVES += 1
            return _CACHE[k]
    mod.ZurcherEnv.calculate_EP_Q = cached
    return mod


def clear():
    global _SOLVES
    with _LOCK:
        _CACHE.clear()
        _SOLVES = 0


def stats():
    with _LOCK:
        return dict(keys=len(_CACHE), solves=_SOLVES)


def generate(seed, n_chains, split=True):
    """Replicate generate_pool's 80/20 sequential calls, or one unsplit panel."""
    mod = _module()
    np.random.seed(seed)
    random.seed(seed)
    cfg = bus_data.GEN_CONFIG
    if split:
        ntr = int(.8 * n_chains)
        tr = mod.generate_Zurcher_histories({**cfg, "num_trajs": ntr})
        va = mod.generate_Zurcher_histories({**cfg, "num_trajs": n_chains-ntr})
        return tr, va
    return mod.generate_Zurcher_histories({**cfg, "num_trajs": n_chains})
