"""Build the bus rerun's final outputs from sealed, terminal fit artifacts.

Run from the baker bus-rerun checkout with the gym Python environment. This
module reads records, selected checkpoints, and frozen observations; it never
calls an estimator or changes a scientific fit.
"""
import csv
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import torch
from scipy.special import logsumexp
from scipy.stats import spearmanr, t

from experiments.fleet_capacity_one.bus_rerun import parametric, protocol
from experiments.fleet_capacity_one.fleet.models import MLP


OUT = protocol.RESULT
FIT_ROOT = protocol.ROOT / "artifacts/bus_rerun/fits"
ARMS = protocol.ARMS
SIZES = protocol.SIZES
STATES = np.arange(1, 11)
FAILED = {"anchor_fail", "optimizer_fail", "nonfinite", "resource_fail", "unassessable"}


def csv_out(name, rows, fields):
    with (OUT / name).open("w", newline="") as f:
        w = csv.DictWriter(f, fields, extrasaction="ignore", lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def mean_sd_se(values):
    x = np.asarray([v for v in values if v is not None and np.isfinite(v)], dtype=float)
    if not len(x):
        return None, None, None, 0
    sd = float(np.std(x, ddof=1)) if len(x) > 1 else None
    return float(np.mean(x)), sd, sd / math.sqrt(len(x)) if sd is not None else None, len(x)


def truth_and_weights():
    truth = parametric.solve(1.0, 5.0)
    q, pi = truth["q"], truth["pi"]
    m = pi[:, 0, None] * parametric.P0 + pi[:, 1, None] * parametric.P1
    d = np.zeros(10)
    d[0] = 1.0
    w = np.zeros((10, 2))
    for _ in range(100):
        w += d[:, None] * pi / 100
        d = d @ m
    assert np.all(w >= 0) and abs(w.sum() - 1) < 1e-12
    return np.column_stack((-STATES, np.full(10, -5))), q, pi, w


def data_counts():
    out = {}
    for seed in range(11000, 11020):
        path = protocol.DATA / f"bus_seed{seed}.npz"
        with np.load(path, allow_pickle=False) as z:
            s, a, isv = z["s"], z["a"], z["is_val"]
        for n in SIZES:
            train = ~isv[:n]
            val = isv[:n]
            if int(train.sum()) != 4 * n // 5 or int(val.sum()) != n // 5:
                raise ValueError(f"split count seed={seed}, n={n}")
            counts = {}
            for label, mask in (("train", train), ("validation", val)):
                states = s[:n][mask].reshape(-1)
                actions = a[:n][mask].reshape(-1)
                c = np.zeros((10, 2), dtype=np.int64)
                np.add.at(c, (states - 1, actions), 1)
                counts[label] = c
            out[(seed, n)] = counts
    panel = protocol.ROOT / "artifacts/bus_rerun/panel/bus_seed11999.npz"
    with np.load(panel, allow_pickle=False) as z:
        s, a = z["s"].reshape(-1), z["a"].reshape(-1)
    c = np.zeros((10, 2), dtype=np.int64)
    np.add.at(c, (s - 1, a), 1)
    if int(c.sum()) != 200000:
        raise ValueError("independent panel row count")
    return out, c


def predictions(rec, spec, fit_dir):
    arm = spec["arm"]
    if arm.startswith("G-"):
        selected = rec.get("horizons", {}).get("50000", {})
        ckpt_path = fit_dir / "ckpt_h50000.pt"
        if not ckpt_path.exists():
            raise FileNotFoundError(ckpt_path)
        ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
        if ckpt.get("hash") != selected.get("hash") or ckpt.get("step") != selected.get("step"):
            raise ValueError(f"selected checkpoint mismatch: {spec['fit_id']}")
        cfg = spec["config"]
        qnet = MLP(1, 2, width=cfg["width"], depth=cfg["depth"])
        znet = MLP(1, 2, width=cfg["width"], depth=cfg["depth"])
        qnet.load_state_dict(ckpt["q"])
        znet.load_state_dict(ckpt["z"])
        with torch.no_grad():
            x = torch.tensor((STATES / 10)[:, None], dtype=torch.float32)
            q = qnet(x).numpy().astype(float)
            z = znet(x).numpy().astype(float)
        return q - 0.95 * z, q, selected, protocol.sha(ckpt_path)
    rc = rec["RC_hat"] if arm == "NFXP-2p" else 5.0
    c = rec["c_hat"]
    if c is None or rc is None or not np.isfinite(c) or not np.isfinite(rc):
        raise ValueError(f"missing scalar estimate: {spec['fit_id']}")
    solved = parametric.solve(c, rc)
    rhat = np.column_stack((-c * STATES, np.full(10, -rc)))
    return rhat, solved["q"], {}, None


def scores(rhat, qhat, rtrue, qtrue, ptrue, w, train, val, panel):
    err = rhat - rtrue
    w0, w1 = w[:, 0] / w[:, 0].sum(), w[:, 1] / w[:, 1].sum()
    logpi = qhat - logsumexp(qhat, axis=1)[:, None]
    pi = np.exp(logpi)
    keep = float(100 * np.sum(w0 * np.abs(err[:, 0]) / STATES))
    repl = float(100 * np.sum(w1 * np.abs(err[:, 1]) / 5))
    result = dict(keep_mape=keep, replace_mape=repl,
                  pooled_mape=float(w[:, 0].sum() * keep + w[:, 1].sum() * repl),
                  keep_mae=float(np.sum(w0 * np.abs(err[:, 0]))),
                  keep_rmse=float(np.sqrt(np.sum(w0 * err[:, 0] ** 2))),
                  replace_rmse=float(np.sqrt(np.sum(w1 * err[:, 1] ** 2))),
                  q_rmse=float(np.sqrt(np.sum(w * (qhat - qtrue) ** 2))),
                  policy_kl=float(np.sum(w * (np.log(ptrue) - logpi))),
                  uniform_keep_mape=float(10 * np.sum(np.abs(err[:, 0]) / STATES)),
                  tail_keep_mae=float(np.mean(np.abs(err[5:, 0]))))
    for label, cnt in (("validation", val), ("panel", panel)):
        n0, n1 = cnt[:, 0].sum(), cnt[:, 1].sum()
        result[label + "_keep_mape"] = float(100 * np.sum(cnt[:, 0] * np.abs(err[:, 0]) / STATES) / n0) if n0 else None
        result[label + "_replace_mape"] = float(100 * np.sum(cnt[:, 1] * np.abs(err[:, 1]) / 5) / n1) if n1 else None
        result[label + "_pooled_mape"] = float(100 * np.sum(cnt * np.abs(err) / np.abs(rtrue)) / cnt.sum())
        result[label + "_nll"] = float(-np.sum(cnt * logpi) / cnt.sum())
        result[label + "_top1"] = float(np.sum(cnt[np.arange(10), np.argmax(pi, axis=1)]) / cnt.sum())
    return result


def preseal_without_truth(manifest, data):
    """Make the observable selection seal before importing any headline truth."""
    selections = []
    for spec in manifest["fits"]:
        fid = spec["fit_id"]
        fit_dir = FIT_ROOT / fid
        rec_path = fit_dir / "record.json"
        try:
            rec = json.loads(rec_path.read_text())
            done = json.loads((fit_dir / "DONE").read_text())
            if done.get("fit_id") != fid or done.get("record_sha256") != protocol.sha(rec_path):
                raise ValueError("DONE/record hash mismatch")
            for key in ("fit_id", "arm", "n", "r", "export_sha256", "code_hash"):
                if rec.get(key) != spec.get(key):
                    raise ValueError(f"record {key} mismatch")
            if rec.get("manifest_sha256") != manifest["sha256"]:
                raise ValueError("manifest seal mismatch")
            if spec["arm"] in ("NFXP-c", "CCP-c", "NFXP-2p"):
                expected_counts = data[(11000 + spec["r"], spec["n"])]["train"].tolist()
                if rec.get("training_counts") != expected_counts:
                    raise ValueError("fit training counts differ from frozen export")
            status = rec["status"]
            if status not in FAILED | {"ok"}:
                raise ValueError("nonterminal or unknown fit status")
            selected, ckpt_sha = {}, None
            if status in ("ok", "anchor_fail"):
                rhat, qhat, selected, ckpt_sha = predictions(rec, spec, fit_dir)
                if not np.isfinite(rhat).all() or not np.isfinite(qhat).all():
                    raise ValueError("nonfinite prediction")
            selections.append(dict(fit_id=fid, arm=spec["arm"], n=spec["n"], r=spec["r"],
                                   status=status, record_sha256=protocol.sha(rec_path),
                                   checkpoint_sha256=ckpt_sha, selected_step=selected.get("step"),
                                   selected_hash=selected.get("hash"), c_hat=rec.get("c_hat"),
                                   RC_hat=rec.get("RC_hat")))
        except Exception:
            selections.append(dict(fit_id=fid, arm=spec["arm"], n=spec["n"], r=spec["r"],
                                   status="missing_or_unreadable", record_sha256=protocol.sha(rec_path) if rec_path.exists() else None,
                                   checkpoint_sha256=None, selected_step=None, selected_hash=None,
                                   c_hat=None, RC_hat=None))
    sealed = protocol.seal(dict(manifest_sha256=manifest["sha256"], n_slots=600, selections=selections))
    (OUT / "selections.json").write_text(json.dumps(sealed, indent=2, allow_nan=False)+"\n")
    return sealed


def main():
    manifest = protocol.load_manifest(OUT / "manifest_RR.json")
    if not (protocol.ROOT / "artifacts/bus_rerun/logs/gladius_runner.DONE").exists():
        raise ValueError("GLADIUS terminal marker absent")
    data, panel = data_counts()
    presealed = preseal_without_truth(manifest, data)
    rtrue, qtrue, ptrue, w = truth_and_weights()
    rec_rows, state_rows, metric_rows, occ_rows, selections, issues = [], [], [], [], [], []
    by_fit = {}
    for spec in manifest["fits"]:
        fid, arm, n, r = spec["fit_id"], spec["arm"], spec["n"], spec["r"]
        fit_dir = FIT_ROOT / fid
        rec_path, done_path = fit_dir / "record.json", fit_dir / "DONE"
        rec = None
        try:
            rec = json.loads(rec_path.read_text())
            done = json.loads(done_path.read_text())
            if done.get("fit_id") != fid or done.get("record_sha256") != protocol.sha(rec_path):
                raise ValueError("DONE/record hash mismatch")
            for key in ("fit_id", "arm", "n", "r", "export_sha256", "code_hash"):
                if rec.get(key) != spec.get(key):
                    raise ValueError(f"record {key} mismatch")
            if rec.get("manifest_sha256") != manifest["sha256"]:
                raise ValueError("manifest seal mismatch")
            if rec.get("status") not in FAILED | {"ok"}:
                raise ValueError("nonterminal or unknown fit status")
        except Exception as exc:
            issues.append({"fit_id": fid, "stage": "record", "error": str(exc)})
            rec = None
        status = rec.get("status", "missing_or_unreadable") if rec else "missing_or_unreadable"
        c = data[(11000 + r, n)]
        train, val = c["train"], c["validation"]
        if rec and arm in ("NFXP-c", "CCP-c", "NFXP-2p") and rec.get("training_counts") != train.tolist():
            issues.append({"fit_id": fid, "stage": "support", "error": "fit training counts differ from frozen export"})
            status = "missing_or_unreadable"
        selected, ckpt_sha, rhat, qhat = {}, None, None, None
        if rec and status in ("ok", "anchor_fail"):
            try:
                rhat, qhat, selected, ckpt_sha = predictions(rec, spec, fit_dir)
                if not (np.isfinite(rhat).all() and np.isfinite(qhat).all()):
                    raise ValueError("nonfinite prediction")
            except Exception as exc:
                issues.append({"fit_id": fid, "stage": "prediction", "error": str(exc)})
                status = "missing_or_unreadable"
        score = scores(rhat, qhat, rtrue, qtrue, ptrue, w, train, val, panel) if rhat is not None and status in ("ok", "anchor_fail") else {}
        base = dict(fit_id=fid, arm=arm, n=n, r=r, data_seed=11000+r, status=status,
                    record_sha256=protocol.sha(rec_path) if rec_path.exists() else None,
                    checkpoint_sha256=ckpt_sha, selected_step=selected.get("step"),
                    selected_hash=selected.get("hash"), selected_nll=selected.get("nll"),
                    selected_anchor_rmse=selected.get("anchor_rmse"),
                    c_hat=rec.get("c_hat") if rec and status != "missing_or_unreadable" else None,
                    RC_hat=rec.get("RC_hat") if rec and status != "missing_or_unreadable" else None,
                    elapsed_wall=rec.get("elapsed_wall") if rec else None)
        row = {**base, **score}
        metric_rows.append(row)
        by_fit[(arm, n, r)] = row
        selections.append({k: base[k] for k in ("fit_id", "arm", "n", "r", "status", "record_sha256", "checkpoint_sha256", "selected_step", "selected_hash", "c_hat", "RC_hat")})
        for i, s in enumerate(STATES):
            visits = int(train[i].sum())
            err_keep = float(rhat[i, 0] - rtrue[i, 0]) if rhat is not None else None
            for a in (0, 1):
                err = float(rhat[i, a] - rtrue[i, a]) if rhat is not None else None
                state_rows.append(dict(fit_id=fid, arm=arm, n=n, r=r, status=status, s=int(s), a=a,
                                       r_true=float(rtrue[i, a]), q_true=float(qtrue[i, a]),
                                       r_hat=float(rhat[i, a]) if rhat is not None else None,
                                       q_hat=float(qhat[i, a]) if qhat is not None else None,
                                       signed_error=err, abs_error=abs(err) if err is not None else None,
                                       squared_error=err * err if err is not None else None,
                                       pct_error=100 * abs(err) / abs(rtrue[i, a]) if err is not None else None,
                                       n_train_state=visits, f_train_state=visits / (80*n),
                                       n_train_action=int(train[i, a]), n_validation_action=int(val[i, a]),
                                       expert_weight=float(w[i, a])))
            occ_rows.append(dict(fit_id=fid, arm=arm, n=n, r=r, status=status, s=int(s),
                                 n_train_state=visits, f_train_state=visits / (80*n),
                                 n_train_keep=int(train[i, 0]), n_validation_state=int(val[i].sum()),
                                 n_validation_keep=int(val[i, 0]), signed_keep_error=err_keep,
                                 abs_keep_error=abs(err_keep) if err_keep is not None else None,
                                 squared_keep_error=err_keep**2 if err_keep is not None else None,
                                 pct_keep_error=100*abs(err_keep)/s if err_keep is not None else None,
                                 bin="0" if visits == 0 else "1-9" if visits < 10 else "10-99" if visits < 100 else ">=100"))
    if len(selections) != 600 or len(state_rows) != 12000:
        raise ValueError("output slot/row count")
    sealed = protocol.seal(dict(manifest_sha256=manifest["sha256"], n_slots=600, selections=selections))
    if sealed["sha256"] != presealed["sha256"]:
        raise ValueError("post-scoring selection audit differs from pre-scoring seal; inspect record_issues.json")
    (OUT / "record_issues.json").write_text(json.dumps(issues, indent=2)+"\n")
    csv_out("fit_metrics_final.csv", metric_rows, list(metric_rows[0]))
    csv_out("state_action_predictions.csv", state_rows, list(state_rows[0]))
    csv_out("occupancy_error.csv", occ_rows, list(occ_rows[0]))
    make_summaries(metric_rows, state_rows, occ_rows, by_fit, issues, manifest, panel, w)


def make_summaries(metrics, states, occ, by_fit, issues, manifest, panel, w):
    table2, fallback, paired = [], [], []
    for arm in ARMS:
        for n in SIZES:
            cell = [by_fit[(arm, n, r)] for r in range(20)]
            status = Counter(x["status"] for x in cell)
            valid = [x for x in cell if x["status"] == "ok"]
            row = dict(arm=arm, n=n, scheduled=20, ok=len(valid), failed=20-len(valid),
                       anchor_fail=status["anchor_fail"], optimizer_fail=status["optimizer_fail"],
                       nonfinite=status["nonfinite"], resource_fail=status["resource_fail"],
                       unreadable=20-sum(status[k] for k in FAILED | {"ok"}),
                       information_set="oracle true form and transitions" if arm in ("NFXP-c", "CCP-c") else
                                       "linear form and transitions, RC estimated" if arm == "NFXP-2p" else "anchor only")
            for field in ("keep_mape", "replace_mape", "pooled_mape", "keep_mae", "keep_rmse", "replace_rmse", "q_rmse", "policy_kl", "validation_keep_mape", "validation_pooled_mape", "panel_keep_mape", "panel_pooled_mape", "validation_nll", "panel_nll"):
                mean, sd, se, count = mean_sd_se([x.get(field) for x in valid])
                row[field+"_mean"], row[field+"_sd"], row[field+"_se"] = mean, sd, se
            row["replace_reward_given"] = arm in ("NFXP-c", "CCP-c")
            table2.append(row)
            incl = [x for x in cell if x["status"] in ("ok", "anchor_fail") and x.get("keep_mape") is not None]
            mu, sd, se, _ = mean_sd_se([x["keep_mape"] for x in incl])
            fallback.append(dict(arm=arm, n=n, n_finite=len(incl), keep_mape_mean=mu, keep_mape_sd=sd, keep_mape_se=se,
                                 anchor_fail_included=sum(x["status"] == "anchor_fail" for x in incl)))
    for n in SIZES:
        for other in ("NFXP-c", "CCP-c", "G-A1"):
            diff = [by_fit[("G-L", n, r)]["keep_mape"] - by_fit[(other, n, r)]["keep_mape"]
                    for r in range(20) if by_fit[("G-L", n, r)]["status"] == "ok" and
                    by_fit[(other, n, r)]["status"] == "ok"]
            mu, sd, se, num = mean_sd_se(diff)
            half = float(t.ppf(.975, num-1) * se) if num > 1 else None
            paired.append(dict(n=n, comparison=f"G-L minus {other}", n_pair=num, scheduled_pairs=20,
                               mean=mu, ci95_low=mu-half if half is not None else None,
                               ci95_high=mu+half if half is not None else None))
    csv_out("table2.csv", table2, list(table2[0]))
    csv_out("table2_fallback_diagnostic.csv", fallback, list(fallback[0]))
    csv_out("table2_paired.csv", paired, list(paired[0]))

    table3, a1 = [], []
    for arm in ARMS:
        for s in STATES:
            x = [z for z in states if z["arm"] == arm and z["n"] == 1000 and z["s"] == s and z["a"] == 0]
            good = [z for z in x if z["status"] == "ok"]
            mu, sd, se, _ = mean_sd_se([z["r_hat"] for z in good])
            table3.append(dict(arm=arm, n=1000, s=int(s), r_true=-int(s), r_hat_mean=mu, r_hat_sd=sd,
                               r_hat_se=se, n_ok=len(good), scheduled=20,
                               train_state_count_mean=float(np.mean([z["n_train_state"] for z in x])),
                               train_keep_count_mean=float(np.mean([z["n_train_action"] for z in x])),
                               validation_keep_count_mean=float(np.mean([z["n_validation_action"] for z in x])),
                               train_keep_count_r0=x[0]["n_train_action"] if x else None))
        for s in STATES:
            for a in (0, 1):
                x = [z for z in states if z["arm"] == arm and z["n"] == 50 and z["s"] == s and z["a"] == a]
                good = [z for z in x if z["status"] == "ok"]
                row = dict(arm=arm, n=50, s=int(s), a=a, r_true=float(x[0]["r_true"]), q_true=float(x[0]["q_true"]), n_ok=len(good), scheduled=20)
                for field in ("r_hat", "q_hat", "signed_error", "abs_error"):
                    mu, sd, se, _ = mean_sd_se([z[field] for z in good])
                    row[field+"_mean"], row[field+"_sd"], row[field+"_se"] = mu, sd, se
                    if field in ("signed_error", "abs_error"):
                        half = float(t.ppf(.975, len(good)-1) * se) if len(good) > 1 else None
                        row[field+"_ci95_low"] = mu-half if half is not None else None
                        row[field+"_ci95_high"] = mu+half if half is not None else None
                a1.append(row)
    csv_out("table3.csv", table3, list(table3[0]))
    csv_out("figure_A1_inputs.csv", a1, list(a1[0]))

    bins = ("0", "1-9", "10-99", ">=100")
    occfit, occsum, rho_rows = [], [], []
    for arm in ARMS:
        for n in SIZES:
            for r in range(20):
                x = [z for z in occ if z["arm"] == arm and z["n"] == n and z["r"] == r]
                assert len(x) == 10 and sum(z["n_train_state"] for z in x) == 80*n
                status = x[0]["status"]
                for b in bins:
                    xb = [z for z in x if z["bin"] == b]
                    good = [z for z in xb if z["abs_keep_error"] is not None]
                    occfit.append(dict(arm=arm, n=n, r=r, status=status, bin=b, n_states=len(xb),
                                       visits=sum(z["n_train_state"] for z in xb),
                                       mean_abs_keep_error=float(np.mean([z["abs_keep_error"] for z in good])) if good else None))
                rho = None
                if status == "ok" and len({z["n_train_state"] for z in x}) > 1 and len({z["abs_keep_error"] for z in x}) > 1:
                    rho = float(spearmanr([math.log1p(z["n_train_state"]) for z in x], [z["abs_keep_error"] for z in x]).statistic)
                rho_rows.append(dict(arm=arm, n=n, r=r, status=status, spearman_rho=rho))
            for b in bins:
                x = [z for z in occfit if z["arm"] == arm and z["n"] == n and z["bin"] == b and z["status"] == "ok" and z["n_states"] > 0]
                mu, sd, se, _ = mean_sd_se([z["mean_abs_keep_error"] for z in x])
                occsum.append(dict(arm=arm, n=n, bin=b, n_contributing_fits=len(x), scheduled=20,
                                   mean_abs_keep_error=mu, sd_abs_keep_error=sd, se_abs_keep_error=se,
                                   mean_states_per_fit=float(np.mean([z["n_states"] for z in x])) if x else None,
                                   mean_visits_per_fit=float(np.mean([z["visits"] for z in x])) if x else None))
    csv_out("occupancy_fit_bins.csv", occfit, list(occfit[0]))
    csv_out("occupancy_summary.csv", occsum, list(occsum[0]))
    csv_out("occupancy_spearman.csv", rho_rows, list(rho_rows[0]))

    lines = ["# Matched bus rerun results", "", "Primary numbers are analytic expert occupancy weighted keep-action reward MAPE (%), conditional on eligible (`ok`) fits. Each cell reports mean ± SE and eligible count out of 20 independent datasets. Replacement reward errors are separate in `table2.csv`; NFXP-c and CCP-c receive the replacement reward and have zero error by construction.", "", "| Trajectories | GLADIUS k=10 | NFXP-c | CCP-c | GLADIUS k=1 reference |", "|---:|---:|---:|---:|---:|"]
    lookup = {(z["arm"], z["n"]): z for z in table2}
    for n in SIZES:
        vals = []
        for arm in ("G-L", "NFXP-c", "CCP-c", "G-A1"):
            z = lookup[(arm, n)]
            vals.append(f"{z['keep_mape_mean']:.3f} ± {z['keep_mape_se']:.3f} ({z['ok']}/20)" if z["keep_mape_mean"] is not None else f"NA ({z['ok']}/20)")
        lines.append(f"| {n} | " + " | ".join(vals) + " |")
    low50 = next(z for z in occsum if z["arm"] == "G-L" and z["n"] == 50 and z["bin"] == "1-9")
    high50 = next(z for z in occsum if z["arm"] == "G-L" and z["n"] == 50 and z["bin"] == ">=100")
    lines += ["", "## Occupancy diagnostic", "", f"At n=50, locked GLADIUS's mean absolute keep-reward error was {low50['mean_abs_keep_error']:.3f} in states visited 1–9 times (18 eligible fits with such states), versus {high50['mean_abs_keep_error']:.3f} in states visited at least 100 times (19 fits). The full per-state counts, predeclared count bins, and per-fit Spearman correlations are in the occupancy CSVs. This is an association, not a causal test.", "", "## Scope and provenance", "", f"All {len(manifest['fits'])} planned fit slots are retained; record/prediction issues: {len(issues)} (listed in `record_issues.json`). `anchor_fail` and optimizer failures are excluded from the headline means, and GLADIUS fallback checkpoint errors appear only in `table2_fallback_diagnostic.csv`. Paired comparisons use only common eligible seeds (`table2_paired.csv`). The independent seed-11999 panel has {int(panel.sum()):,} transitions and supplies corroboration columns, not fits.", "", "NFXP-c and CCP-c know the correct linear reward family and exact transitions. NFXP-2p estimates the replacement cost and appears as an appendix diagnostic. SAmQ, IQ-learn and BC were omitted under the converged scope because the historical setups were unmatched or unverified. The 20 pools reproduce the DGP and matched split protocol; the unavailable historical files are not claimed to be byte-identical. GLADIUS k=1 is the signed 1:1 reference at the locked AdamW optimizer and rates, not a literal paper pseudocode implementation.", "", "The GLADIUS launch was explicitly author-directed while the joint common-design freeze remained unavailable, so these are exploratory rerun results rather than a certified common-protocol headline. The lock remains the verified BL record, with k=10 versus k=1 as recorded in the sealed manifest.", ""]
    (OUT / "RESULTS.md").write_text("\n".join(lines))
    status_counts = Counter(z["status"] for z in metrics)
    freeze = json.loads((OUT / "data_freeze.json").read_text())
    lock = json.loads((OUT / "lock_ref.json").read_text())
    seal = json.loads((OUT / "selections.json").read_text())
    lines = ["# Matched bus rerun — final run report", "", "## Completion and provenance", "", f"All **600/600** planned scientific fits are terminal: 240 GLADIUS and 360 scalar. Final statuses: **{status_counts['ok']} ok, {status_counts['anchor_fail']} anchor_fail, {status_counts['optimizer_fail']} optimizer_fail**. Missing/unreadable records or predictions: **{len(issues)}**; see `record_issues.json`. Failed slots were retained and excluded from eligible-only headline means. No fit was rerun for reporting.", "", f"Fit manifest self-seal `{manifest['sha256']}`; data-freeze self-seal `{freeze['sha256']}`; BL lock self-seal `{lock['sha256']}`; observable selection self-seal `{seal['sha256']}`. The selection seal was written before headline truth was opened. Every record/DONE hash, fit identity, manifest seal and selected GLADIUS checkpoint step/hash was checked while rebuilding.", "", "Twenty frozen 5,000-chain pools at cap 10 supplied nested matched train/validation prefixes. The seed-11999 independent panel contains 200,000 transitions and was used only for post-fit corroboration. The original historical Table 2 files were unavailable; these are regenerated DGP-matched data, not byte-identical historical samples.", "", "## Fit status by arm and sample size", "", "| Arm | n | ok | anchor_fail | optimizer_fail | other |", "|---|---:|---:|---:|---:|---:|"]
    for z in table2:
        other = z["failed"] - z["anchor_fail"] - z["optimizer_fail"]
        lines.append(f"| {z['arm']} | {z['n']} | {z['ok']}/20 | {z['anchor_fail']} | {z['optimizer_fail']} | {other} |")
    lines += ["", "## Evaluation and output checks", "", "Table 2's primary estimand is analytic H=100 expert-occupancy weighted keep-action reward MAPE, conditional on eligible fits; replacement reward error has its own columns. Validation-distribution and independent-panel MAPE, policy NLL and structural metrics are secondary columns. The known replacement reward in NFXP-c/CCP-c is explicitly flagged. `table2_paired.csv` uses only seeds eligible in both compared arms, with t intervals; `table2_fallback_diagnostic.csv` includes finite `anchor_fail` checkpoints as a separate diagnostic.", "", "Table 3 uses only n=1000, all ten mileages and all five arms. Figure A1 inputs use only n=50, both actions and all ten mileages, with means, SDs, SEs and 95% t bands; raw per-fit values remain in `state_action_predictions.csv`. The occupancy diagnostic uses state visits across both actions as its primary support measure, with keep counts alongside it. Bins are 0, 1–9, 10–99 and ≥100; empty bins remain empty. All 600 fit slots and 12,000 state/action rows are represented, with unavailable predictions blank for failed fits.", "", "## Proofs and resource record", "", "Existing audited E1–E5 proofs are recorded in `proofs/`: cached generation byte equivalence, plotting and anomaly replay, combined production replay, and exact BL lock replay all passed. The four scalar package tests passed in the earlier stage. The GLADIUS runner's terminal accounting is in `ledger/gladius_accounting.json`: 240 scheduled/terminal, 40-worker maximum, 44-token cap, and 5,099.8 seconds elapsed. The runner began with five workers and was author-approved for a 40-worker pool while no other project fit was live; admissions were reconciled against the original ledger.", "", "## Interpretation and deviations", "", "NFXP-c and corrected CCP-c have the true linear reward family and exact transition kernel, while GLADIUS has only the replacement anchor. NFXP-2p is an appendix diagnostic with a different anchor information set. SAmQ, IQ-learn and BC were omitted under the converged scope because their historical setups were unmatched or unverified. The k=1 arm is a signed 1:1 reference at the locked AdamW optimizer and rates, not a literal reproduction of the paper's gradient-step pseudocode.", "", "The joint common-design freeze artifact was unavailable. The author explicitly directed the GLADIUS launch against the existing BL lock; the resulting comparison is **exploratory**, not a certified common-protocol headline. This is the principal protocol deviation. Prior engineering limitations remain documented in `protocol_changes.md`: E2/E3 width-50 fixtures used the lock-bound trainer at the legacy architecture size rather than the old loop itself; the scalar wrapper's exit marker was reconciled with 360 valid terminal records; and the earlier controller resize used ledger validation without scientific reruns. No DGP constant, tolerance, fit seed, checkpoint rule or error-based rescue was changed.", "", "## Rebuild", "", "Run `~/miniconda3/envs/gym/bin/python -m experiments.fleet_capacity_one.bus_rerun.finalize` in this checkout. It reads sealed artifacts and frozen data and launches no fits. Outputs: `RESULTS.md`, `table2.csv`, `table2_paired.csv`, `table2_fallback_diagnostic.csv`, `table3.csv`, `figure_A1_inputs.csv`, `fit_metrics_final.csv`, `state_action_predictions.csv`, `occupancy_error.csv`, `occupancy_fit_bins.csv`, `occupancy_summary.csv`, `occupancy_spearman.csv`, `selections.json`, and `record_issues.json`.", ""]
    (OUT / "RUN_REPORT.md").write_text("\n".join(lines))
    print(json.dumps({"statuses": dict(status_counts), "issues": issues, "table2": [{k: z[k] for k in ("arm", "n", "ok", "keep_mape_mean", "keep_mape_se")} for z in table2]}))


if __name__ == "__main__":
    main()
