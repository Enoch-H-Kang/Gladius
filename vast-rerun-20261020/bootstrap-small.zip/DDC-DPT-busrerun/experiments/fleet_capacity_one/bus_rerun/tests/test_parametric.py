import unittest
import numpy as np
from scipy.optimize import minimize
from experiments.fleet_capacity_one.bus_rerun import parametric as p
from experiments.fleet_capacity_one.tuning.data_io import load_bus

DEV="/home/ehwkang/DDC-DPT-fleet/experiments/fleet_capacity_one/artifacts/tuning/bus_pool_seed7000.npz"

class TestParametric(unittest.TestCase):
    def test_kernel_and_action_mapping(self):
        self.assertTrue(np.array_equal(p.P0.sum(1),np.ones(10)))
        self.assertTrue(np.array_equal(p.P1[:,0],np.ones(10)))
        self.assertEqual(p.P0[9,9],1)
        self.assertEqual(p.P0[8,9],1)
        self.assertEqual(p.P0[0,1],.25)
        self.assertEqual(p.P0[0,4],.25)

    def test_derivatives_fixed_nontruth(self):
        counts=np.array([[17+i,7+2*i] for i in range(10)])
        for fun,x in ((p.nfxp_value_grad,np.array([.7])),
                      (p.nfxp_value_grad,np.array([.7,4.3])),
                      (p.ccp_value_grad,np.array([.7]))):
            for h in (1e-4,1e-5):
                val,grad,_=fun(x,counts)
                fd=np.array([(fun(x+np.eye(len(x))[i]*h,counts)[0]-
                              fun(x-np.eye(len(x))[i]*h,counts)[0])/(2*h) for i in range(len(x))])
                self.assertLessEqual(float(np.max(np.abs(grad-fd))),1e-6)

    def test_exact_expected_likelihood(self):
        truth=p.solve(1.)
        pi=truth["pi"]
        weights=np.full((10,1),.1)*pi
        # Weighted joint w(s,a) enters once; no second multiplication by policy.
        for fun in (p.nfxp_value_grad,lambda x,c:p.ccp_value_grad(x,c,truth["pi"][:,1])):
            out=minimize(lambda x:fun(x,weights)[:2],np.array([0.]),jac=True,
                         method="BFGS",options=dict(gtol=1e-10))
            self.assertLess(abs(out.x[0]-1.),1e-6)
        d=p.ccp_value_grad(np.array([1.]),weights,truth["pi"][:,1])[2]["policy_keep"]
        self.assertLess(float(np.max(np.abs(d-pi[:,0]))),1e-8)

    def test_development_seed7000(self):
        data=load_bus(DEV,1000)["train"]
        s,a=data["s"],data["a"]
        for arm in ("NFXP-c","CCP-c"):
            r=p.fit(arm,s,a)
            self.assertEqual(r["status"],"ok",r)
            self.assertLess(abs(r["c_hat"]-1),.05)
            self.assertIsNone(r["RC_hat"])
        two=p.fit("NFXP-2p",s,a)
        self.assertEqual(two["status"],"ok",two)
        changed=p.fit("NFXP-c",s,a,rc_fixed=6)
        self.assertGreater(abs(changed["c_hat"]-p.fit("NFXP-c",s,a)["c_hat"]),1e-4)

if __name__=="__main__":unittest.main()
