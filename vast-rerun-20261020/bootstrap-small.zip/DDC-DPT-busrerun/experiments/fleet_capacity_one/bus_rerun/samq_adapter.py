"""Matched-pool adapter for the SAmQ ``our`` + MLE bus estimator.

No reward labels, structural transition probabilities, or headline truth enter fits.
The ten observed discrete mileage values allow lossless compression of SAmQ's
Q-feature Ward clustering whenever the requested cluster count is at most ten.
"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
from scipy.optimize import minimize

ROOT = Path.home() / "DDC-DPT-busrerun"
OUT = ROOT / "results/bus_rerun/samq"
DEV = Path.home() / "DDC-DPT-fleet/experiments/fleet_capacity_one/artifacts/tuning"
SIZES = (50, 250, 500, 1000, 2500, 5000)
DEV_SEEDS = (7300, 7301, 7302)
DEV_SIZES = (50, 250)
GRID = (5, 10)
STEPS = 100
ALPHA = 0.1
BETA = 0.95
B = 5.0
INIT_THETA = 0.5


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, indent=2, allow_nan=False) + "\n")
    os.replace(tmp, path)


def load_pool(path, n):
    with np.load(path, allow_pickle=False) as z:
        assert set(z.files) == {"s", "a", "sp", "chain_hash", "is_val"}
        s, a, sp, is_val = (z[x][:n] for x in ("s", "a", "sp", "is_val"))
    assert s.shape == a.shape == sp.shape == (n, 100)
    assert int(is_val.sum()) == n // 5
    assert np.all((s >= 1) & (s <= 10)) and np.all((sp >= 1) & (sp <= 10))
    assert np.all((a == 0) | (a == 1))
    out = []
    for mask in (~is_val, is_val):
        # SAmQ uses 0=replace, 1=keep; the frozen pool uses 1=replace.
        out.append(tuple(np.ascontiguousarray(x[mask].reshape(-1).astype(np.int32))
                         for x in (s, 1-a, sp)))
    return out


def ward_map(features, counts, k):
    """Ward on repeated identical features; duplicates merge at distance zero."""
    assert features.shape == (10, 2) and k <= 10 and np.all(counts > 0)
    clusters = {i: (float(counts[i]), features[i].astype(float), (i,)) for i in range(10)}
    while len(clusters) > k:
        choices = []
        ids = sorted(clusters)
        for p, i in enumerate(ids):
            ni, xi, _ = clusters[i]
            for j in ids[p+1:]:
                nj, xj, _ = clusters[j]
                cost = ni*nj/(ni+nj)*float(np.sum((xi-xj)**2))
                choices.append((cost, i, j))
        _, i, j = min(choices)
        ni, xi, si = clusters.pop(i)
        nj, xj, sj = clusters.pop(j)
        clusters[i] = (ni+nj, (ni*xi+nj*xj)/(ni+nj), si+sj)
    mapping = np.empty(10, dtype=np.int32)
    for label, (_, _, members) in enumerate(clusters[i] for i in sorted(clusters)):
        mapping[list(members)] = label
    return mapping


def q_features(train, seed, workdir):
    """SAmQ's neural Q and anchor Q* stages, used solely to cluster states."""
    import torch
    from torch.utils.data import Dataset
    sys.path.insert(0, str(Path.home() / "SAmQ"))
    from SAmQ.irl.pqr import pqr_aggregation

    s, a, sp = train
    torch.set_num_threads(1)
    torch.manual_seed(seed)
    np.random.seed(seed)

    class Data(Dataset):
        def __init__(self):
            self.s = s[:, None].astype(np.float32)
            self.s_next = sp[:, None].astype(np.float32)
            self.a = a[:, None].astype(np.int64)
            # These fields are diagnostic-only in train_q/train_q_star.
            self.p = np.zeros((len(s)+1, 2), dtype=np.float32)
            self.q = np.zeros((len(s)+1, 2), dtype=np.float32)
            self.r = np.zeros((len(s)+1, 1), dtype=np.float32)
        def __len__(self):
            return len(s)
        def __getitem__(self, i):
            return (torch.from_numpy(self.s[i]), torch.from_numpy(self.a[i]),
                    torch.from_numpy(self.p[i]), torch.from_numpy(self.p[i+1]),
                    torch.from_numpy(self.s_next[i]), torch.from_numpy(self.q[i]),
                    torch.from_numpy(self.q[i+1]), torch.from_numpy(self.r[i]))

    class Log:
        dir = workdir
        def __call__(self, *args, **kwargs):
            pass
    class Writer:
        def add_scalar(self, *args, **kwargs):
            pass
    class Env:
        n_a = 2
        d_s = 1

    workdir.mkdir(parents=True, exist_ok=True)
    model = pqr_aggregation(Data(), Env(), Log(), hidden_size=10,
                            optimizer=torch.optim.Adam, l_r=0.004,
                            discount=BETA)
    model.train_q(nEpochs=100, batch_size=100, writer=Writer(), patience=5)
    model.train_q_star(n_steps=200, batch_size=100, writer=Writer(), patience=5)
    with torch.no_grad():
        x = torch.arange(1, 11, dtype=torch.float32)[:, None]
        q = model.q(x)
        features = (q - q[:, 0, None] + model.q_star(x)).numpy().astype(float)
    if not np.isfinite(features).all():
        raise ValueError("nonfinite Q aggregation features")
    return features


def library():
    lib = ctypes.CDLL(str(ROOT / "experiments/fleet_capacity_one/bus_rerun/samq_td.so"))
    ip = ctypes.POINTER(ctypes.c_int)
    dp = ctypes.POINTER(ctypes.c_double)
    lib.samq_td.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int,
                            ctypes.c_double, ctypes.c_double, ctypes.c_double,
                            ctypes.c_double, ip, ip, ip, dp, dp]
    lib.samq_nll.argtypes = [ctypes.c_int, ip, ip, dp]
    lib.samq_nll.restype = ctypes.c_double
    return lib


def ptr(x, kind):
    return x.ctypes.data_as(ctypes.POINTER(kind))


def fit(train, val, mapping):
    lib = library()
    s, a, sp = train
    vs, va, _ = val
    st = np.ascontiguousarray(mapping[s-1]); nxt = np.ascontiguousarray(mapping[sp-1])
    vst = np.ascontiguousarray(mapping[vs-1])
    k = int(mapping.max())+1
    mileage = np.ascontiguousarray(s.astype(np.float64))
    def calc(theta):
        q = np.empty((k, 2), dtype=np.float64)
        lib.samq_td(len(s), k, STEPS, ALPHA, BETA, B, float(theta),
                    ptr(st, ctypes.c_int), ptr(a, ctypes.c_int),
                    ptr(nxt, ctypes.c_int), ptr(mileage, ctypes.c_double),
                    ptr(q, ctypes.c_double))
        return q
    def objective(x):
        q = calc(x[0])
        return float(lib.samq_nll(len(s), ptr(st, ctypes.c_int),
                                  ptr(a, ctypes.c_int), ptr(q, ctypes.c_double)))
    res = minimize(objective, np.array([INIT_THETA]), method="BFGS")
    theta = float(res.x[0])
    q = calc(theta)
    tr_nll = objective([theta])
    va_nll = float(lib.samq_nll(len(vs), ptr(vst, ctypes.c_int),
                                ptr(va, ctypes.c_int), ptr(q, ctypes.c_double)))
    if not np.isfinite([theta, tr_nll, va_nll]).all() or not np.isfinite(q).all():
        raise FloatingPointError("nonfinite MLE output")
    return dict(theta_hat=theta, train_nll=tr_nll, validation_nll=va_nll,
                optimizer_success=bool(res.success), optimizer_status=int(res.status),
                optimizer_message=str(res.message), nit=int(res.nit), nfev=int(res.nfev),
                q_native=q.tolist(), state_mapping=mapping.tolist())


def run_one(path, n, seed, r, k, stage):
    start = time.perf_counter()
    fid = f"{stage}_n{n}_r{r:02d}_k{k}"
    recpath = OUT / stage / "cells" / (fid + ".json")
    if recpath.exists():
        return json.loads(recpath.read_text())
    record = dict(fit_id=fid, n=n, r=r, data_seed=seed, clusters=k,
                  pool_path=str(path), pool_sha256=sha(path),
                  status="pending", stage=stage)
    try:
        train, val = load_pool(path, n)
        record["n_train"] = len(train[0]); record["n_validation"] = len(val[0])
        if k == 10:
            # Each distinct state is its own Ward cluster, independent of Q features.
            mapping = np.arange(10, dtype=np.int32)
        else:
            features = q_features(train, seed+n, OUT/stage/"qstage"/fid)
            counts = np.bincount(np.r_[train[0], train[2]]-1, minlength=10)
            mapping = ward_map(features, counts, k)
            record["q_features"] = features.tolist()
        result = fit(train, val, mapping)
        record.update(result)
        record["status"] = "ok" if result["optimizer_success"] else "optimizer_fail"
    except MemoryError as exc:
        record.update(status="resource_fail", error=repr(exc))
    except Exception as exc:
        record.update(status="fit_fail", error=repr(exc))
    record["elapsed_wall"] = time.perf_counter()-start
    atomic_json(recpath, record)
    print(fid, record["status"], record.get("theta_hat"),
          record.get("validation_nll"), round(record["elapsed_wall"], 2), flush=True)
    return record


def dev():
    records = []
    for seed in DEV_SEEDS:
        path = DEV / f"bus_seed{seed}.npz"
        for n in DEV_SIZES:
            for k in GRID:
                records.append(run_one(path, n, seed, seed-7300, k, "dev"))
    candidate = {}
    for k in GRID:
        vals = [r["validation_nll"] for r in records if r["clusters"] == k and r["status"] == "ok"]
        candidate[str(k)] = float(np.mean(vals)) if len(vals) == len(DEV_SEEDS)*len(DEV_SIZES) else None
    eligible = {int(k): v for k, v in candidate.items() if v is not None}
    if not eligible:
        raise RuntimeError("no complete development candidate")
    chosen = min(eligible, key=lambda k: (eligible[k], -k))
    freeze = dict(chosen_clusters=chosen, grid=list(GRID),
                  objective="mean held-out validation NLL over 3 development seeds x 2 N",
                  candidate_nll=candidate, dev_seeds=list(DEV_SEEDS),
                  dev_sizes=list(DEV_SIZES), n_records=len(records),
                  steps=STEPS, alpha=ALPHA, beta=BETA, b=B,
                  initial_theta=INIT_THETA, method="our", base_method="mle",
                  source_sha256=sha(Path(__file__)), td_sha256=sha(Path(__file__).with_name("samq_td.c")),
                  samq_git="dce1a658d0e750be913c244d52b3e97447554965")
    freeze["sha256"] = hashlib.sha256(json.dumps(freeze, sort_keys=True).encode()).hexdigest()
    atomic_json(OUT/"dev_freeze.json", freeze)
    print("DEV_FREEZE", json.dumps(freeze), flush=True)


def headline():
    freeze = json.loads((OUT/"dev_freeze.json").read_text())
    digest = freeze.pop("sha256")
    assert digest == hashlib.sha256(json.dumps(freeze, sort_keys=True).encode()).hexdigest()
    assert freeze["source_sha256"] == sha(Path(__file__))
    assert freeze["td_sha256"] == sha(Path(__file__).with_name("samq_td.c"))
    data = json.loads((ROOT/"results/bus_rerun/data_freeze.json").read_text())
    assert data["sha256"] == "c46e5c0f70c06d735490a05e524f410f178c5c56a98ebc19ef5bc0dec3febb89"
    pools = {p["seed"]: p for p in data["pools"]}
    for n in SIZES:
        for r in range(20):
            seed = 11000+r
            path = ROOT / f"artifacts/bus_rerun/data/bus_seed{seed}.npz"
            assert sha(path) == pools[seed]["sha256"]
            run_one(path, n, seed, r, freeze["chosen_clusters"], "headline")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("stage", choices=("dev", "headline"))
    args = p.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    (dev if args.stage == "dev" else headline)()
