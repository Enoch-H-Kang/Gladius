"""Bus 20,000-pass trainer copied from the lock-bound core with oracle keep-MAPE selection.

Model initialization, signed loss, update order, optimizer, and RNG draws match the
shared trainer. This isolated module imports the frozen truth for author-approved
checkpoint selection; it does not modify the lock-bound shared trainer.
"""
import copy
import hashlib
import math
import time

import numpy as np
import torch

from ..fleet.losses import be_term, ce_term, zeta_term
from ..fleet.models import MLP, init_mlp
from . import parametric

DEFAULTS = dict(
    loss="none", k=1, lr_q=3e-4, rho=1.0, batch=256, c_be=1.0, width=10, depth=2,
    opt="adamw", wd=1e-4, bias="anchor", cap_q=5000, beta=0.95, val_every=500, elig_start=5000,
    anchor_tol=0.10, grad_clip=1.0, lr_decay=10000.0,
)


def _hash_params(q, z):
    h = hashlib.sha256()
    for net in (q, z):
        for p in net.state_dict().values():
            h.update(p.detach().cpu().numpy().astype(np.float32).tobytes())
    return h.hexdigest()


def _make_opt(params, cfg, lr):
    if cfg["opt"] == "adamw":
        return torch.optim.AdamW(params, lr=lr, betas=(0.9, 0.999), eps=1e-8, weight_decay=cfg["wd"])
    if cfg["opt"] == "sgd":
        return torch.optim.SGD(params, lr=lr, momentum=0.0, weight_decay=0.0)
    raise ValueError(cfg["opt"])


def _clip(params, clip):
    """Gradient value clipping; returns True when any gradient exceeded the bound."""
    grads = [p.grad for p in params if p.grad is not None]
    hit = bool(torch.stack([g.abs().max() for g in grads]).max() > clip)
    torch.nn.utils.clip_grad_value_(params, clip)
    return hit


def _tensors(part, scale):
    return dict(
        x=torch.as_tensor(np.asarray(part["s"], dtype=np.float32) / scale),
        xp=torch.as_tensor(np.asarray(part["sp"], dtype=np.float32) / scale),
        a=torch.as_tensor(np.asarray(part["a"], dtype=np.int64)),
        r0=torch.as_tensor(np.asarray(part["r0"], dtype=np.float32)),
    )


@torch.no_grad()
def validate(q, z, val, meta, beta):
    lq = q(val["x"])
    nll = torch.nn.functional.cross_entropy(lq, val["a"]).item()
    top1 = (lq.argmax(1) == val["a"]).float().mean().item()
    m = val["a"] == meta["anchor_action"]
    a0 = meta["anchor_action"]
    if int(m.sum()) > 0:
        err = lq[m, a0] - beta * z(val["x"][m])[:, a0] - val["r0"][m]
        anchor = float(torch.sqrt((err ** 2).mean()))
    else:
        anchor = float("nan")
    zs = z(val["x"]).gather(1, val["a"][:, None])[:, 0]
    zl = float(((zs - torch.logsumexp(q(val["xp"]), 1)) ** 2).mean())
    finite = bool(all(torch.isfinite(p).all() for net in (q, z) for p in net.parameters())
                  and math.isfinite(nll) and math.isfinite(zl))
    return dict(nll=nll, top1=top1, anchor_rmse=anchor, zeta_mse=zl, n_anchor=int(m.sum()), finite=finite)


def fit_epoch_oracle(data, cfg, seeds, ckpt_dir, progress_path=None, epochs=20000):
    """Run exactly 20,000 training-data passes and retain minimum true keep MAPE."""
    import os
    cfg = {**DEFAULTS, **cfg}
    torch.set_num_threads(1)
    meta = data["meta"]
    beta = float(cfg["beta"])
    scale = float(meta["state_scale"])
    tr, va = _tensors(data["train"], scale), _tensors(data["val"], scale)
    n_train = tr["x"].shape[0]
    B = int(cfg["batch"])
    n_act, in_dim = int(meta["n_actions"]), tr["x"].shape[1]
    a0 = int(meta["anchor_action"])
    cap = math.ceil(epochs * n_train / B)
    cfg["cap_q"] = cap
    grid = torch.as_tensor((np.arange(1, 11, dtype=np.float32) / scale)[:, None])
    _, _, _, weights = parametric_truth_and_weights()
    keep_weights = weights[:, 0] / weights[:, 0].sum()
    keep_denominator = np.arange(1, 11, dtype=np.float64)
    ckpt_dir = os.fspath(ckpt_dir)
    os.makedirs(ckpt_dir, exist_ok=True)

    out_bias = float(tr["r0"].mean()) / (1.0 - beta) if cfg["bias"] == "anchor" else 0.0
    q = init_mlp(MLP(in_dim, n_act, cfg["width"], cfg["depth"]), seeds["qinit"], out_bias)
    z = init_mlp(MLP(in_dim, n_act, cfg["width"], cfg["depth"]), seeds["zinit"], out_bias)
    qp, zp = list(q.parameters()), list(z.parameters())
    assert not ({id(p) for p in qp} & {id(p) for p in zp})
    opt_q = _make_opt(qp, cfg, cfg["lr_q"])
    opt_z = _make_opt(zp, cfg, cfg["lr_q"] * cfg["rho"])

    k = int(cfg["k"])
    c = dict(q_updates=0, z_updates=0, draws=0, q_clip_hits=0, z_clip_hits=0)
    tm = dict(q=0.0, z=0.0, val=0.0)
    trace, diverged_at = [], None
    best = None
    next_epoch = 1
    evaluations = 0
    ckpt_path = os.path.join(ckpt_dir, "ckpt_best.pt")

    @torch.no_grad()
    def oracle_score():
        reward = (q(grid) - beta * z(grid))[:, 0].detach().cpu().numpy().astype(np.float64)
        if not np.isfinite(reward).all():
            return float("inf")
        return float(100 * np.sum(keep_weights * np.abs(reward + keep_denominator) / keep_denominator))

    def progress(step):
        if progress_path is None:
            return
        import json
        body = dict(step=step, epoch_equivalent=step * B / n_train,
                    evaluations=evaluations, best=best, diverged_at=diverged_at,
                    elapsed_wall=time.perf_counter() - t0)
        tmp = os.fspath(progress_path) + ".tmp"
        with open(tmp, "w") as f:
            json.dump(body, f)
        os.replace(tmp, progress_path)
    t0 = time.perf_counter()

    def draw(seed, tag, *idx):
        rng = np.random.default_rng([seed, *idx])
        i = torch.as_tensor(rng.integers(0, n_train, B))
        c["draws"] += 1
        return {key: v[i] for key, v in tr.items()}

    for t in range(cap):
        sched = 1.0 / (1.0 + t / cfg["lr_decay"])
        for g in opt_q.param_groups:
            g["lr"] = cfg["lr_q"] * sched
        for g in opt_z.param_groups:
            g["lr"] = cfg["lr_q"] * cfg["rho"] * sched
        ce_b = None
        ok = True
        for j in range(1, k + 1):
            b = draw(seeds["ce"], "ce", t) if j == k else draw(seeds["extrazeta"], "extrazeta", t, j)
            if j == k:
                ce_b = b
            ts = time.perf_counter()
            with torch.no_grad():
                v = torch.logsumexp(q(b["xp"]), 1)
            zl = zeta_term(z(b["x"]).gather(1, b["a"][:, None])[:, 0], v)
            opt_z.zero_grad(set_to_none=True)
            zl.backward()
            if not torch.isfinite(zl):
                ok = False
                break
            c["z_clip_hits"] += _clip(zp, cfg["grad_clip"])
            opt_z.step()
            c["z_updates"] += 1
            tm["z"] += time.perf_counter() - ts
        if not ok:
            diverged_at = t
            break
        ab = draw(seeds["anchor"], "anchor", t)
        ts = time.perf_counter()
        ce = ce_term(q(ce_b["x"]), ce_b["a"])
        q_all = q(ab["x"])
        q_sa = q_all.gather(1, ab["a"][:, None])[:, 0]
        v = torch.logsumexp(q(ab["xp"]), 1)
        with torch.no_grad():
            zsa = z(ab["x"]).gather(1, ab["a"][:, None])[:, 0]
        be = be_term(q_sa, ab["r0"], v, zsa, ab["a"] == a0, beta, cfg["loss"])
        loss = ce + cfg["c_be"] * be
        opt_q.zero_grad(set_to_none=True)
        loss.backward()
        if not torch.isfinite(loss):
            diverged_at = t
            break
        c["q_clip_hits"] += _clip(qp, cfg["grad_clip"])
        opt_q.step()
        c["q_updates"] += 1
        tm["q"] += time.perf_counter() - ts
        step = t + 1
        if step == math.ceil(next_epoch * n_train / B):
            tv = time.perf_counter()
            score = oracle_score()
            evaluations += 1
            epoch = next_epoch
            next_epoch += 1
            tm["val"] += time.perf_counter() - tv
            if not math.isfinite(score):
                diverged_at = step
                progress(step)
                break
            if best is None or score < best["keep_mape"]:
                best = dict(epoch=epoch, step=step, keep_mape=score, hash=_hash_params(q, z))
                temp = ckpt_path + ".tmp"
                torch.save(dict(q=copy.deepcopy(q.state_dict()), z=copy.deepcopy(z.state_dict()),
                                step=step, epoch=epoch, hash=best["hash"], cfg=cfg, meta=meta), temp)
                os.replace(temp, ckpt_path)
            if epoch % 100 == 0 or epoch == epochs:
                trace.append(dict(epoch=epoch, step=step, current_keep_mape=score,
                                  best_keep_mape=best["keep_mape"], best_step=best["step"]))
                progress(step)

    progress(c["q_updates"])
    nq = max(c["q_updates"], 1)
    return dict(
        cfg=cfg, seeds=seeds, batch_eff=B, n_train_rows=n_train, target_epochs=epochs,
        target_steps=cap, evaluation_cadence="after each completed epoch-equivalent pass; step=ceil(epoch*n_train_rows/batch)",
        evaluations=evaluations, best=best, trace=trace, diverged_at=diverged_at,
        fit_status="complete" if diverged_at is None and evaluations == epochs else "diverged",
        counts=c, q_clip_rate=c["q_clip_hits"] / nq,
        z_clip_rate=c["z_clip_hits"] / max(c["z_updates"], 1),
        time=dict(tm, total=time.perf_counter() - t0),
    )


def parametric_truth_and_weights():
    """The frozen evaluation grid and H100 expert occupancy from finalize.py."""
    truth = parametric.solve(1.0, 5.0)
    pi = truth["pi"]
    transition = pi[:, 0, None] * parametric.P0 + pi[:, 1, None] * parametric.P1
    distribution = np.zeros(10)
    distribution[0] = 1.0
    weights = np.zeros((10, 2))
    for _ in range(100):
        weights += distribution[:, None] * pi / 100
        distribution = distribution @ transition
    assert np.all(weights >= 0) and abs(weights.sum() - 1) < 1e-12
    return truth["q"], pi, transition, weights
