"""Score terminal SAmQ slots with the frozen bus-rerun evaluator."""
from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

from experiments.fleet_capacity_one.bus_rerun import finalize, protocol

OUT = protocol.RESULT / "samq"
SIZES = protocol.SIZES


def main():
    freeze = json.loads((OUT / "dev_freeze.json").read_text())
    k = freeze["chosen_clusters"]
    counts, panel = finalize.data_counts()
    rtrue, qtrue, ptrue, weights = finalize.truth_and_weights()
    rows = []
    for n in SIZES:
        for r in range(20):
            path = OUT / "headline/cells" / f"headline_n{n}_r{r:02d}_k{k}.json"
            if path.exists():
                record = json.loads(path.read_text())
            else:
                record = dict(status="missing_or_unreadable", error="missing terminal record")
            status = record["status"]
            row = dict(fit_id=f"SAMQ_n{n}_r{r:02d}", arm="SAmQ", n=n, r=r,
                       data_seed=11000+r, status=status, theta_hat=record.get("theta_hat"),
                       train_nll=record.get("train_nll"),
                       fit_validation_nll=record.get("validation_nll"),
                       elapsed_wall=record.get("elapsed_wall"),
                       error=record.get("error"),
                       optimizer_message=record.get("optimizer_message"), clusters=k,
                       pool_sha256=record.get("pool_sha256"))
            if status == "ok":
                theta = float(record["theta_hat"])
                mapping = np.array(record["state_mapping"], dtype=int)
                qnative = np.array(record["q_native"], dtype=float)
                # Native SAmQ: (replace=0, keep=5-theta*s). Matched report:
                # (keep=-theta*s, replace=-5). The common -5 reward shift
                # implies a -5/(1-beta)=-100 Q-level shift.
                rhat = np.column_stack((-theta*finalize.STATES,
                                        np.full(10, -5.0)))
                qhat = qnative[mapping, ::-1] - 100.0
                data = counts[(11000+r, n)]
                row.update(finalize.scores(rhat, qhat, rtrue, qtrue, ptrue,
                                           weights, data["train"], data["validation"], panel))
                row["theta_relative_error"] = abs(theta-1.0)
                assert math.isclose(row["keep_mape"], 100*row["theta_relative_error"],
                                    rel_tol=1e-12, abs_tol=1e-10)
            rows.append(row)
    assert len(rows) == 120
    with (OUT / "fit_metrics.csv").open("w", newline="") as f:
        keys = list(dict.fromkeys(key for row in rows for key in row))
        writer = csv.DictWriter(f, fieldnames=keys, lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)

    fields = list(csv.DictReader((protocol.RESULT / "table2.csv").open()).fieldnames)
    metric_keys = ["keep_mape", "replace_mape", "pooled_mape", "keep_mae",
                   "keep_rmse", "replace_rmse", "q_rmse", "policy_kl",
                   "validation_keep_mape", "validation_pooled_mape",
                   "panel_keep_mape", "panel_pooled_mape",
                   "validation_nll", "panel_nll"]
    summary = []
    for n in SIZES:
        cell = [x for x in rows if x["n"] == n]
        ok = [x for x in cell if x["status"] == "ok"]
        statuses = [x["status"] for x in cell]
        out = dict(arm="SAmQ", n=n, scheduled=20, ok=len(ok), failed=20-len(ok),
                   anchor_fail=0, optimizer_fail=statuses.count("optimizer_fail") + statuses.count("fit_fail"),
                   nonfinite=0, resource_fail=statuses.count("resource_fail"),
                   unreadable=statuses.count("missing_or_unreadable"),
                   information_set="replace anchor -5; b=5 known; slope only; sampled transitions",
                   replace_reward_given=True)
        for key in metric_keys:
            values = [x[key] for x in ok]
            mean, sd, se, count = finalize.mean_sd_se(values)
            assert count == len(ok)
            out[key+"_mean"] = mean
            out[key+"_sd"] = sd
            out[key+"_se"] = se
        summary.append(out)
    with (OUT / "table2_fragment.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore", lineterminator="\n")
        writer.writeheader(); writer.writerows(summary)
    lines = ["# SAmQ matched bus rerun", "", f"Development freeze: {freeze['sha256']}",
             f"Clusters: {k} from {freeze['grid']}; held-out NLL {freeze['candidate_nll']}",
             "Native reward normalization is replace=0, keep=5-theta*s. We subtract 5 from both rewards for scoring.",
             "Fitting uses observed successor rows, no known kernel or reward labels.", "",
             "| N | SAmQ keep MAPE mean (SE) % | OK/20 | Theta relative error mean |",
             "|---:|---:|---:|---:|"]
    for item in summary:
        n = item["n"]
        cell = [x for x in rows if x["n"] == n and x["status"] == "ok"]
        theta_mean = np.mean([x["theta_relative_error"] for x in cell]) if cell else float("nan")
        if cell:
            val = f"{item['keep_mape_mean']:.4f} ({item['keep_mape_se']:.4f})" if len(cell)>1 else f"{item['keep_mape_mean']:.4f} (NA)"
        else:
            val = "NA"
        lines.append(f"| {n} | {val} | {len(cell)}/20 | {theta_mean:.6f} |")
    lines += ["", "## Failures", ""]
    failures = [x for x in rows if x["status"] != "ok"]
    lines.append(f"{len(failures)} failed slots of 120, retained in fit_metrics.csv and headline/cells/.")
    for x in failures:
        detail = x.get("error") or x.get("optimizer_message")
        lines.append(f"- {x['fit_id']}: {x['status']} — {detail}" if detail else
                     f"- {x['fit_id']}: {x['status']}")
    (OUT / "RESULTS.md").write_text("\n".join(lines)+"\n")
    print("SUMMARY", json.dumps([{k:r[k] for k in ("n", "ok", "failed", "keep_mape_mean", "keep_mape_se")} for r in summary]))


if __name__ == "__main__":
    main()
