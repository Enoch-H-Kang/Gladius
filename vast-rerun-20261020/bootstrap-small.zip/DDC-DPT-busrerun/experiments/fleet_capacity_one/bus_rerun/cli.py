"""RR command line: freeze_manifest, verify_efficiency, run, seal_selections, evaluate, render."""
import argparse
import hashlib
import json
import os
from pathlib import Path
from . import protocol

ROOT=protocol.ROOT
RESULT=protocol.RESULT
FITS=ROOT/"artifacts/bus_rerun/fits"


def verify_efficiency():
    results={}
    for name in ("E1","E2","E3","E4","E5"):
        p=RESULT/"proofs"/(name+".json")
        results[name]=json.loads(p.read_text()) if p.exists() else dict(pass_=False,missing=True)
    if results["E5"].get("pass_"):
        protocol.lock()
    print(json.dumps({k:dict(pass_=v.get("pass_",False),missing=v.get("missing",False)) for k,v in results.items()}))
    if not all(v.get("pass_") for v in results.values()):raise SystemExit(1)


def seal_selections(manifest):
    m=protocol.load_manifest(manifest)
    records=[]
    missing=[]
    for spec in m["fits"]:
        p=FITS/spec["fit_id"]/"record.json"
        if not p.exists():
            missing.append(spec["fit_id"])
            continue
        rec=json.loads(p.read_text())
        if rec.get("manifest_sha256")!=m["sha256"] or rec.get("code_hash")!=spec["code_hash"]:
            raise ValueError("fit provenance mismatch "+spec["fit_id"])
        status=rec.get("status")
        if spec["arm"].startswith("G-"):
            h=str(spec["horizons"][-1])
            choice=rec["horizons"][h]
            status={"ok":"ok","anchor_fail":"anchor_fail","unassessable":"unassessable",
                    "failed_diverged":"nonfinite"}.get(choice["status"],choice["status"])
            selected=choice.get("hash")
            step=choice.get("step")
        else:
            selected=hashlib.sha256(protocol.canonical(dict(c_hat=rec.get("c_hat"),RC_hat=rec.get("RC_hat"),status=status))).hexdigest()
            step=None
        records.append(dict(fit_id=spec["fit_id"],arm=spec["arm"],n=spec["n"],r=spec["r"],
                            status=status,selected_hash=selected,selected_step=step,
                            record_sha256=protocol.sha(p)))
    if missing:
        raise RuntimeError(f"cannot seal: {len(missing)} of 600 slots missing")
    if len(records)!=600:raise ValueError("record count")
    obj=protocol.seal(dict(manifest_sha256=m["sha256"],n_slots=600,selections=records))
    tmp=RESULT/"selections.json.tmp"
    tmp.write_text(json.dumps(obj,indent=2)+"\n")
    os.replace(tmp,RESULT/"selections.json")
    print(json.dumps(dict(sealed=600,sha256=obj["sha256"])))


def main():
    p=argparse.ArgumentParser()
    sub=p.add_subparsers(dest="command",required=True)
    sub.add_parser("freeze_manifest")
    sub.add_parser("verify_efficiency")
    run=sub.add_parser("run")
    run.add_argument("--manifest",required=True)
    run.add_argument("--ledger",required=True)
    run.add_argument("--arms",choices=["scalar","gladius"],default="scalar")
    seal=sub.add_parser("seal_selections")
    seal.add_argument("--manifest",default=str(RESULT/"manifest_RR.json"))
    evaluate=sub.add_parser("evaluate")
    evaluate.add_argument("--sealed",required=True)
    render=sub.add_parser("render")
    render.add_argument("--results",required=True)
    a=p.parse_args()
    if a.command=="freeze_manifest":
        path,m=protocol.write_manifest()
        print(json.dumps(dict(path=str(path),sha256=m["sha256"],slots=len(m["fits"]),freeze=m["freeze"])))
    elif a.command=="verify_efficiency":verify_efficiency()
    elif a.command=="run":
        if a.arms=="scalar":
            from .runner import run
            run(a.manifest,a.ledger)
        else:
            freeze=protocol.freeze_state()
            if freeze["state"]!="READY":raise RuntimeError(json.dumps(freeze))
            raise RuntimeError("GLADIUS launcher requires verified common freeze and applicable lock")
    elif a.command=="seal_selections":seal_selections(a.manifest)
    elif a.command=="evaluate":
        from .evaluate import evaluate
        evaluate(a.sealed)
    elif a.command=="render":
        from .render import render
        render(a.results)

if __name__=="__main__":main()
