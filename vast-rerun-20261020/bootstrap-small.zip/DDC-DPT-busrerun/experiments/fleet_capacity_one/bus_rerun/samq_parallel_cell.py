import json
import sys
from pathlib import Path

from experiments.fleet_capacity_one.bus_rerun import samq_adapter as x

r = int(sys.argv[1])
n = int(sys.argv[2]) if len(sys.argv) > 2 else 5000
seed = 11000 + r
freeze = json.loads((x.OUT / "dev_freeze.json").read_text())
assert freeze["chosen_clusters"] == 10
assert freeze["source_sha256"] == x.sha(Path(x.__file__))
data = json.loads((x.ROOT / "results/bus_rerun/data_freeze.json").read_text())
p = x.ROOT / f"artifacts/bus_rerun/data/bus_seed{seed}.npz"
assert x.sha(p) == data["pools"][r]["sha256"]
x.run_one(p, n, seed, r, 10, "headline")
