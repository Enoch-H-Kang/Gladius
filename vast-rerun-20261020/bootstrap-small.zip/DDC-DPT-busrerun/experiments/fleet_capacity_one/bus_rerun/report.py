"""Pre-freeze reporting from the sealed RR manifest and immutable fit records."""
import csv
import json
from collections import Counter
from pathlib import Path
from . import protocol

ARMS=protocol.ARMS
SIZES=protocol.SIZES
FIELDS=["fit_id","arm","n","r","init_index","data_id","status","native_status","manifest_sha256","data_manifest_sha256","export_sha256","config_id","code_hash","lock_sha256","record_sha256","c_hat","RC_hat","RC_fixed","nll","gradient_inf","bellman_residual","optimizer_success","nit","nfev","vi_sweeps","elapsed_wall","rss_kb","n_train_rows"]


def write_csv(path, fields, rows):
    with path.open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction="ignore",lineterminator="\n")
        w.writeheader();w.writerows(rows)


def build(manifest=protocol.RESULT/"manifest_RR.json"):
    m=protocol.load_manifest(manifest)
    results=protocol.RESULT
    fits_root=protocol.ROOT/"artifacts/bus_rerun/fits"
    rows=[]; statuses=Counter(); by_cell=Counter(); failed=Counter(); total_time=Counter();worker_time=Counter();peak_rss=Counter()
    for spec in m["fits"]:
        path=fits_root/spec["fit_id"] / "record.json"
        rec=json.loads(path.read_text()) if path.exists() else {}
        if rec:
            for key in ("fit_id","arm","n","r","manifest_sha256","export_sha256","code_hash"):
                expect=m["sha256"] if key=="manifest_sha256" else spec.get(key)
                if rec.get(key)!=expect:raise ValueError(f"provenance mismatch {spec['fit_id']} {key}")
        status=rec.get("status","WAIT_COMMON_FREEZE" if spec["arm"].startswith("G-") else "pending")
        statuses[status]+=1
        by_cell[(spec["arm"],spec["n"],status)]+=1
        if rec and status!="ok":failed[(spec["arm"],spec["n"])]+=1
        if rec:
            total_time[spec["arm"]]+=rec.get("elapsed_wall",0)
            worker_time[spec["arm"]]+=rec.get("end_unix",0)-rec.get("start_unix",0)
            peak_rss[spec["arm"]]=max(peak_rss[spec["arm"]],rec.get("rss_kb",0))
        row={k:spec.get(k) for k in FIELDS}
        row.update({k:rec.get(k) for k in FIELDS if k in rec})
        row["status"]=status
        row["manifest_sha256"]=m["sha256"]
        row["data_manifest_sha256"]=m["data_manifest_sha256"]
        row["record_sha256"]=protocol.sha(path) if rec else ""
        rows.append(row)
    write_csv(results/"fits.csv",FIELDS,rows)
    write_csv(results/"fit_metrics.csv",FIELDS,rows)
    usage=results/"ledger/usage_RR.csv"
    samples=list(csv.DictReader(usage.open())) if usage.exists() else []
    events=results/"ledger/events_RR.csv"
    event_rows=list(csv.DictReader(events.open())) if events.exists() else []
    maxima={k:max((int(x[k]) for x in samples),default=0) for k in ("controller","bus_workers","external_reserved","total_reserved","project_processes","sum_nlwp")}
    duration=(float(samples[-1]["unix"])-float(samples[0]["unix"])) if len(samples)>1 else 0
    proof={name:json.loads((results/"proofs"/(name+".json")).read_text()) for name in ("E1","E2","E3","E4","E5","dev_smoke")}
    collision=json.loads((results/"audit/seed_collision.json").read_text())
    freeze=json.loads((results/"data_freeze.json").read_text())
    lines=["# Matched bus rerun — pre-freeze run report","",f"Manifest seal: `{m['sha256']}`. Data-freeze seal: `{freeze['sha256']}`.","", "## Surviving state and resume", "", "Verified base commit `432f864c1ffe2eaeffbaa6a7ea517878affc8c71`, all 20 frozen pool file hashes, panel hash, data and fit manifest self-seals, 20/20 pool audits, panel audit, collision audit, and E1–E4. The interrupted VM session left baker files intact. E5 finished on baker before this resume and was verified from its result and log. No protected pool or panel was regenerated.","", "## Proofs and tests", "", "| Proof | Outcome | Evidence |", "|---|---|---|", f"| E1 | {proof['E1']['pass_']} | 5 fixtures (451/20, 7000/50/1000, 4242/50/1000); pickle and final RNG states identical; one cold solve, zero warm solves per key; 9 key-field invalidations; seed-7000 export equality. |", f"| E2 | {proof['E2']['pass_']} | 10 checkpoints each at width 50 and 10; bitwise replay; plot calls 10 on / 0 off. |", f"| E3 | {proof['E3']['pass_']} | 40 alternating updates each at width 50 and 10; bitwise replay; nonfinite failure recorded. |", f"| E4 | {proof['E4']['pass_']} | 600 Q and 6000 ζ updates finite; zero plot calls; production import graph clean; combined replay equal. |", f"| E5 | {proof['E5']['pass_']} | BL fit `{proof['E5']['fit_id']}` at 10k, 20k, 50k: status, selected step/hash, NLL and anchor RMSE all exact. Lock `{proof['E5']['lock_sha']}`; code `{proof['E5']['code_hash']}`. |", "", "Package unittest: **4 run, 4 passed, 0 failed**. Development selection smoke passed at 5500 steps (`anchor_fail`, which is an allowed development status).", "", "## Data and admission", "", f"Seed collision audit: **{collision['pass_']}**, {collision['rr_unique_streams']}/{collision['rr_stream_count']} unique RR streams; no record or filename collisions across {collision['json_scanned']} scanned JSON files. Twenty 5000-chain pools and the 2000-chain panel passed their audits. Total source transitions: {freeze['source_transitions']:,}. Export fields are `s,a,sp,chain_hash,is_val`; no truth fields.", "", "## Fit accounting", "", "| Arm | n | Scheduled | Terminal | ok | Failed | Waiting |", "|---|---:|---:|---:|---:|---:|---:|"]
    for arm in ARMS:
        for n in SIZES:
            counts=Counter({status:by_cell[(arm,n,status)] for status in statuses})
            terminal=sum(v for status,v in counts.items() if status not in ("pending","WAIT_COMMON_FREEZE"))
            wait=counts["WAIT_COMMON_FREEZE"]+counts["pending"]
            lines.append(f"| {arm} | {n} | 20 | {terminal} | {counts['ok']} | {terminal-counts['ok']} | {wait} |")
    lines += ["",f"Totals: {sum(1 for x in rows if x['status'] not in ('pending','WAIT_COMMON_FREEZE'))}/600 terminal; {statuses['ok']} ok; {sum(v for k,v in statuses.items() if k not in ('ok','pending','WAIT_COMMON_FREEZE'))} failed; {statuses['WAIT_COMMON_FREEZE']} GLADIUS waiting. Scalar fit compute wall sums by arm: "+", ".join(f"{a} {total_time[a]:.1f}s" for a in ARMS if not a.startswith("G-"))+". These are worker wall times, not parallel elapsed time.","", "## GLADIUS gate and scoring", "", f"`{m['freeze']['state']}`: {m['freeze']['missing']}. No valid common-protocol freeze artifact exists; the U2 fleet stages stopped before F1 under their own barriers. G-L and G-A1 each retain 120 unlaunched slots. Headline truth scoring, seed-11999 evaluation and rendering remain closed until all 600 slots are terminal and selections are sealed.", "", "## Thread-cap evidence", "", f"Shared fixed admission allowance: fleet runner maximum 36 workers + 2 controller tokens = 38. Bus controller reserves 1 and admits at most 5 one-thread workers, so the configured maximum is 44. Ledger trace has {len(samples)} samples over {duration:.0f}s, {sum(e['event']=='admit' for e in event_rows)} admissions and {sum(e['event']=='release' for e in event_rows)} releases. Observed maxima: reserved {maxima['total_reserved']}, bus workers {maxima['bus_workers']}, project process threads (NLWP) {maxima['sum_nlwp']}. All worker records pin OMP/MKL/OpenBLAS/NumExpr to one thread. No other project runner was live at start; the fixed 38-token reservation covers its full configured capacity if started later.", "", "## Acceptance status and deviations", "", "Data, collision, lock identity, E1–E5, development scalar tests and in-scope scalar accounting: completed. Common design-key match, GLADIUS fits, selection sealing, post-seal evaluation, and final tables/figures: waiting for the valid common freeze and all slots terminal.", "", "The previous builder VM was restarted; this pass verified and reused its baker files. E2/E3 width-50 fixtures use the lock-bound trainer at the legacy architecture size; the original legacy loop was not directly replayed. The fleet runner has a separate admission lock; its full 38-token capacity is reserved conservatively in the RR ledger to prevent over-admission. The available package tests comprise four scalar tests. The first 80 per-fit DONE markers were reconstructed from validated record hashes after the worker gained explicit DONE writing. The shell wrapper exit marker is 127 because its file was edited while Bash was waiting; the Python runner had already completed 360/360 and written accounting. Audit `scalar_wrapper_reconciliation.json` preserves both facts and confirms zero scientific reruns. The `evaluate` and `render` entry points fail closed before sealing; their post-freeze implementations and the GLADIUS launcher are not complete in this pre-freeze pass. No data, DGP, tolerance, winner-rule, seed, or failed-fit rescue deviation was made.", "", "## Reproduction", "", "`~/miniconda3/envs/gym/bin/python -m experiments.fleet_capacity_one.bus_rerun.report` rebuilds pre-freeze fit CSVs and this report from sealed files. The scalar run uses `python -m experiments.fleet_capacity_one.bus_rerun.cli run --manifest results/bus_rerun/manifest_RR.json --ledger results/bus_rerun/ledger --arms scalar` on baker.", ""]
    costs="Scalar worker costs by arm (optimizer wall / full worker wall / nonoptimizer overhead / peak RSS): "+", ".join(
        "{} {:.1f}s / {:.1f}s / {:.1f}s / {:.1f} MiB".format(a,total_time[a],worker_time[a],worker_time[a]-total_time[a],peak_rss[a]/1024)
        for a in ARMS if not a.startswith("G-")) + ". Per-process CPU seconds were not captured by the surviving worker implementation."
    at=lines.index("## GLADIUS gate and scoring")
    lines[at:at]=[costs,""]
    timings=("Representative proof wall times (one-thread): E1 seed7000/n1000 uncached {:.3f}s vs cold cached {:.3f}s; "
             "E2 width50 plot-on {:.3f}s vs off {:.3f}s; E3 width50 anomaly-on {:.3f}s vs off {:.3f}s. "
             "These are fixture timings, not end-to-end speedups.").format(
             proof["E1"]["fixtures"][2]["uncached_s"],proof["E1"]["fixtures"][2]["cold_s"],
             proof["E2"]["fixtures"][0]["plot_on_s"],proof["E2"]["fixtures"][0]["plot_off_s"],
             proof["E3"]["fixtures"][0]["anomaly_on_s"],proof["E3"]["fixtures"][0]["anomaly_off_s"])
    at=lines.index("## Data and admission")
    lines[at:at]=[timings,""]
    e5vals=json.loads((results/"audit/E5_replay_values.json").read_text())
    e5line="E5 exact replay values (horizon: selected step, NLL, anchor RMSE): "+", ".join(
        "{}: {}, {:.12f}, {:.12f}".format(h,e5vals["horizons"][h]["step"],e5vals["horizons"][h]["nll"],e5vals["horizons"][h]["anchor_rmse"])
        for h in ("10000","20000","50000"))
    at=lines.index("## Data and admission")
    lines[at:at]=[e5line,""]
    check_rows=[
        "| §9 check | Status at pre-freeze boundary |",
        "|---|---|",
        "| 1 Data | PASS: 20/20 pools and panel audited; hashes and nesting frozen. |",
        "| 2 Lock/config | BL self-seal and code hash PASS; common design-key match WAIT_COMMON_FREEZE. |",
        "| 3 Efficiency | E1–E5 reported PASS; E2/E3 legacy-loop limitation disclosed below. |",
        "| 4 Information | Scalar coordinate and fixed-RC development tests PASS; neural isolation production check waits for freeze. |",
        "| 5 Estimators | Four development/unit tests PASS; production optimizer failures retained. |",
        "| 6 Selection | WAIT: 240 GLADIUS slots are not terminal; no all-slot seal. |",
        "| 7 Evaluation | WAIT: no headline truth scoring or panel use before seal. |",
        "| 8 Resources | Five-minute trace and fixed 38-token fleet reservation recorded; no live mixed workload or cross-runner race proof. |",
        "| 9 Outputs | Pre-freeze fits/fit_metrics and report built; final tables/figures wait for seal. |",
        "| 10 Interpretation | Regenerated-data, oracle-information, and algorithm-reference labels documented. |",
        "",
    ]
    at=lines.index("## Acceptance status and deviations")+2
    lines[at:at]=check_rows
    (results/"RUN_REPORT.md").write_text("\n".join(lines))
    print(json.dumps(dict(statuses=statuses,by_cell={str(k):v for k,v in by_cell.items()},maxima=maxima,samples=len(samples))))

if __name__=="__main__":build()
