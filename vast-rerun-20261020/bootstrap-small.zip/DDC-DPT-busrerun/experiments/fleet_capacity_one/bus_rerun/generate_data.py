"""Generate, audit and freeze RR cap-10 pools after E1 and seed admission."""
import hashlib
import json
import os
from pathlib import Path
import numpy as np
from ..tuning import bus_data, bus_truth
from . import cached_generator

ROOT=Path.home()/"DDC-DPT-busrerun"
DATA=ROOT/"artifacts/bus_rerun/data"
PANEL=ROOT/"artifacts/bus_rerun/panel"
RESULT=ROOT/"results/bus_rerun"
DEV=[Path.home()/"DDC-DPT-fleet/experiments/fleet_capacity_one/artifacts/tuning",
     Path.home()/"DDC-DPT-fleet-r1literal/experiments/fleet_r1literal/artifacts"]


def digest(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1<<20),b""): h.update(chunk)
    return h.hexdigest()


def check_inputs():
    e1=json.loads((RESULT/"proofs/E1.json").read_text())
    seeds=json.loads((RESULT/"audit/seed_collision.json").read_text())
    if not e1["pass_"] or not seeds["pass_"]: raise RuntimeError("E1 or seed audit not passed")


def dev_hashes():
    hashes=set()
    inventory=[]
    for root in DEV:
        if not root.exists(): continue
        for p in root.rglob("*.npz"):
            try:
                with np.load(p,allow_pickle=False) as z:
                    if "chain_hash" not in z.files: continue
                    vals=set(map(str,z["chain_hash"].tolist()))
                    hashes.update(vals)
                    inventory.append(dict(path=str(p),n=len(vals),sha256=digest(p)))
            except Exception:
                continue
    return hashes,inventory


def hashes_from(path):
    with np.load(path,allow_pickle=False) as z:
        assert set(z.files)=={"s","a","sp","chain_hash","is_val"}
        h=z["chain_hash"].astype(str).tolist()
        assert len(h)==5000 and len(set(h))==5000
        assert z["s"].shape==(5000,100) and z["a"].shape==(5000,100) and z["sp"].shape==(5000,100)
        assert int(z["is_val"].sum())==1000
        assert np.array_equal(z["is_val"],np.arange(5000)%5==4)
        for n in (50,250,500,1000,2500,5000):
            assert int(z["is_val"][:n].sum())==n//5
        return h,hashlib.sha256(z["s"].tobytes()+z["a"].tobytes()+z["sp"].tobytes()).hexdigest()


def main():
    check_inputs()
    DATA.mkdir(parents=True,exist_ok=True);PANEL.mkdir(parents=True,exist_ok=True)
    (RESULT/"audit").mkdir(parents=True,exist_ok=True)
    old,inventory=dev_hashes()
    seen=set()
    pools=[]
    for r in range(20):
        seed=11000+r
        path=DATA/f"bus_seed{seed}.npz"
        audit=RESULT/"audit"/f"pool_{seed}.json"
        if not path.exists():
            tr,va=cached_generator.generate(seed,5000)
            result=bus_data.audit_pool(tr,va,str(audit),seed)
            if not result["pass"] or result["n_train"]!=4000 or result["n_test"]!=1000: raise RuntimeError(f"pool {seed} DGP audit failed")
            tmp=DATA/f"bus_seed{seed}.tmp.npz"
            bus_data.export_pool(tr,va,str(tmp))
            os.replace(tmp,path)
            del tr,va
        else:
            result=json.loads(audit.read_text())
            if not result["pass"]: raise RuntimeError(f"existing pool {seed} failed")
        h,content=hashes_from(path)
        inter_dev=len(set(h)&old);inter_rr=len(set(h)&seen)
        if inter_dev or inter_rr: raise RuntimeError(f"chain collision for {seed}: dev={inter_dev}, RR={inter_rr}")
        seen.update(h)
        mapping=RESULT/"audit"/f"ranks_{seed}.json"
        if not mapping.exists():
            mapping.write_text(json.dumps(dict(seed=seed,rank_to_chain_hash=h),separators=(",",":"))+"\n")
        pools.append(dict(seed=seed,data_id=f"bus_seed{seed}",path=str(path),sha256=digest(path),
                          content_sha256=content,rank_map_sha256=digest(mapping),chains=5000,transitions=500000,
                          train_chains=4000,val_chains=1000,dev_chain_overlap=inter_dev,rr_chain_overlap=inter_rr,
                          audit_sha256=digest(audit)))
        print(f"POOL {seed} PASS sha={pools[-1]['sha256']}",flush=True)
    seed=11999
    path=PANEL/"bus_seed11999.npz"
    audit=RESULT/"audit"/"panel_11999.json"
    if not path.exists():
        chains=cached_generator.generate(seed,2000,split=False)
        result=bus_data.audit_pool(chains,[],str(audit),seed)
        if not result["pass"] or result["n_train"]!=2000: raise RuntimeError("panel audit failed")
        rows=[]
        for c in chains:
            s,a,sp=bus_data._arrays(c)
            rows.append((bus_truth.chain_hash(s,a,sp),s,a,sp))
        h=[x[0] for x in rows]
        if len(set(h))!=2000 or set(h)&seen or set(h)&old: raise RuntimeError("panel chain collision")
        tmp=PANEL/"bus_seed11999.tmp.npz"
        np.savez_compressed(tmp,s=np.stack([x[1] for x in rows]),a=np.stack([x[2] for x in rows]),
                            sp=np.stack([x[3] for x in rows]),chain_hash=np.array(h))
        os.replace(tmp,path)
    with np.load(path,allow_pickle=False) as z:
        h=set(map(str,z["chain_hash"].tolist()))
        assert set(z.files)=={"s","a","sp","chain_hash"}
        assert z["s"].shape==(2000,100) and len(h)==2000 and not(h&seen) and not(h&old)
    panel=dict(seed=11999,path=str(path),sha256=digest(path),chains=2000,transitions=200000,
               dev_chain_overlap=0,rr_chain_overlap=0,audit_sha256=digest(audit))
    body=dict(generator_sha256=bus_data.generator_sha(),cap=10,H=100,n_pools=20,
              source_transitions=10200000,pools=pools,panel=panel,development_inventory=inventory,
              development_chain_count=len(old),rr_chain_count=len(seen),
              seed_audit_sha256=digest(RESULT/"audit/seed_collision.json"),E1_sha256=digest(RESULT/"proofs/E1.json"))
    raw=json.dumps(body,sort_keys=True,separators=(",",":"),allow_nan=False).encode()
    body["sha256"]=hashlib.sha256(raw).hexdigest()
    out=RESULT/"data_freeze.json"
    tmp=out.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(body,indent=2)+"\n")
    os.replace(tmp,out)
    print("DATA_FREEZE",body["sha256"],flush=True)


if __name__=="__main__":main()
