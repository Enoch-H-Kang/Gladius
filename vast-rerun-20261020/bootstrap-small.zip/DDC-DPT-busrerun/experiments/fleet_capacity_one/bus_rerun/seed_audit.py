"""Audit protected RR generation seeds and derived streams against actual development records."""
import hashlib
import json
import os
import re
from pathlib import Path
from ..fleet.seeds import expand_seeds

ROOT=Path.home()
SOURCES=[ROOT/"DDC-DPT-fleet",ROOT/"DDC-DPT-fleet-r1literal",ROOT/"DDC-DPT"]
OUT=ROOT/"DDC-DPT-busrerun/results/bus_rerun/audit/seed_collision.json"
PROTECTED=set(range(11000,11020))|{11999}
PROT_STREAM={}
for seed in range(11000,11020):
    PROT_STREAM.update({v:(seed,k) for k,v in expand_seeds("bus","RR",f"bus_seed{seed}",0).items()})


def visit(obj,path,found):
    if isinstance(obj,dict):
        for k,v in obj.items():
            if k in ("seed","generation_seed","data_seed") and isinstance(v,int) and v in PROTECTED:
                found.append((path,k,str(v)))
            if k=="data_id" and isinstance(v,str) and re.fullmatch(r"bus_seed(1100[0-9]|1101[0-9]|11999)",v):
                found.append((path,k,v))
            if k=="seeds" and isinstance(v,dict):
                for stream,number in v.items():
                    if isinstance(number,int) and number in PROT_STREAM:
                        found.append((path,"stream:"+stream,str(number)))
            visit(v,path,found)
    elif isinstance(obj,list):
        for item in obj: visit(item,path,found)


def main():
    hits=[]
    scanned=0
    file_hits=[]
    for root in SOURCES:
        if not root.exists(): continue
        for base,dirs,files in os.walk(root):
            dirs[:]=[d for d in dirs if d not in (".git","__pycache__","node_modules","DDC-DPT-busrerun")]
            for name in files:
                p=Path(base)/name
                if re.search(r"(?:bus_seed)?(?:1100[0-9]|1101[0-9]|11999)(?![0-9])",name):
                    file_hits.append(str(p))
                if p.suffix!=".json" or p.stat().st_size>5_000_000: continue
                scanned+=1
                try: obj=json.loads(p.read_text())
                except Exception: continue
                visit(obj,str(p),hits)
    payload=dict(pass_=not hits and not file_hits,protected_generation_seeds=sorted(PROTECTED),
                 rr_stream_count=len(PROT_STREAM),rr_unique_streams=len(set(PROT_STREAM)),json_scanned=scanned,
                 record_collisions=hits,filename_collisions=file_hits,
                 reservation_union="7000,7100-7105,7199,7200-7204,7299,7300-7302,9200-9209,9250-9254,9260-9262,9100-9103,9300-9304,9400-9402,9450-9452,9500-9504,9700-9701,9399,9997,1000-1009,9998,9999,11050-11054,11998,12050-12054,12998,451,14,4242")
    OUT.parent.mkdir(parents=True,exist_ok=True)
    OUT.write_text(json.dumps(payload,indent=2)+"\n")
    print(json.dumps(payload))
    if not payload["pass_"]: raise SystemExit(1)


if __name__=="__main__": main()
