"""Post-seal evaluator entry point. The pre-freeze build fails closed here."""
from pathlib import Path
from . import protocol


def evaluate(sealed):
    path=Path(sealed)
    if not path.exists():
        raise RuntimeError("WAIT_COMMON_FREEZE: all 600 selections must be sealed before headline evaluation")
    obj=__import__("json").loads(path.read_text())
    protocol.verify_seal(obj)
    if obj.get("n_slots")!=600 or len(obj.get("selections",[]))!=600:
        raise ValueError("incomplete selection seal")
    raise NotImplementedError("post-freeze headline evaluator requires the completed GLADIUS stage")
