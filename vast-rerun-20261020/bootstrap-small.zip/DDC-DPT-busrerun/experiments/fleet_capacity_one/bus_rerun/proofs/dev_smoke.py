import json
from pathlib import Path
from ...fleet.seeds import expand_seeds
from ...fleet.train import fit
from ...tuning.data_io import load_bus
from ..protocol import lock,ROOT

def main():
    l=lock()
    cfg=dict(l["design"])
    cfg["cap_q"]=5500
    cfg["N"]=5000
    data=load_bus(str(Path.home()/"DDC-DPT-fleet/experiments/fleet_capacity_one/artifacts/tuning/bus_pool_seed7000.npz"),50)
    out=ROOT/"artifacts/bus_rerun/proofs/dev_smoke"
    out.mkdir(parents=True,exist_ok=True)
    rec=fit(data,{k:v for k,v in cfg.items() if k!="N"},
            expand_seeds("bus","RR","bus_seed7000",0),horizons=[5500],ckpt_dir=str(out))
    h=rec["horizons"][5500]
    payload=dict(pass_=h["status"] in ("ok","anchor_fail"),status=h["status"],
                 selected_step=h["step"],selected_hash=h["hash"],trace_count=len(rec["trace"]),
                 q_updates=rec["counts"]["q_updates"],z_updates=rec["counts"]["z_updates"])
    (ROOT/"results/bus_rerun/proofs/dev_smoke.json").write_text(json.dumps(payload,indent=2)+"\n")
    print(json.dumps(payload),flush=True)
    if not payload["pass_"]:raise SystemExit(1)
if __name__=="__main__":main()
