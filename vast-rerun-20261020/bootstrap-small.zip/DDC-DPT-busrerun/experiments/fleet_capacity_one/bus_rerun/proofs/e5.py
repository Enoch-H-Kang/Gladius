"""Replay first BL manifest fit with byte-identical trainer modules."""
import hashlib
import json
import os
from pathlib import Path
from ...tuning import run_fit

ROOT=Path.home()/"DDC-DPT-busrerun"
BL=Path.home()/"DDC-DPT-fleet/experiments/fleet_capacity_one"
OUT=ROOT/"results/bus_rerun/proofs/E5.json"


def main():
    lock=json.loads((ROOT/"results/bus_rerun/lock_ref.json").read_text())
    raw=json.dumps({k:v for k,v in lock.items() if k!="sha256"},sort_keys=True,separators=(",",":")).encode()
    lock_sha=hashlib.sha256(raw).hexdigest()
    assert lock_sha==lock["sha256"]=="3a7749e7354fd1472320f76b2d2b62259847eed682dea6379ecff7f02129619b"
    assert run_fit.code_hash()=="d925d15b69206db6fb391738eafbe1b1fd9391ff5046041b7db3bfed734f9eab"
    manifest=BL/"results/tuning/manifests/manifest_BL.json"
    m=json.loads(manifest.read_text())
    assert m["sha256"]==lock["manifest_sha256"] and len(m["fits"])==18
    spec=m["fits"][0]
    fit_id=spec["fit_id"]
    export=BL/"artifacts/tuning"/(spec["data_id"]+".npz")
    outroot=ROOT/"artifacts/bus_rerun/proofs/E5"
    outroot.mkdir(parents=True,exist_ok=True)
    run_fit.main(str(manifest),fit_id,str(outroot),str(export))
    replay=json.loads((outroot/fit_id/"record.json").read_text())
    original=json.loads((BL/"artifacts/tuning/fits_BL"/fit_id/"record.json").read_text())
    checks={}
    for h in ("10000","20000","50000"):
        a=original["horizons"][h]
        b=replay["horizons"][h]
        checks[h]={k:a.get(k)==b.get(k) for k in ("status","step","hash","nll","anchor_rmse")}
    passed=all(all(x.values()) for x in checks.values())
    payload=dict(pass_=passed,lock_sha=lock_sha,code_hash=run_fit.code_hash(),
                 manifest_sha=m["sha256"],fit_id=fit_id,horizon_comparisons=checks)
    OUT.parent.mkdir(parents=True,exist_ok=True)
    OUT.write_text(json.dumps(payload,indent=2)+"\n")
    print(json.dumps(payload),flush=True)
    if not passed: raise SystemExit(1)


if __name__=="__main__": main()
