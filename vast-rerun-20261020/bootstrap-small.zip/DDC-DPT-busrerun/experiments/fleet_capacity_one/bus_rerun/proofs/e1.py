"""Uncached/cached generator replay evidence, run as a detached engineering worker."""
import hashlib
import json
import os
import pickle
import random
import tempfile
import time
import numpy as np
from ...tuning import bus_data
from .. import cached_generator as cg

ROOT=os.path.expanduser("~/DDC-DPT-busrerun")
OUT=os.path.join(ROOT,"results/bus_rerun/proofs/E1.json")


def snapshot(seed,n,cached):
    t=time.perf_counter()
    if cached:
        tr,va=cg.generate(seed,n)
    else:
        with tempfile.TemporaryDirectory() as tmp:
            tr,va=bus_data.generate_pool(seed,n,tmp)
    pb=[pickle.dumps(x) for x in (tr,va)]
    state=pickle.dumps((np.random.get_state(),random.getstate()))
    return dict(train=tr,val=va,bytes=pb,state=state,elapsed=time.perf_counter()-t)


def main():
    assert bus_data.generator_sha()=="9cc9257513c42302b78c5ff0cb922ecee5465bab552984d3d595a4933dd64b7c"
    rows=[]
    for seed,n in ((451,20),(7000,50),(7000,1000),(4242,50),(4242,1000)):
        cg.clear()
        a=snapshot(seed,n,False)
        b=snapshot(seed,n,True)
        first=cg.stats()
        warm=snapshot(seed,n,True)
        second=cg.stats()
        same=all(x==y for x,y in zip(a["bytes"],b["bytes"])) and a["state"]==b["state"]
        same_warm=all(x==y for x,y in zip(b["bytes"],warm["bytes"])) and b["state"]==warm["state"]
        rows.append(dict(seed=seed,n=n,uncached_s=a["elapsed"],cold_s=b["elapsed"],
                         warm_s=warm["elapsed"],pickle_equal=same,state_equal=a["state"]==b["state"],
                         warm_equal=same_warm,cold_solves=first["solves"],warm_extra_solves=second["solves"]-first["solves"]))
        assert same and same_warm and first["solves"]==1 and second["solves"]==1
    mod=cg._module()
    env=mod.ZurcherEnv(type=0,**{**bus_data.GEN_CONFIG,"num_trajs":1})
    baseline=cg.key(env)
    variants=[("beta",dict(beta=.94)),("theta",dict(theta=[2,5,1])),("type",dict(type=1)),
              ("support",dict(maxMileage=11))]
    inv={}
    for name,updates in variants:
        cfg={**bus_data.GEN_CONFIG,"num_trajs":1,**updates}
        typ=cfg.pop("type",0)
        e=mod.ZurcherEnv(type=typ,**cfg)
        inv[name]=cg.key(e)!=baseline
    for name,modified in (("source","different"),("transition","different"),("tol",1e-9),
                          ("update","different"),("dtype","float32")):
        inv[name]=cg.key(env,**{name:modified})!=baseline
    assert all(inv.values())
    frozen=os.path.expanduser("~/DDC-DPT-fleet/experiments/fleet_capacity_one/artifacts/tuning/bus_pool_seed7000.npz")
    tr,va=cg.generate(7000,1000)
    with tempfile.TemporaryDirectory() as tmp:
        out=os.path.join(tmp,"pool.npz")
        bus_data.export_pool(tr,va,out)
        z1=np.load(out,allow_pickle=False);z2=np.load(frozen,allow_pickle=False)
        fields={k:bool(np.array_equal(z1[k],z2[k])) for k in z1.files}
        chain_hash_equal=hashlib.sha256(z1["chain_hash"].tobytes()).hexdigest()==hashlib.sha256(z2["chain_hash"].tobytes()).hexdigest()
    assert all(fields.values()) and chain_hash_equal
    payload=dict(pass_=True,generator_sha=bus_data.generator_sha(),fixtures=rows,key_invalidation=inv,
                 frozen_seed7000_export_fields=fields,frozen_chain_hash_equal=chain_hash_equal)
    os.makedirs(os.path.dirname(OUT),exist_ok=True)
    with open(OUT+".tmp","w") as f: json.dump(payload,f,indent=2)
    os.replace(OUT+".tmp",OUT)
    print(json.dumps(payload),flush=True)


if __name__=="__main__":
    main()
