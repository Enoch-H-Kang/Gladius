"""Bitwise training switches and production smoke; engineering data only."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import pickle
import random
import tempfile
import time
import numpy as np
import torch
from ...fleet import train
from ...fleet.seeds import expand_seeds
from ...tuning.data_io import load_bus
from ...tuning import bus_data
from .. import cached_generator

ROOT=Path.home()/"DDC-DPT-busrerun"
OUT=ROOT/"results/bus_rerun/proofs"
DEV=Path.home()/"DDC-DPT-fleet/experiments/fleet_capacity_one/artifacts/tuning/bus_pool_seed7000.npz"
SEEDS=expand_seeds("bus","RR","bus_seed7000",0)


def cfg(width=10,cap=20,val_every=2,k=1):
    return dict(loss="none",k=k,lr_q=.001,rho=1.,batch=32,c_be=1.,width=width,depth=2,opt="adamw",
                wd=.0001,bias="anchor",beta=.95,cap_q=cap,val_every=val_every,elig_start=4,
                anchor_tol=.1,grad_clip=1.,lr_decay=10000.)


def numeric_snapshot(data,config,anomaly=False,plot=False,inject_nan=False):
    torch.manual_seed(14)
    np.random.seed(14)
    random.seed(14)
    trace=[]
    plot_calls=0
    original_validate=train.validate
    original_ce=train.ce_term
    def wrapped(*args,**kwargs):
        nonlocal plot_calls
        result=original_validate(*args,**kwargs)
        if plot:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            trace.append(result["nll"])
            fig,ax=plt.subplots()
            ax.plot(trace)
            fig.canvas.draw()
            plt.close(fig)
            plot_calls+=1
        return result
    def bad_ce(*args,**kwargs):
        y=original_ce(*args,**kwargs)
        return y*torch.tensor(float("nan"))
    train.validate=wrapped
    if inject_nan:train.ce_term=bad_ce
    torch.autograd.set_detect_anomaly(anomaly)
    t0=time.perf_counter()
    try:
        with tempfile.TemporaryDirectory() as td:
            draws=[]
            rec=train.fit(data,config,SEEDS,horizons=[config["cap_q"]],ckpt_dir=td,probe=draws)
            h=str(config["cap_q"])
            ck=Path(td)/f"ckpt_h{h}.pt"
            if ck.exists():
                state=torch.load(ck,map_location="cpu",weights_only=False)
                tensor_bytes=pickle.dumps({net:{k:v.numpy().tobytes() for k,v in state[net].items()} for net in ("q","z")})
                from ...fleet.models import MLP
                q=MLP(1,2,config["width"],2);z=MLP(1,2,config["width"],2)
                q.load_state_dict(state["q"]);z.load_state_dict(state["z"])
                x=torch.arange(1,11,dtype=torch.float32).view(-1,1)/10
                pred=(q(x).detach().numpy().tobytes(),z(x).detach().numpy().tobytes())
            else:
                tensor_bytes=b"";pred=(b"",b"")
        numeric=dict(trace=rec["trace"],horizons=rec["horizons"],counts=rec["counts"],
                     fit_status=rec["fit_status"],diverged_at=rec["diverged_at"],draws=draws,
                     tensors_sha=hashlib.sha256(tensor_bytes).hexdigest(),
                     prediction_sha=[hashlib.sha256(x).hexdigest() for x in pred],
                     torch_rng_sha=hashlib.sha256(torch.get_rng_state().numpy().tobytes()).hexdigest(),
                     numpy_rng_sha=hashlib.sha256(pickle.dumps(np.random.get_state())).hexdigest(),
                     python_rng_sha=hashlib.sha256(pickle.dumps(random.getstate())).hexdigest())
        return numeric,plot_calls,time.perf_counter()-t0
    finally:
        train.validate=original_validate
        train.ce_term=original_ce
        torch.autograd.set_detect_anomaly(False)


def compare(a,b):
    return a==b


def save(name,obj):
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/name).write_text(json.dumps(obj,indent=2)+"\n")


def e2(data):
    fixtures=[]
    for width in (50,10):
        c=cfg(width=width)
        a,pa,ta=numeric_snapshot(data,c,plot=True)
        b,pb,tb=numeric_snapshot(data,c,plot=False)
        passed=compare(a,b) and pa>=10 and pb==0
        fixtures.append(dict(width=width,checkpoints=len(a["trace"]),plot_on_calls=pa,plot_off_calls=pb,
                             bitwise_equal=compare(a,b),plot_on_s=ta,plot_off_s=tb,pass_=passed))
    result=dict(pass_=all(x["pass_"] for x in fixtures),fixtures=fixtures,
                source_note="same lock-bound trainer; width-50 fixture uses legacy architecture size, not original legacy training loop")
    save("E2.json",result)
    return result


def e3(data):
    fixtures=[]
    for width in (50,10):
        c=cfg(width=width,cap=20,val_every=2,k=1)
        a,_,ta=numeric_snapshot(data,c,anomaly=True)
        b,_,tb=numeric_snapshot(data,c,anomaly=False)
        fixtures.append(dict(width=width,alternating_updates=a["counts"]["q_updates"]+a["counts"]["z_updates"],
                             bitwise_equal=compare(a,b),anomaly_on_s=ta,anomaly_off_s=tb))
    bad,_,_=numeric_snapshot(data,cfg(),inject_nan=True)
    finite_failure=bad["fit_status"]=="diverged" and bad["diverged_at"] is not None
    result=dict(pass_=all(x["bitwise_equal"] and x["alternating_updates"]==40 for x in fixtures) and finite_failure,
                fixtures=fixtures,nonfinite_failure_recorded=finite_failure,
                source_note="same lock-bound trainer; legacy 2x50 training loop not directly executed")
    save("E3.json",result)
    return result


def production_import_graph():
    root=ROOT/"experiments/fleet_capacity_one"
    todo=[root/"tuning/run_fit.py"]
    seen=set()
    bad=[]
    while todo:
        path=todo.pop()
        if path in seen or not path.exists():continue
        seen.add(path)
        source=path.read_text()
        if "matplotlib" in source or "set_detect_anomaly(" in source or "detect_anomaly(" in source:
            bad.append(str(path))
        tree=ast.parse(source)
        for node in ast.walk(tree):
            if isinstance(node,ast.ImportFrom) and node.level:
                base=path.parent
                for _ in range(node.level-1):base=base.parent
                q=base.joinpath(*((node.module or "").split("."))).with_suffix(".py")
                if q.exists():todo.append(q)
    return dict(files=[str(x) for x in sorted(seen)],bad=bad,pass_=not bad)


def e4(data):
    graph=production_import_graph()
    c=cfg(cap=600,val_every=500,k=10)
    c["elig_start"]=5000
    smoke,plots,elapsed=numeric_snapshot(data,c,anomaly=False,plot=False)
    smoke_ok=smoke["counts"]["q_updates"]==600 and smoke["counts"]["z_updates"]==6000 and plots==0
    # Every switch is replayed alone and in combination on a small end-to-end fixture.
    with tempfile.TemporaryDirectory() as td:
        base_train,base_val=bus_data.generate_pool(451,20,td)
        base_bytes=[pickle.dumps(base_train),pickle.dumps(base_val)]
        cached_generator.clear()
        cache_train,cache_val=cached_generator.generate(451,20)
        data_equal=base_bytes==[pickle.dumps(cache_train),pickle.dumps(cache_val)]
        a=Path(td)/"a.npz";b=Path(td)/"b.npz"
        bus_data.export_pool(base_train,base_val,a)
        bus_data.export_pool(cache_train,cache_val,b)
        with np.load(a,allow_pickle=False) as z1,np.load(b,allow_pickle=False) as z2:
            fields_equal=all(np.array_equal(z1[k],z2[k]) for k in z1.files)
        fixture=load_bus(str(a),20)
    base,_,_=numeric_snapshot(fixture,cfg())
    plot_off,_,_=numeric_snapshot(fixture,cfg(),plot=False)
    anomaly_off,_,_=numeric_snapshot(fixture,cfg(),anomaly=False)
    combined,_,_=numeric_snapshot(fixture,cfg(),plot=False,anomaly=False)
    replay_equal=all(compare(base,x) for x in (plot_off,anomaly_off,combined))
    result=dict(pass_=graph["pass_"] and smoke_ok and data_equal and fields_equal and replay_equal,
                import_graph=graph,smoke=dict(q_updates=smoke["counts"]["q_updates"],z_updates=smoke["counts"]["z_updates"],
                                              elapsed_s=elapsed,plot_calls=plots,finite=smoke_ok),
                combined=dict(pickle_equal=data_equal,export_fields_equal=fields_equal,
                              plot_off_equal=compare(base,plot_off),anomaly_off_equal=compare(base,anomaly_off),
                              joint_equal=compare(base,combined)))
    save("E4.json",result)
    return result


def main():
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    data=load_bus(str(DEV),50)
    results={name:fn(data) for name,fn in (("E2",e2),("E3",e3),("E4",e4))}
    print(json.dumps({k:v["pass_"] for k,v in results.items()}),flush=True)
    if not all(v["pass_"] for v in results.values()):raise SystemExit(1)


if __name__=="__main__":main()
