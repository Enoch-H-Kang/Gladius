"""Detached pilot gate and 240-slot 20,000-pass bus GLADIUS queue."""
import csv
import fcntl
from functools import lru_cache
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

from experiments.fleet_capacity_one.bus_rerun import protocol
from experiments.fleet_capacity_one.bus_rerun.epochs20000_worker import OUT, FITS, atomic_json
from experiments.fleet_capacity_one.bus_rerun.runner import proc_start, project_processes

CAP = 44
MAX_WORKERS = 20
WORKER_TOKENS = 2
BASELINE = {1000: 13.14799730305941, 5000: 13.408273206370726}
PILOT_NS = (1000, 5000)
PILOT_RS = (0, 1)


@lru_cache(maxsize=1)
def prior_metrics():
    path = protocol.RESULT / "fit_metrics_final.csv"
    with path.open(newline="") as f:
        return {r["fit_id"]: r for r in csv.DictReader(f)}


def alive(pid, start):
    return pid and proc_start(int(pid)) == start


def all_specs():
    m = protocol.load_manifest(protocol.RESULT / "manifest_RR.json")
    slots = [s for s in m["fits"] if s["arm"] in ("G-L", "G-A1")]
    assert len(slots) == 240
    pilot = [s for s in slots if s["arm"] == "G-L"
             and s["n"] in PILOT_NS and s["r"] in PILOT_RS]
    assert len(pilot) == 4
    return slots, pilot, m


def terminal_record(fid):
    path = FITS / fid / "record.json"
    marker = FITS / fid / "DONE"
    if not path.exists() and not marker.exists():
        return None
    if path.exists() and not marker.exists():
        return None  # worker may be between atomic record and DONE writes
    if marker.exists() and not path.exists():
        raise RuntimeError(f"DONE without record: {fid}")
    rec = json.loads(path.read_text())
    done = json.loads(marker.read_text())
    if rec.get("fit_id") != fid or done.get("fit_id") != fid or done.get("record_sha256") != protocol.sha(path):
        raise RuntimeError(f"invalid terminal slot: {fid}")
    return rec


def external_reservation():
    ext = []
    for pid, cmd in project_processes():
        if "bus_rerun.epochs20000_worker" in cmd or "bus_rerun.epochs20000_runner" in cmd:
            continue
        if "experiments.fleet_" in cmd or "DDC-DPT-fleet" in cmd:
            ext.append(dict(pid=pid, tokens=38, cmd=cmd[:120]))
        else:
            ext.append(dict(pid=pid, tokens=1, cmd=cmd[:120]))
    return min(CAP, sum(x["tokens"] for x in ext)), ext


def fail_slot(fid, message):
    out = FITS / fid
    out.mkdir(parents=True, exist_ok=True)
    if terminal_record(fid) is not None:
        return
    existing = out / "record.json"
    if existing.exists():
        rec = json.loads(existing.read_text())
        if rec.get("fit_id") != fid or rec.get("status") not in ("ok", "nonfinite", "resource_fail"):
            raise RuntimeError(f"invalid partial record: {fid}")
        atomic_json(out / "DONE", dict(fit_id=fid, status=rec["status"],
                                      record_sha256=protocol.sha(existing)))
        return
    rec = dict(fit_id=fid, status="resource_fail", error=message, end_unix=time.time())
    atomic_json(out / "record.json", rec)
    atomic_json(out / "DONE", dict(fit_id=fid, status="resource_fail",
                                  record_sha256=protocol.sha(out / "record.json")))


def summary(slots, pilot, phase, start_unix, active, admissions, verdict=None):
    records = {s["fit_id"]: terminal_record(s["fit_id"]) for s in slots}
    rows = []
    for arm in ("G-L", "G-A1"):
        for n in protocol.SIZES:
            rr = [records[s["fit_id"]] for s in slots if s["arm"] == arm and s["n"] == n]
            ok = [r for r in rr if r and r.get("status") == "ok"]
            values = [r["best"]["keep_mape"] for r in ok]
            mean = statistics.mean(values) if values else None
            se = statistics.stdev(values) / math.sqrt(len(values)) if len(values) > 1 else None
            rows.append(dict(arm=arm, n=n, scheduled=20, completed=sum(r is not None for r in rr),
                             ok=len(ok), failed=sum(r is not None and r.get("status") != "ok" for r in rr),
                             keep_mape_mean=mean, keep_mape_se=se))
    path = OUT / "per_n_mean_se.csv"
    temp = path.with_suffix(".csv.tmp")
    with temp.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    os.replace(temp, path)
    p = []
    for s in pilot:
        r = records[s["fit_id"]]
        prior = prior_metrics()[s["fit_id"]]
        progress = FITS / s["fit_id"] / "progress.json"
        pg = json.loads(progress.read_text()) if progress.exists() else None
        p.append(dict(fit_id=s["fit_id"], n=s["n"], r=s["r"],
                      status=r.get("status") if r else "running" if s["fit_id"] in active else "queued",
                      wall_seconds=r.get("elapsed_wall") if r else pg.get("elapsed_wall") if pg else None,
                      keep_mape=(r.get("best") or {}).get("keep_mape") if r else None,
                      best_epoch=(r.get("best") or {}).get("epoch") if r else None,
                      best_step=(r.get("best") or {}).get("step") if r else None,
                      progress=pg, baseline_50k=BASELINE[s["n"]],
                      prior_50k_keep_mape=float(prior["keep_mape"]),
                      prior_50k_status=prior["status"]))
    atomic_json(OUT / "PILOT.json", dict(verdict=verdict, fits=p, baseline_50k=BASELINE))
    done = sum(r is not None for r in records.values())
    projected = []
    for s in slots:
        r = records[s["fit_id"]]
        if r and r.get("target_steps") and r.get("elapsed_wall"):
            k = 10 if r["arm"] == "G-L" else 1
            projected.append(r["elapsed_wall"] / (r["target_steps"] * (k + 1)))
    for s in pilot:
        pg_path = FITS / s["fit_id"] / "progress.json"
        if pg_path.exists():
            pg = json.loads(pg_path.read_text())
            if pg.get("step", 0) > 0 and pg.get("elapsed_wall"):
                projected.append(pg["elapsed_wall"] / (pg["step"] * 11))
    sec_per_update_unit = statistics.median(projected) if projected else None
    remaining_units = 0
    pilot_remaining_units = []
    longest_remaining_units = 0
    for s in slots:
        if records[s["fit_id"]] is not None:
            continue
        train_rows = 80 * s["n"]
        target = math.ceil(20000 * train_rows / 1024)
        pg_path = FITS / s["fit_id"] / "progress.json"
        step = json.loads(pg_path.read_text()).get("step", 0) if pg_path.exists() else 0
        units = max(0, target - step) * (11 if s["arm"] == "G-L" else 2)
        remaining_units += units
        longest_remaining_units = max(longest_remaining_units, units)
        if s["fit_id"] in {p["fit_id"] for p in pilot}:
            pilot_remaining_units.append(units)
    eta = None
    pilot_eta = None
    if sec_per_update_unit:
        if phase == "pilot":
            pilot_units = max(pilot_remaining_units, default=0)
            pilot_eta = time.time() + pilot_units * sec_per_update_unit
            rollout_units = remaining_units - sum(pilot_remaining_units)
            eta = pilot_eta + max(rollout_units / MAX_WORKERS, longest_remaining_units) * sec_per_update_unit
        else:
            eta = time.time() + max(remaining_units / MAX_WORKERS, longest_remaining_units) * sec_per_update_unit
    body = dict(phase=phase, unix=time.time(), started_unix=start_unix, pilot_verdict=verdict,
                scheduled=240, terminal=done, ok=sum(r is not None and r.get("status") == "ok" for r in records.values()),
                failed=sum(r is not None and r.get("status") != "ok" for r in records.values()),
                active=len(active), admitted=len(admissions), queued=240-done-len(active),
                cap=CAP, max_workers=MAX_WORKERS, worker_thread_reservation=WORKER_TOKENS,
                rough_pilot_eta_unix=pilot_eta, rough_eta_unix=eta,
                eta_note="rough projection from observed G-L update rate, with 20-worker rollout" if eta else None)
    atomic_json(OUT / "STATUS.json", body)
    return records, body


def pilot_gate(pilot, records):
    rr = [records[s["fit_id"]] for s in pilot]
    if not all(rr):
        return None
    if any(r.get("status") != "ok" for r in rr):
        return dict(rollout=False, reason="one or more pilot fits failed or diverged")
    if any(r.get("elapsed_wall", 1e99) > (24 if r["n"] == 1000 else 72) * 3600 for r in rr):
        return dict(rollout=False, reason="pilot wall time exceeds 24h (N=1000) or 72h (N=5000)")
    for n in PILOT_NS:
        vals = [r["best"]["keep_mape"] for r in rr if r["n"] == n]
        if all(v > 2 * BASELINE[n] for v in vals):
            return dict(rollout=False, reason=f"systematic pilot MAPE blowup at N={n}")
    return dict(rollout=True, reason="four finite pilot fits; wall times feasible; no systematic MAPE blowup")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    FITS.mkdir(parents=True, exist_ok=True)
    lock = (OUT / "controller.lock").open("a+")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    slots, pilot, old = all_specs()
    byid = {s["fit_id"]: s for s in slots}
    admissions_path = OUT / "admissions.json"
    admissions = json.loads(admissions_path.read_text()) if admissions_path.exists() else {}
    if set(admissions) - set(byid):
        raise RuntimeError("unknown admitted slot")
    active = {}
    for fid, item in admissions.items():
        if terminal_record(fid) is None:
            if alive(item["pid"], item["pid_start"]):
                active[fid] = item
            else:
                fail_slot(fid, "previously admitted worker exited without DONE; slot retained")
    start_unix = time.time()
    phase = "pilot"
    verdict = None
    events = OUT / "events.jsonl"
    while True:
        for fid, item in list(active.items()):
            if terminal_record(fid) is not None:
                del active[fid]
            elif not alive(item["pid"], item["pid_start"]):
                fail_slot(fid, "worker exited without DONE; slot retained")
                del active[fid]
        records, _ = summary(slots, pilot, phase, start_unix, active, admissions, verdict)
        verdict = pilot_gate(pilot, records)
        if verdict is not None:
            phase = "rollout" if verdict["rollout"] else "stopped_after_pilot"
        if phase == "stopped_after_pilot":
            summary(slots, pilot, phase, start_unix, active, admissions, verdict)
            break
        eligible = pilot if phase == "pilot" else slots
        pending = [s for s in eligible if s["fit_id"] not in admissions and records[s["fit_id"]] is None]
        ext, external = external_reservation()
        while pending and len(active) < MAX_WORKERS and ext + 1 + WORKER_TOKENS * (len(active) + 1) <= CAP:
            s = pending.pop(0)
            fid = s["fit_id"]
            log = (OUT / (fid + ".log")).open("a")
            env = dict(os.environ, OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
                       OPENBLAS_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1",
                       PYTHONHASHSEED="0", CUDA_VISIBLE_DEVICES="")
            proc = subprocess.Popen(["nice", "-n", "10", sys.executable, "-m",
                                     "experiments.fleet_capacity_one.bus_rerun.epochs20000_worker", fid],
                                    cwd=protocol.ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                                    start_new_session=True)
            item = dict(pid=proc.pid, pid_start=proc_start(proc.pid), admitted_unix=time.time())
            if not item["pid_start"]:
                raise RuntimeError("could not capture worker PID start")
            admissions[fid] = item
            active[fid] = item
            atomic_json(admissions_path, admissions)
            with events.open("a") as f:
                f.write(json.dumps(dict(event="admit", unix=time.time(), fit_id=fid, **item)) + "\n")
        records, status = summary(slots, pilot, phase, start_unix, active, admissions, verdict)
        atomic_json(OUT / "reservations.json", dict(unix=time.time(), cap=CAP,
                    controller_pid=os.getpid(), external_reserved=ext, external=external,
                    workers=active, worker_thread_reservation=WORKER_TOKENS,
                    total_reserved=ext+1+WORKER_TOKENS*len(active)))
        if status["terminal"] == 240:
            phase = "complete"
            summary(slots, pilot, phase, start_unix, active, admissions, verdict)
            break
        time.sleep(30)
    (OUT / "DONE").write_text(json.dumps(dict(phase=phase, unix=time.time(), verdict=verdict)) + "\n")


if __name__ == "__main__":
    main()
