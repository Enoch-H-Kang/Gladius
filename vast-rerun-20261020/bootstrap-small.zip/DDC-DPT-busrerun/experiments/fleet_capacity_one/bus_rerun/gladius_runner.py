"""Detached, resumable GLADIUS queue for the sealed bus rerun."""
import csv
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from experiments.fleet_capacity_one.bus_rerun import protocol
from experiments.fleet_capacity_one.bus_rerun.runner import project_processes, proc_start, usage_snapshot

CAP = 44
MAX_WORKERS = 40


def other_reservation():
    """Reserve only live project jobs; the fleet stage is currently blocked."""
    fleet = []
    other = []
    for pid, cmd in project_processes():
        if "bus_rerun.gladius_runner" in cmd or "bus_rerun.gladius_worker" in cmd:
            continue
        if "experiments.fleet_" in cmd or "DDC-DPT-fleet" in cmd:
            fleet.append(pid)
        else:
            other.append(pid)
    live = [dict(pid=pid, kind="fleet", tokens=38) for pid in fleet]
    live += [dict(pid=pid, kind="other", tokens=1) for pid in other]
    return (38 if fleet else 0) + len(other), live


def completed_slots(slots, fits, event_path):
    """Validate every old admission before making a new one."""
    admitted = set()
    if event_path.exists():
        with event_path.open(newline="") as ef:
            for row in csv.DictReader(ef):
                if row["event"] == "admit":
                    fid = row["fit_id"]
                    if fid in admitted:
                        raise RuntimeError(f"duplicate prior admission: {fid}")
                    admitted.add(fid)
    ids = {s["fit_id"] for s in slots}
    if not admitted <= ids:
        raise RuntimeError("GLADIUS ledger contains an unknown fit ID")
    terminal = set()
    for fid in ids:
        record = fits / fid / "record.json"
        done = fits / fid / "DONE"
        if not record.exists() and not done.exists():
            continue
        if not record.exists() or not done.exists():
            raise RuntimeError(f"partial terminal slot: {fid}")
        marker = json.loads(done.read_text())
        rec = json.loads(record.read_text())
        if (marker.get("fit_id") != fid or rec.get("fit_id") != fid or
                marker.get("record_sha256") != protocol.sha(record) or
                marker.get("status") != rec.get("status")):
            raise RuntimeError(f"invalid terminal slot: {fid}")
        terminal.add(fid)
    if terminal != admitted:
        raise RuntimeError(f"old admissions need reconciliation: missing={sorted(admitted-terminal)}, unexpected={sorted(terminal-admitted)}")
    return terminal


def main():
    root = protocol.ROOT
    manifest = protocol.RESULT / "manifest_RR.json"
    ledger = protocol.RESULT / "ledger"
    fits = root / "artifacts/bus_rerun/fits"
    m = protocol.load_manifest(manifest)
    protocol.lock()
    slots = [s for s in m["fits"] if s["arm"] in ("G-L", "G-A1")]
    if len(slots) != 240:
        raise ValueError("expected 240 GLADIUS slots")
    # Alternate arms, then sample sizes and repetitions in sealed order.
    left = [s for s in slots if s["arm"] == "G-L"]
    right = [s for s in slots if s["arm"] == "G-A1"]
    roster = ledger / "gladius_reservations.json"
    event_path = ledger / "gladius_events.csv"
    usage_path = ledger / "gladius_usage.csv"
    terminal = completed_slots(slots, fits, event_path)
    pending = [s for pair in zip(left, right) for s in pair if s["fit_id"] not in terminal]
    active = {}
    start = time.time()
    with event_path.open("a", newline="") as ef, usage_path.open("a", newline="") as uf:
        ew, uw = csv.writer(ef), csv.writer(uf)
        if event_path.stat().st_size == 0:
            ew.writerow(["unix", "event", "fit_id", "pid", "pid_start", "detail"])
        if usage_path.stat().st_size == 0:
            uw.writerow(["unix", "workers", "queued", "terminal", "external_reserved", "total_reserved", "project_nlwp"])
        ew.writerow([time.time(), "resume", "", os.getpid(), proc_start(os.getpid()),
                     f"terminal={len(terminal)};max_workers={MAX_WORKERS}"])
        ef.flush()
        while pending or active:
            with (ledger / "admission.lock").open("a+") as lf:
                fcntl.flock(lf, fcntl.LOCK_EX)
                for fid, (proc, st) in list(active.items()):
                    rc = proc.poll()
                    if rc is None:
                        continue
                    if not (fits / fid / "DONE").exists():
                        # A killed process still consumes its original slot; never rerun it.
                        out = fits / fid
                        out.mkdir(parents=True, exist_ok=True)
                        record = out / "record.json"
                        if record.exists():
                            rec = json.loads(record.read_text())
                            if rec.get("fit_id") != fid or "status" not in rec:
                                raise RuntimeError(f"invalid unfinished record: {fid}")
                        else:
                            rec = dict(fit_id=fid, status="resource_fail", native_status="worker_exit",
                                       exit_code=rc, manifest_sha256=m["sha256"])
                            record.write_text(json.dumps(rec) + "\n")
                        (out / "DONE").write_text(json.dumps(dict(fit_id=fid, status=rec["status"],
                            record_sha256=protocol.sha(record))) + "\n")
                    ew.writerow([time.time(), "release", fid, proc.pid, st, f"rc={rc}"])
                    del active[fid]
                external, live = other_reservation()
                if external + 1 + len(active) > CAP:
                    raise RuntimeError("thread reservation exceeded cap; inspect external job")
                while pending and len(active) < MAX_WORKERS and external + 1 + len(active) + 1 <= CAP:
                    spec = pending.pop(0)
                    fid = spec["fit_id"]
                    log = (ledger / (fid + ".log")).open("w")
                    env = dict(os.environ, OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
                               OPENBLAS_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1",
                               PYTHONHASHSEED="0", CUDA_VISIBLE_DEVICES="")
                    proc = subprocess.Popen(["nice", "-n", "10", sys.executable,
                        "-m", "experiments.fleet_capacity_one.bus_rerun.gladius_worker",
                        str(manifest), fid], cwd=root, env=env,
                        stdout=log, stderr=subprocess.STDOUT)
                    st = proc_start(proc.pid)
                    active[fid] = (proc, st)
                    ew.writerow([time.time(), "admit", fid, proc.pid, st, ""])
                body = dict(unix=time.time(), controller=dict(pid=os.getpid(),
                    pid_start=proc_start(os.getpid()), tokens=1), external_fixed_reservation=0,
                    external_reserved=external, external_live=live, cap=CAP,
                    workers=[dict(fit_id=fid, pid=p.pid, pid_start=st, tokens=1)
                             for fid, (p, st) in active.items()], queued=len(pending),
                    terminal=240-len(pending)-len(active), total_reserved=external+1+len(active))
                tmp = roster.with_suffix(".json.tmp")
                tmp.write_text(json.dumps(body, indent=2) + "\n")
                os.replace(tmp, roster)
                fcntl.flock(lf, fcntl.LOCK_UN)
            project_nlwp = sum(p["nlwp"] for p in usage_snapshot())
            uw.writerow([time.time(), len(active), len(pending), body["terminal"],
                         external, body["total_reserved"], project_nlwp])
            uf.flush(); ef.flush()
            if pending or active:
                time.sleep(15)
    summary = dict(manifest_sha256=m["sha256"], scheduled=240, terminal=240,
                   elapsed_wall=time.time()-start, cap=CAP, fleet_reserved=0,
                   max_workers=MAX_WORKERS)
    (ledger / "gladius_accounting.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
