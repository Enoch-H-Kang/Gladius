"""One immutable 20,000-pass bus GLADIUS slot."""
import hashlib
import json
import os
from pathlib import Path
import resource
import socket
import sys
import time
import traceback

from experiments.fleet_capacity_one.bus_rerun import protocol
from experiments.fleet_capacity_one.bus_rerun.epochs20000_train import fit_epoch_oracle
from experiments.fleet_capacity_one.tuning.data_io import load_bus
from experiments.fleet_capacity_one.tuning.run_fit import code_hash

OUT = protocol.RESULT / "epochs20000"
FITS = protocol.ROOT / "artifacts/bus_rerun/epochs20000/fits"


def atomic_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, allow_nan=False) + "\n")
    os.replace(tmp, path)


def main(fit_id):
    old = protocol.load_manifest(protocol.RESULT / "manifest_RR.json")
    specs = {s["fit_id"]: s for s in old["fits"] if s["arm"] in ("G-L", "G-A1")}
    spec = specs[fit_id]
    lock = protocol.lock()
    if spec["code_hash"] != code_hash() or spec["lock_sha256"] != lock["sha256"]:
        raise ValueError("shared trainer or lock identity changed")
    expected = dict(lock["design"])
    expected["N"] = 100 * spec["n"]
    if spec["arm"] == "G-A1":
        expected["k"] = 1
    if spec["config"] != expected:
        raise ValueError("50k settings differ from sealed lock")
    export = protocol.DATA / (spec["data_id"] + ".npz")
    if protocol.sha(export) != spec["export_sha256"]:
        raise ValueError("frozen export hash mismatch")
    out = FITS / fit_id
    out.mkdir(parents=True, exist_ok=True)
    if (out / "DONE").exists() or (out / "record.json").exists():
        raise RuntimeError("slot already terminal")
    started = time.time()
    base = dict(fit_id=fit_id, arm=spec["arm"], n=spec["n"], r=spec["r"],
                data_id=spec["data_id"], old_manifest_sha256=old["sha256"],
                export_sha256=spec["export_sha256"], lock_sha256=lock["sha256"],
                shared_code_hash=code_hash(), seeds=spec["seeds"],
                host=socket.gethostname(), pid=os.getpid(), start_unix=started,
                env_threads={k: os.environ.get(k) for k in
                             ("OMP_NUM_THREADS", "MKL_NUM_THREADS",
                              "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS")})
    try:
        data = load_bus(str(export), spec["n_chains"])
        cfg = {k: v for k, v in expected.items() if k != "N"}
        result = fit_epoch_oracle(data, cfg, spec["seeds"], out, out / "progress.json")
        best = result["best"]
        if result["fit_status"] == "complete" and best is not None:
            import torch
            ckpt = torch.load(out / "ckpt_best.pt", map_location="cpu", weights_only=False)
            if ckpt["step"] != best["step"] or ckpt["hash"] != best["hash"]:
                raise ValueError("saved best checkpoint mismatch")
            status = "ok"
        else:
            status = "nonfinite"
        rec = {**base, **result, "status": status,
               "n_train_chains": data["n_train_chains"],
               "n_val_chains": data["n_val_chains"],
               "n_train_rows": len(data["train"]["a"]),
               "checkpoint_sha256": protocol.sha(out / "ckpt_best.pt") if best else None}
    except Exception as exc:
        traceback.print_exc()
        rec = {**base, "status": "resource_fail", "error": str(exc),
               "traceback": traceback.format_exc()}
    rec.update(end_unix=time.time(), elapsed_wall=time.time() - started,
               rss_kb=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    atomic_json(out / "record.json", rec)
    atomic_json(out / "DONE", dict(fit_id=fit_id, status=rec["status"],
                                  record_sha256=protocol.sha(out / "record.json")))
    print(json.dumps(dict(fit_id=fit_id, status=rec["status"],
                          elapsed_wall=rec["elapsed_wall"],
                          best=rec.get("best"))), flush=True)


if __name__ == "__main__":
    main(sys.argv[1])
