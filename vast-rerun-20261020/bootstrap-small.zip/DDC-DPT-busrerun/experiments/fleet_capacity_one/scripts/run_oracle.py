"""Solve the K ladder; save V_K (float64 .npy) + meta json; recompute the residual on the RELOADED V."""
import json
import os
import sys
import time

import numpy as np

from experiments.fleet_capacity_one.fleet import oracle
from experiments.fleet_capacity_one.fleet.params import Params

PKG = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
ODIR = os.path.join(PKG, "artifacts", "oracle")


def main(Ks):
    os.makedirs(ODIR, exist_ok=True)
    p = Params.from_json(os.path.join(PKG, "configs", "dgp.json"))
    cfg = json.load(open(os.path.join(PKG, "configs", "oracle.json")))
    for K in Ks:
        log = lambda m: print(time.strftime("%H:%M:%S"), m, flush=True)
        res = oracle.solve_vi(p, K, tol=cfg["vi_tol"], max_sweeps=cfg["max_sweeps"], log=log)
        path = os.path.join(ODIR, f"V_K{K}.npy")
        np.save(path, res["V"])
        V = np.load(path)
        t = time.time()
        resid = oracle.residual(V, p, K)
        meta = {"K": K, "dgp_id": p.dgp_id, "sweeps": res["sweeps"], "converged": res["converged"],
                "dV_last": res["dV_last"], "vi_wall_s": res["wall_s"], "saved_V_residual": resid,
                "residual_ok": resid <= cfg["saved_residual_tol"], "resid_wall_s": time.time() - t,
                "V_min": float(V.min()), "V_max": float(V.max()), "dV_hist_head": res["dV_hist"][:5]}
        json.dump(meta, open(os.path.join(ODIR, f"meta_K{K}.json"), "w"), indent=1)
        log(f"K={K} done: {json.dumps(meta)}")
        open(os.path.join(ODIR, f"DONE_K{K}"), "w").write("ok\n")


if __name__ == "__main__":
    main([int(k) for k in sys.argv[1:]])
