"""G1 evidence: key numbers behind the unit tests + full unittest run -> results/gates/G1.txt"""
import itertools
import os
import subprocess
import sys

import numpy as np

from experiments.fleet_capacity_one.fleet import anchor, env, kernels, oracle
from experiments.fleet_capacity_one.fleet.params import Params
from experiments.fleet_capacity_one.fleet.rewards import reward_all
from experiments.fleet_capacity_one.tests.test_kernels import XS, quad_row

PKG = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
ROOT = os.path.abspath(os.path.join(PKG, "..", ".."))
P = Params.from_json(os.path.join(PKG, "configs", "dgp.json"))


def main():
    L = []
    w = L.append
    w(f"dgp_id {P.dgp_id}")
    w(f"r0(0) = {float(anchor.r0_np(np.zeros(5), P.arr('u'), P.arr('v')))!r}   r0(1) = {float(anchor.r0_np(np.ones(5), P.arr('u'), P.arr('v')))!r}")
    rs = max(np.abs(kernels.kernel_matrix(K, P.shape, P.scale[j]).sum(1) - 1).max() for K in (7, 31, 101) for j in range(5))
    mn = min(kernels.kernel_matrix(K, P.shape, P.scale[j]).min() for K in (7, 31, 101) for j in range(5))
    w(f"kernel max |row sum - 1| over K in (7,31,101), 5 buses = {rs:.2e}; min weight = {mn:.2e}; clip log = {kernels.CLIP_LOG}")
    x = np.concatenate([XS, np.random.default_rng(1).uniform(size=2000)])
    mi = max(np.abs(kernels.hat_rows(x, K, P.shape, P.scale[j]) @ np.linspace(0, 1, K) - kernels.expected_next(x, P.shape, P.scale[j])).max()
             for K in (7, 31) for j in range(5))
    w(f"mean identity max |sum g_k w_k - E[min(1,x+D)]| = {mi:.2e}")
    worst = 0.0
    for K in (5, 11, 31):
        for j in range(5):
            ww = kernels.hat_rows(XS, K, P.shape, P.scale[j])
            for i, xx in enumerate(XS):
                worst = max(worst, np.abs(ww[i] - quad_row(xx, K, P.shape, P.scale[j])).max())
    w(f"quad agreement (K 5/11/31, 5 buses, x incl. 1-1e-6, 0.999, 1.0) max abs diff = {worst:.2e}")
    p = P.replace(beta=0.0)
    res = oracle.solve_vi(p, 5, tol=1e-14)
    g = oracle.grid(5)
    S = np.array(list(itertools.product(g, repeat=5)))
    w(f"V1 beta=0: max|Q - r| = {np.abs(oracle.node_Q(res['V'], p, 5) - reward_all(S, p).reshape((5,)*5 + (6,))).max():.2e}")
    z = oracle.solve_vi(P, 4, tol=1e-13, reward_mult=0.0)
    w(f"V1 zero reward: max|V - log6/(1-beta)| = {np.abs(z['V'] - np.log(6)/(1-P.beta)).max():.2e}  (log6/(1-beta) = {np.log(6)/(1-P.beta):.10f})")
    r = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "experiments/fleet_capacity_one/tests", "-t", ".", "-v"],
                       cwd=ROOT, capture_output=True, text=True)
    w("---- unittest discover -v (stderr) ----")
    w(r.stderr)
    with open(os.path.join(PKG, "results", "gates", "G1.txt"), "w") as fh:
        fh.write("\n".join(L) + "\n")
    print("\n".join(L[:12]))
    return r.returncode


if __name__ == "__main__":
    sys.exit(main())
