"""G0 evidence: interpreter, versions, no CUDA, disk, unittest discovery."""
import json
import os
import shutil
import subprocess
import sys
import time

os.environ.setdefault("CUDA_VISIBLE_DEVICES", "")
import numpy
import scipy
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
ROOT = os.path.abspath(os.path.join(PKG, "..", ".."))
EXPECT_PY = os.path.expanduser("~/miniconda3/envs/gym/bin/python")


def main():
    r = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "experiments/fleet_capacity_one/tests",
                        "-t", "."], cwd=ROOT, capture_output=True, text=True,
                       env={**os.environ, "PYTHONPATH": ROOT})
    tail = (r.stderr or "").strip().splitlines()[-3:]
    n_tests = None
    for line in tail:
        if line.startswith("Ran "):
            n_tests = int(line.split()[1])
    free_gb = shutil.disk_usage(os.path.expanduser("~")).free / 1e9
    br = subprocess.run(["git", "-C", ROOT, "rev-parse", "--abbrev-ref", "HEAD"], capture_output=True, text=True).stdout.strip()
    base = subprocess.run(["git", "-C", ROOT, "merge-base", "HEAD", "main"], capture_output=True, text=True).stdout.strip()
    ev = {
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "sys_executable": sys.executable,
        "interpreter_is_gym_env": os.path.realpath(sys.executable) == os.path.realpath(EXPECT_PY),
        "python": sys.version.split()[0],
        "torch": torch.__version__, "numpy": numpy.__version__, "scipy": scipy.__version__,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "torch_cuda_available_with_env": torch.cuda.is_available(),
        "disk_free_gb_home": round(free_gb, 1),
        "git_branch": br, "git_merge_base_main": base,
        "unittest_returncode": r.returncode, "unittest_tail": tail, "unittest_tests_run": n_tests,
    }
    ev["pass"] = bool(ev["interpreter_is_gym_env"] and ev["torch"].startswith("2.5.1") and not ev["torch_cuda_available_with_env"]
                      and free_gb > 50 and br == "fleet-capacity-one" and n_tests is not None and n_tests > 0
                      and r.returncode == 0)
    out = os.path.join(PKG, "results", "gates", "G0.json")
    with open(out, "w") as fh:
        json.dump(ev, fh, indent=1)
    print(json.dumps(ev, indent=1))
    return 0 if ev["pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
