"""Timing probe: sweeps/s at K and lookahead queries/s. Writes results/gates/timing_probe_K{K}.json"""
import json
import os
import sys
import time

import numpy as np

from experiments.fleet_capacity_one.fleet import oracle
from experiments.fleet_capacity_one.fleet.params import Params

PKG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")


def main(K, n_sweeps=5):
    p = Params.from_json(os.path.join(PKG, "configs", "dgp.json"))
    Ps = oracle.kernel_list(p, K)
    r0, delta = oracle.reward_grids(p, K)
    V = r0 / (1 - p.beta)
    t = time.time()
    for _ in range(n_sweeps):
        V, _ = oracle.bellman(V, p, Ps, r0, delta)
    sweep_s = (time.time() - t) / n_sweeps
    out = {"K": K, "threads_env": os.environ.get("OMP_NUM_THREADS"), "sweep_s": sweep_s}
    rng = np.random.default_rng(0)
    for dtype in (np.float64, np.float32):
        x = rng.uniform(size=(2048, 5))
        t = time.time()
        oracle.lookahead_Q(x, V, p, dtype=dtype)
        out[f"query_s_per_state_{np.dtype(dtype).name}"] = (time.time() - t) / 2048
    out["projected_vi_400_sweeps_s"] = 400 * sweep_s
    print(json.dumps(out, indent=1))
    with open(os.path.join(PKG, "results", "gates", f"timing_probe_K{K}.json"), "w") as fh:
        json.dump(out, fh, indent=1)


if __name__ == "__main__":
    main(int(sys.argv[1]))
