"""Gate A validation V2-V7. Usage: validate_oracle.py <stage> [args]. Outputs go to results/gates/oracle_diagnostics/."""
import json
import os
import sys
import time

import numpy as np
from scipy import stats
from scipy.special import logsumexp

from experiments.fleet_capacity_one.fleet import env, evalsets, kernels, oracle
from experiments.fleet_capacity_one.fleet.params import Params
from experiments.fleet_capacity_one.fleet.rewards import reward_all

PKG = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
ODIR = os.path.join(PKG, "artifacts", "oracle")
DDIR = os.path.join(PKG, "results", "gates", "oracle_diagnostics")
P = Params.from_json(os.path.join(PKG, "configs", "dgp.json"))
CFG = json.load(open(os.path.join(PKG, "configs", "oracle.json")))
LADDER, KREF = CFG["ladder"], CFG["K_ref"]
if os.environ.get("FLEET_TEST_KREF"):  # pipeline smoke test only: scratch dirs, smaller reference
    KREF = int(os.environ["FLEET_TEST_KREF"])
    LADDER = [k for k in LADDER if k <= KREF]
    ODIR = os.path.join(PKG, "artifacts", "scratch_oracle")
    DDIR = os.path.join(PKG, "artifacts", "scratch_diag")
SEEDS = CFG["seeds"]


def log(m):
    print(time.strftime("%H:%M:%S"), m, flush=True)


def loadV(K):
    return np.load(os.path.join(ODIR, f"V_K{K}.npy"))


def dump(name, obj):
    os.makedirs(DDIR, exist_ok=True)
    with open(os.path.join(DDIR, name), "w") as fh:
        json.dump(obj, fh, indent=1, default=lambda o: o.tolist() if isinstance(o, np.ndarray) else float(o))


def get_evalsets():
    path = os.path.join(ODIR, "evalsets.npz")
    if os.path.exists(path):
        z = np.load(path)
        return {k: z[k] for k in z.files}
    VR = loadV(KREF)
    sets = {"occ": evalsets.occupancy_states(VR, P, SEEDS["occupancy_chains"]),
            "uni": evalsets.uniform_states(10000, P.F, SEEDS["uniform"]),
            "face": evalsets.face_states(1024, P.F, SEEDS["face"])}
    np.savez(path, **sets)
    return sets


# ---------------------------------------------------------------- V2
def v2():
    sets = get_evalsets()
    names = list(sets)
    allS = np.concatenate([sets[k] for k in names])
    bounds = np.cumsum([0] + [len(sets[k]) for k in names])
    Q = {}
    for K in LADDER:
        path = os.path.join(ODIR, f"Qeval_K{K}.npy")
        if os.path.exists(path):
            Q[K] = np.load(path)
            continue
        t = time.time()
        Q[K] = oracle.lookahead_Q(allS, loadV(K), P)
        np.save(path, Q[K])
        log(f"Qeval K={K} {time.time() - t:.1f}s")
    h = {K: 1.0 / (K - 1) for K in LADDER}
    KPREV = max(k for k in LADDER if k < KREF)
    out = {"groups": {}, "ladder": LADDER, "K_ref": KREF}
    dQ = lambda q: q[:, 1:] - q[:, :1]
    for gi, g in enumerate(names):
        sl = slice(bounds[gi], bounds[gi + 1])
        ref = Q[KREF][sl]
        pref = oracle.softmax(ref)
        srt = np.sort(ref, 1)
        wide = (srt[:, -1] - srt[:, -2]) > 0.1
        rows = {}
        for K in LADDER:
            if K == KREF:
                continue
            q = Q[K][sl]
            pk = oracle.softmax(q)
            kl = np.sum(pref * (np.log(pref + 1e-300) - np.log(pk + 1e-300)), 1)
            tv = 0.5 * np.abs(pref - pk).sum(1)
            agree_all = (q.argmax(1) == ref.argmax(1))
            rows[K] = {"rmse_Q": float(np.sqrt(np.mean((q - ref) ** 2))), "max_Q": float(np.abs(q - ref).max()),
                       "rmse_dQ": float(np.sqrt(np.mean((dQ(q) - dQ(ref)) ** 2))), "max_dQ": float(np.abs(dQ(q) - dQ(ref)).max()),
                       "KL_ref_to_K": float(kl.mean()), "TV_mean": float(tv.mean()), "TV_p95": float(np.quantile(tv, 0.95)),
                       "top_agree_gap>0.1": float(agree_all[wide].mean()) if wide.any() else None,
                       "n_gap>0.1": int(wide.sum()), "top_agree_all": float(agree_all.mean())}
        out["groups"][g] = {"n": int(sl.stop - sl.start), "vs_ref": rows}
        Ks = [K for K in LADDER if K != KREF]
        lh = np.log([h[K] for K in Ks])
        fits = {}
        for key in ("rmse_Q", "rmse_dQ"):
            e = np.log([rows[K][key] for K in Ks])
            slope, icpt = np.polyfit(lh, e, 1)
            fits[key] = {"p_all": float(slope)}
            # fit also on the finer part of the ladder (K>=11), less contaminated by pre-asymptotic effects
            sel = [i for i, K in enumerate(Ks) if K >= 11]
            fits[key]["p_K>=11"] = float(np.polyfit(lh[sel], e[sel], 1)[0])
            fits[key]["p_K>=17"] = float(np.polyfit(lh[[i for i, K in enumerate(Ks) if K >= 17]], e[[i for i, K in enumerate(Ks) if K >= 17]], 1)[0])
        # three-level (Cauchy) orders: ratio of successive differences
        tri = {}
        for (a, b, c) in [t3 for t3 in [(13, 17, 21), (17, 21, 25), (21, 25, 31), (17, 25, 31)] if all(k in Q for k in t3)]:
            e1 = np.sqrt(np.mean((Q[a][sl] - Q[b][sl]) ** 2)); e2 = np.sqrt(np.mean((Q[b][sl] - Q[c][sl]) ** 2))
            ra = e1 / e2
            fn = lambda pp: (h[a] ** pp - h[b] ** pp) / (h[b] ** pp - h[c] ** pp) - ra
            try:
                from scipy.optimize import brentq
                tri[f"{a},{b},{c}"] = float(brentq(fn, 0.2, 6.0))
            except Exception:
                tri[f"{a},{b},{c}"] = None
        fits["three_level_p"] = tri
        out["groups"][g]["order_fits"] = fits
        # Richardson error estimate at K_ref from K=25 vs 31, with fitted p (K>=11 fit) and fixed p=2
        ric = {}
        for label, pp in (("p_fit_K>=11", fits["rmse_Q"]["p_K>=11"]), ("p=2", 2.0)):
            fac = 1.0 / ((h[KPREV] / h[KREF]) ** pp - 1.0)
            err = (Q[KPREV][sl] - ref) * fac   # estimate of (Q_ref - Q*) up to sign
            ric[label] = {"p": float(pp), "rmse_Q": float(np.sqrt(np.mean(err ** 2))), "max_Q": float(np.abs(err).max()),
                          "rmse_dQ": float(np.sqrt(np.mean(dQ(err) ** 2))), "max_dQ": float(np.abs(dQ(err)).max())}
        out["groups"][g]["richardson_at_Kref"] = ric
    dump("v2_cross_K.json", out)
    # Q-corner multilinear interpolation diagnostic (NOT the expert): K=21 nodes interpolated vs lookahead K_ref
    from scipy.interpolate import RegularGridInterpolator
    Qn = oracle.node_Q(loadV(21), P, 21)
    rgi = RegularGridInterpolator([oracle.grid(21)] * 5, Qn, method="linear")
    sl = slice(bounds[0], bounds[1])
    diag = {}
    for gi, g in enumerate(names[:2]):
        sl = slice(bounds[gi], bounds[gi + 1])
        qi = rgi(sets[g][:4000]); ref = Q[KREF][sl][:4000]
        diag[g] = {"rmse_Qcorner_K21_vs_lookahead_K31": float(np.sqrt(np.mean((qi - ref) ** 2))),
                   "max": float(np.abs(qi - ref).max())}
    dump("v2_qcorner_diagnostic.json", diag)
    log("v2 done")


# ---------------------------------------------------------------- V3
def v3(K, n_states, n_succ, probe=False):
    sets = get_evalsets()
    rng = evalsets.seeded(SEEDS["v3"], 0)
    pick_o = rng.choice(len(sets["occ"]), n_states // 2, replace=False)
    pick_u = rng.choice(len(sets["uni"]), n_states - n_states // 2, replace=False)
    S = np.concatenate([sets["occ"][pick_o], sets["uni"][pick_u]])
    V = loadV(K)
    Qref = oracle.lookahead_Q(S, V, P)
    R = reward_all(S, P)
    bhat = np.zeros((len(S), P.n_actions)); se = np.zeros_like(bhat)
    t0 = time.time()
    for i in range(len(S)):
        rr = evalsets.seeded(SEEDS["v3"], 1000 + i)           # common random numbers across K (and actions)
        D = env.sample_increments(rr, n_succ, P)
        for a in range(P.n_actions):
            sp = env.step(np.broadcast_to(S[i], (n_succ, P.F)).copy(), np.full(n_succ, a), D, P)
            val = oracle.lse(oracle.lookahead_Q(sp, V, P))
            bhat[i, a] = Qref[i, a] - R[i, a] - P.beta * val.mean()
            se[i, a] = P.beta * val.std(ddof=1) / np.sqrt(n_succ)
        if (i + 1) % 8 == 0:
            log(f"v3 K={K} state {i + 1}/{len(S)} {time.time() - t0:.0f}s")
    el = time.time() - t0
    res = {"K": K, "n_states": len(S), "n_succ": n_succ, "wall_s": el, "s_per_state": el / len(S)}
    if not probe:
        b, s = bhat.ravel(), se.ravel()
        N = b.size
        ms = np.mean(b ** 2)
        rms = float(np.sqrt(ms))
        se_ms = np.sqrt(np.sum((2 * b * s) ** 2)) / N          # delta-method SE of mean(b^2) (noise-only part)
        res.update({"rms": rms, "se_rms": float(se_ms / (2 * rms)),
                    "rms_bias_corrected": float(np.sqrt(max(0.0, np.mean(b ** 2 - s ** 2)))),
                    "signed_mean": float(b.mean()), "se_signed_mean": float(np.sqrt(np.sum(s ** 2)) / N),
                    "p95_abs": float(np.quantile(np.abs(b), 0.95)), "max_abs": float(np.abs(b).max()),
                    "mean_pair_se": float(s.mean()), "max_pair_se": float(s.max()),
                    "rms_by_action": [float(np.sqrt(np.mean(bhat[:, a] ** 2))) for a in range(P.n_actions)],
                    "rms_occ": float(np.sqrt(np.mean(bhat[:n_states // 2] ** 2))),
                    "rms_uni": float(np.sqrt(np.mean(bhat[n_states // 2:] ** 2)))})
        np.savez(os.path.join(ODIR, f"v3_K{K}.npz"), bhat=bhat, se=se, S=S)
        dump(f"v3_residual_K{K}.json", res)
    else:
        dump(f"v3_probe_K{K}.json", res)
    log(f"v3 {json.dumps(res)}")


# ---------------------------------------------------------------- V4
def v4(K, n_roll, T):
    V = loadV(K)
    rng0 = evalsets.seeded(SEEDS["v4"], 0)
    x0 = rng0.uniform(0, P.start_max, size=(20, P.F))
    Vref = oracle.lse(oracle.lookahead_Q(x0, V, P))
    s = np.repeat(x0, n_roll, axis=0)
    N = s.shape[0]
    ra, ri = evalsets.seeded(SEEDS["v4"], 1), evalsets.seeded(SEEDS["v4"], 2)
    G = np.zeros(N)
    disc = 1.0
    t0 = time.time()
    for t in range(T):
        Q = oracle.lookahead_Q(s, V, P)
        pr = oracle.softmax(Q)
        a = env.sample_actions(pr, ra.uniform(size=N))
        r = reward_all(s, P)[np.arange(N), a]
        G += disc * (r - np.log(pr[np.arange(N), a]))
        s = env.step(s, a, env.sample_increments(ri, N, P), P)
        disc *= P.beta
        if (t + 1) % 25 == 0:
            log(f"v4 K={K} t={t + 1}/{T} {time.time() - t0:.0f}s")
    G = G.reshape(20, n_roll)
    mc, se = G.mean(1), G.std(1, ddof=1) / np.sqrt(n_roll)
    trunc = P.beta ** T * (np.abs(Vref).max())
    res = {"K": K, "n_rollouts": n_roll, "T": T, "wall_s": time.time() - t0, "V_ref": Vref, "mc_return": mc, "se": se,
           "diff": mc - Vref, "z": (mc - Vref) / se, "max_abs_diff": float(np.abs(mc - Vref).max()),
           "mean_diff": float(np.mean(mc - Vref)), "se_mean_diff": float(np.sqrt(np.sum(se ** 2)) / 20),
           "truncation_bound": float(trunc), "within_3se_plus_0.01": [bool(abs(d) <= 3 * s_ + 0.01) for d, s_ in zip(mc - Vref, se)],
           "max_se": float(se.max())}
    res["all_within"] = bool(all(res["within_3se_plus_0.01"]))
    dump(f"v4_forward_return_K{K}.json", res)
    log("v4 done")


# ---------------------------------------------------------------- V5
def gl_nodes(n):
    x, w = np.polynomial.legendre.leggauss(n)
    return 0.5 * (x + 1), 0.5 * w


def dense_1d_solver(p, n=4001, tol=1e-11):
    """Independent F=1 solver: Toeplitz hat-kernel by composite Gauss-Legendre (no incomplete-gamma formulas)."""
    shape, theta, beta = p.shape, p.scale[0], p.beta
    h = 1.0 / (n - 1)
    pdf = stats.gamma(shape, scale=theta).pdf
    t, w = gl_nodes(10)
    m = np.arange(n - 1)                                       # cell index in D: [m h, (m+1) h]
    Dm = (m[:, None] + t[None, :]) * h
    up = (w[None, :] * (t[None, :]) * pdf(Dm) * h).sum(1)      # int of (D-mh)/h pdf  -> weight to node m+1
    dn = (w[None, :] * (1 - t[None, :]) * pdf(Dm) * h).sum(1)  # weight to node m
    c = np.zeros(n)
    c[:-1] += dn
    c[1:] += up
    Pm = np.zeros((n, n))
    sf = stats.gamma(shape, scale=theta).sf
    for i in range(n):
        M = n - 1 - i                                          # complete cells above x = g_i
        Pm[i, i:i + M] += dn[:M]
        Pm[i, i + 1:i + M + 1] += up[:M]
        Pm[i, n - 1] += sf(M * h)                              # atom at the cap
    return Pm, h


def f1_dense_reference(p, n=4001):
    g = np.linspace(0, 1, n)
    Pm = dense_1d_solver(p, n)[0]
    if abs(Pm.sum(1) - 1).max() > 1e-9:
        raise RuntimeError(f"dense 1-D kernel rows do not sum to 1: {abs(Pm.sum(1) - 1).max()}")
    m = p.u[0] * g + p.v[0] * g ** 2
    r0 = -m
    r1 = -(p.Kcost_eff[0] + p.d[0] * g ** 2)
    V = r0 / (1 - p.beta)
    for it in range(2000):
        Q0 = r0 + p.beta * Pm @ V
        Q1 = r1 + p.beta * V[0]
        Vn = np.logaddexp(Q0, Q1)
        dv = np.abs(Vn - V).max()
        V = Vn
        if dv < 1e-11:
            break
    return g, V, it + 1, dv


def dense_Q_at(x, V, p, n=4001):
    """Independent off-grid lookahead for F=1: composite GL of I_n V(x+D) pdf(D) with kinks at nodes."""
    g = np.linspace(0, 1, n)
    h = 1.0 / (n - 1)
    dist = stats.gamma(p.shape, scale=p.scale[0])
    t, w = gl_nodes(10)
    out = np.zeros((len(x), 2))
    for i, xi in enumerate(x):
        edges = np.unique(np.concatenate([[0.0], g[g > xi] - xi, [1 - xi]]))
        edges = edges[edges <= 1 - xi + 1e-15]
        lo, hi = edges[:-1], edges[1:]
        Dp = lo[:, None] + (hi - lo)[:, None] * t[None, :]
        y = xi + Dp
        Vy = np.interp(y, g, V)
        integ = (w[None, :] * (hi - lo)[:, None] * Vy * dist.pdf(Dp)).sum()
        cont0 = integ + V[-1] * dist.sf(1 - xi)
        out[i, 0] = -(p.u[0] * xi + p.v[0] * xi ** 2) + p.beta * cont0
        out[i, 1] = -(p.Kcost_eff[0] + p.d[0] * xi ** 2) + p.beta * V[0]
    return out


def v5():
    res = {}
    p1 = P.subset(1)
    t0 = time.time()
    g, Vd, its, dv = f1_dense_reference(p1)
    res["F1"] = {"dense_K": 4001, "dense_sweeps": its, "dense_dV": dv, "dense_wall_s": time.time() - t0}
    r = oracle.solve_vi(p1, 31, tol=5e-8)
    x = np.concatenate([np.linspace(0, 1, 201), evalsets.seeded(9005, 0).uniform(size=100)])
    Qc = oracle.lookahead_Q(x[:, None], r["V"], p1)
    Qd = dense_Q_at(x, Vd, p1)
    d = Qc - Qd
    dq = (Qc[:, 1] - Qc[:, 0]) - (Qd[:, 1] - Qd[:, 0])
    res["F1"].update({"K31_sweeps": r["sweeps"], "max_abs_dQ": float(np.abs(d).max()), "rmse_Q": float(np.sqrt(np.mean(d ** 2))),
                      "max_abs_advantage_err": float(np.abs(dq).max()), "mean_signed_Q_err": float(d.mean()),
                      "pass_1e-3_on_advantage": bool(np.abs(dq).max() <= 1e-3), "pass_1e-3_on_Q_level": bool(np.abs(d).max() <= 1e-3)})
    # also: K=401 tensor-code F=1 vs dense (checks the tensor code itself at fine K)
    r401 = oracle.solve_vi(p1, 401, tol=5e-9)
    Q401 = oracle.lookahead_Q(x[:, None], r401["V"], p1)
    res["F1"]["max_abs_dQ_K401_vs_dense"] = float(np.abs(Q401 - Qd).max())
    log(f"v5 F1 {res['F1']}")
    p2 = P.subset(2)
    r31 = oracle.solve_vi(p2, 31, tol=5e-8)
    r401 = oracle.solve_vi(p2, 401, tol=5e-8)
    X = np.concatenate([evalsets.uniform_states(3000, 2, 9005, per_axis=40), evalsets.face_states(500, 2, 9006),
                        evalsets.seeded(9005, 1).uniform(0, 0.5, size=(500, 2))])
    A = oracle.lookahead_Q(X, r31["V"], p2); B = oracle.lookahead_Q(X, r401["V"], p2)
    res["F2"] = {"K31_sweeps": r31["sweeps"], "K401_sweeps": r401["sweeps"], "K401_wall_s": r401["wall_s"],
                 "max_abs_dQ": float(np.abs(A - B).max()), "rmse_Q": float(np.sqrt(np.mean((A - B) ** 2))),
                 "max_abs_advantage_err": float(np.abs((A[:, 1:] - A[:, :1]) - (B[:, 1:] - B[:, :1])).max()),
                 "mean_signed_Q_err": float((A - B).mean()),
                 "pass_5e-3_on_advantage": bool(np.abs((A[:, 1:] - A[:, :1]) - (B[:, 1:] - B[:, :1])).max() <= 5e-3),
                 "pass_5e-3_on_Q_level": bool(np.abs(A - B).max() <= 5e-3)}
    # tensor-code F=2 K=401 vs K=801 as a convergence sanity check of the 'truth' used here (RMS on a subset)
    log(f"v5 F2 {res['F2']}")
    dump("v5_dimension_ladder.json", res)


# ---------------------------------------------------------------- V6
def v6():
    V = {K: loadV(K) for K in LADDER}
    nc, H = 200, 100
    runs = {}
    for K in LADDER:
        pol = evalsets.policy_from_V(V[K], P)
        sd = SEEDS["v6"]
        ch = env.simulate_chains(pol, nc, P, evalsets.seeded(sd, 1), evalsets.seeded(sd, 2), evalsets.seeded(sd, 3), H=H)
        runs[K] = ch
        log(f"v6 chains K={K}")
    ref = runs[KREF]
    refS = ref["s"].reshape(-1, P.F)
    pol_ref_at_ref_states = oracle.softmax(oracle.lookahead_Q(refS, V[KREF], P))
    shares_ref = np.bincount(ref["a"].ravel(), minlength=P.n_actions) / ref["a"].size
    out = {"n_chains": nc, "H": H, "ref_action_shares": shares_ref, "per_K": {}}
    for K in LADDER:
        ch = runs[K]
        sh = np.bincount(ch["a"].ravel(), minlength=P.n_actions) / ch["a"].size
        entry = {"action_shares": sh, "share_abs_diff_max": float(np.abs(sh - shares_ref).max()), "share_TV": float(0.5 * np.abs(sh - shares_ref).sum()),
                 "mean_x": ch["s"].reshape(-1, P.F).mean(0), "mean_x_ref": refS.mean(0),
                 "mean_x_abs_diff_max": float(np.abs(ch["s"].reshape(-1, P.F).mean(0) - refS.mean(0)).max()),
                 "p95_x": np.quantile(ch["s"].reshape(-1, P.F), 0.95, axis=0),
                 "coupled_action_agreement": float((ch["a"] == ref["a"]).mean())}
        if K != KREF:
            pk = oracle.softmax(oracle.lookahead_Q(refS, V[K], P))
            entry["argmax_disagree_on_ref_states"] = float((pk.argmax(1) != pol_ref_at_ref_states.argmax(1)).mean())
            entry["mean_TV_on_ref_states"] = float(0.5 * np.abs(pk - pol_ref_at_ref_states).sum(1).mean())
        out["per_K"][K] = entry
    dump("v6_policy_stability.json", out)
    log("v6 done")


# ---------------------------------------------------------------- V7
def bspline_basis(x, nk=8, deg=3):
    from scipy.interpolate import BSpline
    t = np.concatenate([[0.0] * deg, np.linspace(0, 1, nk), [1.0] * deg])
    nb = len(t) - deg - 1
    B = np.zeros((len(x), nb))
    for j in range(nb):
        c = np.zeros(nb)
        c[j] = 1.0
        B[:, j] = BSpline(t, c, deg, extrapolate=True)(x)
    return B


def v7():
    K = 21
    Qn = oracle.node_Q(loadV(K), P, K)            # (K,)*5 + (6,)
    g = oracle.grid(K)
    B = bspline_basis(g)                           # (K, nb)
    nb = B.shape[1]
    ncol = 1 + P.F * nb
    # design on all K^5 nodes, by slabs over axis 0
    XtX = np.zeros((ncol, ncol)); Xty = np.zeros((ncol, P.n_actions)); n = 0
    rest = np.array(np.meshgrid(*([np.arange(K)] * 4), indexing="ij")).reshape(4, -1)
    def design(i0):
        cols = [np.ones((rest.shape[1], 1)), np.repeat(B[i0][None, :], rest.shape[1], 0)]
        for j in range(4):
            cols.append(B[rest[j]])
        return np.hstack(cols)
    for i0 in range(K):
        X = design(i0); y = Qn[i0].reshape(-1, P.n_actions)
        XtX += X.T @ X; Xty += X.T @ y; n += len(X)
    coef = np.linalg.lstsq(XtX + 1e-12 * np.eye(ncol), Xty, rcond=None)[0]
    resid = np.empty_like(Qn)
    for i0 in range(K):
        resid[i0] = (Qn[i0].reshape(-1, P.n_actions) - design(i0) @ coef).reshape(Qn[i0].shape)
    out = {"K": K, "n_nodes": int(n), "n_basis_per_axis": nb, "per_action": {}, "advantage": {}}
    for a in range(P.n_actions):
        y = Qn[..., a]; r = resid[..., a]
        out["per_action"][a] = {"rmse": float(np.sqrt(np.mean(r ** 2))), "sd_Q": float(y.std()), "R2_shortfall": float(np.mean(r ** 2) / y.var())}
    for f in range(1, P.n_actions):
        y = Qn[..., f] - Qn[..., 0]; r = resid[..., f] - resid[..., 0]
        ent = {"rmse": float(np.sqrt(np.mean(r ** 2))), "sd_dQ": float(y.std()), "R2_shortfall": float(np.mean(r ** 2) / y.var())}
        ax = f - 1
        # SD over the other four mileages at fixed own mileage x_f
        other = tuple(j for j in range(P.F) if j != ax)
        sd_over_others = y.std(axis=other)           # (K,) per own-mileage level
        mean_over_others = y.mean(axis=other)
        ent["sd_over_x_minus_f_by_own_level"] = sd_over_others
        ent["mean_over_x_minus_f_by_own_level"] = mean_over_others
        ent["mean_sd_over_x_minus_f"] = float(sd_over_others.mean())
        ent["range_dQ_over_x_minus_f_at_own=0.5"] = float(np.ptp(np.take(y, K // 2, axis=ax)))
        out["advantage"][f] = ent
    out["mean_R2_shortfall_dQ"] = float(np.mean([out["advantage"][f]["R2_shortfall"] for f in out["advantage"]]))
    # coupling data: P(a=f) of pi_ref as bus g's mileage varies (quintile bins), on occupancy and uniform eval states
    sets = get_evalsets()
    Qref = {k: np.load(os.path.join(ODIR, f"Qeval_K{KREF}.npy")) for k in [0]}[0]
    n_o, n_u = len(sets["occ"]), len(sets["uni"])
    groups = {"occ": (sets["occ"], Qref[:n_o]), "uni": (sets["uni"], Qref[n_o:n_o + n_u])}
    coup = {}
    bins = np.linspace(0, 1, 6)
    for gname, (S, Qg) in groups.items():
        pi = oracle.softmax(Qg)
        tab = np.full((P.F, P.F, 5), np.nan)
        for f in range(P.F):
            for gg in range(P.F):
                b = np.clip(np.digitize(S[:, gg], bins) - 1, 0, 4)
                for k in range(5):
                    m = b == k
                    if m.sum() > 20:
                        tab[f, gg, k] = pi[m, f + 1].mean()
        coup[gname] = {"table_P(a=f)[f][g][x_g quintile]": tab,
                       "max_shift_offdiag": float(np.nanmax(np.abs(np.nanmax(tab, 2) - np.nanmin(tab, 2))[~np.eye(P.F, dtype=bool)]))}
    out["coupling"] = coup
    dump("v7_nonseparability.json", out)
    log("v7 done")


if __name__ == "__main__":
    st = sys.argv[1]
    if st == "v2":
        v2()
    elif st == "v3":
        v3(int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), probe=len(sys.argv) > 5 and sys.argv[5] == "probe")
    elif st == "v4":
        v4(int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]))
    elif st == "v5":
        v5()
    elif st == "v6":
        v6()
    elif st == "v7":
        v7()
