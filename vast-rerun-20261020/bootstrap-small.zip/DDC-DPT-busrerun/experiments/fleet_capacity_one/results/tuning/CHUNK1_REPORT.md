# Tuning chunk 1: shared core, bus P0 and B1

Branch: `fleet-capacity-one`. This is development evidence on the bus testbed. No B2, fleet tuning, or protected headline data were used.

## Inventory and data lineage

At handoff, the shared fleet trainer modules, `tuning/` package, two tuning test files, P0 results, and a live B1 runner already existed but were uncommitted. The P0 gate and archive/pool audits existed; B1 had partial fit records and no end marker. I reviewed the trainer, selector, manifests, runner, evaluator, gate, and analysis code. No trainer or selector change was needed. I corrected the analysis failure penalty and added a regression test. After B1, I added one token of admission headroom to the runner for later stages; this does not alter completed fits.

The review zero-dummy archives were rejected by the lineage/DGP audit. They are internally nested slices of a 10,000-chain stream, but states reach mileage 13 and their archived Q values match a cap at least 20 rather than the required `maxMileage=10`; their generation seed is absent. They were not mixed with the study pool. The runs used the audited seed-7000 generated pool: 1,000 distinct 100-step chains, 800/200 source train/test chains, no chain overlap, maximum state 10, generator SHA256 `9cc9257513c42302b78c5ff0cb922ecee5465bab552984d3d595a4933dd64b7c`. The truth-stripped export uses a permanent whole-chain 80/20 split and a hash-ordered 200-chain prefix for N=20,000. The separate development occupancy panel used seed 7199.

## Tests and P0 gate

The requested tuning core and integrity suite passed **34/34** before changes and **35/35** after the analysis regression test and runner change. These include shape/mask and signed-loss fixtures, zero subgradients, the two-successor identity distinction, Q/zeta parameter isolation, paired streams and fresh initialization, checkpoint reload, and truth-unavailable replay.

P0 protocol gate: **PASS**. All 24 scheduled slots have valid status/provenance records, one code hash and one export hash, correct completed update counts, valid checkpoint reloads, two matching truth-unavailable replays, and zero numerical divergences. All 24 optimizer trajectories completed but all 24 selected checkpoints were `anchor_fail` at the 0.10 threshold. Median selected anchor RMSE was 0.411; this is not a P0 performance gate. P0 wall time from first fit start to last fit end was **166.0 s** (2.77 min); median per-fit time was 45.8 s.

## B1 status and selection

The original single runner completed all **216/216** scheduled fits. All 216 worker exits were zero; all 216 records and 216 separate truth-evaluation files are present. Optimizer status: **216 complete, 0 diverged, 0 worker failed, 0 missing**. Checkpoint status: **47 eligible (`ok`), 169 `anchor_fail`**. Each completed fit has exactly 20,000 Q updates, `k × 20,000` zeta updates, and `(k+1) × 20,000` batch draws. Provenance and selected checkpoint parameter hashes verified across all fits.

Family centers follow the development rule: all three initializations must be anchor eligible; eligible configurations must pass the within-family median validation NLL gate (best +0.01); the mean log normalized non-anchor occupancy reward RMSE is primary, with the 5% practical band and fidelity tie break. On this one-archive screen no sampling confidence interval is used. If a family has no eligible configuration, the center is a **flagged rescue** chosen by fewest failed fits, then median validation NLL+A², then configuration ID. The raw truth RMSE in rescue rows is descriptive, while their stage score applies the fixed log(10) penalty to failed fits. Metrics below are medians across the three initializations except the mean log score; A is anchor RMSE. `RMSE` is occupancy-weighted non-anchor reward RMSE on seed 7199, in reward units.

| Protected family | Center loss / k / lr_Q / rho | Eligible fits | Status | Reward RMSE | Mean log score | Val NLL | A | Q RMSE | Truth-policy KL | Median fit s |
|---|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| signed structure, k=1 | none / 1 / 0.001 / 1 | 0/3 | rescue; 0 stable candidates | 1.8983 | 2.3026 | 0.4103 | 0.1798 | 24.7870 | 0.01404 | 83.3 |
| signed structure, k>1 | none / 10 / 0.001 / 3 | 2/3 | rescue; 0 stable candidates | 0.9389 | -0.3058 | 0.4004 | 0.0738 | 12.1135 | 0.00393 | 390.6 |
| clip0 | clip0 / 10 / 0.001 / 1 | 3/3 | eligible; 6 stable candidates | 0.3633 | -2.0267 | 0.3974 | 0.0205 | 4.7390 | 0.00099 | 393.6 |
| abs | abs / 10 / 0.001 / 1 | 3/3 | eligible; 5 stable candidates | 0.3009 | -2.2074 | 0.3973 | 0.0182 | 3.2532 | 0.00084 | 392.4 |

The abs center has the lowest eligible B1 development score. This is a screen result, not a frozen or headline protocol. The full per-fit observable/truth table is `B1_fits.csv`, all 72 candidate summaries are `B1_candidates.csv`, the decision trace is `B1_family_centers.json`, and the independent completion audit is `B1_integrity.json`. Failed slots remain in every denominator and no seeds were replaced.

## Wall time, resource ledger, and deviations

B1 fit wall time from first start to last end was **4,089.4 s** (68.16 min); median per-fit time was 203.8 s. From the first P0 fit to the last B1 fit was **4,420.7 s** (73.68 min), including the inter-stage gap. The runner admitted at most 12 one-thread fit workers while the concurrent oracle job normally reserved 32 tokens.

One B1 resource-ledger sample at Unix time `1792373673.1685123` recorded **12 running fit tokens plus 33 other-job reserved tokens = 45**, one above the 44-token project cap. The independent oracle reservation rose after those fits had been admitted; the runner did not shed a running fit. This is a resource-rule deviation, although all B1 fit/provenance checks pass. The post-B1 runner code now keeps one admission token free to cover this observed one-token fluctuation; completed B1 trajectories were not rerun or changed. The review-archive fallback was the brief's prescribed response to the failed audit. There were no replacements, numerical divergences, or tuning stage extensions.

Uncommitted items after this chunk: the pre-existing `bg.sh` and `bgt.sh` helper scripts, `experiments/__pycache__/`, and the ignored `artifacts/tuning/` directory containing generated inputs, fit checkpoints/records, and server-side logs. The committed CSV/JSON tables carry fit status, metrics, and provenance; checkpoint binaries stay in the ignored artifact directory. No Phase-1 paths were staged.
