# Phase 1 report — Gate A pre-assembly

Branch `fleet-capacity-one` in the baker worktree `~/DDC-DPT-fleet`. This report covers completed Phase 1 work and the provisional Gate A evidence. V4 has no final verdict yet. See `A.md` and `oracle_diagnostics/*.json` for the criteria and detailed numbers.

## Built

- `experiments/fleet_capacity_one` package, configuration, environment check, and vendored multi-headed MLP with provenance.
- Fleet DGP parameters, reward and replacement semantics, occupancy simulation, and closed-form truncated Gamma hat kernels.
- Float64 tensor soft value iteration and batched off-grid lookahead Q, with saved-value residual checks. Solved K={7,9,11,13,17,21,25,31}; all eight converged in 325–327 sweeps. At K=31, last dV was 4.906e-8 and the saved-V residual was 4.661e-8.
- Evaluation sets and V1–V7 validation scripts. V2, V3, V5, V6, and V7 diagnostics are present; V4 is running. G0 and G1 evidence is present.

## Provisional validation outcomes

| Validation | Verdict | Headline evidence |
|---|---|---|
| V1 deterministic controls | PASS | beta=0 max `|Q-r|` 3.55e-15; zero-reward V error 1.78e-12; dense Kronecker and reset invariance tests pass. |
| V2 cross K | FAIL | Fitted p(Q, K>=11)=2.990–2.991, above 2.5; Richardson K=31 RMSE(Q)=0.0531–0.0562, above 0.01. RMSE(ΔQ)=0.000644–0.001431, KL(K25)=5.57e-8–9.56e-8, and TV(K25)=0.000111–0.000180 pass their limits. |
| V3 off-grid residual | PASS on recorded RMS and SE | 512 × 6 × 4096; RMS 0.007926 ± 0.000133 SE, bias-corrected RMS 0.003426, signed mean +0.003579 ± 0.000129 SE; p95 absolute 0.015614, max absolute 0.030814. |
| V4 forward soft return | PENDING | Job `v4 31 2000 450` still running at pre-assembly. It uses 20 starts × 2,000 rollouts each × 450 steps, versus specified 20 × 20,000 × 450. |
| V5 dimension ladder | PASS for advantage thresholds | Maximum advantage error 0.000907 (F=1; limit 0.001) and 0.001536 (F=2; limit 0.005). Absolute Q-level maxima are 0.013636 and 0.033115; see notation issue below. |
| V6 policy stability | REPORTED | 200 × 100 chains; at K=25, action-share TV 0.000550, max mean-mileage shift 0.000284, argmax disagreement 0.000450. No Gate A threshold. |
| V7 nonseparability | REPORTED | Advantage additive-fit mean R² shortfall 0.02951; RMSE 0.4711–0.5947; off-diagonal policy-probability shifts up to 0.11975 occupancy / 0.18952 uniform. Not a gate. |

**Provisional Gate A: FAIL on completed V2 criteria, with V4 pending.** The tolerances were not loosened. K=37 was not run because the Phase 1 brief requires escalation at that point and Gate A is a human checkpoint.

## Timings and resource use

- K=21 timing probe: 0.5689 s per VI sweep; off-grid lookahead 9.83e-5 s per state in float64 and 7.34e-5 s in float32; 400-sweep VI projection 227.6 s.
- Actual K=31 VI: 1,688.1 s (28.1 min) for 327 sweeps; K=25 VI 521.1 s. The K=31 run stayed under the 2.5 h projection warning threshold.
- V2 Q evaluation at K=31: 6.8 s for 21,024 states. V3 32-state probe: 225.1 s, implying about 3,601 s for 512 states; actual full V3: 4,953.5 s (82.6 min), under the 2 h trigger; the actual run was 1.38 h.
- V5 dense F=1 reference: 22.24 s; F=2 K=401 reference: 2.99 s.
- Package tree uses about 568 MiB on baker; `artifacts/oracle` uses 349 MiB. This is under the 3 GiB package cap. Baker `/home` had about 107 GiB free at report time. Artifacts are git-ignored.

## Deviations and evidence gaps

1. V4's third positional configuration is correct at 450 steps, but its second positional argument is `n_roll=2000` per start. The 20 start states are made inside `v4`. The running job therefore has 40,000 total rollouts, one tenth of the 400,000 specified. It should be treated as a lower-sample diagnostic until the finisher resolves the mismatch.
2. V5's specification uses `ΔQ_f=Q_f−Q_0` and says max `|ΔQ|`; the advantage reading passes. If it was intended as an absolute Q-level threshold, F=1 and F=2 both fail (0.013636 > 0.001 and 0.033115 > 0.005). The report keeps both readings visible; no tolerance was changed.
3. V3 records SE for RMS and signed mean, plus mean/max per-pair SE. It does not record separate SEs for p95 and max although §d.3.5 requests each with an SE. The finisher should decide how to supply or label those missing uncertainty estimates.
4. V2 finest three-level p estimates are 2.071–2.072 and meet [1.5,2.5], but the prescribed log-error/log-h fit is 2.59 over all nonreference K and about 2.99 at K>=11. The fitted criterion is recorded as FAIL.
5. The K=31 Richardson Q error is over five times the 0.01 limit even when using the fitted p. The advantage error is below its 0.005 limit; both are reported.

## Fresh tests and handoff

Ran the fleet package's seven non-tuning unittest modules on baker with BLAS/OpenMP thread caps of 1:

`~/miniconda3/envs/gym/bin/python -m unittest -v experiments.fleet_capacity_one.tests.test_anchor experiments.fleet_capacity_one.tests.test_dense_reference experiments.fleet_capacity_one.tests.test_env experiments.fleet_capacity_one.tests.test_g0 experiments.fleet_capacity_one.tests.test_kernels experiments.fleet_capacity_one.tests.test_oracle_small experiments.fleet_capacity_one.tests.test_rewards`

**25 tests run, 25 passed, 0 failures/errors**, in 8.301 s. The tuning tests are excluded because a separate B1 tuning runner is live; no `tuning/` or tuning core module was touched.

For the Claude finisher: check `artifacts/logs/v4_K31.done` and the V4 JSON, resolve the rollout-count shortfall and final V4 criterion, address the V3 uncertainty and V5 notation issues, review the V2 failures at the Gate A human checkpoint, and determine the authorized K=37 fallback or other decision. Do not treat this report as a final Gate A pass.

## Commit scope

The Phase 1 commit includes only the fleet oracle stack, package/config scaffolding, Phase 1 scripts, seven fleet test modules, and `results/gates/`. Deliberately left uncommitted: all concurrent tuning work (`tuning/`, `fleet/{models,losses,train,select,seeds}.py`, tuning tests/fixtures, and `results/tuning/`); local background launch helpers `bg.sh` and `bgt.sh`; ignored `artifacts/`; and generated `__pycache__` files. No push is planned.
