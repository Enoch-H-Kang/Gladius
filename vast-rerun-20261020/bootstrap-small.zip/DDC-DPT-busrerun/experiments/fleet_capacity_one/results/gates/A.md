# Gate A — provisional oracle validation

Status: **FAIL on completed criteria; V4 PENDING.** This is a provisional assessment for the Claude finisher and human Gate A checkpoint. The stated tolerances in `planning/r2-claude.md §d.3.5` are applied without adjustment. K=37 has not been run.

## VI ladder and V1

| K | Sweeps | Last `||dV||∞` | Saved V residual | VI time (s) |
|---:|---:|---:|---:|---:|
| 7 | 325 | 4.980e-8 | 4.731e-8 | 0.54 |
| 9 | 326 | 4.885e-8 | 4.640e-8 | 1.55 |
| 11 | 326 | 4.976e-8 | 4.727e-8 | 6.43 |
| 13 | 327 | 4.782e-8 | 4.543e-8 | 12.71 |
| 17 | 327 | 4.843e-8 | 4.601e-8 | 62.89 |
| 21 | 327 | 4.874e-8 | 4.631e-8 | 186.40 |
| 25 | 327 | 4.892e-8 | 4.647e-8 | 521.10 |
| 31 | 327 | 4.906e-8 | 4.661e-8 | 1688.09 |

**VI PASS:** all eight K meet `||dV||∞ < 5e-8` and saved V residual `<= 1e-6`; none reached the 1,000-sweep cap.

**V1 PASS:** beta=0 gives max `|Q-r|=3.55e-15`; zero reward gives max `|V-log(6)/(1-beta)|=1.78e-12`. The F=2, K=3 dense Kronecker fixture and reset continuation independence pass the 1e-12 unit-test bounds. See `G1.txt` and the fresh suite result in `PHASE1_REPORT.md`.

## V2 — cross K

Evaluation sets: 10,000 occupancy, 10,000 uniform, and 1,024 face/boundary states. K_ref=31. All numbers below compare K=25 with K=31 unless labeled otherwise.

| Set | RMSE(Q) / max | RMSE(ΔQ) / max | KL(ref‖25) | Mean TV | Top action agreement, gap > 0.1 |
|---|---:|---:|---:|---:|---:|
| Occupancy | 0.053377 / 0.056591 | 0.000611 / 0.002514 | 9.557e-8 | 0.000180 | 1.000 (8,759 states) |
| Uniform | 0.050391 / 0.061614 | 0.001226 / 0.007155 | 5.573e-8 | 0.000111 | 1.000 (9,345 states) |
| Face/boundary | 0.050407 / 0.058290 | 0.001358 / 0.005502 | 6.263e-8 | 0.000114 | 1.000 (983 states) |

**Policy KL/TV PASS:** all three groups meet KL <= 1e-4 and TV <= 0.005. The full K ladder, Q/advantage max errors, p95 TV, and all top-action agreements are in `oracle_diagnostics/v2_cross_K.json`. The separate K=21 Q-corner interpolation diagnostic has RMSE 0.1250 (occupancy) and 0.1169 (uniform), versus K=31 lookahead; Q-corner interpolation is not the expert and has no Gate A tolerance.

**Observed-order criterion FAIL on the specified log-error/log-h fit:** for Q, p over all K<31 is 2.595/2.593/2.592 (occupancy/uniform/face); the K>=11 fits used for the Richardson calculation are 2.991/2.990/2.990. For ΔQ, the K>=11 fits are 2.958/2.958/2.959. These exceed [1.5, 2.5]. Three-level adjacent-grid estimates at (21,25,31) are 2.071/2.072/2.071 and do lie in range; they do not make the recorded log-log fits pass.

**Richardson criterion FAIL:** using the recorded K>=11 fitted p, K_ref error estimates are RMSE(Q) 0.056239/0.053101/0.053126 and RMSE(ΔQ) 0.000644/0.001292/0.001431. The Q estimates exceed 0.01 in every set; ΔQ estimates meet 0.005. With p fixed at 2, the corresponding RMSE(Q) values are 0.094893/0.089584/0.089612, also above 0.01. The Q level error is predominantly common across actions, but the Gate A Q tolerance still applies.

## V3 — off-grid Monte Carlo Bellman residual

**PASS on recorded RMS and its SE:** 512 states (256 occupancy + 256 uniform) × 6 actions × 4,096 successors. RMS=0.0079263 <= 0.01, SE(RMS)=0.0001330 <= 0.003; bias-corrected RMS=0.0034263. Signed mean=+0.0035794, SE=0.0001290; p95 absolute residual=0.0156137, max absolute residual=0.0308135. Mean/max per-state-action Monte Carlo SE are 0.007097/0.010890. The specification asks for an SE for p95 and max; the recorded diagnostic has no such SE, so this remains an evidence gap for the finisher. The 32-state timing probe took 225.1 s; the full run took 4953.5 s.

## V4 — forward soft return

**PENDING:** as checked on baker, `artifacts/logs/v4_K31.done` is absent and `v4_K31.log` shows the job still running. Launched as `validate_oracle v4 31 2000 450`. In `scripts/validate_oracle.py`, the positional arguments are `K`, `n_roll`, and `T`; `v4` creates 20 start states and repeats each `n_roll` times. Thus the active job is **20 starts × 2,000 rollouts per start × 450 steps = 40,000 rollouts**, versus the specification's **20 starts × 20,000 per start × 450 = 400,000 rollouts**. The configured sample count is one tenth of the specification. Once it completes, read `oracle_diagnostics/v4_forward_return_K31.json` and assess each start against `|mean−V_ref| <= 3 SE + 0.01`; the sample-count deviation still needs resolution before a final V4 verdict.

## V5 — dimension ladder

**PASS on the specified advantage tolerance:** F=1 K=31 versus independent dense K=4001 has max `|ΔQ|` error 0.0009071 <= 0.001. F=2 K=31 versus K=401 has max `|ΔQ|` error 0.0015359 <= 0.005. F=1 dense K=4001 took 454 sweeps and 22.24 s; F=2 K=401 took 310 sweeps and 2.99 s. F=1 tensor K=401 versus dense K=4001 has max Q-level error 0.00007363.

The Q-level max errors are 0.0136364 (F=1) and 0.0331151 (F=2), with mean signed Q differences +0.0127170 and +0.0308772. These exceed 0.001 and 0.005 if `max |ΔQ|` is interpreted as a bound on absolute Q levels instead of on the defined advantages `ΔQ_f=Q_f−Q_0`. The finisher should preserve both readings in the Gate A decision; the Q-level discrepancy is also consistent with the failed Richardson Q criterion.

## V6 — policy stability

**REPORTED, no Gate A threshold:** 200 chains × 100 steps with common random numbers. At K=25 versus K=31: maximum action-share difference 0.000350, share TV 0.000550, maximum mean-mileage difference 0.000284, coupled action agreement 0.99465, argmax disagreement on reference states 0.000450, and mean policy TV on reference states 0.000182. All K results and marginals are in `oracle_diagnostics/v6_policy_stability.json`.

## V7 — nonseparability

**REPORTED, not a gate:** additive cubic B-spline fits on 21^5=4,084,101 nodes. Per-action Q RMSE ranges 0.6277–0.8785, R² shortfall 0.01314–0.01501. Advantage RMSE ranges 0.4711–0.5947; R² shortfall 0.02919–0.03019 (mean 0.02951). Mean SD of ΔQ over other mileages at fixed own mileage ranges 0.6403–0.8520; the range over other mileages at own mileage 0.5 is 3.123–4.488. Maximum off-diagonal policy-probability shift across other-bus mileage quintiles is 0.11975 (occupancy) and 0.18952 (uniform). The coupling figure data are in `oracle_diagnostics/v7_nonseparability.json`.

## Decision for handoff

Completed criteria already fail on V2 fitted p and Richardson RMSE(Q), while V4 remains pending with a sample-count deviation. This is not a final human Gate A decision. The finisher must read the V4 marker/result, resolve or rerun its sample count, assess the V3 p95/max SE evidence gap and V5 notation, then present the failed Gate A criteria for the human checkpoint. The phase-1 brief forbids running K=37 without escalation; none has been run here.
