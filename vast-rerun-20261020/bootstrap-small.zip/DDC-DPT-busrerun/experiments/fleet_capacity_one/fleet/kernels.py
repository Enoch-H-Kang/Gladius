"""Closed-form hat-Gamma kernel rows.

w_k(x) = E[phi_k(min(1, x + D))], D ~ Gamma(shape, scale), phi_k the hat function on the uniform grid
g_k = k/(K-1). On each grid cell [g_i, g_{i+1}] intersected with D in (0, 1-x) the contribution needs
P = P(l<D<u) and the partial first moment E[D; l<D<u] = shape*scale*(F_{shape+1}(u)-F_{shape+1}(l));
the atom P(D >= 1-x) goes to node K-1.
"""
import numpy as np
from scipy.special import gammainc, gammaincc

CLIP_LOG = {"max_neg": 0.0, "n_clipped": 0}


def _diff(a, l, u, scale):
    """F_a(u)-F_a(l) for Gamma(a, scale), via survival differences above the mean (no cancellation)."""
    zl, zu = l / scale, u / scale
    cdf = gammainc(a, zu) - gammainc(a, zl)
    sf = gammaincc(a, zl) - gammaincc(a, zu)
    return np.where(zl >= a, sf, cdf)


def hat_rows(x, K, shape, scale):
    """x (n,) -> rows (n,K). Rows sum to 1."""
    x = np.atleast_1d(np.asarray(x, dtype=np.float64))
    g = np.linspace(0.0, 1.0, K)
    h = 1.0 / (K - 1)
    lo = np.maximum(0.0, g[None, :-1] - x[:, None])
    hi = np.minimum(1.0 - x[:, None], g[None, 1:] - x[:, None])
    ok = hi > lo
    lo = np.where(ok, lo, 0.0)
    hi = np.where(ok, hi, 0.0)
    P = _diff(shape, lo, hi, scale)
    M = shape * scale * _diff(shape + 1.0, lo, hi, scale)
    w = np.zeros((x.shape[0], K))
    w[:, :-1] += ((g[None, 1:] - x[:, None]) * P - M) / h
    w[:, 1:] += ((x[:, None] - g[None, :-1]) * P + M) / h
    w[:, -1] += gammaincc(shape, (1.0 - x) / scale)  # atom at the cap
    neg = w.min()
    if neg < 0:
        if neg < -1e-13:
            raise FloatingPointError(f"kernel weight {neg} below -1e-13")
        CLIP_LOG["max_neg"] = min(CLIP_LOG["max_neg"], float(neg))
        CLIP_LOG["n_clipped"] += int((w < 0).sum())
        w = np.maximum(w, 0.0)
    return w


def kernel_matrix(K, shape, scale):
    """P[i,k] = w_k(g_i)."""
    return hat_rows(np.linspace(0.0, 1.0, K), K, shape, scale)


def expected_next(x, shape, scale):
    """E[min(1, x + D)] in closed form."""
    x = np.asarray(x, dtype=np.float64)
    c = 1.0 - x
    part = shape * scale * gammainc(shape + 1.0, c / scale)  # E[D; D < c]
    return x * gammainc(shape, c / scale) + part + 1.0 * gammaincc(shape, c / scale)
