"""Soft value iteration on the K^F tensor grid (float64) and lookahead Q_ref at off-grid states.

Q(s,a) = r(s,a) + beta * E[I_K V(s')],  V = logsumexp_a Q  (lambda = 1, no Euler constant).
a = 0 applies the F one-dimensional kernels to V; a = f slices V at x_f = 0 and contracts the other
F-1 axes (continuation does not depend on x_f).
"""
import json
import time

import numpy as np
from scipy.special import logsumexp

from .kernels import hat_rows, kernel_matrix
from .rewards import reward_all


def grid(K):
    return np.linspace(0.0, 1.0, K)


def kernel_list(p, K):
    return [kernel_matrix(K, p.shape, p.scale[j]) for j in range(p.F)]


def reward_grids(p, K):
    """r0 on the K^F nodes, and 1-D vectors delta_f(g) = m_f - C_f so that r_f = r0 + delta_f on axis f."""
    g = grid(K)
    u, v, Kc, d = p.arr("u"), p.arr("v"), p.Kcost_eff, p.arr("d")
    m = [u[j] * g + v[j] * g * g for j in range(p.F)]
    r0 = np.zeros((K,) * p.F)
    for j in range(p.F):
        shp = [1] * p.F
        shp[j] = K
        r0 = r0 - m[j].reshape(shp)
    delta = [m[f] - (Kc[f] + d[f] * g * g) for f in range(p.F)]
    return r0, delta


def apply_axes(W, Ps, axes):
    for P, ax in zip(Ps, axes):
        W = np.moveaxis(np.tensordot(P, W, axes=([1], [ax])), 0, ax)
    return W


def continuation(V, Ps, F):
    """List of F+1 continuation arrays: [0] full K^F, [f] shape K^(F-1) (axis f removed)."""
    out = [apply_axes(V, Ps, list(range(F)))]
    for f in range(F):
        sl = np.take(V, 0, axis=f)
        others = [j for j in range(F) if j != f]
        out.append(apply_axes(sl, [Ps[j] for j in others], list(range(F - 1))))
    return out


def bellman(V, p, Ps, r0, delta, reward_mult=1.0):
    """One application of T. Returns (Vnew, list of Q arrays)."""
    F = p.F
    cont = continuation(V, Ps, F)
    Qs = [reward_mult * r0 + p.beta * cont[0]]
    for f in range(F):
        shp = [1] * F
        shp[f] = V.shape[f]
        Qs.append(reward_mult * (r0 + delta[f].reshape(shp)) + p.beta * np.expand_dims(cont[f + 1], f))
    Vnew = logsumexp(np.stack(Qs, axis=0), axis=0)
    return Vnew, Qs


def solve_vi(p, K, V0=None, tol=5e-8, max_sweeps=1000, reward_mult=1.0, log=None):
    Ps = kernel_list(p, K)
    r0, delta = reward_grids(p, K)
    V = r0 / (1.0 - p.beta) if V0 is None else V0.copy()
    if reward_mult != 1.0 and V0 is None:
        V = reward_mult * r0 / (1.0 - p.beta)
    t0 = time.time()
    hist = []
    for n in range(1, max_sweeps + 1):
        Vn, _ = bellman(V, p, Ps, r0, delta, reward_mult)
        if not np.all(np.isfinite(Vn)):
            raise FloatingPointError("non-finite V in VI")
        dv = float(np.max(np.abs(Vn - V)))
        V = Vn
        hist.append(dv)
        if log and (n % 25 == 0 or dv < tol):
            log(f"K={K} sweep {n} dV={dv:.3e} t={time.time() - t0:.1f}s")
        if dv < tol:
            break
    return {"V": V, "sweeps": n, "dV_last": dv, "converged": dv < tol, "wall_s": time.time() - t0, "dV_hist": hist}


def residual(V, p, K, reward_mult=1.0):
    Ps = kernel_list(p, K)
    r0, delta = reward_grids(p, K)
    Vn, _ = bellman(V, p, Ps, r0, delta, reward_mult)
    return float(np.max(np.abs(Vn - V)))


def node_Q(V, p, K):
    Ps = kernel_list(p, K)
    r0, delta = reward_grids(p, K)
    return np.stack(bellman(V, p, Ps, r0, delta)[1], axis=-1)


# ---- off-grid lookahead -------------------------------------------------------------------
def _kron_rows(rows):
    out = rows[0]
    for r in rows[1:]:
        out = (out[:, :, None] * r[:, None, :]).reshape(out.shape[0], -1)
    return out


def contract_full(T, rows, n=None):
    """sum_{i1..id} T[i1..id] prod_j rows[j][n,ij] -> (n,). First ceil(d/2) axes via one GEMM."""
    d = len(rows)
    if d == 0:
        return np.full(n, float(np.asarray(T).reshape(-1)[0]))
    if d == 1:
        return rows[0] @ T
    m = (d + 1) // 2
    K = T.shape[0]
    M = _kron_rows(rows[:m]) @ T.reshape(K ** m, -1)
    return (M * _kron_rows(rows[m:])).sum(axis=1)


def lookahead_Q(states, V, p, chunk_bytes=2.0e8, dtype=np.float64):
    """Q_ref(s,a) = r(s,a) + beta * E[I_K V(s')] for states (n,F) -> (n,F+1)."""
    states = np.atleast_2d(np.asarray(states, dtype=np.float64))
    n, F = states.shape
    K = V.shape[0]
    Vd = V.astype(dtype, copy=False)
    Vf = [np.ascontiguousarray(np.take(Vd, 0, axis=f)) for f in range(F)]
    m = (F + 1) // 2
    ch = max(1, int(chunk_bytes // (np.dtype(dtype).itemsize * K ** m)))
    cont = np.empty((n, F + 1))
    for a in range(0, n, ch):
        x = states[a:a + ch]
        rows = [hat_rows(x[:, j], K, p.shape, p.scale[j]).astype(dtype, copy=False) for j in range(F)]
        cont[a:a + ch, 0] = contract_full(Vd, rows)
        for f in range(F):
            cont[a:a + ch, f + 1] = contract_full(Vf[f], [rows[j] for j in range(F) if j != f], x.shape[0])
    return reward_all(states, p) + p.beta * cont


def lse(Q):
    return logsumexp(Q, axis=-1)


def softmax(Q):
    return np.exp(Q - lse(Q)[..., None])


def save_V(path, V):
    np.save(path, V)


def load_V(path):
    return np.load(path)


def dump_json(path, obj):
    with open(path, "w") as fh:
        json.dump(obj, fh, indent=1, default=float)
