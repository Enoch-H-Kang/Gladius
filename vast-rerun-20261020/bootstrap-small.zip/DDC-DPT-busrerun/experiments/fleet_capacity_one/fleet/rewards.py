"""Full reward r(s, a) for evaluation / data generation only (needs Kcost, d)."""
import numpy as np

from .anchor import r0_np


def maintenance(s, p):
    s = np.asarray(s, dtype=np.float64)
    return p.arr("u") * s + p.arr("v") * s * s


def replacement(s, p):
    s = np.asarray(s, dtype=np.float64)
    return p.Kcost_eff + p.arr("d") * s * s


def reward_all(s, p):
    """(..., F+1): column 0 is the anchor r0, column f is r0 + m_f - C_f."""
    s = np.asarray(s, dtype=np.float64)
    r0 = r0_np(s, p.arr("u"), p.arr("v"))
    out = np.empty(s.shape[:-1] + (p.F + 1,))
    out[..., 0] = r0
    out[..., 1:] = r0[..., None] + maintenance(s, p) - replacement(s, p)
    return out


def reward(s, a, p):
    return np.take_along_axis(reward_all(s, p), np.asarray(a)[..., None], axis=-1)[..., 0]
