"""Known anchor reward r0(s) = r(s, a=0) = -sum_j (u_j x_j + v_j x_j^2).

This module must stay free of Kcost, d and transition parameters: it takes only u and v.
Anything imported by training code may import this module and nothing else from the DGP.
"""
import numpy as np


def r0_np(s, u, v):
    s = np.asarray(s, dtype=np.float64)
    return -(np.asarray(u) * s + np.asarray(v) * s * s).sum(axis=-1)


def r0_torch(s, u, v):
    import torch
    u = torch.as_tensor(u, dtype=s.dtype, device=s.device)
    v = torch.as_tensor(v, dtype=s.dtype, device=s.device)
    return -(u * s + v * s * s).sum(dim=-1)
