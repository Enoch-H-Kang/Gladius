"""Q-step and zeta-step losses (tuning-r2-codex section 3).

u = (q - r0 - beta*v)^2 - beta^2 (v - sg(z))^2, evaluated per transition. Because
(A)^2 - (beta B)^2 = (A - beta B)(A + beta B), u is computed in product form:
    (q - r0 - beta z) (q - r0 - 2 beta v + beta z).
`z` must already be detached by the caller (zeta is frozen during the Q step).
"""
import torch
import torch.nn.functional as F

LOSSES = ("none", "clip0", "abs")


def u_product(q, r0, v, z, beta):
    return (q - r0 - beta * z) * (q - r0 - 2.0 * beta * v + beta * z)


def u_square(q, r0, v, z, beta):
    return (q - r0 - beta * v) ** 2 - beta ** 2 * (v - z) ** 2


def f_of_u(u, loss):
    """Per-row transform. clip0 and abs have zero derivative at u = 0 (the mask is detached)."""
    if loss == "none":
        return u
    if loss == "clip0":
        return u * (u > 0).to(u.dtype).detach()
    if loss == "abs":
        return u * torch.sign(u).detach()
    raise ValueError(f"unknown loss {loss!r}")


def be_term(q_sa, r0, v, z, is_anchor, beta, loss):
    """mean over the WHOLE anchor batch of m * f(u); all operands have shape (B,)."""
    assert q_sa.dim() == 1 and q_sa.shape == r0.shape == v.shape == z.shape == is_anchor.shape
    u = u_product(q_sa, r0, v, z, beta)
    return (is_anchor.to(u.dtype) * f_of_u(u, loss)).mean()


def ce_term(q_all, a):
    assert q_all.dim() == 2 and a.dim() == 1 and q_all.shape[0] == a.shape[0]
    return F.cross_entropy(q_all, a)


def zeta_term(z_sa, v):
    assert z_sa.dim() == 1 and z_sa.shape == v.shape
    return ((z_sa - v) ** 2).mean()
