"""Observable-only checkpoint selection (tuning-r2-codex section 6, within-fit layer).

Inputs are validation records {t, nll, anchor_rmse, finite, hash}; nothing here can see truth.
"""
import math

TIE_NLL = 0.001


def select_checkpoint(records, horizon, elig_start=5000, anchor_tol=0.10):
    """Return (status, chosen_record_or_None).

    status: ok | anchor_fail | failed. Candidates are checkpoints with elig_start <= t <= horizon.
    ok: among finite records with A <= anchor_tol take min NLL, tie set NLL <= min + 0.001,
    pick min A, then earliest step, then checkpoint hash. anchor_fail: no eligible record, keep min NLL + A^2
    (flagged). failed: no finite candidate or validation has no anchor row (A is NaN).
    """
    cand = [r for r in records if elig_start <= r["t"] <= horizon]
    fin = [r for r in cand if r["finite"] and math.isfinite(r["nll"]) and math.isfinite(r["anchor_rmse"])]
    if not fin:
        return "failed", None
    elig = [r for r in fin if r["anchor_rmse"] <= anchor_tol]
    if elig:
        m = min(r["nll"] for r in elig)
        tie = [r for r in elig if r["nll"] <= m + TIE_NLL]
        return "ok", min(tie, key=lambda r: (r["anchor_rmse"], r["t"], r["hash"]))
    best = min(fin, key=lambda r: (r["nll"] + r["anchor_rmse"] ** 2, r["t"], r["hash"]))
    return "anchor_fail", best
