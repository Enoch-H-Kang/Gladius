"""Fixed numerical-validation state sets (no estimator involvement)."""
import numpy as np

from . import env, oracle


def seeded(seed, stream):
    return np.random.default_rng(np.random.SeedSequence([seed, stream]))


def uniform_states(n, F, seed, per_axis=4):
    """Jittered-stratified uniform states on per_axis^F cells, repeated and truncated to n."""
    rng = seeded(seed, 0)
    ncell = per_axis ** F
    reps = -(-n // ncell)
    cells = np.tile(np.arange(ncell), reps)
    rng.shuffle(cells)
    cells = cells[:n]
    idx = np.stack([(cells // per_axis ** j) % per_axis for j in range(F)], 1)
    return (idx + rng.uniform(size=(n, F))) / per_axis


def face_states(n, F, seed):
    """Coordinate chosen uniformly, set alternately to exactly 0 / 1, others uniform."""
    rng = seeded(seed, 0)
    x = rng.uniform(size=(n, F))
    f = rng.integers(0, F, size=n)
    x[np.arange(n), f] = (np.arange(n) % 2).astype(float)
    return x


def policy_from_V(V, p):
    return lambda s: oracle.softmax(oracle.lookahead_Q(s, V, p))


def occupancy_states(V, p, seed, n_chains=100, H=100):
    pol = policy_from_V(V, p)
    ch = env.simulate_chains(pol, n_chains, p, seeded(seed, 1), seeded(seed, 2), seeded(seed, 3), H=H)
    return ch["s"].reshape(-1, p.F)
