"""Stream-seed derivation for the tuning study (tuning-r2-codex section 4).

Seeds exclude loss / k / rates so that candidate configurations are paired on identical data
orders and initial weights.
"""
import hashlib

ROOT = "20261018"
STREAMS = ("qinit", "zinit", "ce", "extrazeta", "anchor", "eval")
MOD = 2 ** 63 - 1


def derive_seed(testbed, stage, data_id, init_index, stream):
    key = f"{ROOT}|{testbed}|{stage}|{data_id}|{init_index}|{stream}"
    return int.from_bytes(hashlib.sha256(key.encode("utf-8")).digest()[:8], "big") % MOD


def expand_seeds(testbed, stage, data_id, init_index):
    return {s: derive_seed(testbed, stage, data_id, init_index, s) for s in STREAMS}
