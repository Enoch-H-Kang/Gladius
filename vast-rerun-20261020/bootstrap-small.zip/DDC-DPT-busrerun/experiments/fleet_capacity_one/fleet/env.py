"""Chain simulator. Replaced bus -> exactly 0 (no same-period increment); others min(1, x + D).

Restarts are recording artifacts: each chain contributes H transitions (s_t, a_t, s_{t+1}) and the
last one keeps its real successor. A restart is never a transition.
"""
import numpy as np


def sample_increments(rng, n, p):
    return rng.gamma(p.shape, p.scale, size=(n, p.F))


def step(s, a, D, p):
    """s (n,F), a (n,) in 0..F, D (n,F) increments. Returns s' (n,F)."""
    s = np.asarray(s, dtype=np.float64)
    a = np.asarray(a)
    sp = np.minimum(1.0, s + D)
    rows = np.nonzero(a > 0)[0]
    sp[rows, a[rows] - 1] = 0.0
    return sp


def sample_actions(probs, u):
    c = np.cumsum(probs, axis=1)
    c[:, -1] = 1.0
    return (u[:, None] > c).sum(axis=1)


def simulate_chains(policy_fn, n_chains, p, rng_start, rng_action, rng_incr, H=None, burn_in=0, x0=None):
    """policy_fn(states (n,F)) -> probs (n,F+1). Returns dict of arrays shaped (n_chains, H, ...)."""
    H = p.H if H is None else H
    s = rng_start.uniform(0.0, p.start_max, size=(n_chains, p.F)) if x0 is None else np.array(x0, float)
    for _ in range(burn_in):
        a = sample_actions(policy_fn(s), rng_action.uniform(size=n_chains))
        s = step(s, a, sample_increments(rng_incr, n_chains, p), p)
    S = np.empty((n_chains, H, p.F)); A = np.empty((n_chains, H), dtype=np.int64); SP = np.empty_like(S)
    for t in range(H):
        a = sample_actions(policy_fn(s), rng_action.uniform(size=n_chains))
        sp = step(s, a, sample_increments(rng_incr, n_chains, p), p)
        S[:, t], A[:, t], SP[:, t] = s, a, sp
        s = sp
    return {"s": S, "a": A, "sp": SP}
