"""Q and zeta networks: two hidden layers of ReLU units, Xavier-normal weights, zero hidden biases."""
import math

import torch
import torch.nn as nn


class MLP(nn.Module):
    def __init__(self, in_dim, out_dim, width=10, depth=2):
        super().__init__()
        dims = [in_dim] + [width] * depth + [out_dim]
        self.layers = nn.ModuleList(nn.Linear(dims[i], dims[i + 1]) for i in range(len(dims) - 1))

    def forward(self, x):
        for layer in self.layers[:-1]:
            x = torch.relu(layer(x))
        return self.layers[-1](x)


def init_mlp(net, seed, out_bias):
    """Xavier-normal weights drawn from an explicit generator, zero hidden biases, constant output bias."""
    g = torch.Generator().manual_seed(int(seed))
    with torch.no_grad():
        for i, layer in enumerate(net.layers):
            fan_out, fan_in = layer.weight.shape
            std = math.sqrt(2.0 / (fan_in + fan_out))
            layer.weight.copy_(torch.randn(layer.weight.shape, generator=g) * std)
            layer.bias.zero_()
        net.layers[-1].bias.fill_(float(out_bias))
    return net
