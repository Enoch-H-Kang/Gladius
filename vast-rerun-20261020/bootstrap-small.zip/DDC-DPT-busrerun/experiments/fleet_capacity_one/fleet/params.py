"""Frozen DGP parameters. Load from configs/dgp.json; dgp_id = sha256 of the canonical JSON."""
import dataclasses
import hashlib
import json

import numpy as np


@dataclasses.dataclass(frozen=True)
class Params:
    F: int
    u: tuple
    v: tuple
    Kcost: tuple
    d: tuple
    mean: tuple
    shape: float
    beta: float
    lam: float
    H: int
    start_max: float
    kcost_scale: float = 1.0

    @classmethod
    def from_json(cls, path):
        with open(path) as fh:
            raw = json.load(fh)
        for k, val in list(raw.items()):
            if isinstance(val, list):
                raw[k] = tuple(float(x) for x in val)
        return cls(**raw)

    def to_dict(self):
        out = dataclasses.asdict(self)
        return {k: (list(v) if isinstance(v, tuple) else v) for k, v in out.items()}

    @property
    def dgp_id(self):
        blob = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(blob.encode()).hexdigest()

    @property
    def n_actions(self):
        return self.F + 1

    @property
    def scale(self):
        return np.asarray(self.mean) / self.shape

    @property
    def Kcost_eff(self):
        return np.asarray(self.Kcost) * self.kcost_scale

    def arr(self, name):
        return np.asarray(getattr(self, name), dtype=np.float64)

    def subset(self, F):
        """First F buses (used by the F=1 / F=2 dimension ladder)."""
        sl = lambda t: tuple(t[:F])
        return dataclasses.replace(self, F=F, u=sl(self.u), v=sl(self.v), Kcost=sl(self.Kcost),
                                   d=sl(self.d), mean=sl(self.mean))

    def replace(self, **kw):
        return dataclasses.replace(self, **kw)
