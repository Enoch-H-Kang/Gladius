"""Run one compound released-code BR diagnostic in a fresh process."""
import hashlib
import json
import os
import socket
import sys
import time
import torch
from .refcode_fit import fit
from .data_io import load_bus
from .run_fit import file_hash

def code_hash():
    names=("tuning/run_refcode.py","tuning/refcode_fit.py","tuning/data_io.py","tuning/bus_anchor.py",
           "fleet/models.py","fleet/losses.py","fleet/select.py")
    root=os.path.dirname(os.path.dirname(__file__))
    h=hashlib.sha256()
    for name in names: h.update(open(os.path.join(root,name),"rb").read())
    return h.hexdigest()

def main(manifest,fit_id,fits_root,export):
    torch.set_num_threads(1)
    m=json.load(open(manifest))
    spec=next(f for f in m["fits"] if f["fit_id"]==fit_id)
    export_path=os.path.join(export,spec["data_id"]+".npz") if os.path.isdir(export) else export
    data=load_bus(export_path,spec["n_chains"])
    cfg={k:v for k,v in spec["config"].items() if k!="N"}
    out=os.path.join(fits_root,fit_id)
    os.makedirs(out,exist_ok=True)
    start=time.time()
    rec=fit(data,cfg,spec["seeds"],horizons=spec["horizons"],ckpt_dir=out)
    rec.update(fit_id=fit_id,stage="BR",config_id=spec["config_id"],init_index=spec["init_index"],
               data_id=spec["data_id"],n_chains=spec["n_chains"],manifest_sha=m["sha256"],
               code_hash=code_hash(),export_hash=file_hash(export_path),host=socket.gethostname(),
               pid=os.getpid(),start_unix=start,end_unix=time.time(),
               refcode_adapter="one zeta then one Q update per cycle; historical skipped parity batches omitted",
               env_threads={k:os.environ.get(k) for k in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS")})
    tmp=os.path.join(out,"record.json.tmp")
    with open(tmp,"w") as f: json.dump(rec,f)
    os.replace(tmp,os.path.join(out,"record.json"))

if __name__=="__main__":
    main(*sys.argv[1:])
