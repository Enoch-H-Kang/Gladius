"""Public bus anchor interface: replacing the engine (action 1) has the known reward -theta_2."""
ANCHOR_ACTION = 1
N_ACTIONS = 2
THETA_REPLACE = 5.0
BETA = 0.95
MAX_MILEAGE = 10
STATE_SCALE = 10.0


def r0(s):
    """Anchor reward at state s (constant for the zero-dummy, one-type bus DGP)."""
    import numpy as np
    return np.full(np.shape(s)[:1], -THETA_REPLACE, dtype=np.float64)
