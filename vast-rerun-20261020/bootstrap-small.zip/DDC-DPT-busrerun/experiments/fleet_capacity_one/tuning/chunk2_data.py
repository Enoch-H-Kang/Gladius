"""Fresh, truth-stripped B3/BL bus pools and cross-pool collision audit."""
import json
import os
import pickle
import sys
from . import bus_data

def make(seeds, art, out):
    os.makedirs(art, exist_ok=True)
    os.makedirs(out, exist_ok=True)
    all_hashes = {}
    prior = os.path.join(art, "gen7000")
    all_hashes[7000] = set(bus_data.chain_hashes(pickle.load(open(os.path.join(prior, "train.pkl"), "rb")) +
                                                 pickle.load(open(os.path.join(prior, "test.pkl"), "rb"))))
    audits = {}
    for seed in seeds:
        raw = os.path.join(art, f"gen{seed}")
        audit_path = os.path.join(out, f"bus_pool_seed{seed}.json")
        export_path = os.path.join(art, f"bus_seed{seed}.npz")
        if os.path.exists(audit_path) and os.path.exists(export_path):
            tr=pickle.load(open(os.path.join(raw, "train.pkl"), "rb"))
            te=pickle.load(open(os.path.join(raw, "test.pkl"), "rb"))
            audit=json.load(open(audit_path))
        else:
            tr, te = bus_data.generate_pool(seed, 1000, raw)
            audit = bus_data.audit_pool(tr, te, audit_path, seed)
        assert audit["pass"], (seed, audit)
        hh = set(bus_data.chain_hashes(tr + te))
        assert len(hh) == 1000
        all_hashes[seed] = hh
        if not os.path.exists(export_path): bus_data.export_pool(tr, te, export_path)
        audits[str(seed)] = audit
        print(seed, audit["pass"], flush=True)
    for panel_seed in (7199, 7299):
        all_hashes[panel_seed] = set(bus_data.chain_hashes(bus_data.generate_chains(panel_seed, 200)))
    collisions = {f"{a}-{b}": len(all_hashes[a] & all_hashes[b])
                  for a in all_hashes for b in all_hashes if a < b}
    assert all(v == 0 for v in collisions.values()), collisions
    json.dump(dict(seeds=list(seeds), collisions=collisions,
                   generator_sha256=bus_data.generator_sha(), audits=audits),
              open(os.path.join(out, "chunk2_pool_audit.json"), "w"), indent=1)

if __name__ == "__main__":
    stage=sys.argv[1]
    seeds=range(7200,7205) if stage=="B3" else (range(7300,7303) if stage=="BL" else list(range(7200,7205))+list(range(7300,7303)))
    make(seeds, "experiments/fleet_capacity_one/artifacts/tuning",
         "experiments/fleet_capacity_one/results/tuning/audit")
