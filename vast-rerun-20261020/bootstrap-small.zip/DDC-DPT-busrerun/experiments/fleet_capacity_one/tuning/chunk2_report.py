"""Render chunk-2 evidence after B2/B3/BL/BR completion. Reporting only."""
import csv
import json
import math
from statistics import median
from .chunk2_analysis import load, RES, ART, FAMILIES

def J(name): return json.load(open(f"{RES}/{name}.json"))
def F(x,n=4):
    if x is None:return "—"
    if isinstance(x,float) and not math.isfinite(x):return "—"
    if isinstance(x,int):return str(x)
    return f"{x:.{n}f}"
def T(lines,header,rows):
    lines.append("| "+" | ".join(header)+" |")
    lines.append("| "+" | ".join(["---"]*len(header))+" |")
    for row in rows: lines.append("| "+" | ".join(map(str,row))+" |")
    lines.append("")

def main():
    b2=J("B2_family_finalists"); b3=J("B3_confirmation"); lock=J("bus_locked_protocol")
    ints={s:J(s+"_integrity") for s in ("B2","B3","BL","BR")}
    audits=J("audit/chunk2_pool_audit")
    lines=["# Tuning chunk 2: bus B2, B3, BL, BR","",
           "Branch: `fleet-capacity-one`. Development study only; no fleet transfer or protected headline data were opened.","",
           "## Pools, integrity, and selection boundary","",
           "B2 and BR used the audited seed-7000 fallback pool from chunk 1. B3 used fresh data seeds 7200–7204 at N=5,000 and 100,000; BL used fresh seeds 7300–7302 at N=20,000. Each pool has 1,000 distinct 100-step chains, a permanent whole-chain 80/20 split, and truth stripped from trainer exports. The fresh-pool audits passed and all "+
           str(len(audits["collisions"]))+" pairwise comparisons among the development pools and panels had zero chain collisions. B2/B3 structural comparisons use development truth only at observable-selected checkpoints. BL's rate/horizon lock was written by `observable_lock.py` from validation records and hashed before BL truth evaluation.","",
           "## B2 nuisance refinement","",
           "Exactly 4 protected family centers × 16 specified nuisance rows × 3 archive initializations were scheduled. The table gives the width-10 family finalist; width-50/64 rows are capacity diagnostics and cannot advance to B3. RMSE and Q RMSE are development-truth metrics; NLL and A are validation observables. Values are medians across three initializations except score, which is the mean log-normalized reward error with failure penalties.",""]
    r=[]
    for fam in FAMILIES:
        x=b2[fam];c=x["config"]
        r.append([fam,x["row"],c["loss"],c["k"],c["opt"],c["width"],c["batch"],F(c["c_be"],2),
                  c["bias"],F(c["lr_q"],6),F(c["rho"],3),f"{x['n_ok']}/3",
                  "rescue" if x["info"]["rescue"] else "eligible",
                  F(x["med_truth_nonanchor_rmse"]),F(x["score"]),F(x["med_nll"]),F(x["med_anchor_rmse"]),
                  F(x["med_truth_q_rmse"])])
    T(lines,["Family","row","L","k","opt","width","B","c_BE","bias","lr_Q","rho","ok","status",
             "reward RMSE","score","val NLL","A","Q RMSE"],r)
    lines += ["Full 64-row table: `B2_candidates.csv`; all 192 slots: `B2_fits.csv`. The two B1 none-family centers entered as flagged rescues; a B2 none-family row is releasable only if all its fits meet the observable gates.","",
              "## B3 fresh-seed confirmation","",
              "The four B2 width-10 family finalists were fixed before B3. Each received 5 new data seeds × 2 initializations at each N. Each stratum needs at least 9/10 eligible fits and validation NLL within 0.01 of the best stability-eligible candidate. The paired bootstrap resamples whole data-seed blocks (2,000 draws); B3 truth did not trigger any re-selection or new fit.",""]
    r=[]
    for x in b3["candidates"]:
        for n in ("5000","100000"):
            z=x["strata"][n]
            r.append([x["family"],n,f"{z['n_ok']}/{z['n']}",F(z["med_truth_nonanchor_rmse"]),
                      F(z["score"]),F(z["med_nll"]),F(z["med_anchor_rmse"]),
                      "yes" if x.get("in_tie_set") else "no", "yes" if x["stable"] else "no"])
    T(lines,["Family","N","ok","reward RMSE","score","val NLL","A","winner tie","stable"],r)
    win=next((x for x in b3["candidates"] if x["config_id"]==b3["winner_config_id"]),None)
    if win:
        lines += [f"**B3 bus choice:** `{win['family']}`, loss `{win['config']['loss']}`, k={win['config']['k']}; "+
                  f"aggregate score {F(win['score'])}, median reward RMSE {F(win['med_truth_nonanchor_rmse'])}, "+
                  f"median val NLL {F(win['med_nll'])}, A {F(win['med_anchor_rmse'])}. "+
                  "This is the pre-registered confirmation rule's result; no candidate was swapped after viewing B3 truth.",""]
    else: lines += ["**B3 outcome:** no releasable winner under the pre-registered gates; no bus release.",""]
    lines += ["Full per-fit results: `B3_fits.csv`; candidate decisions: `B3_confirmation.json`.","",
              "## BL observable rate and horizon lock","",
              "All 18 rate-pair fits were trained to 50,000 Q steps. The table treats 10k/20k/50k as prefix policies, not independent fits. Each policy needs 3/3 eligible checkpoints. Validation NLL selects the 0.001 tie set; median A, shorter horizon, rho=1, smaller rate, and ID break ties. The lock was hashed before any BL reward-truth evaluation.",""]
    _,blrows=load("BL",truth=True)
    policies=list(csv.DictReader(open(f"{RES}/BL_policies.csv")))
    rr=[]
    for p in policies:
        h=int(p["horizon"]);eta=float(p["lr_q"]);rho=float(p["rho"])
        x=[z for z in blrows if z["horizon"]==h and z["lr_q"]==eta and z["rho"]==rho]
        vals=[z["truth_nonanchor_rmse"] for z in x if z.get("truth_nonanchor_rmse") is not None]
        rm=median(vals) if vals else None
        rr.append([F(eta,6),F(rho,2),h,p["n_ok"]+"/3",F(rm),F(float(p["med_nll"]) if p["med_nll"] else None),
                   F(float(p["med_anchor_rmse"]) if p["med_anchor_rmse"] else None),
                   "LOCK" if h==lock["policy"]["horizon"] and eta==lock["policy"]["lr_q"] and rho==lock["policy"]["rho"] else ""])
    T(lines,["lr_Q","rho","horizon","ok","reward RMSE (post-lock)","val NLL","A","decision"],rr)
    c=lock["design"]
    lines += [f"**Bus locked protocol candidate:** loss `{c['loss']}`, k={c['k']}, width={c['width']}×{c['depth']}, "+
              f"`{c['opt']}`, B={c['batch']}, c_BE={F(c['c_be'],2)}, bias=`{c['bias']}`, "+
              f"lr_Q={F(c['lr_q'],6)}, rho={F(c['rho'],2)}, Q horizon={c['cap_q']}; "+
              f"checkpoint gate A≤{F(c['anchor_tol'],2)}, NLL tie width 0.001. Lock SHA256: `{lock['sha256']}`. "+
              "This is the bus-side candidate for fleet transfer and the later joint design decision, not a protected headline result.","",
              "## BR released-code diagnostic","",
              "BR is context only and cannot win. It uses a shared trunk, two overlapping AdamW optimizers, |u| averaged over observed anchor rows, section-3 default rate/batch/bias, and one zeta step followed by one Q step per cycle. The last schedule is the declared adapter difference from the historical parity-skipped loop.",""]
    _,brrows=load("BR",truth=True)
    brrows=[x for x in brrows if x["horizon"]==50000]
    T(lines,["init","optimizer status","checkpoint","reward RMSE","Q RMSE","KL","val NLL","A","fit s"],
      [[x["init"],x["fit_status"],x["status"],F(x.get("truth_nonanchor_rmse")),F(x.get("truth_q_rmse")),
        F(x.get("truth_kl")),F(x.get("nll")),F(x.get("anchor_rmse")),F(x.get("time_total"),1)] for x in brrows])
    lines += ["## Fit accounting and wall time","",
              "Completed/diverged count fresh optimization trajectories. An `anchor_fail` is a completed trajectory with no checkpoint below A=0.10; it remains in the denominator. No seed or initialization was replaced.",""]
    rr=[]
    for stage in ("B2","B3","BL","BR"):
        x=ints[stage];co=x["counts"]
        rr.append([stage,x["planned"],co.get("complete",0),co.get("diverged",0),co.get("missing",0),x["worker_failed_attempts"],
                   co.get("h50000_anchor_fail",0),co.get("h50000_ok",0),
                   F(x.get("stage_wall_s") or x.get("fit_wall_s"),1),
                   (x["sampled_peak_tokens"] or "—")])
    T(lines,["stage","planned","complete","diverged","missing","worker failed attempts","50k anchor fail","50k ok","wall s","tokens"],rr)
    lines += ["B2's initial launch had 10 infrastructure exits before the seed-7000 export alias existed. Those exact fit IDs were retried with unchanged settings and seeds; their first failed attempts are recorded in `ledger/queue_B2.csv` and `ledger/B2_resume_dispatch.json`. The first runner's 10 active fits drained while a filtered exact-slot queue admitted additional workers after the oracle ended. The queue has 202 starts for 192 distinct fit IDs: 10 initial failed attempts were retried, and 42 starts have no end event after runner interruptions. Every planned slot has one terminal record. The sampled peak was 44 total project tokens with no over-cap sample; no fleet tuning or protected headline runs were started. BR's queue ledger records each separate diagnostic process.","",
              "## Deviations and handoff","",
              "- The rejected review archives and seed-7000 fallback are inherited from chunk 1; B2 and BR kept that audited pool.",
              "- B2 launch alias error caused 10 failed worker attempts, then exact-slot retries. No planned fit was dropped or replaced.",
              "- Fresh-pool generation paused during the oracle's final run to preserve thread headroom; it resumed and passed all audits.",
              "- BR's one-zeta/one-Q adapter omits historical skipped parity batches, as pre-specified.",
              "- The bus candidate proceeds only to the separate fleet transfer chunk after Gate A/B/C. This chunk stops after BR.",""]
    path=f"{RES}/CHUNK2_REPORT.md"
    with open(path,"w") as f:f.write("\n".join(lines))
    print(path,len(lines),"lines")

if __name__=="__main__":main()
