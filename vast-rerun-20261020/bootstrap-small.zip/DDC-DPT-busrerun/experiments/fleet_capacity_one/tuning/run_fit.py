"""Run ONE scheduled fit in a fresh process: python -m ...tuning.run_fit MANIFEST FIT_ID FITS_ROOT EXPORT_NPZ"""
import hashlib
import json
import os
import socket
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = [os.path.join(HERE, "..", "fleet", f) for f in ("train.py", "losses.py", "models.py", "select.py", "seeds.py")] + \
      [os.path.join(HERE, f) for f in ("run_fit.py", "data_io.py", "bus_anchor.py")]


def code_hash():
    h = hashlib.sha256()
    for p in SRC:
        h.update(open(p, "rb").read())
    return h.hexdigest()


def file_hash(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main(manifest, fit_id, fits_root, export):
    import torch
    from ..fleet.train import fit
    from .data_io import load_bus
    torch.set_num_threads(1)
    m = json.load(open(manifest))
    spec = next(f for f in m["fits"] if f["fit_id"] == fit_id)
    t_start = time.time()
    export_path = os.path.join(export, spec["data_id"] + ".npz") if os.path.isdir(export) else export
    data = load_bus(export_path, spec["n_chains"])
    cfg = {k: v for k, v in spec["config"].items() if k != "N"}
    out = os.path.join(fits_root, fit_id)
    os.makedirs(out, exist_ok=True)
    rec = fit(data, cfg, spec["seeds"], horizons=spec["horizons"], ckpt_dir=out)
    rec.update(fit_id=fit_id, stage=spec["stage"], config_id=spec["config_id"], init_index=spec["init_index"],
               data_id=spec["data_id"], n_chains=spec["n_chains"], manifest_sha=m["sha256"],
               code_hash=code_hash(), export_hash=file_hash(export_path), n_train_chains=data["n_train_chains"],
               n_val_chains=data["n_val_chains"], host=socket.gethostname(), pid=os.getpid(),
               start_unix=t_start, end_unix=time.time(),
               env_threads={k: os.environ.get(k) for k in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS")})
    tmp = os.path.join(out, "record.json.tmp")
    with open(tmp, "w") as f:
        json.dump(rec, f)
    os.replace(tmp, os.path.join(out, "record.json"))


if __name__ == "__main__":
    main(*sys.argv[1:5])
