"""Post-fit development analysis. No trainer or selector imports this file."""
import csv
import hashlib
import json
import math
import os
import sys
from collections import defaultdict
from statistics import median
import numpy as np
from .chunk2_manifest import FAMILIES, b3, bl, write
from .manifest import config_id

PRACTICAL = math.log(1.05)
BASE = "experiments/fleet_capacity_one"
RES = BASE + "/results/tuning"
ART = BASE + "/artifacts/tuning"
TRUTH_KEYS = ("nonanchor_rmse","reward_scale","q_rmse","adv_rmse","kl","nonanchor_mape",
              "uniform_nonanchor_rmse","tail_nonanchor_rmse","zeta_lag_rmse")

def save_json(path, x):
    with open(path, "w") as f: json.dump(x, f, indent=1, allow_nan=False)

def write_csv(path, rows):
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with open(path,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=keys)
        w.writeheader(); w.writerows(rows)

def load(stage, truth=True):
    m=json.load(open(f"{RES}/manifests/manifest_{stage}.json"))
    rows=[]
    for spec in m["fits"]:
        c=spec["config"]; rp=f"{ART}/fits_{stage}/{spec['fit_id']}/record.json"
        rec=json.load(open(rp)) if os.path.exists(rp) else None
        tpath=f"{RES}/truth_{stage}/{spec['fit_id']}.json"
        t=json.load(open(tpath)) if truth and os.path.exists(tpath) else None
        for h in spec["horizons"]:
            hr=rec["horizons"][str(h)] if rec else {}
            th=t["horizons"].get(str(h)) if t else None
            row=dict(fit_id=spec["fit_id"],config_id=spec["config_id"],family=spec.get("family"),
                     row=spec.get("row"),data_id=spec["data_id"],N=spec["n_chains"]*100,init=spec["init_index"],
                     horizon=h,loss=c["loss"],k=c["k"],width=c["width"],opt=c["opt"],
                     batch=c["batch"],c_be=c["c_be"],bias=c["bias"],lr_q=c["lr_q"],rho=c["rho"],
                     status=hr.get("status","no_record"),fit_status=rec["fit_status"] if rec else "no_record",
                     nll=hr.get("nll"),anchor_rmse=hr.get("anchor_rmse"),top1=hr.get("top1"),
                     step=hr.get("step"),time_total=rec["time"]["total"] if rec else None,
                     start_unix=rec["start_unix"] if rec else None,end_unix=rec["end_unix"] if rec else None,
                     q_updates=rec["counts"]["q_updates"] if rec else None,
                     z_updates=rec["counts"]["z_updates"] if rec else None)
            if th: row.update({"truth_"+key:th.get(key) for key in TRUTH_KEYS})
            rows.append(row)
    return m,rows

def score(r):
    if r["status"]=="ok" and r.get("truth_nonanchor_rmse") is not None and r.get("truth_reward_scale"):
        x=r["truth_nonanchor_rmse"]/max(r["truth_reward_scale"],1e-8)
        if math.isfinite(x): return math.log(min(max(x,1e-8),10.0))
    return math.log(10)

def med(rows,key):
    v=[r[key] for r in rows if r.get(key) is not None and math.isfinite(r[key])]
    return float(median(v)) if v else None

def fidelity(c):
    cfg=c["config"]
    return ({"none":0,"clip0":1,"abs":2}[cfg["loss"]],cfg["k"],
            0 if cfg["opt"]=="sgd" else 1,
            0 if cfg["c_be"]==1 else 1,abs(math.log(cfg["c_be"])),
            0 if cfg["rho"]==1 else 1,abs(math.log(cfg["rho"])),
            0 if cfg["bias"]=="anchor" else 1,
            abs(math.log(cfg["batch"]/256)),cfg["width"],cfg["k"]+1,c["config_id"])

def summary(specs, rows):
    by=defaultdict(list)
    for r in rows: by[r["config_id"]].append(r)
    out=[]
    for s in specs:
        cid=s["config_id"]
        if any(x["config_id"]==cid for x in out): continue
        rs=by[cid]
        v=dict(config_id=cid,config=s["config"],family=s.get("family"),row=s.get("row"),
               n=len(rs),n_ok=sum(r["status"]=="ok" for r in rs),
               n_truth=sum(r.get("truth_nonanchor_rmse") is not None for r in rs),
               n_diverged=sum(r["fit_status"]=="diverged" for r in rs),
               n_failed=sum(r["status"] not in ("ok","anchor_fail") for r in rs),
               n_anchor_fail=sum(r["status"]=="anchor_fail" for r in rs),
               score=float(np.mean([score(r) for r in rs])),med_nll=med(rs,"nll"),
               med_anchor_rmse=med(rs,"anchor_rmse"),
               med_truth_nonanchor_rmse=med(rs,"truth_nonanchor_rmse"),
               med_truth_q_rmse=med(rs,"truth_q_rmse"),med_truth_kl=med(rs,"truth_kl"),
               med_top1=med(rs,"top1"),med_time_total=med(rs,"time_total"))
        v["med_nll_plus_a2"]=med([dict(x,nll_a2=x["nll"]+x["anchor_rmse"]**2)
                                   for x in rs if x.get("nll") is not None and x.get("anchor_rmse") is not None],"nll_a2")
        out.append(v)
    return out

def b2_analyze():
    m,allrows=load("B2")
    rows=[r for r in allrows if r["horizon"]==50000]
    write_csv(f"{RES}/B2_fits.csv",rows)
    cs=summary(m["fits"],rows)
    flat=[{k:v for k,v in c.items() if k!="config"} | c["config"] for c in cs]
    write_csv(f"{RES}/B2_candidates.csv",flat)
    picks={}
    for fam in FAMILIES:
        fc=[c for c in cs if c["family"]==fam and c["config"]["width"]==10]
        stable=[c for c in fc if c["n_ok"]==3 and c["n_truth"]==3 and c["n_diverged"]==0 and c["med_nll"] is not None]
        if stable:
            best_nll=min(c["med_nll"] for c in stable)
            eligible=[c for c in stable if c["med_nll"]<=best_nll+0.01]
            best=min(eligible,key=lambda c:(c["score"],c["config_id"]))
            tie=[c for c in eligible if c["score"]-best["score"]<=PRACTICAL]
            pick=min(tie,key=fidelity)
            info=dict(rescue=False,best=best["config_id"],tie_set=[c["config_id"] for c in tie],
                      n_width10_eligible=len(eligible))
        else:
            pick=min(fc,key=lambda c:(c["n"]-c["n_ok"],
                        float("inf") if c["med_nll_plus_a2"] is None else c["med_nll_plus_a2"],c["config_id"]))
            info=dict(rescue=True,best=None,tie_set=[],n_width10_eligible=0)
        picks[fam]=dict(pick,info=info)
    save_json(f"{RES}/B2_family_finalists.json",picks)
    bm=b3(picks)
    write(bm,f"{RES}/manifests")
    return picks,bm

def bootstrap_lower(a,b):
    # 5 fresh data blocks, preserving both N and both initializations in each resample.
    seeds=sorted(set(r["data_id"] for r in a))
    av=np.array([np.mean([score(r) for r in a if r["data_id"]==s]) for s in seeds])
    bv=np.array([np.mean([score(r) for r in b if r["data_id"]==s]) for s in seeds])
    rng=np.random.default_rng(20261019)
    ix=rng.integers(0,len(seeds),size=(2000,len(seeds)))
    return float(np.quantile((av-bv)[ix].mean(axis=1),.025,method="linear"))

def b3_analyze():
    m,allrows=load("B3")
    rows=[r for r in allrows if r["horizon"]==50000]
    write_csv(f"{RES}/B3_fits.csv",rows)
    by=defaultdict(list)
    for r in rows: by[r["family"]].append(r)
    cs=[]
    for fam in FAMILIES:
        rr=by[fam]
        cfg=dict(next(f["config"] for f in m["fits"] if f["family"]==fam),N=20000)
        c=dict(family=fam,config=cfg,config_id=config_id(cfg),n=len(rr),
               n_ok=sum(r["status"]=="ok" for r in rr),
               n_truth=sum(r.get("truth_nonanchor_rmse") is not None for r in rr),
               n_diverged=sum(r["fit_status"]=="diverged" for r in rr),
               n_anchor_fail=sum(r["status"]=="anchor_fail" for r in rr),
               n_failed=sum(r["status"] not in ("ok","anchor_fail") for r in rr),
               score=float(np.mean([score(r) for r in rr])),
               med_nll=med(rr,"nll"),med_anchor_rmse=med(rr,"anchor_rmse"),
               med_truth_nonanchor_rmse=med(rr,"truth_nonanchor_rmse"),
               med_truth_q_rmse=med(rr,"truth_q_rmse"),
               med_truth_kl=med(rr,"truth_kl"),
               med_time_total=med(rr,"time_total"))
        strata={}
        for n in (5000,100000):
            sr=[r for r in rr if r["N"]==n]
            strata[str(n)]=dict(n=len(sr),n_ok=sum(r["status"]=="ok" for r in sr),
                                med_nll=med(sr,"nll"),med_anchor_rmse=med(sr,"anchor_rmse"),
                                score=float(np.mean([score(r) for r in sr])),
                                med_truth_nonanchor_rmse=med(sr,"truth_nonanchor_rmse"))
        c["strata"]=strata
        c["stable"]=all(x["n_ok"]>=9 for x in strata.values()) and c["n_truth"]==20
        cs.append(c)
    stable=[c for c in cs if c["stable"]]
    if stable:
        best_nll={n:min(c["strata"][str(n)]["med_nll"] for c in stable) for n in (5000,100000)}
        elig=[c for c in stable if all(c["strata"][str(n)]["med_nll"]<=best_nll[n]+0.01 for n in best_nll)]
    else: elig=[]
    # Fresh confirmation can establish eligibility for a family carried as a B2 rescue.
    release=list(elig)
    if release:
        best=min(release,key=lambda c:(c["score"],c["config_id"]))
        for c in cs:
            c["paired_ci_lower_vs_best"]=bootstrap_lower(by[c["family"]],by[best["family"]])
            c["in_tie_set"]=c in release and (c["score"]-best["score"]<=PRACTICAL or c["paired_ci_lower_vs_best"]<=0)
        winner=min([c for c in release if c["in_tie_set"]],key=fidelity)
    else: best=winner=None
    save_json(f"{RES}/B3_confirmation.json",dict(candidates=cs,
                 best_config_id=best["config_id"] if best else None,
                 winner_config_id=winner["config_id"] if winner else None,
                 winner_family=winner["family"] if winner else None,
                 no_releasable_winner=winner is None))
    write_csv(f"{RES}/B3_candidates.csv",
              [{k:v for k,v in c.items() if k not in ("config","strata")} | c["config"] |
               {f"N{n}_{k}":v for n,ss in c["strata"].items() for k,v in ss.items()} for c in cs])
    if winner: write(bl(winner),f"{RES}/manifests")
    return winner

if __name__=="__main__":
    {"B2":b2_analyze,"B3":b3_analyze}[sys.argv[1]]()
