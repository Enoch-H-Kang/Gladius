"""Stage completion and resource ledger audit; retains every scheduled slot."""
import csv
import hashlib
import json
import os
import sys
from collections import Counter

BASE="experiments/fleet_capacity_one"
RES=BASE+"/results/tuning"
ART=BASE+"/artifacts/tuning"

def audit(stage):
    m=json.load(open(f"{RES}/manifests/manifest_{stage}.json"))
    counts=Counter(); errors=[]; starts=[]; ends=[]; hashes=set(); exports=set()
    for f in m["fits"]:
        rp=f"{ART}/fits_{stage}/{f['fit_id']}/record.json"
        if not os.path.exists(rp):
            counts["missing"]+=1; errors.append("missing "+f["fit_id"]); continue
        r=json.load(open(rp))
        assert r["config_id"]==f["config_id"] and r["manifest_sha"]==m["sha256"],f["fit_id"]
        assert r["seeds"]==f["seeds"],f["fit_id"]
        hashes.add(r["code_hash"]); exports.add(r["export_hash"])
        counts[r["fit_status"]]+=1
        for h in f["horizons"]:
            counts["h"+str(h)+"_"+r["horizons"][str(h)]["status"]]+=1
        if r["fit_status"]=="complete":
            k=f["config"]["k"]; cap=f["config"]["cap_q"]
            assert r["counts"]["q_updates"]==cap and r["counts"]["z_updates"]==k*cap
            assert r["counts"]["draws"]==(k+1)*cap
        starts.append(r["start_unix"]); ends.append(r["end_unix"])
    qpath=f"{RES}/ledger/queue_{stage}.csv"
    attempts=Counter(); queue_starts=[]; queue_ends=[]
    if os.path.exists(qpath):
        for row in csv.reader(open(qpath)):
            if len(row)>2 and row[1]=="start": queue_starts.append(float(row[2]))
            if len(row)>4 and row[1]=="end":
                attempts[(row[3],row[4])]+=1
                queue_ends.append(float(row[2]))
    upath=f"{RES}/ledger/usage_{stage}.csv"
    over=[]; peak=0
    if os.path.exists(upath):
        for row in csv.reader(open(upath)):
            if len(row)<3: continue
            total=int(row[1])+int(row[2]); peak=max(peak,total)
            if total>44: over.append(row)
    out=dict(stage=stage,planned=m["n_fits"],counts=dict(counts),errors=errors,
             code_hashes=sorted(hashes),export_hashes=sorted(exports),
             fit_wall_s=max(ends)-min(starts) if starts else None,
             stage_wall_s=max(queue_ends)-min(queue_starts) if queue_starts and queue_ends else None,
             first_start=min(starts) if starts else None,last_end=max(ends) if ends else None,
             worker_attempt_ends={str(k):v for k,v in attempts.items()},
             worker_failed_attempts=sum(v for (code,record),v in attempts.items() if code!="0"),
             sampled_peak_tokens=peak,sampled_over_cap=over,
             all_slots_accounted=counts["missing"]==0 and sum(counts[x] for x in ("complete","diverged"))==m["n_fits"])
    json.dump(out,open(f"{RES}/{stage}_integrity.json","w"),indent=1)
    print(json.dumps(out,indent=1))
    return out

if __name__=="__main__": audit(sys.argv[1])
