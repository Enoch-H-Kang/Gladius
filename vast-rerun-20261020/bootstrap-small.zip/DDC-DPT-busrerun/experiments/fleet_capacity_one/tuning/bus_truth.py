"""Bus exact solution and development panels. TRUTH MODULE: evaluator / audit / exporter only,
never imported by the trainer, selector or fit runner."""
import numpy as np
from scipy.special import logsumexp

THETA = (1.0, 5.0, 1.0)
BETA = 0.95
XMAX = 10


def reward_table(theta=THETA, xmax=XMAX):
    s = np.arange(xmax + 1, dtype=np.float64)
    return np.column_stack([-theta[0] * s, -theta[1] * np.ones_like(s)])  # keep, replace (type 0)


def vfi(beta=BETA, theta=THETA, xmax=XMAX, tol=1e-8):
    """Same iteration as review:bus/Zurcher_collect_data.py (tol on the Q change norm)."""
    U = reward_table(theta, xmax)
    Q = np.zeros((xmax + 1, 2))
    dist = 1.0
    while dist > tol:
        V = logsumexp(Q, axis=1)
        expV0 = np.zeros_like(V)
        for i in range(4):
            expV0 += np.append(V[i + 1:], [V[-1]] * (i + 1)) / 4
        expV1 = V[1] * np.ones_like(V)
        Q1 = np.column_stack([U[:, 0] + beta * expV0, U[:, 1] + beta * expV1])
        dist = np.linalg.norm(Q1 - Q)
        Q = Q1
    V = logsumexp(Q, axis=1)
    expV = np.column_stack([expV0, expV1])
    EP = np.exp(Q - V[:, None])
    return dict(Q=Q, V=V, expV=expV, EP=EP, U=U)


def chain_hash(s, a, sp):
    import hashlib
    return hashlib.sha256(np.asarray(s, np.int64).tobytes() + np.asarray(a, np.int64).tobytes()
                          + np.asarray(sp, np.int64).tobytes()).hexdigest()
