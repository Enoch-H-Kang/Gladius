"""Post-hoc tables: per-fit status, P0 gate, B1 family centers (section 6 development rule). ANALYSIS ONLY:
joins observable fit records with the separate truth-evaluator outputs; never feeds back into training."""
import csv
import json
import math
import os
import sys
from statistics import median

import numpy as np

FAMILIES = {
    "none_k1": lambda c: c["loss"] == "none" and c["k"] == 1,
    "none_k3_5_10": lambda c: c["loss"] == "none" and c["k"] in (3, 5, 10),
    "clip0_anyk": lambda c: c["loss"] == "clip0",
    "abs_anyk": lambda c: c["loss"] == "abs",
}
LOSS_RANK = {"none": 0, "clip0": 1, "abs": 2}
PRACTICAL = math.log(1.05)


def load(manifest, fits_root, truth_root=None):
    m = json.load(open(manifest))
    rows = []
    for f in m["fits"]:
        cfg, h = f["config"], str(f["horizons"][0])
        row = dict(fit_id=f["fit_id"], config_id=f["config_id"], init=f["init_index"], loss=cfg["loss"], k=cfg["k"],
                   lr_q=cfg["lr_q"], rho=cfg["rho"], cap=cfg["cap_q"])
        rp = os.path.join(fits_root, f["fit_id"], "record.json")
        if not os.path.exists(rp):
            row.update(status="no_record")
            rows.append(row)
            continue
        r = json.load(open(rp))
        hr = r["horizons"][h]
        row.update(status=hr["status"], fit_status=r["fit_status"], diverged_at=r["diverged_at"], step=hr.get("step"),
                   nll=hr.get("nll"), top1=hr.get("top1"), anchor_rmse=hr.get("anchor_rmse"), zeta_mse=hr.get("zeta_mse"),
                   q_updates=r["counts"]["q_updates"], z_updates=r["counts"]["z_updates"], draws=r["counts"]["draws"],
                   q_clip_rate=r["q_clip_rate"], z_clip_rate=r["z_clip_rate"], time_q=r["time"]["q"], time_z=r["time"]["z"],
                   time_total=r["time"]["total"], start_unix=r["start_unix"], end_unix=r["end_unix"], pid=r["pid"])
        if truth_root and os.path.exists(os.path.join(truth_root, f["fit_id"] + ".json")):
            t = json.load(open(os.path.join(truth_root, f["fit_id"] + ".json")))["horizons"].get(h)
            if t:
                row.update({"truth_" + k: v for k, v in t.items() if k != "occupancy"})
        rows.append(row)
    return m, rows


def write_csv(path, rows):
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, keys, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def fit_score(r):
    if r["status"] == "ok" and r.get("truth_nonanchor_rmse") is not None and r.get("truth_reward_scale") is not None:
        x = r["truth_nonanchor_rmse"] / max(r["truth_reward_scale"], 1e-8)
        if math.isfinite(x):
            return math.log(min(max(x, 1e-8), 10.0))
    return math.log(10.0)


def candidates(rows):
    groups = {}
    for r in rows:
        groups.setdefault((r["loss"], r["k"], r["lr_q"], r["rho"]), []).append(r)
    out = []
    for (loss, k, lr, rho), rs in groups.items():
        oks = [r for r in rs if r["status"] == "ok"]
        fin = [r for r in rs if r.get("nll") is not None]
        c = dict(loss=loss, k=k, lr_q=lr, rho=rho, n=len(rs), n_ok=len(oks),
                 n_diverged=sum(r["status"] == "failed_diverged" for r in rs),
                 n_anchor_fail=sum(r["status"] == "anchor_fail" for r in rs),
                 n_truth=sum(r.get("truth_nonanchor_rmse") is not None and math.isfinite(r["truth_nonanchor_rmse"]) for r in rs),
                 config_id=rs[0]["config_id"],
                 score=float(np.mean([fit_score(r) for r in rs])),
                 med_nll=median(r["nll"] for r in fin) if len(fin) == len(rs) else float("inf"),
                 med_anchor_rmse=median(r["anchor_rmse"] for r in fin) if len(fin) == len(rs) else float("inf"),
                 med_nll_plus_a2=median(r["nll"] + r["anchor_rmse"] ** 2 for r in fin) if len(fin) == len(rs) else float("inf"))
        for key in ("truth_nonanchor_rmse", "truth_q_rmse", "truth_adv_rmse", "truth_kl", "truth_nonanchor_mape",
                    "truth_uniform_nonanchor_rmse", "truth_tail_nonanchor_rmse", "truth_zeta_lag_rmse", "step", "top1",
                    "time_total"):
            vals = [r[key] for r in rs if r.get(key) is not None and np.isfinite(r[key])]
            c["med_" + key] = median(vals) if vals else float("nan")
        c["stable"] = c["n_ok"] == c["n"] and c["n_truth"] == c["n"]
        out.append(c)
    return out


def fidelity_key(c):
    return (LOSS_RANK[c["loss"]], c["k"], abs(math.log(c["rho"])), (1 + c["k"]) * 1.0, c["config_id"])


def choose_center(cands):
    """Section-6 rule restricted to one protected family (one stratum, one archive: 5% band only)."""
    stable = [c for c in cands if c["stable"] and np.isfinite(c["med_nll"])]
    flagged = None
    if stable:
        best_nll = min(c["med_nll"] for c in stable)
        elig = [c for c in stable if c["med_nll"] <= best_nll + 0.01]
        b = min(elig, key=lambda c: (c["score"], c["config_id"]))
        tie = [c for c in elig if c["score"] - b["score"] <= PRACTICAL]
        pick = min(tie, key=fidelity_key)
        return pick, dict(n_candidates=len(cands), n_stable=len(stable), n_nll_eligible=len(elig), best=b["config_id"][:10],
                          tie_set=[c["config_id"][:10] for c in tie], rescue=False)
    pick = min(cands, key=lambda c: (c["n"] - c["n_ok"], c["med_nll_plus_a2"], c["config_id"]))
    return pick, dict(n_candidates=len(cands), n_stable=0, rescue=True, tie_set=[])


def b1(manifest, fits_root, truth_root, out_dir):
    m, rows = load(manifest, fits_root, truth_root)
    write_csv(os.path.join(out_dir, "B1_fits.csv"), rows)
    cands = candidates(rows)
    write_csv(os.path.join(out_dir, "B1_candidates.csv"), cands)
    centers = {}
    for fam, pred in FAMILIES.items():
        fc = [c for c in cands if pred(c)]
        pick, info = choose_center(fc)
        pick = dict(pick)
        pick["info"] = info
        pick["family_n_candidates"] = len(fc)
        centers[fam] = pick
    json.dump(centers, open(os.path.join(out_dir, "B1_family_centers.json"), "w"), indent=1, default=float)
    return m, rows, cands, centers


def p0(manifest, fits_root, truth_root, out_dir):
    m, rows = load(manifest, fits_root, truth_root)
    write_csv(os.path.join(out_dir, "P0_fits.csv"), rows)
    return m, rows


if __name__ == "__main__":
    which = sys.argv[1]
    f = dict(b1=b1, p0=p0)[which]
    f(*sys.argv[2:6])
