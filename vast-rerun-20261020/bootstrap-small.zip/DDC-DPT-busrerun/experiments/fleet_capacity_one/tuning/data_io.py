"""Training-side loader for truth-stripped bus exports (s, a, s', chain ids, public anchor)."""
import numpy as np

from . import bus_anchor as ba


def load_bus(npz_path, n_chains):
    """First `n_chains` hash-ranked chains; nested prefixes keep each chain in its permanent partition."""
    z = np.load(npz_path, allow_pickle=False)
    take = slice(0, n_chains)
    isv = z["is_val"][take]

    def part(mask):
        s, a, sp = (z[k][take][mask].reshape(-1, 1) if k != "a" else z[k][take][mask].reshape(-1)
                    for k in ("s", "a", "sp"))
        s = s.astype(np.float64)
        return dict(s=s, a=a, sp=sp.astype(np.float64), r0=ba.r0(s))

    meta = dict(n_actions=ba.N_ACTIONS, anchor_action=ba.ANCHOR_ACTION, beta=ba.BETA, state_scale=ba.STATE_SCALE)
    return dict(train=part(~isv), val=part(isv), meta=meta,
                n_chains=int(n_chains), n_train_chains=int((~isv).sum()), n_val_chains=int(isv.sum()))
