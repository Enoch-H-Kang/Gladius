"""P0 protocol-check gate (tuning-r2-codex section 5): provenance, update counts, serialization,
truth-unavailable replay. ANALYSIS ONLY."""
import json
import os
import subprocess
import sys
import tempfile

from .analyze import load, write_csv

FORBIDDEN = ["fleet.oracle", "fleet.kernels", "fleet.env", "fleet.params", "fleet.evalsets", "fleet.rewards", "fleet.anchor",
             "tuning.bus_truth", "tuning.bus_data", "tuning.evaluate", "tuning.analyze", "tuning.gates"]
PKG = "experiments.fleet_capacity_one"
VALID = {"ok", "anchor_fail", "failed", "failed_diverged"}
REPLAY = ("import sys\nfor n in %(forb)r:\n    sys.modules[n] = None\nsys.modules['scipy'] = None\n"
          "sys.path.insert(0, %(root)r)\n"
          "from experiments.fleet_capacity_one.tuning import run_fit\n"
          "run_fit.main(%(manifest)r, %(fid)r, %(out)r, %(export)r)\n")


def p0_gate(manifest, fits_root, truth_root, out_dir, export, repo_root, replay_ids=2):
    import torch
    manifest, export, fits_root = (os.path.abspath(x) for x in (manifest, export, fits_root))
    from ..fleet import train
    from ..fleet.models import MLP
    m, rows = load(manifest, fits_root, truth_root)
    write_csv(os.path.join(out_dir, "P0_fits.csv"), rows)
    checks, problems = {}, []
    recs = {}
    for f in m["fits"]:
        p = os.path.join(fits_root, f["fit_id"], "record.json")
        if os.path.exists(p):
            recs[f["fit_id"]] = json.load(open(p))
    checks["slots_scheduled"] = m["n_fits"]
    checks["slots_with_record"] = len(recs)
    code_hashes, export_hashes = set(), set()
    n_div = 0
    for f in m["fits"]:
        fid, r = f["fit_id"], recs.get(f["fit_id"])
        if r is None:
            problems.append(f"{fid}: no record")
            continue
        cfg, h = f["config"], str(f["horizons"][0])
        code_hashes.add(r["code_hash"])
        export_hashes.add(r["export_hash"])
        if r["config_id"] != f["config_id"] or r["seeds"] != f["seeds"] or r["manifest_sha"] != m["sha256"]:
            problems.append(f"{fid}: provenance mismatch")
        for k in ("host", "pid", "start_unix", "end_unix", "n_train_chains", "n_val_chains"):
            if r.get(k) is None:
                problems.append(f"{fid}: missing {k}")
        if r["horizons"][h]["status"] not in VALID or r["fit_status"] not in ("complete", "diverged"):
            problems.append(f"{fid}: invalid status")
        if r["fit_status"] == "complete":
            c, k, cap = r["counts"], cfg["k"], cfg["cap_q"]
            if (c["q_updates"], c["z_updates"], c["draws"]) != (cap, k * cap, (k + 1) * cap):
                problems.append(f"{fid}: update counts {c}")
        else:
            n_div += 1
        hr = r["horizons"][h]
        if hr.get("hash"):
            ck = torch.load(os.path.join(fits_root, fid, f"ckpt_h{h}.pt"), weights_only=False)
            q, z = MLP(1, 2, cfg["width"], cfg["depth"]), MLP(1, 2, cfg["width"], cfg["depth"])
            q.load_state_dict(ck["q"])
            z.load_state_dict(ck["z"])
            if train._hash_params(q, z) != hr["hash"] or ck["hash"] != hr["hash"]:
                problems.append(f"{fid}: checkpoint hash mismatch on reload")
    checks["code_hash_unique"] = len(code_hashes) == 1
    checks["export_hash_unique"] = len(export_hashes) == 1
    checks["divergences_recorded"] = n_div
    checks["status_counts"] = {s: sum(r["horizons"]["5000"]["status"] == s for r in recs.values()) for s in VALID}
    # truth-unavailable replay on real P0 slots (fresh process, truth modules and scipy poisoned)
    rep = []
    ids = [f["fit_id"] for f in m["fits"] if f["config"]["loss"] != "none" and f["config"]["k"] == 3][:1] + \
          [f["fit_id"] for f in m["fits"] if f["config"]["loss"] == "none" and f["config"]["k"] == 1][:1]
    for fid in ids[:replay_ids]:
        with tempfile.TemporaryDirectory() as d:
            code = REPLAY % dict(forb=[f"{PKG}.{x}" for x in FORBIDDEN], root=repo_root, manifest=manifest, fid=fid, out=d, export=export)
            r = subprocess.run([sys.executable, "-I", "-c", code], capture_output=True, text=True, cwd=d,
                               env=dict(os.environ, OMP_NUM_THREADS="1", MKL_NUM_THREADS="1"))
            if r.returncode != 0:
                rep.append(dict(fit_id=fid, same=False, err=r.stderr[-400:]))
                problems.append(f"{fid}: replay process failed")
                continue
            new = json.load(open(os.path.join(d, fid, "record.json")))
            same = ([x["hash"] for x in new["trace"]] == [x["hash"] for x in recs[fid]["trace"]]
                    and new["horizons"] == recs[fid]["horizons"] and new["counts"] == recs[fid]["counts"])
            rep.append(dict(fit_id=fid, same=bool(same)))
            if not same:
                problems.append(f"{fid}: truth-unavailable replay differs")
    checks["truth_unavailable_replay"] = rep
    checks["all_diverged"] = n_div == m["n_fits"]
    checks["problems"] = problems
    passed = (len(recs) == m["n_fits"] and len(rep) >= 2 and not problems and checks["code_hash_unique"] and checks["export_hash_unique"]
              and not checks["all_diverged"])
    checks["PASS"] = bool(passed)
    os.makedirs(out_dir, exist_ok=True)
    json.dump(checks, open(os.path.join(out_dir, "P0_protocol_check.json"), "w"), indent=1)
    return checks


if __name__ == "__main__":
    print(json.dumps(p0_gate(*sys.argv[1:6], repo_root=sys.argv[6]), indent=1))
