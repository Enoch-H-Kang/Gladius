"""Serial BR launcher, fresh process per slot and explicit queue ledger."""
import csv
import json
import os
import subprocess
import sys
import time
from .run_refcode import code_hash

RES="experiments/fleet_capacity_one/results/tuning"
ART="experiments/fleet_capacity_one/artifacts/tuning"
manifest=f"{RES}/manifests/manifest_BR.json"
fits_root=f"{ART}/fits_BR"
export=ART
ledger=f"{RES}/ledger/queue_BR.csv"

def main():
    m=json.load(open(manifest))
    os.makedirs(fits_root,exist_ok=True)
    env=dict(os.environ,OMP_NUM_THREADS="1",MKL_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",
             CUDA_VISIBLE_DEVICES="",PYTHONHASHSEED="0")
    with open(ledger,"a",newline="") as f:
        w=csv.writer(f)
        for spec in m["fits"]:
            rp=f"{fits_root}/{spec['fit_id']}/record.json"
            if os.path.exists(rp):
                r=json.load(open(rp))
                if r["config_id"]==spec["config_id"] and r["code_hash"]==code_hash():continue
            cmd=["nice","-n","10",sys.executable,"-m","experiments.fleet_capacity_one.tuning.run_refcode",
                 manifest,spec["fit_id"],fits_root,export]
            start=time.time()
            w.writerow([spec["fit_id"],"start",start,"",""]);f.flush()
            proc=subprocess.run(cmd,env=env)
            w.writerow([spec["fit_id"],"end",time.time(),proc.returncode,int(os.path.exists(rp))]);f.flush()
            if proc.returncode: print("failed",spec["fit_id"],proc.returncode,flush=True)

if __name__=="__main__":main()
