"""Bus rate and horizon lock from validation records only. This module has no truth imports."""
import csv
import hashlib
import json
import os
from statistics import median

RES="experiments/fleet_capacity_one/results/tuning"
ART="experiments/fleet_capacity_one/artifacts/tuning"

def main():
    manifest_path=f"{RES}/manifests/manifest_BL.json"
    m=json.load(open(manifest_path))
    rows=[]
    for f in m["fits"]:
        rp=f"{ART}/fits_BL/{f['fit_id']}/record.json"
        assert os.path.exists(rp),f["fit_id"]
        r=json.load(open(rp))
        assert r["config_id"]==f["config_id"] and r["manifest_sha"]==m["sha256"]
        for h in (10000,20000,50000):
            hr=r["horizons"][str(h)]
            rows.append(dict(fit_id=f["fit_id"],data_id=f["data_id"],horizon=h,
                             lr_q=f["config"]["lr_q"],rho=f["config"]["rho"],
                             status=hr["status"],nll=hr.get("nll"),anchor_rmse=hr.get("anchor_rmse"),
                             config_id=f["config_id"]))
    pairs=sorted({(r["lr_q"],r["rho"]) for r in rows})
    assert len(pairs)==6 and len(rows)==54
    policies=[]
    for h in (10000,20000,50000):
        for lr,rho in pairs:
            rr=[r for r in rows if r["horizon"]==h and r["lr_q"]==lr and r["rho"]==rho]
            assert len(rr)==3 and len({r["data_id"] for r in rr})==3
            finite=[r for r in rr if r["nll"] is not None and r["anchor_rmse"] is not None]
            policies.append(dict(horizon=h,lr_q=lr,rho=rho,n=3,n_ok=sum(r["status"]=="ok" for r in rr),
                                 med_nll=median(r["nll"] for r in finite) if len(finite)==3 else None,
                                 med_anchor_rmse=median(r["anchor_rmse"] for r in finite) if len(finite)==3 else None,
                                 config_id=rr[0]["config_id"]))
    elig=[p for p in policies if p["n_ok"]==3 and p["med_nll"] is not None]
    if not elig: raise RuntimeError("No eligible BL policy; no bus lock")
    min_nll=min(p["med_nll"] for p in elig)
    tie=[p for p in elig if p["med_nll"]<=min_nll+0.001]
    winner=min(tie,key=lambda p:(p["med_anchor_rmse"],p["horizon"],p["rho"]!=1,p["lr_q"],p["config_id"]))
    cfg=dict(m["fits"][0]["config"],lr_q=winner["lr_q"],rho=winner["rho"],cap_q=winner["horizon"],N=20000)
    lock=dict(design=cfg,policy=winner,tie_set=tie,all_policies=policies,
              manifest_sha256=m["sha256"],selection_input="validation records only")
    body=json.dumps(lock,sort_keys=True,separators=(",",":")).encode()
    lock["sha256"]=hashlib.sha256(body).hexdigest()
    path=f"{RES}/bus_locked_protocol.json"
    with open(path,"w") as f:json.dump(lock,f,indent=1)
    with open(f"{RES}/BL_policies.csv","w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(policies[0]));w.writeheader();w.writerows(policies)
    print(path,lock["sha256"],winner)

if __name__=="__main__":main()
