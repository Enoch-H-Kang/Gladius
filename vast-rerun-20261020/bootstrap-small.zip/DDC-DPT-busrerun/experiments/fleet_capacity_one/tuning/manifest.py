"""Expanded, hashed study manifests for P0 and B1 (bus). Seeds are expanded and stored before launch."""
import hashlib
import itertools
import json
import os

from ..fleet.seeds import expand_seeds

LOSSES = ("none", "clip0", "abs")
KS = (1, 3, 5, 10)
N_CHAINS = 200  # N = 20k retained transitions, H = 100
DATA_ID = "bus_seed7000"


def config_id(cfg):
    return hashlib.sha256(json.dumps(cfg, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def base_cfg(**kw):
    cfg = dict(loss="none", k=1, lr_q=3e-4, rho=1.0, batch=256, c_be=1.0, width=10, depth=2, opt="adamw",
               wd=1e-4, bias="anchor", beta=0.95, cap_q=5000, N=20000, val_every=500, elig_start=5000,
               anchor_tol=0.10, grad_clip=1.0, lr_decay=10000.0)
    cfg.update(kw)
    return cfg


def _fit(stage, cfg, init):
    cid = config_id(cfg)
    return dict(fit_id=f"{stage}_{cid[:10]}_i{init}", stage=stage, config=cfg, config_id=cid, init_index=init,
                seeds=expand_seeds("bus", stage, DATA_ID, init), data_id=DATA_ID, n_chains=N_CHAINS,
                horizons=[cfg["cap_q"]])


def build(stage):
    fits = []
    if stage == "P0":
        for loss, k, init in itertools.product(LOSSES, KS, (0, 1)):
            fits.append(_fit("P0", base_cfg(loss=loss, k=k, cap_q=5000), init))
    elif stage == "B1":
        for loss, k, lr, rho, init in itertools.product(LOSSES, KS, (1e-4, 3e-4, 1e-3), (1.0, 3.0), (0, 1, 2)):
            fits.append(_fit("B1", base_cfg(loss=loss, k=k, lr_q=lr, rho=rho, cap_q=20000), init))
    else:
        raise ValueError(stage)
    assert len({f["fit_id"] for f in fits}) == len(fits)
    body = json.dumps(fits, sort_keys=True, separators=(",", ":"))
    return dict(stage=stage, n_fits=len(fits), sha256=hashlib.sha256(body.encode()).hexdigest(), fits=fits)


def write(stage, out_dir):
    m = build(stage)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"manifest_{stage}.json")
    with open(path, "w") as f:
        json.dump(m, f, indent=1)
    return path, m
