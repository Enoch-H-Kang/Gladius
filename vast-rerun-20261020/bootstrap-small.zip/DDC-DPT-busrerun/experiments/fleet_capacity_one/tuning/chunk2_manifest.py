"""Frozen stage manifests for the second bus-tuning chunk."""
import hashlib
import json
import os
from .manifest import base_cfg, config_id
from ..fleet.seeds import expand_seeds

FAMILIES = ("none_k1", "none_k3_5_10", "clip0_anyk", "abs_anyk")

def slot(stage, cfg, init, data_id, n_chains, horizons=None, row=None, family=None):
    cid = config_id(cfg)
    fit_id = f"{stage}_{cid[:10]}_{data_id}_i{init}"
    return dict(fit_id=fit_id, stage=stage, config=cfg, config_id=cid,
                init_index=init, data_id=data_id, n_chains=n_chains,
                seeds=expand_seeds("bus", stage, data_id, init),
                horizons=horizons or [10000, 20000, 50000],
                row=row, family=family)

def manifest(stage, fits):
    ids = [x["fit_id"] for x in fits]
    assert len(ids) == len(set(ids)), "duplicate fit slot"
    body = json.dumps(fits, sort_keys=True, separators=(",", ":"))
    return dict(stage=stage, n_fits=len(fits), sha256=hashlib.sha256(body.encode()).hexdigest(), fits=fits)

def write(m, root):
    os.makedirs(root, exist_ok=True)
    p = os.path.join(root, f"manifest_{m['stage']}.json")
    with open(p, "w") as f:
        json.dump(m, f, indent=1)
    return p

def center_cfg(c):
    return base_cfg(loss=c["loss"], k=int(c["k"]), lr_q=float(c["lr_q"]),
                    rho=float(c["rho"]), cap_q=50000)

def b2(centers):
    fits = []
    for fam in FAMILIES:
        c = center_cfg(centers[fam])
        eta, rho = c["lr_q"], c["rho"]
        rows = [
            {}, {"lr_q":eta/3}, {"lr_q":3*eta},
            {"rho":rho/3}, {"rho":3*rho},
            {"batch":64}, {"batch":1024},
            {"width":50}, {"width":64},
            {"c_be":0.3}, {"c_be":3.0},
            {"bias":"zero"},
            {"opt":"sgd", "lr_q":3e-3, "wd":0.0},
            {"width":64, "batch":1024, "lr_q":3*eta, "c_be":0.3},
            {"batch":64, "lr_q":eta/3, "c_be":3.0, "bias":"zero"},
            {"opt":"sgd", "lr_q":3e-2, "wd":0.0},
        ]
        assert len(rows) == 16
        for ri, delta in enumerate(rows, 1):
            cfg = dict(c, **delta)
            for init in range(3):
                fits.append(slot("B2", cfg, init, "bus_seed7000", 200, row=ri, family=fam))
    m=manifest("B2",fits)
    assert m["n_fits"] == 192
    return m

def b3(finalists):
    fits=[]
    for fam in FAMILIES:
        cfg=dict(finalists[fam]["config"])
        assert cfg["width"] == 10
        for n in (5000,100000):
            for seed in range(7200,7205):
                for init in range(2):
                    cc=dict(cfg, N=n, cap_q=50000)
                    fits.append(slot("B3",cc,init,f"bus_seed{seed}",n//100,family=fam))
    m=manifest("B3",fits)
    assert m["n_fits"] == 80
    return m

def bl(winner):
    fits=[]
    w=dict(winner["config"])
    rates=(1e-4,3e-4,1e-3) if w["opt"] == "adamw" else (1e-3,1e-2,1e-1)
    for seed in range(7300,7303):
        for eta in rates:
            for rho in (1.0,3.0):
                cfg=dict(w,lr_q=eta,rho=rho,cap_q=50000,N=20000)
                fits.append(slot("BL",cfg,0,f"bus_seed{seed}",200))
    m=manifest("BL",fits)
    assert m["n_fits"] == 18
    return m

def br():
    cfg=base_cfg(loss="refcode",k=1,lr_q=3e-4,rho=1.0,cap_q=50000)
    fits=[slot("BR",cfg,i,"bus_seed7000",200) for i in range(3)]
    return manifest("BR",fits)
