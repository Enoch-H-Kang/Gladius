"""Bus pool audit, audited-generator wrapper and truth-stripping exporter.
TRUTH-AWARE (reads archived truth fields); the trainer never imports it."""
import hashlib
import importlib.util
import json
import os
import pickle
import random

import numpy as np

from . import bus_truth as bt

HERE = os.path.dirname(os.path.abspath(__file__))
ART = os.path.join(HERE, "..", "artifacts", "tuning")
GEN_SRC = os.path.join(ART, "gen", "Zurcher_collect_data.py")   # `git show review:bus/Zurcher_collect_data.py`, unmodified
SIZES = (50, 100, 250, 500, 1000, 2500, 5000, 10000)
GEN_CONFIG = dict(env="zurcher", H=100, beta=0.95, theta=[1, 5, 1], rollin_type="expert", maxMileage=10,
                  numTypes=1, num_dummies=0, dummy_dim=10)


def _gen_module():
    spec = importlib.util.spec_from_file_location("review_zurcher_collect", GEN_SRC)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def generator_sha():
    return hashlib.sha256(open(GEN_SRC, "rb").read()).hexdigest()


def generate_chains(seed, n_chains):
    """Exactly the review generator (legacy np.random / random seeding, as in its generate())."""
    mod = _gen_module()
    np.random.seed(seed)
    random.seed(seed)
    return mod.generate_Zurcher_histories({**GEN_CONFIG, "num_trajs": n_chains})


def generate_pool(seed, n_chains, out_dir):
    """Mimic generate(): 80% train chains then 20% test chains from one seeded stream."""
    mod = _gen_module()
    np.random.seed(seed)
    random.seed(seed)
    ntr = int(0.8 * n_chains)
    train = mod.generate_Zurcher_histories({**GEN_CONFIG, "num_trajs": ntr})
    test = mod.generate_Zurcher_histories({**GEN_CONFIG, "num_trajs": n_chains - ntr})
    os.makedirs(out_dir, exist_ok=True)
    for nm, obj in (("train", train), ("test", test)):
        with open(os.path.join(out_dir, f"{nm}.pkl"), "wb") as f:
            pickle.dump(obj, f)
    return train, test


def _arrays(c):
    return (np.asarray(c["states"]).reshape(-1).astype(np.int64), np.asarray(c["actions"]).reshape(-1).astype(np.int64),
            np.asarray(c["next_states"]).reshape(-1).astype(np.int64))


def chain_hashes(chains):
    return [bt.chain_hash(*_arrays(c)) for c in chains]


def audit_archives(raw_dir, out_json):
    """Content-level lineage / overlap / DGP audit of the 16 review-branch zero-dummy archives."""
    names = [f"n{n}_{m}" for n in SIZES for m in ("train", "test")]
    hashes, counts, smax, gt10 = {}, {}, {}, {}
    for nm in names:
        chains = pickle.load(open(os.path.join(raw_dir, nm + ".pkl"), "rb"))
        hashes[nm] = chain_hashes(chains)
        S = np.concatenate([_arrays(c)[0] for c in chains])
        smax[nm], gt10[nm] = int(S.max()), int((S > bt.XMAX).sum())
        counts[nm] = dict(chains=len(chains), unique=len(set(hashes[nm])))
    overlap = {a: {b: len(set(hashes[a]) & set(hashes[b])) for b in names} for a in names}
    stream = set(hashes["n10000_train"]) | set(hashes["n10000_test"])
    sol10, sol20 = bt.vfi(xmax=10), bt.vfi(xmax=20)
    q1 = np.asarray(pickle.load(open(os.path.join(raw_dir, "n1000_train.pkl"), "rb"))[0]["states_true_Qs"])[0]
    res = dict(
        counts=counts, overlap_matrix=overlap, max_state=smax, n_states_gt_maxMileage10=gt10,
        pool_1000_distinct=len(set(hashes["n1000_train"] + hashes["n1000_test"])),
        pool_1000_train_test_overlap=overlap["n1000_train"]["n1000_test"],
        all_archives_subset_of_one_10000_stream=all(set(h) <= stream for h in hashes.values()),
        n10000_train_test_overlap=overlap["n10000_train"]["n10000_test"],
        archived_Q_state1=[float(x) for x in q1], vfi_xmax10_Q_state1=[float(x) for x in sol10["Q"][1]],
        vfi_xmax20_Q_state1=[float(x) for x in sol20["Q"][1]],
    )
    res["dgp_matches_brief_maxMileage10"] = bool(max(smax.values()) <= bt.XMAX
                                                 and np.allclose(q1, sol10["Q"][1], atol=1e-9, rtol=0))
    res["lineage_established"] = bool(res["pool_1000_distinct"] == 1000 and res["pool_1000_train_test_overlap"] == 0
                                      and res["dgp_matches_brief_maxMileage10"])
    res["conclusion"] = (
        "PASS" if res["lineage_established"] else
        "FAIL: archives are internally consistent nested slices of one 10,000-chain stream, but they were generated with a "
        "mileage cap larger than the brief's maxMileage=10 (observed states up to %d; archived Q(1,.) matches the xmax>=20 solution "
        "to 1e-8 and differs from the xmax=10 solution at 1e-6); the generation seed is not recorded. Per brief: use the seed-7000 "
        "generated pool, do not mix." % max(smax.values()))
    os.makedirs(os.path.dirname(out_json), exist_ok=True)
    json.dump(res, open(out_json, "w"), indent=1)
    return res


def audit_pool(train, test, out_json, seed):
    """DGP / truth-field / overlap audit of the generated seed pool."""
    sol = bt.vfi()
    issues = []
    for nm, chains in (("train", train), ("test", test)):
        for ci, c in enumerate(chains):
            s, a, sp = _arrays(c)
            if s[0] != 1:
                issues.append(f"{nm}[{ci}] first state != 1")
            if not np.all(s[1:] == sp[:-1]):
                issues.append(f"{nm}[{ci}] continuity")
            if (s < 1).any() or (s > bt.XMAX).any() or (sp < 1).any() or (sp > bt.XMAX).any():
                issues.append(f"{nm}[{ci}] state out of 1..{bt.XMAX}")
            rep = a == 1
            if not np.all(sp[rep] == 1):
                issues.append(f"{nm}[{ci}] replace did not reset to 1")
            kp = ~rep
            if not np.all((sp[kp] >= np.minimum(s[kp] + 1, bt.XMAX)) & (sp[kp] <= np.minimum(s[kp] + 4, bt.XMAX))):
                issues.append(f"{nm}[{ci}] keep step outside s+1..s+4 (capped)")
            for key, tab in (("states_true_Qs", sol["Q"]), ("states_true_EPs", sol["EP"]), ("states_true_expVs", sol["expV"])):
                if not np.allclose(np.asarray(c[key]).reshape(len(s), 2), tab[s], atol=1e-6):
                    issues.append(f"{nm}[{ci}] {key} != recomputed exact solution")
    ht, hs = chain_hashes(train), chain_hashes(test)
    allh = ht + hs
    S = np.concatenate([_arrays(c)[0] for c in train + test])
    A = np.concatenate([_arrays(c)[1] for c in train + test])
    # replacement frequency vs the exact policy at the observed states
    exp_rep = float(sol["EP"][S, 1].mean())
    res = dict(seed=seed, generator_sha256=generator_sha(), n_train=len(train), n_test=len(test), distinct=len(set(allh)),
               train_test_overlap=len(set(ht) & set(hs)), max_state=int(S.max()), replace_freq_obs=float(A.mean()),
               replace_freq_expected_from_EP=exp_rep, dgp_issue_count=len(issues), dgp_issues=issues[:20])
    res["pass"] = bool(len(set(allh)) == len(allh) and res["train_test_overlap"] == 0 and not issues
                       and abs(res["replace_freq_obs"] - exp_rep) < 0.01)
    os.makedirs(os.path.dirname(out_json), exist_ok=True)
    json.dump(res, open(out_json, "w"), indent=1)
    return res


def export_pool(train, test, out_npz):
    """Union the verified distinct chains, order them by content hash, assign every 5th ranked chain
    (rank % 5 == 4) to validation permanently, and strip all truth fields."""
    rows = []
    for c in train + test:
        s, a, sp = _arrays(c)
        rows.append((bt.chain_hash(s, a, sp), s, a, sp))
    rows.sort(key=lambda r: r[0])
    assert len({r[0] for r in rows}) == len(rows)
    np.savez_compressed(
        out_npz, s=np.stack([r[1] for r in rows]), a=np.stack([r[2] for r in rows]), sp=np.stack([r[3] for r in rows]),
        chain_hash=np.array([r[0] for r in rows]), is_val=(np.arange(len(rows)) % 5 == 4))
    return out_npz
