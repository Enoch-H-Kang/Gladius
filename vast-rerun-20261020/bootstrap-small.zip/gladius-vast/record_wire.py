"""Print hash-bound fit records as log-safe numbered lines."""
import base64
import hashlib
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def emit_fit(fit_id, record_path, marker_path):
    record = Path(record_path).read_bytes()
    marker = Path(marker_path).read_bytes()
    import json
    if json.loads(marker)['record_sha256'] != sha(record):
        raise ValueError('terminal record hash mismatch: ' + fit_id)
    counts = []
    for kind, data in [('R', record), ('M', marker)]:
        encoded = base64.b64encode(data).decode('ascii')
        chunks = []
        cursor = 0
        while cursor < len(encoded):
            prefix = f'{kind}{fit_id}:{len(chunks):04d}:'
            width = 400 - len(prefix)
            if width < 4:
                raise ValueError('fit ID too long for log protocol')
            chunks.append(encoded[cursor:cursor + width])
            cursor += width
        for sequence, chunk in enumerate(chunks):
            print(f'{kind}{fit_id}:{sequence:04d}:{chunk}', flush=True)
        counts.append(len(chunks))
    print(f'F{fit_id}:{counts[0]}:{counts[1]}:{sha(record)}:{sha(marker)}', flush=True)
