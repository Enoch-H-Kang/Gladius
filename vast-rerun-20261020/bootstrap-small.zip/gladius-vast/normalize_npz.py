"""Restore the pre-ZIP64 headers used by the frozen NumPy archives."""
import os
from pathlib import Path
import struct
import zipfile


def normalize(path):
    path = Path(path)
    data = bytearray(path.read_bytes())
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        for item in entries:
            if item.file_size >= 2**32 or item.compress_size >= 2**32:
                raise ValueError('ZIP64 archive cannot be normalized')
            offset = item.header_offset
            if data[offset:offset + 4] != b'PK\x03\x04':
                raise ValueError('invalid local ZIP header')
            data[offset + 4:offset + 6] = struct.pack('<H', 20)
            data[offset + 18:offset + 22] = struct.pack('<I', item.compress_size)
            data[offset + 22:offset + 26] = struct.pack('<I', item.file_size)
        offset = archive.start_dir
        for item in entries:
            if data[offset:offset + 4] != b'PK\x01\x02':
                raise ValueError('invalid central ZIP header')
            data[offset + 4:offset + 6] = struct.pack('<H', 20 | (3 << 8))
            data[offset + 6:offset + 8] = struct.pack('<H', 20)
            name_len, extra_len, comment_len = struct.unpack_from('<HHH', data, offset + 28)
            offset += 46 + name_len + extra_len + comment_len
    temp = path.with_name(path.name + '.tmp')
    temp.write_bytes(data)
    os.replace(temp, path)
