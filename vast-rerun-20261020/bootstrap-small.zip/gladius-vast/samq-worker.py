#!/usr/bin/env python3
"""One matched SAmQ neural-aggregation fit from a frozen bus pool."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import numpy as np

SIZES = (50, 250, 500, 1000, 2500, 5000)
K = 5  # Fixed neural-sensitive Ward aggregation; see shards-samq/README.md.
SOURCE_COMMIT = "4a782e40225e91a4baf267d5d793dceacdf8197f"
DATA_SEAL = "c46e5c0f70c06d735490a05e524f410f178c5c56a98ebc19ef5bc0dec3febb89"


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(data, indent=2, sort_keys=True, allow_nan=False) + "\n")
    os.replace(temp, path)


def train_neural(train, seed, workdir, samq_root):
    import torch
    from torch.utils.data import Dataset
    sys.path.insert(0, str(samq_root))
    from SAmQ.irl.pqr import pqr_aggregation

    s, a, sp = train
    torch.set_num_threads(1)
    torch.manual_seed(seed)
    np.random.seed(seed)

    class Data(Dataset):
        def __init__(self):
            self.s = s[:, None].astype(np.float32)
            self.s_next = sp[:, None].astype(np.float32)
            self.a = a[:, None].astype(np.int64)
            # Diagnostics in the authors' training loops; no truth enters loss.
            self.p = np.zeros((len(s) + 1, 2), dtype=np.float32)
            self.q = np.zeros((len(s) + 1, 2), dtype=np.float32)
            self.r = np.zeros((len(s) + 1, 1), dtype=np.float32)
        def __len__(self):
            return len(s)
        def __getitem__(self, i):
            return (torch.from_numpy(self.s[i]), torch.from_numpy(self.a[i]),
                    torch.from_numpy(self.p[i]), torch.from_numpy(self.p[i+1]),
                    torch.from_numpy(self.s_next[i]), torch.from_numpy(self.q[i]),
                    torch.from_numpy(self.q[i+1]), torch.from_numpy(self.r[i]))

    class Log:
        dir = workdir
    class Writer:
        def add_scalar(self, *args, **kwargs):
            pass
    class Env:
        n_a = 2
        d_s = 1

    workdir.mkdir(parents=True, exist_ok=True)
    model = pqr_aggregation(Data(), Env(), Log(), hidden_size=10,
                            optimizer=torch.optim.Adam, l_r=0.004,
                            discount=0.95)
    model.train_q(nEpochs=100, batch_size=100, writer=Writer(), patience=5)
    model.train_q_star(n_steps=200, batch_size=100, writer=Writer(), patience=5)
    with torch.no_grad():
        x = torch.arange(1, 11, dtype=torch.float32)[:, None]
        q = model.q(x)
        features = (q - q[:, 0, None] + model.q_star(x)).numpy().astype(float)
    if not np.isfinite(features).all():
        raise FloatingPointError("nonfinite neural aggregation features")
    return features


def run(fit_id, bundle_root, results_dir):
    import torch
    from experiments.fleet_capacity_one.bus_rerun import finalize
    from experiments.fleet_capacity_one.bus_rerun import samq_adapter as backend

    parts = fit_id.split("_")
    if len(parts) != 4 or parts[:2] != ["SAMQ", "NN"]:
        raise ValueError(fit_id)
    n = int(parts[2].removeprefix("n"))
    r = int(parts[3].removeprefix("r"))
    if n not in SIZES or not 0 <= r < 20 or fit_id != f"SAMQ_NN_n{n}_r{r:02d}":
        raise ValueError(fit_id)
    bus = bundle_root / "DDC-DPT-busrerun"
    samq = bundle_root / "SAmQ-matched-repaired"
    path = bus / f"artifacts/bus_rerun/data/bus_seed{11000+r}.npz"
    freeze = json.loads((bus / "results/bus_rerun/data_freeze.json").read_text())
    if freeze["sha256"] != DATA_SEAL:
        raise ValueError("wrong frozen data seal")
    expected = {p["seed"]: p["sha256"] for p in freeze["pools"]}[11000+r]
    if sha(path) != expected:
        raise ValueError("pool hash mismatch")
    out = results_dir / "fits" / fit_id
    record_path = out / "record.json"
    marker = out / "DONE"
    if marker.exists() and record_path.exists():
        done = json.loads(marker.read_text())
        if done.get("record_sha256") == sha(record_path):
            return json.loads(record_path.read_text())
    start = time.perf_counter()
    record = dict(fit_id=fit_id, n=n, r=r, seed=11000+r, clusters=K,
                  pool_sha256=expected, data_seal=DATA_SEAL,
                  samq_commit=SOURCE_COMMIT, estimator="SAmQ NN our+mle repaired",
                  status="pending")
    try:
        train, val = backend.load_pool(path, n)
        record.update(n_train=len(train[0]), n_validation=len(val[0]))
        features = train_neural(train, 11000+r+n, out / "neural", samq)
        counts = np.bincount(np.r_[train[0], train[2]] - 1, minlength=10)
        mapping = backend.ward_map(features, counts, K)
        # Exact duplicate-state Ward compression and compiled row-wise TD are
        # mathematical accelerators of the repaired estimator for large pools.
        result = backend.fit(train, val, mapping)
        record.update(result)
        record["neural_features"] = features.tolist()
        record["status"] = "ok" if result["optimizer_success"] else "optimizer_fail"
        if record["status"] == "ok":
            theta = result["theta_hat"]
            rhat = np.column_stack((-theta * finalize.STATES,
                                    np.full(10, -5.0)))
            qnative = np.asarray(result["q_native"])
            qhat = qnative[mapping, ::-1] - 5.0/(1.0-0.95)
            rtrue, qtrue, ptrue, weights = finalize.truth_and_weights()
            def state_action_counts(sa):
                s, a, _ = sa
                table = np.zeros((10, 2), dtype=np.int64)
                np.add.at(table, (s-1, 1-a), 1)
                return table
            panel_path = bus / "artifacts/bus_rerun/panel/bus_seed11999.npz"
            with np.load(panel_path, allow_pickle=False) as panel_file:
                ps = panel_file["s"].reshape(-1)
                pa = panel_file["a"].reshape(-1)
            panel = np.zeros((10, 2), dtype=np.int64)
            np.add.at(panel, (ps-1, pa), 1)
            record["metrics"] = finalize.scores(
                rhat, qhat, rtrue, qtrue, ptrue, weights,
                state_action_counts(train), state_action_counts(val), panel)
            record["reward_shift"] = -5.0
            record["action_code"] = "SAmQ 0=replace,1=keep; score 0=keep,1=replace"
            assert abs(record["metrics"]["keep_mape"] - 100*abs(theta-1)) < 1e-8
    except Exception as exc:
        record.update(status="fit_fail", error=repr(exc))
    record["elapsed_wall"] = time.perf_counter()-start
    write_json(record_path, record)
    write_json(marker, dict(fit_id=fit_id, status=record["status"],
                            record_sha256=sha(record_path)))
    return record


def main():
    p = argparse.ArgumentParser()
    p.add_argument("fit_id")
    p.add_argument("--bundle-root", type=Path, default=Path("/home/ehwkang"))
    p.add_argument("--results-dir", type=Path, default=Path("/workspace/vast-results/samq"))
    args = p.parse_args()
    sys.path.insert(0, str(args.bundle_root / "DDC-DPT-busrerun"))
    rec = run(args.fit_id, args.bundle_root, args.results_dir)
    print(json.dumps({k: rec.get(k) for k in ("fit_id", "status", "theta_hat", "elapsed_wall", "error")},
                     sort_keys=True), flush=True)
    if rec["status"] != "ok":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
