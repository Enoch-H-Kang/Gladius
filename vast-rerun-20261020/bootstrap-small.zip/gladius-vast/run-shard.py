#!/usr/bin/env python3
"""Run one immutable Vast shard using the baker workers and their record formats."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time
from record_wire import emit_fit


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as file:
        for block in iter(lambda: file.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
    os.replace(temp, path)


def source_paths(item, root):
    fit_id = item['fit_id']
    if item['suite'] == 'bus':
        repo = root / 'DDC-DPT-busrerun'
        out = repo / 'artifacts/bus_rerun/epochs20000/fits' / fit_id
        marker = 'DONE'
        module = 'experiments.fleet_capacity_one.bus_rerun.epochs20000_worker'
    else:
        repo = root / 'DDC-DPT-fleet-r1literal'
        out = repo / 'experiments/fleet_r1literal/results/rerun20k/fits' / item['suite'] / fit_id
        marker = 'DONE.json'
        module = 'experiments.fleet_r1literal.rerun20k'
    expected = ['python', '-m', module] + (['worker'] if item['suite'] != 'bus' else []) + [fit_id]
    if item['trainer_argv'] != expected:
        raise ValueError('trainer command differs from manifest for ' + fit_id)
    return repo, out, marker


def verify_terminal(out, marker, fit_id):
    record = out / 'record.json'
    done = out / marker
    if not record.exists() and not done.exists():
        return None
    if not record.exists() or not done.exists():
        raise RuntimeError(f'partial terminal files for {fit_id}: {out}')
    rec = json.loads(record.read_text())
    mark = json.loads(done.read_text())
    if rec.get('fit_id') != fit_id or mark.get('fit_id') != fit_id or mark.get('record_sha256') != sha(record):
        raise RuntimeError(f'invalid terminal marker for {fit_id}: {out}')
    return rec


def run_one(item, root, result_root, python):
    fit_id = item['fit_id']
    repo, out, marker = source_paths(item, root)
    result = result_root / 'fits' / item['suite'] / fit_id
    existing = verify_terminal(out, marker, fit_id)
    if existing is None:
        out.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        env.update(HOME=str(root), PYTHONPATH=str(repo), OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
                   OPENBLAS_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1',
                   CUDA_VISIBLE_DEVICES='')
        args = [str(python)] + item['trainer_argv'][1:]
        log = result_root / 'logs' / (fit_id + '.log')
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open('ab') as output:
            output.write((f'command={args!r} started={time.time()}\n').encode())
            completed = subprocess.run(args, cwd=repo, env=env, stdout=output, stderr=subprocess.STDOUT)
            output.write((f'exit={completed.returncode} finished={time.time()}\n').encode())
        try:
            existing = verify_terminal(out, marker, fit_id)
        except RuntimeError:
            existing = None
        if existing is None:
            status = 'resource_fail' if item['suite'] == 'bus' else 'process_failure'
            rec = {'fit_id': fit_id, 'status': status, 'error': f'worker exited {completed.returncode} without valid terminal files',
                   'end_unix': time.time()} if item['suite'] == 'bus' else {
                   'fit_id': fit_id, 'suite': item['suite'], 'fit_status': status,
                   'error': f'worker exited {completed.returncode} without valid terminal files', 'end_unix': time.time()}
            atomic_json(out / 'record.json', rec)
            mark = {'fit_id': fit_id, 'status': status, 'record_sha256': sha(out / 'record.json')}
            if item['suite'] != 'bus':
                mark.update(suite=item['suite'], finished_unix=time.time())
            atomic_json(out / marker, mark)
            existing = verify_terminal(out, marker, fit_id)
    if result.exists():
        shutil.rmtree(result)
    shutil.copytree(out, result)
    verify_terminal(result, marker, fit_id)
    status = existing.get('status') if item['suite'] == 'bus' else existing.get('fit_status')
    return {'fit_id': fit_id, 'suite': item['suite'], 'status': status, 'record_sha256': sha(result / 'record.json')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('shard_file', type=Path, help='JSON list of fit descriptors')
    parser.add_argument('--bundle-root', type=Path, default=Path('/home/ehwkang'))
    parser.add_argument('--results-dir', type=Path, default=Path('/workspace/vast-results'))
    parser.add_argument('--python', type=Path, default=Path('/opt/gladius-venv/bin/python'))
    parser.add_argument('--workers', type=int, default=None)
    args = parser.parse_args()
    items = json.loads(args.shard_file.read_text())
    if not isinstance(items, list) or not items:
        parser.error('shard file must contain a nonempty list')
    shard = args.shard_file.stem
    if len({x['fit_id'] for x in items}) != len(items):
        parser.error('duplicate fit IDs')
    if any(x['shard'] != shard for x in items):
        parser.error('shard name mismatch')
    for item in items:
        source_paths(item, args.bundle_root)
    if any(x['suite'] in ('headline', 'matrix') for x in items):
        lock = args.bundle_root / 'DDC-DPT-fleet-r1literal/experiments/fleet_r1literal/results/rerun20k/locks_FL.json'
        if not lock.is_file():
            parser.error(f'FL rate lock required before this shard: {lock}')
    if any(x['suite'] == 'EX' for x in items):
        lock = args.bundle_root / 'DDC-DPT-fleet-r1literal/experiments/fleet_r1literal/results/rerun20k/locks_EL.json'
        if not lock.is_file():
            parser.error(f'EL rate lock required before this shard: {lock}')
    result_root = args.results_dir / shard
    result_root.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.shard_file, result_root / 'shard.json')
    workers = args.workers or min(len(os.sched_getaffinity(0)), len(items))
    if workers < 1:
        parser.error('--workers must be positive')
    outcomes = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        jobs = {pool.submit(run_one, item, args.bundle_root, result_root, args.python): item for item in items}
        for future in as_completed(jobs):
            item = jobs[future]
            try:
                outcome = future.result()
            except Exception as exc:
                outcome = {'fit_id': item['fit_id'], 'suite': item['suite'], 'status': 'runner_failure', 'error': str(exc)}
            outcomes.append(outcome)
            print(json.dumps(outcome, sort_keys=True), flush=True)
            if outcome.get('status') != 'runner_failure':
                result = result_root / 'fits' / item['suite'] / item['fit_id']
                marker = 'DONE' if item['suite'] == 'bus' else 'DONE.json'
                emit_fit(item['fit_id'], result / 'record.json', result / marker)
    outcomes.sort(key=lambda x: x['fit_id'])
    atomic_json(result_root / 'outcomes.json', outcomes)
    archive = args.results_dir / ('results-' + shard + '.tar.gz')
    temp = archive.with_name(archive.name + '.tmp')
    with tarfile.open(temp, 'w:gz') as tar:
        tar.add(result_root, arcname=shard)
    os.replace(temp, archive)
    print(json.dumps({'archive': str(archive), 'sha256': sha(archive), 'fits': len(outcomes)}), flush=True)
    if all(x['status'] in ('complete', 'ok') for x in outcomes):
        print(f'===SHARD DONE===:{shard}:{len(outcomes)}', flush=True)
        return 0
    print(f'===SHARD FAILED===:{shard}', flush=True)
    return 2


if __name__ == '__main__':
    sys.exit(main())
