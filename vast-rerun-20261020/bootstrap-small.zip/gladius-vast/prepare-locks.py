#!/usr/bin/env python3
"""Build FL/EL 20k rate locks from pulled wave-1 Vast records, off baker."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import time


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, allow_nan=False) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle-root', type=Path, required=True)
    parser.add_argument('--results-dir', type=Path, required=True,
                        help='directory containing extracted lock-XX result directories')
    parser.add_argument('--output-dir', type=Path, required=True,
                        help='directory for the two lock files to send to wave-2 instances')
    args = parser.parse_args()
    root = args.bundle_root / 'DDC-DPT-fleet-r1literal/experiments/fleet_r1literal'
    names = {'FL': 'manifest_FL_followup.json', 'EL': 'manifest_EL_followup.json'}
    for stage, name in names.items():
        source = root / 'results/frozen_followups' / name
        manifest = json.loads(source.read_text())
        specs = manifest['fits']
        expected = 108 if stage == 'FL' else 54
        if len(specs) != expected:
            raise ValueError(f'{stage}: source manifest count differs')
        records = {}
        for spec in specs:
            fid = spec['fit_id']
            candidates = list(args.results_dir.glob(f'lock-*/fits/{stage}/{fid}'))
            if len(candidates) != 1:
                raise ValueError(f'{fid}: expected one pulled result, got {len(candidates)}')
            directory = candidates[0]
            rec_path, marker_path = directory / 'record.json', directory / 'DONE.json'
            rec = json.loads(rec_path.read_text())
            marker = json.loads(marker_path.read_text())
            if rec.get('fit_id') != fid or marker.get('fit_id') != fid or marker.get('record_sha256') != sha(rec_path):
                raise ValueError(f'{fid}: invalid terminal pair')
            if rec.get('suite') != stage or rec.get('source_manifest_sha256') != sha(source):
                raise ValueError(f'{fid}: record source differs from frozen {stage} manifest')
            records[fid] = rec
        choices, unavailable = {}, {}
        for arch in sorted({x['architecture'] for x in specs}):
            candidates = []
            for lr in (1e-4, 3e-4, 1e-3):
                for rho in (1, 3):
                    group = [s for s in specs if s['architecture'] == arch and
                             s['config']['lr_q'] == lr and s['config']['rho'] == rho]
                    if len(group) != 3:
                        raise ValueError(f'{stage} {arch} {lr} {rho}: not three blocks')
                    recs = [records[x['fit_id']] for x in group]
                    vals = [r.get('best_validation') or {} for r in recs]
                    if not all(r.get('fit_status') == 'complete' and v.get('finite') and
                               math.isfinite(v.get('nll', float('nan'))) and
                               math.isfinite(v.get('anchor_rmse', float('nan')))
                               for r, v in zip(recs, vals)):
                        continue
                    candidates.append(dict(lr_q=lr, rho=rho,
                                           median_nll=sorted(v['nll'] for v in vals)[1],
                                           median_anchor=sorted(v['anchor_rmse'] for v in vals)[1],
                                           fit_ids=[x['fit_id'] for x in group],
                                           anchor_errors={str(x['data_id']): v['anchor_rmse']
                                                          for x, v in zip(group, vals)}))
            if not candidates:
                unavailable[arch] = 'no complete three-block rate pair with finite validation observables'
                continue
            floor = min(x['median_nll'] for x in candidates)
            tied = [x for x in candidates if x['median_nll'] <= floor + .001]
            choices[arch] = min(tied, key=lambda x: (x['median_anchor'], x['rho'] != 1, x['lr_q']))
        if unavailable:
            raise ValueError(f'{stage}: rate choices unavailable for {unavailable}')
        lock = dict(stage=stage, choices=choices, unavailable=unavailable,
                    rule='minimum three-block median validation NLL within 0.001; tie by median anchor, rho=1, lower rate; anchor diagnostic only',
                    source_manifest_sha256=sha(source), created_unix=time.time())
        destination = args.output_dir / f'locks_{stage}.json'
        write(destination, lock)
        # Same location expected by the unchanged baker worker in this local snapshot.
        internal = root / 'results/rerun20k' / destination.name
        internal.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(destination, internal)
        print(f'{stage}: {len(choices)} architecture choices; {destination}; sha256={sha(destination)}')


if __name__ == '__main__':
    main()
