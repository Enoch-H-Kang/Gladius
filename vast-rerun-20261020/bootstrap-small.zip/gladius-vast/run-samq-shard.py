#!/usr/bin/env python3
"""Run one SAmQ descriptor shard and archive its terminal fit records."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time
from record_wire import emit_fit


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    os.replace(tmp, path)


def terminal(out, fit_id):
    record, marker = out / "record.json", out / "DONE"
    if not record.exists() or not marker.exists():
        return None
    rec, done = json.loads(record.read_text()), json.loads(marker.read_text())
    if rec.get("fit_id") != fit_id or done.get("fit_id") != fit_id or done.get("record_sha256") != sha(record):
        raise ValueError("invalid terminal record for " + fit_id)
    return rec


def run_one(item, bundle_root, result_root, python):
    fit_id = item["fit_id"]
    out = result_root / "fits" / fit_id
    rec = terminal(out, fit_id)
    if rec is None:
        env = os.environ.copy()
        env.update(HOME=str(bundle_root), PYTHONPATH=str(bundle_root / "DDC-DPT-busrerun"),
                   OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
                   NUMEXPR_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1", CUDA_VISIBLE_DEVICES="")
        command = [str(python), str(bundle_root / "gladius-vast/samq-worker.py"), fit_id,
                   "--bundle-root", str(bundle_root), "--results-dir", str(result_root)]
        log = result_root / "logs" / (fit_id + ".log")
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open("ab") as stream:
            stream.write((f"command={command!r} started={time.time()}\n").encode())
            completed = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT)
            stream.write((f"exit={completed.returncode} finished={time.time()}\n").encode())
        rec = terminal(out, fit_id)
        if rec is None:
            rec = {"fit_id": fit_id, "status": "process_failure",
                   "error": f"worker exited {completed.returncode} without terminal files"}
            write_json(out / "record.json", rec)
            write_json(out / "DONE", {"fit_id": fit_id, "status": rec["status"],
                                      "record_sha256": sha(out / "record.json")})
    return {"fit_id": fit_id, "status": rec["status"],
            "record_sha256": sha(out / "record.json")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("shard_file", type=Path)
    parser.add_argument("--bundle-root", type=Path, default=Path("/home/ehwkang"))
    parser.add_argument("--results-dir", type=Path, default=Path("/workspace/vast-results/samq"))
    parser.add_argument("--python", type=Path, default=Path("/opt/gladius-venv/bin/python"))
    parser.add_argument("--workers", type=int, default=None)
    args = parser.parse_args()
    items = json.loads(args.shard_file.read_text())
    shard = args.shard_file.stem
    worker = args.bundle_root / "gladius-vast/samq-worker.py"
    manifest = json.loads((args.shard_file.parent / "manifest.json").read_text())
    if not items or len({x["fit_id"] for x in items}) != len(items):
        parser.error("shard must have unique fit IDs")
    if any(x["suite"] != "samq_nn" or x["shard"] != shard or
           x["trainer_argv"] != ["python", str(worker), x["fit_id"]] for x in items):
        parser.error("descriptor/worker mismatch")
    if manifest["worker_sha256"] != sha(worker):
        parser.error("worker hash mismatch")
    for name, expected in manifest["repair_files"].items():
        if sha(args.bundle_root / "SAmQ-matched-repaired" / name) != expected:
            parser.error("repair hash mismatch: " + name)
    workers = args.workers or min(len(os.sched_getaffinity(0)), len(items))
    if workers < 1:
        parser.error("--workers must be positive")
    result_root = args.results_dir / shard
    result_root.mkdir(parents=True, exist_ok=True)
    (result_root / "shard.json").write_bytes(args.shard_file.read_bytes())
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(run_one, item, args.bundle_root, result_root, args.python) for item in items]
        outcomes = [future.result() for future in as_completed(futures)]
    outcomes.sort(key=lambda x: x["fit_id"])
    for outcome in outcomes:
        fit_id = outcome['fit_id']
        out = result_root / 'fits' / fit_id
        emit_fit(fit_id, out / 'record.json', out / 'DONE')
    write_json(result_root / "outcomes.json", outcomes)
    archive = args.results_dir / ("results-" + shard + ".tar.gz")
    tmp = archive.with_name(archive.name + ".tmp")
    with tarfile.open(tmp, "w:gz") as tar:
        tar.add(result_root, arcname=shard)
    os.replace(tmp, archive)
    print(json.dumps({"archive": str(archive), "sha256": sha(archive),
                      "fits": len(outcomes), "ok": sum(x["status"] == "ok" for x in outcomes)}))
    if all(x['status'] == 'ok' for x in outcomes):
        print(f'===SHARD DONE===:{shard}:{len(outcomes)}', flush=True)
        return 0
    print(f'===SHARD FAILED===:{shard}', flush=True)
    return 2


if __name__ == "__main__":
    sys.exit(main())
