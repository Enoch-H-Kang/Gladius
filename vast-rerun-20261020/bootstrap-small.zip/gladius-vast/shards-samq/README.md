# Repaired neural SAmQ Vast shards

This is the authors' `pqr_aggregation` neural Q/Q* path (`hidden_size=10`, two hidden layers), followed by the `our` aggregation and sampled-transition MLE slope fit. The fork is **SAmQ repaired**, branch `samq-matched-repaired`, commit `4a782e40225e91a4baf267d5d793dceacdf8197f` from `dce1a658d0e750be913c244d52b3e97447554965`. See `SAmQ-matched-repaired/REPAIRS.md` in the bundle for the two estimator repairs. The earlier simplified tabular SAmQ results are separate and superseded for this comparison.

## Fit plan

`manifest.json` and `samq-01.json` through `samq-06.json` use the same descriptor format as `vast/shards/`. There are **120 fits: 6 sizes (50, 250, 500, 1000, 2500, 5000 chains) × 20 frozen-pool repetitions**, with 20 fits per shard. Each fit uses its matching frozen `bus_seed11000`–`bus_seed11019` pool, 80/20 chain split, Q training up to 100 epochs, Q* training up to 200 steps, five Ward clusters, 100 TD passes, and MLE initialized at slope 0.5. The worker checks the pool SHA-256 and frozen data seal before fitting.

For each descriptor, the **entry command per fit** is its `trainer_command_line`, for example after `vast/bootstrap.sh` has installed the full bundle:

```bash
/opt/gladius-venv/bin/python /home/ehwkang/gladius-vast/samq-worker.py SAMQ_NN_n50_r00 \
  --bundle-root /home/ehwkang --results-dir /workspace/vast-results/samq
```

To execute a complete shard and archive its records, use:

```bash
/opt/gladius-venv/bin/python /home/ehwkang/gladius-vast/run-samq-shard.py \
  /home/ehwkang/gladius-vast/shards-samq/samq-01.json --workers 20
```

For a direct fit, expected outputs are `/workspace/vast-results/samq/fits/<fit_id>/record.json`, its hash-bound `DONE`, and neural checkpoints under `neural/train/`. A successful record has `status=ok`, `theta_hat`, Q values, neural features, and matched metrics. Failures retain a terminal record and status. For a complete shard, the runner writes `samq-XX/shard.json`, `samq-XX/outcomes.json`, per-fit logs/records, and `results-samq-XX.tar.gz`, then prints the archive SHA-256. It exits nonzero if any fit fails. No Vast fit or instance has been launched by this preparation.

## Scoring and implementation

Frozen-pool action 0 is keep and action 1 is replace; SAmQ uses the reverse codes. The worker reverses codes on import and in scoring. It shifts native rewards and Q levels by the common 5 anchor, yielding replacement reward −5 and keep reward `−theta × mileage`. `keep_mape` is the matched keep-action reward MAPE. The worker reuses the existing matched-pool adapter's duplicate-state Ward compression and compiled row-wise TD calculation for large pools; these are runner-side mathematical accelerators. The fork's estimator code has only the two documented repairs. The packaged Vast environment pins Torch 2.5.1 CPU, NumPy 1.26.4, SciPy 1.13.1, scikit-learn 1.5.2, pandas 2.2.3, dowel 0.0.4, tqdm 4.66.5, and TensorBoard 2.17.0; native verification on baker used its SAmQ environment (Torch 2.3.1, NumPy 2.0.2, scikit-learn 1.5.2).

## Development verification

`verification/native-dev-7300.json` records an end-to-end native development-pool slice (`bus_seed7300`, five chains, 400 training and 100 validation rows): Q and Q* widths 10, five requested and five actual clusters, Q training log likelihood −0.375827, and Q* training loss 0.404134. At all three chain boundaries the next-array-row successor differed from the recorded successor. At fixed slope 1, old versus repaired NLL was 0.382285 versus 0.382494, with maximum absolute Q difference 0.240122. The old versus repaired fitted slopes were 1.011208 versus 1.014326; both optimizers succeeded. `vast/samq-verify.py --seed 7300` reproduces this check on baker with `~/miniconda3/envs/SAmQ/bin/python`.

`verification/native-dev-7301.json` records a second development-pool slice with the same widths, row counts, and five clusters. Its old versus repaired fitted slopes were 0.917069 versus 0.916274; both optimizers succeeded. This slice had zero mismatched successor cluster labels at its three chain boundaries; the old loop still omitted its final row, and its fixed-slope Q table differed by up to 0.047579. Run `vast/samq-verify.py --seed 7301` on baker to reproduce it.

`verification/n50-fit-record.json` is the prior builder's saved complete frozen-pool fit `SAMQ_NN_n50_r00`: 4,000 training and 1,000 validation rows, slope 0.983069, keep MAPE 1.693065%, validation NLL 0.386464, status `ok`, 55.19 seconds. This fit predates a correction to unused diagnostic next-row fields in the worker dataset; the neural losses use observed states, actions, and recorded successors. The 120-fit production run has not been launched.
