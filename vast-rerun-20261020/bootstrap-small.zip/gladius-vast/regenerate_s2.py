#!/usr/bin/env python3
"""Regenerate frozen S2 pools and E2 panel, then enforce their recorded SHA-256s."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

from normalize_npz import normalize


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bundle-root', type=Path, default=Path('/home/ehwkang'))
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--data-ids', type=int, nargs='+', required=True)
    args = parser.parse_args()
    source = args.bundle_root.resolve()
    destination = (args.output_root or source).resolve()
    s2 = source / 'DDC-DPT-fleet-s2/experiments/fleet_commonshock'
    target = destination / 'DDC-DPT-fleet-s2/experiments/fleet_commonshock'
    sys.path.insert(0, str(source / 'DDC-DPT-fleet-s2'))
    import experiments
    experiments.__path__.append(str(source / 'DDC-DPT-fleet-r1literal/experiments'))
    from experiments.fleet_commonshock import data
    from experiments.fleet_commonshock.core import Component, Reference, all_reward

    manifest = json.loads((s2 / 'artifacts/data/freeze_manifest.json').read_text())
    burn = json.loads((s2 / 'artifacts/pilot/acceptance.json').read_text())['burn']
    refsha = manifest['reference_sha256']
    reference_dir = s2 / 'artifacts/reference'
    if sha(reference_dir / 'reference_manifest.json') != refsha:
        raise ValueError('S2 reference manifest SHA mismatch')
    reference_manifest = json.loads((reference_dir / 'reference_manifest.json').read_text())
    if reference_manifest['status'] != 'certified':
        raise ValueError('S2 reference is not certified')
    components = []
    for bus in range(5):
        path = reference_dir / f'v_bus{bus + 1}.npy'
        if sha(path) != reference_manifest['values_sha256'][f'bus{bus + 1}']:
            raise ValueError(f'S2 reference bus {bus + 1} SHA mismatch')
        components.append(Component(bus, np.load(path, allow_pickle=False)))
    reference = Reference(components)
    data.ROOT = target
    data.ART = target / 'artifacts'
    for data_id in args.data_ids:
        wanted = next((x for x in manifest['pools'] if x['data_id'] == data_id), None)
        if wanted is None:
            raise ValueError(f'unknown frozen data ID: {data_id}')
        if any((target / wanted['exports'][arm]['path']).exists() for arm in ('obs', 'omit')):
            raise FileExistsError(f'refusing existing frozen pool {data_id}')
        data.export(data_id, reference, burn, refsha)
        for arm in ('obs', 'omit'):
            path = target / wanted['exports'][arm]['path']
            normalize(path)
            if sha(path) != wanted['exports'][arm]['sha256']:
                raise ValueError(f'frozen pool SHA mismatch: {path}')
        print(json.dumps({'data_id': data_id, 'pools_verified': 2}), flush=True)

    panel = target / manifest['panels']['E2']['truth']
    if not panel.exists():
        source_states = source / 'gladius-vast/s2_e2_source_states.npy'
        states0 = np.load(source_states, allow_pickle=False)
        expected_states_sha = manifest['panels']['E2']['source_state_sha256']
        if hashlib.sha256(states0.tobytes()).hexdigest() != expected_states_sha:
            raise ValueError('S2 E2 source states SHA mismatch')
        z = np.repeat(np.arange(2), len(states0))
        states = np.tile(states0, (2, 1))
        q, v, pi = reference.joint_query(states, z)
        reward = all_reward(states)
        panel.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(panel, states=states, z=z, Q=q, V=v, pi=pi,
                            reward=reward, reference_sha256=refsha)
        normalize(panel)
    if sha(panel) != manifest['panels']['E2']['truth_sha256']:
        raise ValueError('S2 E2 panel SHA mismatch')
    print(json.dumps({'E2_panel_verified': sha(panel), 'data_ids': args.data_ids}), flush=True)


if __name__ == '__main__':
    main()
