#!/bin/bash
set -euo pipefail
cd "$HOME/DDC-DPT-fleet-s2"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONHASHSEED=0 CUDA_VISIBLE_DEVICES=""
exec "$HOME/miniconda3/envs/gym/bin/python" -u -m experiments.fleet_commonshock.queue run
