# S2 persistent-regime build and queue status

Author confirmation: 2026-10-19. Governing contract: `protocol/commonshock-converged.md`. This checkout is the isolated `fleet-s2-commonshock` worktree on baker. The frozen S1 worktree and its running controllers were not edited.

## Build and validation

- Two-regime reference: **certified** at K=4001 for all five buses. The joint Q allowance is `1.4986578328917723e-05`, below `1e-4`; reference manifest SHA256 `c6faa5ae711045aaf9106336f3170f5747967709c2f46f4df3ca626e22487f67`.
- Exact kernel and sampler checks: **PASS**. K9 joint/component Q difference `4.263256414560601e-14`; off-grid difference `4.973799150320701e-14`; K401 two-bus same-grid Q difference `3.552713678800501e-14`. All 3,840 fixed-cell continuation, regime, and two-bus checks passed. All 200 component and 40 joint whole-path forward checks passed.
- Strict pilot: **accepted**, burn-in `0`; anchor share `0.426825`, replacement shares `0.147969`–`0.183810`, singleton shares `0.066000`–`0.087160`, and state spans `0.396279`–`0.475414`. These are outcomes, not changed acceptance limits.
- Protected data: **frozen**, ten IDs `1000`–`1009`, one million physical rows. Omit and observed exports share actions, rewards, split membership, and first five state coordinates. Freeze manifest SHA256 `5251205b3bb805324df35f67b31890cd2b4fdcde7bf26098338fb42d731a1e79`. The binary exports and evaluation panels remain on baker and are excluded from Git; their hashes are in the committed freeze manifest.
- Implementation tests: `python -m unittest experiments.fleet_commonshock.test_commonshock -v` passed **7/7**, including frozen trainer smoke tests for five and six inputs, paired export/nested split checks, causal action-likelihood filter timing, and squared-error averaging across both regimes. A separate full 20,000-row E1 filter pass completed: observed oracle NLL `1.9321546275190067`, history NLL `1.9322405762128492`, sample information gap `0.00008594869384248582`, full-policy KL `0.0005254136652895396`.
- Shared-code replay condition: no shared source was edited. The five trainer/model source files used by S2 are byte-identical to the frozen S1 worktree. The inherited three P0 bitwise replays passed (72 parameter arrays and all loss traces); their recorded trainer hash matches the current source. One completed frozen fleet 2×10 record's code hash also matches the current source. `results/replay_provenance.json` records hashes. A new full-record replay was not triggered because there was no shared-code edit.

## Sealed fit queue

`results/manifest_S2.json` has SHA256 **`7209067219ddfaabf7c29c2524ea012099a768def36e2238549b08ae03a7d4dd`**. It has 80 distinct slots: 40 omit and 40 observed, each with four N values and ten paired data IDs. It fixes the unchanged 50,000-update signed-loss 2×10 trainer and the sole five/six-input distinction. The endpoint source hash is `51b624b91fc7cf2b7cae2d350b76465239f7eeafa92b6be1a8faa02737fa6919`. No S2 performance gate controls whether later slots run.

The detached baker controller (`run_s2_queue.sh`, Python PID 186920 at verification) is live and waiting. At 2026-10-20 04:49 UTC, its `results/status.json` read `waiting_predecessors`, `waiting_headline`, `started: 0`; the frozen chain was running F2 and the follow-up controller was waiting for the headline stage. Trigger order is F1 → F2 → F3 → D → D_ref → H → FL_followup → M1_followup → EL_followup → EX_followup → S2. S2 only admits after the registered follow-up controller reports completion with terminal accounting and DONE markers, or an explicit hold with reservations released. A failed S1 headline admission stays a hold and leaves the S1 comparison unavailable; independently accepted S2 fits can then start.

The S2 controller admits at most 36 one-thread fit workers, reserves two controller/evaluation tokens, and uses the shared baker CPU-load budget against 44 busy compute threads. It writes every fit record and keeps failed slots in the 80-slot accounting. Each attempt has its own directory, so a restarted slot retains partial checkpoints and its log. `artifacts/logs/S2.DONE` means all 80 fit records are terminal; `artifacts/logs/ENDPOINTS.DONE` means endpoint scoring completed. No S2 protected fit had started at the build verification.

## Later completion check

From `~/DDC-DPT-fleet-s2` on baker:

```bash
cat experiments/fleet_commonshock/results/status.json
cat experiments/fleet_commonshock/results/accounting_S2.json
test -f experiments/fleet_commonshock/artifacts/logs/S2.DONE && echo fits_terminal
test -f experiments/fleet_commonshock/artifacts/logs/ENDPOINTS.DONE && echo endpoints_complete
ps -eo pid,ppid,nlwp,etime,args | grep -E 'fleet_commonshock.queue|frozen_followups|frozen_headline' | grep -v grep
```

The queue log is `artifacts/logs/S2_queue.log`; per-slot logs are `artifacts/logs/S2_*.log`; starts and exits are in `results/queue_S2.csv`. When endpoints finish, inspect `results/endpoints.json` and write the final outcome narrative in `RUN_REPORT.md`. A missing record or failed fit stays in the denominator; the full ten-member contrast is unavailable if any required member fails. Do not restart an active controller or reroll a seed.

## Deviations and pending outcomes

There were no changes to the frozen protocol, DGP constants, numerical tolerances, protected pools, or existing frozen controllers. A new bitwise replay was not run because no shared source changed. The resource controller uses the existing baker-wide busy-core sampler and the 36-worker/two-token admission rule; the pre-existing frozen controllers do not participate in one atomic project-wide ledger, so that literal ledger requirement is not met. S2 starts only after those controllers terminate or release reservations. Training and endpoint outcomes are pending the frozen queue; this build records no empirical reward-recovery conclusion.

## 2026-10-20 author gate release audit

The author removed the fleet D-reference k=1 gate leg at 09:20 PDT and excluded k=1 from every non-main experiment. The original two failed D-reference fits remain recorded as results. The S2 sealed manifest was audited after this decision: all 80 slots have `config.k = 10` (40 omit, 40 observed), and no S2 slot was removed. The main bus rerun was untouched.

The S2 controller had already used its registered `held_feasibility` predecessor-release rule before the amended headline was launched. It completed all 80 fit records at 2026-10-20 09:34:31 UTC and wrote `S2.DONE` and `ENDPOINTS.DONE`; terminal statuses were 7 `ok` and 73 `anchor_fail`. Its endpoint record was computed while S1 headline records were absent, so all S1 rows were marked missing and S1 contrasts remain unavailable in that version. This is a queue-order deviation from the intended headline-first sequence, although the controller followed its explicit hold-release trigger. No S2 fit is being relaunched.

`refresh_s1_endpoints.py` is a detached one-thread watcher for the resumed chain. It waits for the registered follow-up predecessor rule and a complete 40-record S1 headline accounting, then preserves the early endpoint record as `results/endpoints_before_s1_refresh.json` and recomputes `results/endpoints.json` with the sealed endpoint code. It records state in `results/endpoint_refresh_status.json` and completion in `artifacts/logs/ENDPOINTS_S1_REFRESH.DONE`. If the headline never completes, it records `held_s1_unavailable` and leaves the early endpoint result in place. It launches no fits.
