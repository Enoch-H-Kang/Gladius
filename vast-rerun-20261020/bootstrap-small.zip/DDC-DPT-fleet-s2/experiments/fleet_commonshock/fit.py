"""Truth-isolated S2 adapter to the unchanged frozen shared GLADIUS trainer."""
import json
import hashlib
import os
import shutil
import time
from pathlib import Path
import numpy as np
from experiments.fleet_capacity_one.fleet.models import MLP
from experiments.fleet_r1literal.models import initialize

ROOT=Path(__file__).resolve().parent

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+'\n')
    os.replace(tmp,path)

def load_split(path,arm,n_chains,expected_sha):
    if sha(path)!=expected_sha: raise ValueError('dataset hash mismatch')
    with np.load(path,allow_pickle=False) as z:
        required={'s','sp','a','r0','is_val','chain_id','stream_id','arm',
                  'n_actions','anchor_action','namespace','reference_sha256'}
        if set(z.files)!=required: raise ValueError('export schema mismatch')
        if str(z['arm'])!=arm or str(z['namespace'])!='r1literal_s2_v1': raise ValueError('arm mismatch')
        d=5 if arm=='omit' else 6
        if z['s'].shape!=(1000,100,d) or z['sp'].shape!=z['s'].shape: raise ValueError('state shape mismatch')
        if int(z['n_actions'])!=32 or int(z['anchor_action'])!=0: raise ValueError('action mismatch')
        if n_chains not in (10,50,200,1000): raise ValueError('invalid prefix')
        mask=z['is_val'][:n_chains].astype(bool)
        if int(mask.sum())!=n_chains//5: raise ValueError('split mismatch')
        def part(sel):
            return dict(s=z['s'][:n_chains][sel].reshape(-1,d).astype(np.float32),
                        sp=z['sp'][:n_chains][sel].reshape(-1,d).astype(np.float32),
                        a=z['a'][:n_chains][sel].reshape(-1).astype(np.int64),
                        r0=z['r0'][:n_chains][sel].reshape(-1).astype(np.float32))
        return dict(train=part(~mask),val=part(mask),
                    meta=dict(n_actions=32,anchor_action=0,beta=.95,state_scale=1.,arm='s2_'+arm,
                              input_dim=d,namespace='r1literal_s2_v1'),
                    n_train_chains=int((~mask).sum()),n_val_chains=int(mask.sum()))

def factory(cfg,meta):
    if cfg['architecture']!='mlp2x10': raise ValueError('frozen architecture required')
    d=int(meta['input_dim'])
    if d not in (5,6): raise ValueError('input dimension mismatch')
    return MLP(d,32,10,2)

def fit_s2(data,cfg,seeds,ckpt_dir):
    from experiments.fleet_capacity_one.fleet.train import fit
    if cfg['loss']!='signed': raise ValueError('frozen signed loss required')
    shared={**cfg,'loss':'none'}
    result=fit(data,shared,seeds,horizons=[10000,20000,50000],ckpt_dir=ckpt_dir,
               model_factory=factory,model_initializer=initialize)
    result['declared_loss']='signed';result['shared_loss_semantics']='none'
    return result

def worker(manifest_path,fit_id):
    import traceback
    import torch
    torch.set_num_threads(1)
    try: torch.set_num_interop_threads(1)
    except RuntimeError: pass
    m=json.loads(Path(manifest_path).read_text())
    spec=next(s for s in m['fits'] if s['fit_id']==fit_id)
    out=ROOT/'artifacts/fits'/fit_id;out.mkdir(parents=True,exist_ok=True)
    start=time.time()
    # A restarted worker gets a new attempt directory. Partial checkpoints and
    # its log remain available for an infrastructure audit.
    attempt=out/'attempts'/f'{time.time_ns()}_{os.getpid()}'
    attempt.mkdir(parents=True,exist_ok=False)
    try:
        path=ROOT/spec['pool']
        data=load_split(path,spec['arm'],spec['n_chains'],spec['pool_sha256'])
        result=fit_s2(data,{k:v for k,v in spec['config'].items() if k!='N'},spec['seeds'],attempt)
        result.update(n_train_chains=data['n_train_chains'],n_val_chains=data['n_val_chains'])
    except BaseException as exc:
        result=dict(fit_status='process_failure',error=f'{type(exc).__name__}: {exc}',
                    traceback=traceback.format_exc())
    result.update(fit_id=fit_id,arm=spec['arm'],data_id=spec['data_id'],N=spec['config']['N'],
                  manifest_sha256=sha(manifest_path),data_sha256=spec['pool_sha256'],
                  frozen_code_sha256=m['frozen_code_sha256'],start_unix=start,end_unix=time.time(),
                  pid=os.getpid(),attempt_path=str(attempt.relative_to(ROOT)))
    for checkpoint in attempt.glob('*.pt'):
        shutil.copy2(checkpoint,out/checkpoint.name)
    write(attempt/'record.json',result)
    write(out/'record.json',result)
    print(json.dumps(dict(fit_id=fit_id,fit_status=result['fit_status'])),flush=True)
    return 0 if result['fit_status']=='complete' else 2
