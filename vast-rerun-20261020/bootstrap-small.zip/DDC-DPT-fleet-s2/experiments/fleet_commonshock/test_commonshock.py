"""Implementation controls using frozen reference and protected export metadata."""
import ast
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
import numpy as np
import torch
from .core import B,P,half_increment,half_mass,all_reward
from .data import ROOT,REF,split,seed
from .fit import load_split,factory,fit_s2
from .reference import load,sha
from .endpoints import filtered_oracle,successor_loglike,eval_fit,predict,rmse
from experiments.fleet_r1literal.params import ACTIONS,MU,BETA,encode,decode
from experiments.fleet_r1literal.texp import L
from experiments.fleet_capacity_one.fleet.losses import be_term,u_square

class CommonShockTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.ref=load(REF)

    def test_constants_and_timing(self):
        s1=json.loads((ROOT.parent/'fleet_r1literal/configs/dgp_r1literal.json').read_text())
        s2=json.loads((ROOT/'configs/dgp_s2_commonshock.json').read_text())
        self.assertEqual(s1['buses'],s2['buses'])
        self.assertEqual(s1['beta'],s2['beta'])
        self.assertEqual(s2['s2_commonshock']['regime_transition'],P.tolist())
        self.assertTrue(np.array_equal(encode(decode(np.arange(32))),np.arange(32)))
        self.assertTrue(np.all(np.diff(B)>-1))
        for f in range(5):
            self.assertLess(B[f],L[f])
            self.assertLess(float(half_increment(0.,f,0)),float(half_increment(1.,f,1)))
            self.assertAlmostEqual(float(half_mass(0.,L[f],f,0)),1.,places=13)
            self.assertAlmostEqual(float(half_mass(0.,L[f],f,1)),1.,places=13)

    def test_joint_product_and_reward(self):
        rng=np.random.default_rng(923)
        s=rng.random((20,5));z=rng.integers(0,2,20)
        Q,V,pi=self.ref.joint_query(s,z)
        self.assertLess(np.max(np.abs(np.log(np.exp(Q).sum(axis=1))-V)),1e-10)
        self.assertLess(np.max(np.abs(pi.sum(axis=1)-1)),1e-12)
        r=all_reward(s)
        self.assertEqual(r.shape,(20,32))
        self.assertLess(np.max(np.abs(r[:,0]+np.sum(s*np.array([1,1.2,.9,1.3,1.1])+
                                                    s*s*np.array([2,2.6,1.7,2.3,3]),axis=1))),1e-12)

    def test_paired_exports_and_nested_split(self):
        manifest=json.loads((ROOT/'artifacts/data/freeze_manifest.json').read_text())
        self.assertEqual(len(manifest['pools']),10)
        p=manifest['pools'][0]
        with np.load(ROOT/p['exports']['omit']['path'],allow_pickle=False) as omit, \
             np.load(ROOT/p['exports']['obs']['path'],allow_pickle=False) as obs:
            self.assertEqual(omit['s'].shape,(1000,100,5))
            self.assertEqual(obs['s'].shape,(1000,100,6))
            self.assertTrue(np.array_equal(omit['s'],obs['s'][...,:5]))
            self.assertTrue(np.array_equal(omit['sp'],obs['sp'][...,:5]))
            for key in ('a','r0','is_val','chain_id'):
                self.assertTrue(np.array_equal(omit[key],obs[key]))
            self.assertNotIn('z',omit.files)
            self.assertEqual(int(obs['is_val'][:10].sum()),2)
            self.assertEqual(int(obs['is_val'][:50].sum()),10)
            self.assertEqual(int(obs['is_val'][:200].sum()),40)
            self.assertEqual(int(obs['is_val'].sum()),200)

    def test_signed_alias_and_smoke(self):
        q=torch.tensor([.7,-.2,1.],dtype=torch.float64,requires_grad=True)
        r=torch.tensor([.1,.2,-.3],dtype=torch.float64)
        v=torch.tensor([.5,.4,.1],dtype=torch.float64,requires_grad=True)
        z=torch.tensor([.4,.1,.2],dtype=torch.float64)
        mask=torch.tensor([True,False,True])
        actual=be_term(q,r,v,z,mask,.95,'none')
        expected=(u_square(q,r,v,z,.95)*mask).mean()
        self.assertLess(abs((actual-expected).item()),1e-13)
        torch.autograd.grad(actual,(q,v))
        # No protected truth is read by the trainer. Small synthetic data exercise both dimensions.
        for d in (5,6):
            rg=np.random.default_rng(d)
            x=rg.random((32,d)).astype(np.float32)
            part=dict(s=x,sp=x*.95,a=rg.integers(0,32,32,dtype=np.int64),
                      r0=np.full(32,-1.,dtype=np.float32))
            part['a'][0]=0
            data=dict(train=part,val=part,meta=dict(n_actions=32,anchor_action=0,
                 beta=.95,state_scale=1.,input_dim=d,arm='s2_smoke'))
            cfg=dict(architecture='mlp2x10',loss='signed',k=10,cap_q=2,
                     batch=16,val_every=1,elig_start=1)
            seeds={s:100+i for i,s in enumerate(('qinit','zinit','ce','extrazeta','anchor','eval'))}
            from experiments.fleet_capacity_one.fleet.train import fit
            res=fit(data,{**cfg,'loss':'none'},seeds,horizons=[2],
                    model_factory=factory,model_initializer=__import__('experiments.fleet_r1literal.models',fromlist=['initialize']).initialize)
            self.assertEqual(res['counts']['q_updates'],2)
            self.assertEqual(res['counts']['z_updates'],20)

    def test_trainer_import_graph(self):
        source=(ROOT/'fit.py').read_text()
        imports=[]
        for node in ast.walk(ast.parse(source)):
            if isinstance(node,ast.ImportFrom): imports.append(node.module or '')
        forbidden=('reference','core','data','oracle','eval','reward','texp')
        self.assertFalse(any(any(k in name for k in forbidden) for name in imports))

    def test_filter_action_likelihood_and_regime_timing(self):
        # Both histories end at exactly zero mileage after replace-all. Their
        # different earlier mileages make the observed action informative.
        x=np.array([[[.1]*5, [0.]*5], [[.9]*5, [0.]*5]])
        xp=np.zeros_like(x)
        xp[:,1,:]=half_increment(.25,0,0)  # overwritten below per bus
        for f in range(5): xp[:,1,f]=half_increment(.25,f,0)
        a=np.array([[31,0],[31,0]],dtype=np.int64)
        z=np.zeros((2,2),dtype=np.int64)
        got=filtered_oracle(self.ref,dict(s=x,sp=xp,a=a,z=z))
        expected=[];post=[]
        for i in range(2):
            pi0=self.ref.joint_query(x[i,:1],np.array([0]))[2][0]
            pi1=self.ref.joint_query(x[i,:1],np.array([1]))[2][0]
            first=.5*(pi0[31]+pi1[31])
            posterior=np.array([pi0[31],pi1[31]])/(pi0[31]+pi1[31])
            next_prior=posterior@P
            post.append(next_prior[0])
            q0=self.ref.joint_query(x[i,1:2],np.array([0]))[2][0,0]
            q1=self.ref.joint_query(x[i,1:2],np.array([1]))[2][0,0]
            expected.extend([-np.log(first),-np.log(next_prior@[q0,q1])])
        self.assertAlmostEqual(got['history_nll'],float(np.mean(expected)),places=12)
        self.assertAlmostEqual(got['mean_filtered_pz0'],float(np.mean([.5,.5]+post)),places=12)
        self.assertGreater(abs(post[0]-post[1]),.001)
        self.assertEqual(successor_loglike(x[0,0],xp[0,0],31,0),0.)
        self.assertEqual(successor_loglike(x[0,0],xp[0,0],31,1),0.)
        self.assertTrue(np.isfinite(successor_loglike(x[0,1],xp[0,1],0,0)))
        self.assertEqual(successor_loglike(x[0,1],xp[0,1],0,1),-np.inf)

    def test_scoring_averages_squared_errors_over_both_regimes(self):
        from experiments.fleet_capacity_one.fleet.models import MLP
        from .core import all_reward
        torch.manual_seed(71)
        q,z=MLP(6,32,10,2),MLP(6,32,10,2)
        states=np.array([[.2,.3,.4,.5,.6],[.2,.3,.4,.5,.6]])
        regimes=np.array([0,1])
        tq,tv,tp=self.ref.joint_query(states,regimes)
        truth={'E2':dict(states=states,z=regimes,Q=tq,V=tv,pi=tp,reward=all_reward(states))}
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'ckpt.pt'
            torch.save(dict(q=q.state_dict(),z=z.state_dict(),step=5000),path)
            got=eval_fit(path,6,'obs',truth)
            Q,Z=predict((q,z),np.column_stack([states,regimes]))
            err=(Q-.95*Z-all_reward(states))[:,1:]
            self.assertAlmostEqual(got['panels']['E2']['M'],rmse(err),places=12)
            self.assertEqual(got['panels']['E2']['Q_comparison_role'],'augmented_truth_recovery')

if __name__=='__main__': unittest.main()
