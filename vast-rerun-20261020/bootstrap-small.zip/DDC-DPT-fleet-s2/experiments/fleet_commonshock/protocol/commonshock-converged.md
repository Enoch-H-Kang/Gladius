# S2 common shock: converged build specification

## AUTHOR-CONFIRM

**Should S2 use a persistent usage regime known to the bus manager, comparing estimates that omit it with estimates that observe it (recommended), or a fresh common mileage shock each period that only tests correlated transitions?**

The recommendation is specified completely below; confirmation authorizes the changed information structure and its 80-fit allocation. It is not yet an author decision. The alternative is not a second implementation in this spec.

## Decision and scope

Use **S2-omit/S2-obs on one persistent-regime DGP**, with the frozen independent-fleet results as S1. The editor requests model-misspecification evidence in addition to other robustness checks; the locally preserved letter transcription is in [response-draft.tex, `e:misspecification`](../response/response-draft.tex). Under the proposed iid, after-choice common shock, additive rewards, coordinate-local marginals and Cartesian actions imply

```
E[Σ_f v_f(x'_f) | x,a] = Σ_f E[v_f(x'_f) | x_f,a_f]
logsumexp_a Σ_f q_f(x_f,a_f) = Σ_f logsumexp_b q_f(x_f,b).
```

Bellman contraction gives the same Q/V/policy as S1 when those marginals are preserved. GLADIUS fits a joint 32-action function and does not assume independent buses. Correlation alone therefore does not introduce the claimed misspecification.

The selected DGP changes the true decision problem to `(x,z)`. Omitting z violates the estimator's state-sufficiency/Markov specification; conditional additivity across buses still holds. **Do not call this nonadditive reward truth or generic cross-bus value interactions.** S2-obs restores the information needed for a Markov model, but does not prove exact realizability by a finite 2×10 network. This is an omitted-state stress test, complementary to the existing fixed-DGP capacity-by-N study, not a replacement for that direct response to the editor's approximation-error concern.

Binding precedence: [author decisions](final-decisions.md), especially the strict LC pilot rule and common-protocol freeze; [R1-literal contract](r1literal-converged.md); this S2 delta. The original Zurcher bus remains the paper's main experiment. No main-arm constant, artifact, admission rule or fit changes.

## Disagreement adjudication

Each row is a decision and its reason; neither source planner's unselected provisions remain implicit requirements.

| Issue | Decision and reason |
|---|---|
| iid mixture versus persistent half-law regime | Choose Claude's regime: Codex's truth-preserving dependence changes sampling noise but introduces no violated GLADIUS assumption. |
| Meaning of nonseparability | Keep `Q(x,z,a)=Σ_f q_f(x_f,z,a_f)`: the misspecification is omitted information, not failure of conditional bus additivity. |
| “Only increments change; marginals unchanged” | Preserve stationary unconditional primitive-increment marginals only: persistence changes laws conditional on mileage, actions and history, which is precisely the misspecification mechanism. |
| Strength/second author question | Fix λ=1 and p=.95 without a separate strength decision: costs must stay frozen, and a bounded mild stress test answers a narrower, honest question. |
| “Strongest possible” split | Drop this claim and the claimed <10% gain at p=.98: the prototype does not establish a universal extremum, and its displayed gaps do not support that percentage. |
| Omit-only versus observed control | Run 40 omit + 40 obs fits on identical rows: the control helps distinguish omitted information from general difficulty on the new DGP. |
| Reuse S1 reference versus new solve | Build five two-regime 1-D references: S1 truth is no longer valid, while exact conditional decomposition avoids an unnecessary full-dimensional production grid. |
| Direct tensor checks | Retain the inherited K9 joint and K401 two-bus checks with a regime axis: the new timing/kernel needs validation before interpreting recovery errors. |
| Monte Carlo checks | Use 200 component and 40 joint start/regime checks with simultaneous intervals: correct joint uncertainty and timing matter for credible truth comparisons. |
| Sampler significance rules | Freeze streams and report simultaneous/block uncertainty; investigate discrepancies without rerolling: isolated KS/3-SE rejections must not become outcome-dependent simulation selection. |
| Two development fits/KL admission versus none | No new performance-gated S2 development stage: failure under misspecification is an outcome, so a KL≤.02 precondition would censor the intended stress test. |
| Frozen trainer details | Carry Codex's explicit batch, selector and optimizer contract into both information sets: misspecification must not be confounded with a changed training recipe. |
| E2–E4 regeneration versus reuse | Reuse S1's exact x-panels and average S2 truth over both regimes: common state weighting makes structural recovery comparisons interpretable. |
| Primary evaluation distribution | Use common E2 at N100k; report E1/E3/E4 and all N secondarily: occupancy shifts must not determine the headline recovery ratio. |
| Cross-arm pairing | S1 versus S2 is two-sample; omit versus obs is paired: equal numeric IDs do not create common random numbers across DGP namespaces. |
| 1.25 robustness margin | Reject the unsupported margin; report absolute errors, ratios, intervals and failures: the editor needs measured limits, not an arbitrary success label. |
| N20k→100k flattening | Report the directly bootstrapped slope difference as exploratory: finite-N flattening also reflects optimization and cannot establish an asymptotic bias floor. |
| Policy oracle and filtered benchmark | Retain both with a causal forward filter and corrected NLL sign: information loss must be separated from estimator error without treating history as mileage-only information. |
| Omitted-model Q scoring | Score against augmented truth only as an explicit mismatch diagnostic; omit filter-averaged Q as a recovery target because it is not a Bellman value for the omitted model. |
| <8/10 versus full-denominator reporting | Keep all ten slots; a missing member makes the declared full-sample ratio unavailable: successful-subset summaries cannot certify robustness. |
| S1 feasibility failure | Preserve S1's hold, but allow independently accepted S2 fits after queue release: within-S2 misspecification evidence remains meaningful when the S1 comparison is unavailable. |
| Active worktree versus isolated build | Use an isolated worktree/package: altering active frozen code would confound the comparison and invalidate provenance. |
| One replay versus three | Require the inherited three P0 default-path bitwise replays for shared edits, plus a completed fleet-record replay: the existing safety contract cannot be weakened for S2. |
| 42-worker versus 36-worker pool | Preserve the stricter existing 36-worker pool and shared 44-thread ceiling: added evidence must not disturb the frozen chain. |
| Compute forecasts | Budget 80 fits using measured S2 timings; planner timing snapshots are estimates: a new two-regime reference and six-input control have not been timed in production. |
| Deadline interpretation | Keep the inherited Stage-2 scheduling rule without inventing a November 2 UTC start cutoff: calendar reinterpretation must not silently trim the evidence. |

## 1. DGP and information sets

Hash-check these values against the accepted S1 artifact; copy its full-precision constants rather than recomputing rounded versions.

| Bus | u | v | Kcost | d | μ | L=5μ |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 1.0 | 2.0 | 3.0 | .15 | .040 | .200 |
| 2 | 1.2 | 2.6 | 3.4 | .35 | .050 | .250 |
| 3 | .9 | 1.7 | 2.7 | .25 | .060 | .300 |
| 4 | 1.3 | 2.3 | 3.5 | .40 | .045 | .225 |
| 5 | 1.1 | 3.0 | 3.1 | .20 | .055 | .275 |

Retain `x∈[0,1]^5`, β=.95, temperature 1, 32 actions `a=Σ_f a_f 2^(f−1)`, anchor 0, replace-all 31, 100 retained transitions/chain, independent initial coordinates `U[0,.5]`, and cost scale 1:

```
m_f(x) = u_f*x + v_f*x²
C_f(x) = Kcost_f + d_f*x²
r(x,a) = Σ_f [−(1−a_f)*m_f(x_f) − a_f*C_f(x_f)]
r0(x) = −Σ_f m_f(x_f)
x'_f = 0 if a_f=1 else min(1,x_f+D_f).
```

Replacement has no maintenance charge or same-period increment. Preserve centered independent per-bus/action Gumbel utility shocks, implemented by independent binary policy draws given `(x,z)`; do not draw 32 independent joint-utility Gumbels.

Let t solve `1/t−5/expm1(5t)=1`, with displayed check `.9602015099445034`; `ρ_f=t/μ_f`, `Z=−expm1(−5t)`, `F_f⁻¹(w)=−log1p(−wZ)/ρ_f`, and median `b_f=F_f⁻¹(.5)`.

```
z_0 ~ Bernoulli(.5), independently of x_0
P = [[.95,.05],[.05,.95]]

At each time:
  manager observes (x_t,z_t), then chooses a_t from π_ref(.|x_t,z_t)
  draw five independent U_f ~ Uniform(0,1)
  D_f = F_f⁻¹((z_t+U_f)/2)              # λ=1, lower/upper half
  apply reset/cap to obtain x_{t+1}
  draw z_{t+1} from P[z_t,:], independently of increments conditional on z_t.
```

Draw all five increments and the regime transition on every step, irrespective of actions. Each chain has its own regime; “common” means shared across its five buses, not across replication chains. The regime affects usage only. There is no cost shock, capacity constraint or Kcost-rescale exception.

At stationarity, each primitive D_f has exactly S1's marginal law, including mean μ_f and support `[0,L_f]`. This does **not** preserve the increment distribution conditional on x, a, keeping a bus, or history. For standardized Y=D_f/μ_f, the two conditional means are approximately `.316271709` and `1.683728291`, and variance is `.875655819`. Thus

```
c = Var(E[Y|z])/Var(Y) = .5338677204707422
corr(D_f,t,D_g,t) = c                    # f != g
corr(D_f,t,D_g,t+k) = c*.9^k             # k>=1, including f=g.
```

These are primitive-increment correlations, not reset/capped mileage correlations. Regime length has mean 20. The [planning prototype](proto/commonshock/proto.py) suggests maximum per-bus replacement-probability gaps of roughly 3.8–6.3 percentage points; these are unvalidated planning numbers, not production results or a maximum attainable stress.

S2-omit receives only x; S2-obs receives `(x,z)` with z coded 0/1, and the successor includes `z_{t+1}`. Reward truth is identical in both. The reference structure follows the existing integrated-hat solver; serially correlated omitted states are the relevant DDC departure, as studied by [Norets (2009)](https://onlinelibrary.wiley.com/doi/10.3982/ECTA7292). The particular regime split, constants and equations here are this experiment's construction.

## 2. Reference and simulator acceptance

Solve five float64 coupled `(x_f,z)` problems:

```
q_f(x,z,0) = −m_f(x) + β Σ_z' P[z,z'] E_D|z[v_f(min(1,x+D),z')]
q_f(x,z,1) = −C_f(x) + β Σ_z' P[z,z'] v_f(0,z')
v_f(x,z) = logsumexp_b q_f(x,z,b)
Q(x,z,a) = Σ_f q_f(x_f,z,a_f)
V(x,z) = Σ_f v_f(x_f,z)
π(a|x,z) = Π_f softmax(q_f(x_f,z,:))[a_f].
```

The shared successor regime does not invalidate this decomposition: expectation of a sum remains a sum. Reuse the integrated-hat implementation with density `2ρ_f exp(−ρ_f d)/Z` restricted to `[0,b_f)` or `[b_f,L_f]`, exact cap mass and deterministic replacement. Production queries use analytic rewards plus integrals of interpolated V at the actual continuous input; never interpolate Q corners.

Retain the complete [S1 reference acceptance contract](r1literal-converged.md), applied to both regimes:

- Grid ladder K={1001,2001,4001,8001}; initial release candidate 4001; reload residual ≤1e−11 and ≤2,000 sweeps; K2001→4001 q change ≤2e−5 per bus over both regimes, with K8001 comparison.
- Kernel row-sum error ≤1e−12, weights ≥−1e−13, independent split quadrature agreement ≤1e−10, and the inherited continuous query/check panels.
- Enclose `δ_f=max_z sup_x |T_f vtilde_f(x,z)−vtilde_f(x,z)|≤1e−6`, including arithmetic/integration allowances, and certify `epsilon_Q=β/(1−β) Σ_f δ_f + query_allowance≤1e−4`, with query allowance ≤5e−6.
- Split at interpolation knots, support and cap junctions, and all shifts induced by b_f and L_f; the median is not grid-aligned. A dense-panel maximum is not a uniform certificate. Refine to K8001 if needed; unresolved certification failure holds production.

Required implementation checks:

1. **Nesting/algebra:** λ=0 test kernel reproduces S1 for any p, within 1e−12 with matched numerical operations; β=0 static logit, zero-reward `V=log32/(1−β)`, joint/product identities, regime-label permutation with the laws permuted, reset/cap and action encoding. λ=0 is a test fixture, not another fitted arm.
2. **Tensor:** K9, `2×9^5` augmented states, 32 actions, identical component/joint kernels; same-grid Q/V and off-grid lookahead agreement ≤1e−10. Implement joint transitions by tensor contractions, not a dense state-by-state matrix. Retain the F=2 K401 versus fine-component diagnostic; its discretization difference is not a certified error bound.
3. **Kernel/sampler:** 10^6 independent stationary joint vectors for marginals, half-laws, cross-bus correlation and product-policy sampling; 10,000 independent H100 regime/increment chains for serial correlations k=1…5, regime frequencies and switches. Use independent blocks/chains for uncertainty. At 20 fixed x states × two z ×32 actions, use 10,000 draws/cell to check joint continuation means, successor-regime frequencies, and `x'_1*x'_2` against independent quadrature. Include mutation tests that swap current/next regime or silently use the full marginal law.
4. **Forward validation:** inherited 20-start fixture ×two initial regimes ×2,000 paths ×450 steps per bus, and ×1,000 joint paths ×450 steps. There are 200 component plus 40 joint checks; use `Φ⁻¹(1−.05/(2*240))`, whole-path SEs, and certified numerical/policy-query allowances. Joint soft return sums `r+H(π)` once; tail allowance is `β^450*(17.9+log32)/(1−β)`; component bounds use their own reward maximum plus log2. Joint SEs must include bus covariance.
5. **Misspecification witness:** on the fixed reference panels, report regime differences in anchor-relative Q and policy at identical x, with numerical allowances, and two feasible histories giving different filtered regime probabilities at the same current x. This verifies the violated state-sufficiency assumption; if differences cannot be resolved numerically, report that limitation rather than increase shock strength.

Freeze diagnostic seeds and save every discrepancy. Statistical intervals are implementation diagnostics, not a uniform certificate; an unresolved mismatch holds release for review, without new seeds or repeated-until-pass checks. Only certified references admit production fits. Archive all bound terms, arrays, timings and reference/query/simulator hashes.

## 3. Data and leakage controls

Use namespace **`r1literal_s2_v1`** in the inherited seed expansion: first eight SHA256 bytes, big-endian, of UTF-8 `20261018|testbed|stage|data_id|init_index|stream_name`, modulo `2^63−1`. Save expanded seeds. Separate starts, initial regime, regime transitions, five increment streams, five choice streams, Q/ζ initialization, CE, extra ζ, anchor and evaluation streams. Omit/obs share physical rows and split membership; data/batch streams are paired. Initialization uses the same declared stream mapping, but different first-layer dimensions do not imply identical weights or subsequent RNG consumption.

**Pilot:** 10,000 chains ×100 retained rows. Apply the existing rule once: burn-in 50 iff any bus's KS distance between `t<20` and `t≥50` exceeds .1, otherwise zero; regenerate once for the chosen recording protocol if necessary. All strict LC conditions must pass: anchor share [.25,.95], each bus replacement share [.03,.30], each singleton action share ≥.01, each coordinate's 95th–5th percentile span ≥.25. Failure stops this DGP version; no strength/cost search. Report all action shares, regime-specific replacement gaps, cap/tail coverage, fixed-time and pooled mileage correlations with chain uncertainty. Prototype results do not grant acceptance.

**Protected pools:** IDs 1000–1009, each 1,000 independent chains and permanent 800/200 train/validation membership before nesting:

| N total joint transitions | Training chains | Validation chains |
|---:|---:|---:|
| 1,000 | 8 | 2 |
| 5,000 | 40 | 10 |
| 20,000 | 160 | 40 |
| 100,000 | 800 | 200 |

This is 1,000,000 protected physical rows reused by both information sets, not eight separately generated datasets per block. Preserve actual last-row successors; chain restarts are not transitions. No balancing, replacement seeds or rare-action oversampling.

Export only s, sp, joint a, total r0, chain/split/stream metadata and provenance hashes. Shapes are `(chains,100,5)` for omit and `(chains,100,6)` for obs. No increments, regime paths in omit, kernel/cost parameters, action bits, component labels or truth. Simulator/evaluator retain float64; training copies are float32. Validate input-rounding allowances separately. Omit's trainer cannot open obs exports or evaluator sidecars. Test import-graph isolation and replay with truth unavailable.

**Evaluation:** S2 E1 uses 200 fresh H100 occupancy chains, namespace stream 9999; retain z, action labels and successors outside trainers. Reuse S1 E2 (20,000 uniform states), E3 (3,125 grid states) and E4 (1,024 boundary states) byte-identically with hashes. Evaluate S2 on both z, equally weighted, on E2–E4; on E1 use realized z. E1 S1/S2 cross-panel tables use the realized z on S2 E1 and balanced synthetic z on S1 E1 for S2 truth; do not use S1 action labels to score a changed policy's “own-DGP” NLL. S1 reward predictions can be scored on either x-panel because reward truth is unchanged.

For the history benchmark, retain evaluator-only burn-in x/action history when burn-in is used, so filtering starts from the specified initial distribution and proceeds through burn-in. No hindsight smoothing, true z, or future rows enter the predictive filter. No S2 tuning pools, fit-stage development allocation or new locks.

## 4. Frozen fits

Create exactly **80 protected fits**: `{omit,obs} × N{1k,5k,20k,100k} × blocks{1000,…,1009} × one initialization`. Reuse the 40 frozen S1 2×10 headline fits without refitting/reselection. Fresh model, optimizer and process for every slot.

Verify common-freeze SHA256 `dcba37006a1ef6747671f03fc4e9a88f388ad2f4261086c45a32656788d7afba` and originating lock `3a7749e7354fd1472320f76b2d2b62259847eed682dea6379ecff7f02129619b`; a mismatch requires provenance reconciliation, not replacing the expected hash. Preserve disclosure that selection was exploratory and the author froze the protocol without pristine confirmation.

Both Q and ζ use separate ReLU networks, `d→10→10→32`, with d=5/6 as the sole model-input change. Copy the complete frozen trainer config:

- Signed loss (`none` alias only after equivalence assertion), k=10, lr_Q=.001, ρ=1, batch setting 1024, **50,000 Q updates**, no terminal ζ polish.
- `B_eff=min(1024,ceil(N_train/8))` = 100,500,1024,1024; ten fresh ζ batches per cycle, final ζ batch shared with CE, separate anchor batch.
- AdamW betas (.9,.999), eps 1e−8, weight decay 1e−4, c_BE=1, anchor-derived output bias, Xavier-normal/zero hidden biases, gradient-value clipping 1, learning-rate decay `lr0/(1+t/10000)`.
- Disjoint Q/ζ parameters and optimizers; signed anchor gradients through both current and successor Q. Preserve the existing loss, normalization, batch construction and update order.
- Validate every 500 updates; eligibility starts at 5,000. Select finite predictions with observed validation-anchor reward RMSE A≤.10, minimum validation NLL with .001 tie band, lower A, earlier step, then hash. Run all 50k updates; prefixes are diagnostics.

No eligible checkpoint: retain minimum `NLL+A²` for diagnosis only, and flag failed; missing validation anchors is unassessable/failed. Do not relax the frozen selector for omit. Report failures as sensitivity of the full frozen procedure, rather than interpreting successful fits alone as robust.

There is **no S2 KL≤.02 launch gate**. Use deterministic trainer/serialization/gradient controls and non-reporting synthetic smoke tests for implementation acceptance; neither development truth nor protected results may choose hyperparameters or determine whether later protected slots run. The inherited S1 gates remain unchanged.

## 5. Endpoints and inference

Freeze/hash endpoint code and manifests before any S2 estimator is fit or scored. Reference construction and truth-side pilot diagnostics necessarily precede this; do not claim truth has never been opened.

For learned raw reward `rhat=Qhat−βζhat`, define M on a panel as equal-weight RMSE across states and actions 1…31. For obs on E2–E4, compute **one RMSE after averaging squared errors over both regimes**, not the average of two RMSEs. The analytic target r is z-free and has no Q-reference floor.

**Co-primary at N100k on shared E2:**

```
R_between = exp(mean_i log M_omit,i − mean_j log M_S1,j)
R_info    = exp(mean_i [log M_omit,i − log M_obs,i]).
```

Report both arms' absolute RMSEs, arithmetic differences, ratios, 95% intervals and success counts. `R_between` combines the changed DGP/information structure; `R_info` measures the effect of providing z under the fixed training procedure on identical data, including the necessary first-layer input change. It is not an exact causal decomposition of all approximation/optimization error.

Use 2,000 block bootstrap resamples with a frozen seed: independently resample S1 and S2 blocks for `R_between`, jointly resample omit/obs for `R_info`, and preserve all N within a block. Intervals are conditional on the fixed evaluation panels and are pointwise, not a familywise guarantee. E1 NLL uncertainty separately clusters whole chains.

Report all N and E1/E3/E4 as secondary. For each arm compute `Δ=mean_i[log M_i,100k−log M_i,20k]` and directly bootstrap `Δ_omit−Δ_S1` (independent blocks) and `Δ_omit−Δ_obs` (paired blocks). A positive difference indicates less finite-N improvement, not proof of a misspecification bias floor.

No 1.25 margin or binary “robust” verdict. An interval entirely above 1 resolves worse reward recovery for that contrast; containing 1 is unresolved, not equivalence. A zero RMSE makes its log contrast undefined; report raw errors/differences without an invented floor.

**Policy and information diagnostics on S2 E1.** Let `b_t(z)=Pr(z_t=z | x_0:t,a_0:t−1)` and `g_z(x'|x,a)` be the exact half-law successor likelihood, including point masses:

```
b_0 = (.5,.5)
π_hist(a|h_t) = Σ_z b_t(z) π_ref(a|x_t,z)
w_t(z) ∝ b_t(z) π_ref(a_t|x_t,z) g_z(x_{t+1}|x_t,a_t)
b_{t+1}(z') = Σ_z w_t(z) P[z,z'].
```

Use log arithmetic and normalized weights. Reset coordinates contribute likelihood 1 at zero; uncapped kept coordinates use the half-law density; capped coordinates use the half-law survival mass (1 at x=1). Include action likelihood: replacing all buses makes successor mileages uninformative, but the action can still convey regime information. An impossible all-zero likelihood is an implementation/data error, not permission to insert a smoothing floor. At λ=1, an uncapped kept increment identifies the **previous** regime almost surely; it does not reveal the next regime before its random transition.

Report NLL for `π_ref(.|x,z)`, `π_hist`, omit and obs. The information gap is **NLL(history)−NLL(observed-regime oracle)**, not the reverse; its population expectation is nonnegative, though the sample difference can be negative. Also report `mean KL(π_ref(.|x,z)||π_hist)` as a nonnegative, full-policy diagnostic. The history predictor is optimal for its richer observed history under the known DGP; it is **not** the optimal mileage-only predictor or an estimated competitor. Omit NLL minus history NLL combines memory omission, approximation and fitting error.

Required secondary diagnostics: reward anchor/all-action/per-action RMSE, policy-weighted reward error; joint KL/TV, top-1, marginal and replacement-count calibration; observed/unobserved action counts; replacement-count/mileage/cap/tail bins; inherited singleton incentive and reward-interaction diagnostics. True reward interactions remain zero. Empty bins are NA.

For obs, score Q and anchor-relative advantages against the certified augmented truth, with allowances `epsilon_Q` and `2 epsilon_Q` reported separately, never subtracted. For omit, report the same comparison on realized E1 `(x,z)` only as **augmented-truth mismatch**, not recovery of a true mileage-only Markov Q. Report obs reward z-invariance error and true regime-specific policy gaps; no guaranteed monotonic shrinkage with N. Do not fit a history model, a filter-mixed Q target, new class or four-step comparator in S2.

## 6. Failure accounting, integration and queue

Release order: author-confirmed design → constant/protocol provenance → simulator/reference validation → strict pilot → immutable datasets/manifests/endpoints → trainer/isolation/replay checks → queue admission → all 80 fits → reporting. Reference, pilot or implementation failure holds downstream work with explicit slot statuses; estimator performance does not stop subsequent protected slots.

Keep every scheduled slot in denominators. Record nonfinite/divergence, missing anchor, no eligible checkpoint, process failure, hash mismatch, reference/pilot hold and interruption separately. Infrastructure restart may reproduce the identical slot/seed/config or resume complete state, with all attempts retained; no seed substitution or rescue hyperparameters.

Each co-primary contrast requires all its declared ten-member groups/pairs. If any required fit fails, its full-sample contrast is unavailable; show complete-case results only as secondary with count and both arms' failure rates out of ten. Do not use an 8/10 substitute, imputed RMSE, or the tuning penalty log(10) as a measured error.

Build in an isolated worktree, package `experiments/fleet_commonshock/`, pinned to the actual frozen implementation. Reuse the locked trainer through a dimension-aware adapter, default dimension 5. Do not modify active hashed sources, manifests, controllers or locks. Shared edits require the inherited three old/new P0 default-path bitwise comparisons plus replay of one completed frozen fleet 2×10 record, including loss traces and Q/ζ arrays. Timestamp-bearing serialization bytes are not the comparison target. Never rewrite historical hashes to hide code changes.

Append behind **all already registered frozen stages and follow-ups**, verifying live controllers, accounting and reservations; a saved pipeline snapshot or missing DONE is insufficient. A predecessor must be terminal or explicitly held with reservations released. If S1 headline admission fails, preserve that failure and leave `R_between` unavailable; the independently accepted S2 omit/obs comparison can proceed after queue release. This grants no waiver to S1, the coupled extension or their existing controllers.

Use one atomic project-wide ledger for original bus, fleet, reference, simulation, validation and controllers: ≤44 actual compute threads total; retain the existing ≤36 fit workers and two controller/evaluation tokens, reducing admissions for other work. Torch intra/inter-op, BLAS/OpenMP/MKL/OpenBLAS/NumExpr are one per fit, with no data-loader workers. Evaluators/reference jobs reserve their actual threads; CPU-load throttling supplements the ledger.

There are **4 million Q updates and 40 million ζ updates**, excluding replay tests. The planner's 1,435–1,783 seconds per one-thread 2×10 fit suggests roughly 32–40 fit CPU-hours for 80 fits, before six-input overhead and non-fit work; this is a forecast, not a live measurement. Time the new reference/validation, simulation, evaluation and first already-counted protected fits, then update only scheduling estimates. At 36 workers, 80 fits need at least three waves. No performance-driven truncation, smaller seed count or extra shock-strength sweep; unrun slots stay explicit.

Builder deliverables:

- `configs/dgp_s2_commonshock.json`, isolated simulator/half-law kernels/two-regime oracle/filter, implementation tests and full provenance hashes.
- Reference manifest/certificate/check arrays, strict pilot/burn-in report, paired omit/obs export manifests and common-panel hashes.
- Sealed 40-slot manifests for each information set, unchanged trainer config plus declared input dimension, endpoint code hash and queue prerequisites.
- Per-slot records/checkpoints/attempts, complete accounting, primary/secondary tables with failures, policy-information and strength diagnostics, timing/resource report and `protocol_changes.md`.
- `RUN_REPORT.md` stating the approved information change, actual numerical certificates and outcomes, mild measured stress, exploratory protocol selection, and the distinction from the separate capacity-by-N misspecification study.

This convergence writes a build contract only; it neither records author confirmation nor claims implementation, validation or jobs have run.
