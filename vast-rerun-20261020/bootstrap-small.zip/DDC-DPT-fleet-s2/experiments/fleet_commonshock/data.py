"""S2 pilot and paired, truth-stripped protected data exports."""
import hashlib
import itertools
import json
import time
from pathlib import Path
import numpy as np
from scipy.stats import ks_2samp
from .core import simulate, P, all_reward
from .reference import load, sha, write
from experiments.fleet_r1literal.params import ACTIONS,U,V

ROOT=Path(__file__).resolve().parent
S1=Path('/home/ehwkang/DDC-DPT-fleet-r1literal/experiments/fleet_r1literal')
ART=ROOT/'artifacts'
REF=ART/'reference'
NS='r1literal_s2_v1'
H=100

def seed(stage,data_id,stream,init=0):
    s=f'20261018|{NS}|{stage}|{data_id}|{init}|{stream}'
    return int.from_bytes(hashlib.sha256(s.encode()).digest()[:8],'big')%(2**63-1)

def streams(stage,data_id):
    names=(['starts','initial_regime','regime_transition']+
           [f'action_bus_{f}' for f in range(5)]+[f'increment_bus_{f}' for f in range(5)])
    seeds={name:seed(stage,data_id,name) for name in names}
    rng=lambda name: np.random.default_rng(seeds[name])
    return (rng('starts'),rng('initial_regime'),rng('regime_transition'),
            [rng(f'action_bus_{f}') for f in range(5)],
            [rng(f'increment_bus_{f}') for f in range(5)]),seeds

def split(data_id):
    rng=np.random.default_rng(seed('protected',data_id,'permanent_split'))
    p=rng.permutation(1000);tr=p[:800];va=p[800:]
    order=np.empty(1000,dtype=np.int32)
    for j in range(200):
        order[5*j:5*j+4]=tr[4*j:4*j+4];order[5*j+4]=va[j]
    return order,np.tile([False,False,False,False,True],200)

def pilot_report(ch,burn,ks):
    s=ch['s'];a=ch['a'];z=ch['z'];bits=ACTIONS[a];n=a.size
    shares=np.bincount(a.ravel(),minlength=32)/n
    replace=bits.mean(axis=(0,1))
    spans=np.quantile(s,.95,axis=(0,1))-np.quantile(s,.05,axis=(0,1))
    singleton=shares[[1<<f for f in range(5)]]
    pass_lc=bool(.25<=shares[0]<=.95 and np.all((replace>=.03)&(replace<=.30))
                 and np.all(singleton>=.01) and np.all(spans>=.25))
    reg_repl=np.stack([bits[z==zz].mean(axis=0) for zz in (0,1)])
    chain_se=np.std(bits.mean(axis=1),axis=0,ddof=1)/np.sqrt(len(a))
    return dict(status='accepted' if pass_lc else 'failed_strict_LC',burn=burn,
                ks_early_late=ks,chains=len(a),rows=n,
                action_shares=shares.tolist(),anchor_share=float(shares[0]),
                singleton_shares=singleton.tolist(),replacement_shares=replace.tolist(),
                regime_replacement_shares=reg_repl.tolist(),
                regime_replacement_gaps=(reg_repl[1]-reg_repl[0]).tolist(),
                replacement_chain_se=chain_se.tolist(),spans_95_05=spans.tolist(),
                cap_mass=np.mean(s==1,axis=(0,1)).tolist(),tail_gt_07=np.mean(s>.7,axis=(0,1)).tolist(),
                pooled_correlation=np.corrcoef(s.reshape(-1,5).T).tolist(),
                fixed_t50_correlation=np.corrcoef(s[:,50,:].T).tolist(),
                by_replacement_count=np.bincount(bits.sum(2).ravel(),minlength=6).tolist(),
                regime_share=float(z.mean()),
                checks=dict(anchor=[.25,.95],replace=[.03,.30],singleton_min=.01,span_min=.25))

def pilot():
    t0=time.perf_counter();out=ART/'pilot';out.mkdir(parents=True,exist_ok=True)
    ref=load(REF)
    ch=simulate(10000,H,ref,streams('pilot_zero',0)[0])
    ks=[float(ks_2samp(ch['s'][:,:20,f].ravel(),ch['s'][:,50:,f].ravel(),method='asymp').statistic)
        for f in range(5)]
    write(out/'zero.json',pilot_report(ch,0,ks))
    burn=50 if max(ks)>.1 else 0
    if burn:
        del ch
        ch=simulate(10000,H,ref,streams('pilot_burn50',0)[0],burn=50)
    report=pilot_report(ch,burn,ks)
    report['wall_s']=time.perf_counter()-t0
    write(out/'acceptance.json',report)
    print(json.dumps(dict(status=report['status'],burn=burn,ks=ks,anchor=report['anchor_share'],
                          replacement=report['replacement_shares'],singleton=report['singleton_shares'],
                          spans=report['spans_95_05'],wall_s=report['wall_s'])),flush=True)
    return report

def export(data_id,ref,burn,ref_sha):
    out=ART/'data';out.mkdir(parents=True,exist_ok=True)
    ch=simulate(1000,H,ref,streams('protected',data_id)[0],burn=burn)
    order,mask=split(data_id)
    ids=np.array([f's2_{data_id}_chain{int(i):04d}' for i in order])
    meta=dict(a=ch['a'][order],r0=ch['r0'][order],is_val=mask,chain_id=ids,
              stream_id=np.array([f'{NS}:protected:{data_id}']*1000),
              n_actions=32,anchor_action=0,namespace=NS,reference_sha256=ref_sha)
    records={}
    for arm in ('omit','obs'):
        s=ch['s'][order];sp=ch['sp'][order]
        if arm=='obs':
            s=np.concatenate([s,ch['z'][order,...,None]],axis=-1)
            sp=np.concatenate([sp,ch['zp'][order,...,None]],axis=-1)
        path=out/f'{arm}_{data_id}.npz'
        if path.exists(): raise RuntimeError(f'refusing overwrite {path}')
        np.savez_compressed(path,s=s,sp=sp,arm=arm,**meta)
        records[arm]=dict(path=str(path.relative_to(ROOT)),sha256=sha(path),bytes=path.stat().st_size,
                          shape=list(s.shape))
        path.chmod(0o444)
    return dict(data_id=data_id,seeds=streams('protected',data_id)[1],
                split_seed=seed('protected',data_id,'permanent_split'),
                n_train=800,n_val=200,prefixes={str(n):dict(train=n*4//500,val=n//500)
                                                 for n in (1000,5000,20000,100000)},
                exports=records)

def panels(ref,burn,ref_sha):
    out=ART/'eval';out.mkdir(parents=True,exist_ok=True)
    ch=simulate(200,H,ref,streams('evaluation',9999)[0],burn=burn,history=burn>0)
    e1=out/'E1_labels.npz'
    keep={k:ch[k] for k in ('s','sp','z','zp','a')}
    if burn: keep['burn_s']=np.stack([h[0] for h in ch['burn_history']],axis=1)
    if burn: keep['burn_sp']=np.stack([h[1] for h in ch['burn_history']],axis=1)
    if burn: keep['burn_a']=np.stack([h[2] for h in ch['burn_history']],axis=1)
    np.savez_compressed(e1,**keep)
    result={'E1':dict(labels=str(e1.relative_to(ROOT)),labels_sha256=sha(e1),
                      seeds=streams('evaluation',9999)[1],n_states=20000)}
    for name in ('E1','E2','E3','E4'):
        if name=='E1': states=ch['s'].reshape(-1,5);z=ch['z'].ravel()
        else:
            src=S1/'artifacts/eval'/f'{name}_truth.npz'
            data=np.load(src,allow_pickle=False);states=data['states']
            z=np.repeat(np.arange(2),len(states));states=np.tile(states,(2,1))
            result[name]=dict(source_sha256=sha(src),source_state_sha256=hashlib.sha256(data['states'].tobytes()).hexdigest(),
                              n_states=len(data['states']))
        q,v,pi=ref.joint_query(states,z)
        r=all_reward(states)
        target=out/f'{name}_truth.npz'
        np.savez_compressed(target,states=states,z=z,Q=q,V=v,pi=pi,reward=r,
                            reference_sha256=ref_sha)
        result[name].update(truth=str(target.relative_to(ROOT)),truth_sha256=sha(target))
    return result

def build():
    t0=time.perf_counter();accept=json.loads((ART/'pilot/acceptance.json').read_text())
    refman=json.loads((REF/'reference_manifest.json').read_text())
    if accept['status']!='accepted' or refman['status']!='certified': raise RuntimeError('reference/pilot hold')
    ref=load(REF);refsha=sha(REF/'reference_manifest.json')
    pools=[export(i,ref,accept['burn'],refsha) for i in range(1000,1010)]
    evalpanels=panels(ref,accept['burn'],refsha)
    manifest=dict(status='frozen',namespace=NS,reference_sha256=refsha,
                  reference_status=refman['status'],pilot_sha256=sha(ART/'pilot/acceptance.json'),
                  pools=pools,panels=evalpanels,total_physical_rows=1000000,
                  wall_s=time.perf_counter()-t0)
    write(ART/'data/freeze_manifest.json',manifest)
    print(json.dumps(dict(status='frozen',pools=len(pools),physical_rows=1000000,
                          wall_s=manifest['wall_s'])),flush=True)
    return manifest
