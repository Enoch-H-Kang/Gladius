"""Pre-registered S2 endpoints; this file is hashed before any protected fit starts."""
import json
import math
from pathlib import Path
import numpy as np
import torch
from scipy.special import logsumexp
from experiments.fleet_capacity_one.fleet.models import MLP
from experiments.fleet_r1literal.params import ACTIONS
from .core import P, B, half_survival
from .reference import load, write, sha
from experiments.fleet_r1literal.texp import RHO,L,Z

ROOT=Path(__file__).resolve().parent
S1=Path('/home/ehwkang/DDC-DPT-fleet-r1literal/experiments/fleet_r1literal')
EVAL=ROOT/'artifacts/eval'
NVALS=(1000,5000,20000,100000)
SEED=202610198761
BOOT=2000

def load_checkpoint(path,d):
    ck=torch.load(path,map_location='cpu',weights_only=False)
    q=MLP(d,32,10,2);z=MLP(d,32,10,2)
    q.load_state_dict(ck['q']);z.load_state_dict(ck['z'])
    q.eval();z.eval()
    return q,z,ck

@torch.no_grad()
def predict(models,s,batch=2048):
    q,z=models[:2]
    Q=[];Z=[]
    for i in range(0,len(s),batch):
        x=torch.as_tensor(s[i:i+batch].astype(np.float32))
        Q.append(q(x).numpy().astype(np.float64))
        Z.append(z(x).numpy().astype(np.float64))
    return np.concatenate(Q),np.concatenate(Z)

def rmse(err): return float(np.sqrt(np.mean(np.square(err))))

def eval_fit(path,d,arm,truths):
    models=load_checkpoint(path,d)
    out=dict(checkpoint_sha256=sha(path),checkpoint_step=models[2]['step'],panels={})
    for name,t in truths.items():
        states=t['states'];z=t['z']
        inp=states if d==5 else np.column_stack([states,z])
        Q,Z=predict(models,inp)
        rhat=Q-.95*Z
        err=rhat-t['reward'];pi=np.exp(Q-logsumexp(Q,axis=1)[:,None])
        truepi=t['pi']
        non=err[:,1:]
        p=dict(M=rmse(non),anchor_rmse=rmse(err[:,0]),all_action_rmse=rmse(err),
               per_action_rmse=np.sqrt(np.mean(err*err,axis=0)).tolist(),
               policy_weighted_reward_rmse=float(np.sqrt(np.mean(np.sum(truepi*err*err,axis=1)))),
               joint_kl=float(np.mean(np.sum(truepi*(np.log(np.maximum(truepi,1e-300))-
                                       np.log(np.maximum(pi,1e-300))),axis=1))),
               joint_tv=float(np.mean(.5*np.sum(np.abs(pi-truepi),axis=1))),
               top1_agreement=float(np.mean(pi.argmax(1)==truepi.argmax(1))),
               marginal_brier=[float(np.mean((pi@ACTIONS[:,f]-truepi@ACTIONS[:,f])**2)) for f in range(5)],
               replacement_count_error=[float(np.mean(pi@(ACTIONS.sum(axis=1)==k).astype(float)-
                                                        truepi@(ACTIONS.sum(axis=1)==k).astype(float))) for k in range(6)])
        single=np.array([1<<f for f in range(5)])
        p['singleton_incentive_rmse']=[rmse((rhat[:,j]-rhat[:,0])-
                                            (t['reward'][:,j]-t['reward'][:,0])) for j in single]
        interaction=rhat-rhat[:,0,None]
        for f,j in enumerate(single): interaction-=ACTIONS[None,:,f]*(rhat[:,j]-rhat[:,0])[:,None]
        p['reward_interaction_rmse']=rmse(interaction)
        if arm=='obs' or name=='E1':
            p['Q_rmse_augmented_truth']=rmse(Q-t['Q'])
            adv=Q-Q[:,0,None];tadv=t['Q']-t['Q'][:,0,None]
            p['advantage_rmse_augmented_truth']=rmse(adv-tadv)
            p['Q_comparison_role']='augmented_truth_recovery' if arm=='obs' else 'augmented_truth_mismatch'
        if name=='E1':
            labels=np.load(EVAL/'E1_labels.npz',allow_pickle=False)['a'].ravel()
            p['NLL']=float(-np.mean(np.log(np.maximum(pi[np.arange(len(pi)),labels],1e-300))))
            chainlog=-np.log(np.maximum(pi[np.arange(len(pi)),labels],1e-300)).reshape(200,100).mean(axis=1)
            p['NLL_chain_se']=float(chainlog.std(ddof=1)/np.sqrt(200))
            p['top1_label_accuracy']=float(np.mean(pi.argmax(1)==labels))
            p['observed_action_counts']=np.bincount(labels,minlength=32).tolist()
            p['unobserved_actions']=[int(a) for a,c in enumerate(p['observed_action_counts']) if c==0]
            p['obs_reward_z_invariance']=None
            chosen=err[np.arange(len(err)),labels]
            count=ACTIONS[labels].sum(axis=1)
            mileage=states.mean(axis=1)
            masks={'replacement_count_'+str(k):count==k for k in range(6)}
            masks.update({'mileage_low':mileage<.25,'mileage_mid':(mileage>=.25)&(mileage<.5),
                          'mileage_high':mileage>=.5,'any_cap':np.any(states==1.,axis=1),
                          'any_tail_gt_07':np.any(states>.7,axis=1)})
            p['chosen_action_reward_bins']={key:dict(count=int(mask.sum()),
                rmse=rmse(chosen[mask]) if mask.any() else None) for key,mask in masks.items()}
        out['panels'][name]=p
    if arm=='obs':
        t=truths['E2'];n=len(t['states'])//2
        x=t['states'][:n]
        Q0,Z0=predict(models,np.column_stack([x,np.zeros(n)]))
        Q1,Z1=predict(models,np.column_stack([x,np.ones(n)]))
        out['reward_z_invariance_rmse']=rmse((Q1-.95*Z1)-(Q0-.95*Z0))
    return out

def successor_loglike(x,xp,a,z):
    bits=ACTIONS[int(a)];val=0.
    for f in range(5):
        if bits[f]:
            if xp[f]!=0.: return -np.inf
            continue
        if x[f]>=1.:
            if xp[f]!=1.: return -np.inf
            continue
        if xp[f]>=1.:
            prob=float(half_survival(1.-x[f],f,z))
            if prob<=0.: return -np.inf
            val+=math.log(prob)
            continue
        d=xp[f]-x[f]
        lo=0. if z==0 else B[f];hi=B[f] if z==0 else L[f]
        if not (d>=lo-1e-12 and d<=hi+1e-12): return -np.inf
        val+=math.log(2*RHO[f]/Z[f])-RHO[f]*d
    return val

def filtered_oracle(ref,labels):
    s=labels['s'];sp=labels['sp'];a=labels['a'];ztrue=labels['z']
    burn=labels['burn_s'].shape[1] if 'burn_s' in labels else 0
    N=s.shape[0];b=np.full((N,2),.5)
    nll_hist=[];nll_obs=[];kl=[];b0=[]
    def step(xs,xps,acts,truth=None,score=False):
        nonlocal b
        pis=[ref.joint_query(xs,np.full(N,zz))[2] for zz in (0,1)]
        mix=b[:,0,None]*pis[0]+b[:,1,None]*pis[1]
        if score:
            idx=np.arange(N)
            nll_hist.append(-np.log(mix[idx,acts]))
            nll_obs.append(-np.log(np.where(truth[:,None]==0,pis[0],pis[1])[idx,acts]))
            truepi=np.where(truth[:,None]==0,pis[0],pis[1])
            kl.append(np.sum(truepi*(np.log(truepi)-np.log(mix)),axis=1))
            b0.append(b[:,0].copy())
        logw=np.log(b)+np.stack([np.log(pis[zz][np.arange(N),acts]) for zz in (0,1)],axis=1)
        for i in range(N):
            for zz in (0,1): logw[i,zz]+=successor_loglike(xs[i],xps[i],acts[i],zz)
        norm=logsumexp(logw,axis=1)
        if not np.isfinite(norm).all(): raise RuntimeError('impossible filter likelihood')
        w=np.exp(logw-norm[:,None])
        b=w@P
    for t in range(burn): step(labels['burn_s'][:,t],labels['burn_sp'][:,t],labels['burn_a'][:,t])
    for t in range(s.shape[1]): step(s[:,t],sp[:,t],a[:,t],ztrue[:,t],True)
    nh=np.stack(nll_hist,axis=1);no=np.stack(nll_obs,axis=1);kl=np.stack(kl,axis=1)
    return dict(oracle_observed_nll=float(no.mean()),history_nll=float(nh.mean()),
                information_gap=float(nh.mean()-no.mean()),full_policy_kl=float(kl.mean()),
                history_nll_chain_se=float(nh.mean(axis=1).std(ddof=1)/np.sqrt(N)),
                observed_nll_chain_se=float(no.mean(axis=1).std(ddof=1)/np.sqrt(N)),
                mean_filtered_pz0=float(np.mean(b0)))

def contrast(a,b,paired,rng):
    if len(a)!=10 or len(b)!=10 or not np.isfinite(a).all() or not np.isfinite(b).all() or np.any(a<=0) or np.any(b<=0):
        return dict(status='unavailable_full_denominator',count_a=len(a),count_b=len(b))
    la=np.log(a);lb=np.log(b)
    idxa=rng.integers(0,10,(BOOT,10))
    idxb=idxa if paired else rng.integers(0,10,(BOOT,10))
    lr=la[idxa].mean(axis=1)-lb[idxb].mean(axis=1)
    dif=a[idxa].mean(axis=1)-b[idxb].mean(axis=1)
    return dict(status='available',mean_a=float(a.mean()),mean_b=float(b.mean()),
                arithmetic_difference=float(a.mean()-b.mean()),
                arithmetic_difference_ci95=np.quantile(dif,[.025,.975]).tolist(),
                ratio=float(np.exp(la.mean()-lb.mean())),
                ratio_ci95=np.exp(np.quantile(lr,[.025,.975])).tolist(),paired=paired,
                bootstrap_resamples=BOOT)

def slope_diffs(values,arm_a,arm_b,paired,rng):
    a20=values[arm_a][20000];a100=values[arm_a][100000]
    b20=values[arm_b][20000];b100=values[arm_b][100000]
    if any(len(x)!=10 or np.any(x<=0) or not np.isfinite(x).all()
           for x in (a20,a100,b20,b100)):
        return dict(status='unavailable_full_denominator')
    da=np.log(a100)-np.log(a20);db=np.log(b100)-np.log(b20)
    ia=rng.integers(0,10,(BOOT,10));ib=ia if paired else rng.integers(0,10,(BOOT,10))
    boot=da[ia].mean(axis=1)-db[ib].mean(axis=1)
    return dict(status='available',delta_a=float(da.mean()),delta_b=float(db.mean()),
                difference=float(da.mean()-db.mean()),ci95=np.quantile(boot,[.025,.975]).tolist(),
                paired=paired,bootstrap_resamples=BOOT)

def run():
    torch.set_num_threads(1)
    truths={n:dict(np.load(EVAL/f'{n}_truth.npz',allow_pickle=False)) for n in ('E1','E2','E3','E4')}
    ref=load(ROOT/'artifacts/reference')
    labels=dict(np.load(EVAL/'E1_labels.npz',allow_pickle=False))
    info=filtered_oracle(ref,labels)
    man=json.loads((ROOT/'results/manifest_S2.json').read_text())
    rows=[]
    for spec in man['fits']:
        fid=spec['fit_id'];recpath=ROOT/'artifacts/fits'/fid/'record.json'
        if not recpath.exists(): rows.append(dict(fit_id=fid,status='missing'));continue
        rec=json.loads(recpath.read_text())
        horizon=rec.get('horizons',{}).get('50000',{})
        if rec.get('fit_status')!='complete' or horizon.get('status')!='ok':
            rows.append(dict(fit_id=fid,arm=spec['arm'],data_id=spec['data_id'],N=spec['config']['N'],
                             status=horizon.get('status',rec.get('fit_status'))));continue
        ck=ROOT/'artifacts/fits'/fid/'ckpt_h50000.pt'
        metrics=eval_fit(ck,spec['input_dim'],spec['arm'],truths)
        rows.append(dict(fit_id=fid,arm=spec['arm'],data_id=spec['data_id'],N=spec['config']['N'],
                         status='ok',metrics=metrics))
    s1rows=[]
    for di in range(1000,1010):
        for n in NVALS:
            fid=f'H_frozen_{di}_{n}'
            p=S1/'artifacts/headline_frozen/fits'/fid/'record.json'
            if not p.exists(): s1rows.append(dict(fit_id=fid,data_id=di,N=n,status='missing'));continue
            rec=json.loads(p.read_text());hr=rec.get('horizons',{}).get('50000',{})
            if rec.get('fit_status')!='complete' or hr.get('status')!='ok':
                s1rows.append(dict(fit_id=fid,data_id=di,N=n,status=hr.get('status',rec.get('fit_status'))));continue
            ck=p.parent/'ckpt_h50000.pt'
            # S1 truth for policy metrics differs; shared E2 reward target is identical.
            model=load_checkpoint(ck,5)
            ms={}
            for name,t in truths.items():
                states=t['states'] if name=='E1' else t['states'][:len(t['states'])//2]
                reward=t['reward'] if name=='E1' else t['reward'][:len(states)]
                Q,Z=predict(model,states)
                ms['M_'+name]=rmse(((Q-.95*Z)-reward)[:,1:])
            s1rows.append(dict(fit_id=fid,data_id=di,N=n,status='ok',
                               checkpoint_sha256=sha(ck),**ms))
    def arr(arm,n):
        source=s1rows if arm=='S1' else rows
        vals=[]
        for di in range(1000,1010):
            r=next((x for x in source if x.get('data_id')==di and x.get('N')==n and
                    (arm=='S1' or x.get('arm')==arm)),None)
            if r and r['status']=='ok': vals.append(r['M_E2'] if arm=='S1' else r['metrics']['panels']['E2']['M'])
        return np.array(vals)
    rng=np.random.default_rng(SEED)
    primary=dict(R_between=contrast(arr('omit',100000),arr('S1',100000),False,rng),
                 R_info=contrast(arr('omit',100000),arr('obs',100000),True,rng))
    values={arm:{n:arr(arm,n) for n in NVALS} for arm in ('S1','omit','obs')}
    slopes=dict(omit_minus_S1=slope_diffs(values,'omit','S1',False,rng),
                omit_minus_obs=slope_diffs(values,'omit','obs',True,rng))
    byN={str(n):{arm:dict(successes=len(arr(arm,n)),failures=10-len(arr(arm,n)),
                               mean_M=float(arr(arm,n).mean()) if len(arr(arm,n)) else None)
                  for arm in ('S1','omit','obs')} for n in NVALS}
    t=truths['E2'];n=len(t['states'])//2
    policy_gap=float(np.max(np.abs(t['pi'][:n]-t['pi'][n:])))
    adv=t['Q']-t['Q'][:,0,None]
    advantage_gap=float(np.max(np.abs(adv[:n]-adv[n:])))
    xlo=np.full((1,5),.1);xhi=np.full((1,5),.9)
    post=[]
    for x in (xlo,xhi):
        a=np.array([ref.joint_query(x,zz)[2][0,31] for zz in (0,1)])
        w=a/a.sum();post.append(float((w@P)[1]))
    witness=dict(same_current_mileage=[0.]*5,history_action=31,
                 prior_state_levels=[.1,.9],filtered_next_regime_one=post,
                 absolute_probability_gap=abs(post[1]-post[0]))
    out=dict(endpoint_code_sha256=sha(__file__),manifest_sha256=sha(ROOT/'results/manifest_S2.json'),
             reference_Q_allowance=json.loads((ROOT/'artifacts/reference/reference_manifest.json').read_text())['joint_Q_bound'],
             advantage_allowance=2*json.loads((ROOT/'artifacts/reference/reference_manifest.json').read_text())['joint_Q_bound'],
             primary=primary,byN=byN,slopes=slopes,information=info,
             true_policy_regime_max_gap=policy_gap,
             true_advantage_regime_max_gap=advantage_gap,misspecification_witness=witness,
             rows=rows,S1_rows=s1rows,
             failure_rule='Any missing or failed required member makes the full ten-member contrast unavailable.')
    write(ROOT/'results/endpoints.json',out)
    (ROOT/'artifacts/logs/ENDPOINTS.DONE').write_text('complete\n')
    return out

if __name__=='__main__':
    x=run();print(json.dumps(x['primary']),flush=True)
