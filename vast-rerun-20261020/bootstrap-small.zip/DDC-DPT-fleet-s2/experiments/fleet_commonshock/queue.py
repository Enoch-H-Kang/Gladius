"""Seal 80 protected slots and append them after every registered frozen follow-up."""
import csv
import fcntl
import hashlib
import json
import math
import os
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path
from .fit import sha,write

ROOT=Path(__file__).resolve().parent
S1=Path('/home/ehwkang/DDC-DPT-fleet-r1literal/experiments/fleet_r1literal')
FROZEN=ROOT.parent/'fleet_r1literal'
SHARED=ROOT.parent/'fleet_capacity_one/fleet'
RESULT=ROOT/'results'
LOG=ROOT/'artifacts/logs'
FREEZE=FROZEN/'protocol/common_protocol_freeze.json'
FREEZE_SHA='dcba37006a1ef6747671f03fc4e9a88f388ad2f4261086c45a32656788d7afba'
LOCK_EMBED='3a7749e7354fd1472320f76b2d2b62259847eed682dea6379ecff7f02129619b'
STAGES=(('FL_followup',108),('M1_followup',200),('EL_followup',54),('EX_followup',45))
STREAMS=('qinit','zinit','ce','extrazeta','anchor','eval')
CAP=36

def seed(stage,data_id,stream,init=0):
    s=f'20261018|r1literal_s2_v1|{stage}|{data_id}|{init}|{stream}'
    return int.from_bytes(hashlib.sha256(s.encode()).digest()[:8],'big')%(2**63-1)

def code_hash():
    paths=[ROOT/'fit.py',FROZEN/'models.py',SHARED/'train.py',
           SHARED/'losses.py',SHARED/'select.py',SHARED/'models.py']
    for p in paths[1:]:
        active=S1.parent/p.relative_to(ROOT.parent)
        if sha(p)!=sha(active): raise RuntimeError(f'frozen source changed: {p}')
    return hashlib.sha256(''.join(sha(p) for p in paths).encode()).hexdigest()

def frozen():
    if sha(FREEZE)!=FREEZE_SHA: raise RuntimeError('common freeze hash mismatch')
    obj=json.loads(FREEZE.read_text())
    if obj['bus_lock_embedded_sha256']!=LOCK_EMBED: raise RuntimeError('originating lock mismatch')
    d=obj['design']
    assert d==dict(architecture='mlp2x10',batch=1024,bias='anchor',c_be=1.,
                   horizon=50000,k=10,loss='signed',lr_q=.001,optimizer='adamw',rho=1.)
    return obj

def config(n):
    return dict(N=n,anchor_tol=.1,architecture='mlp2x10',batch=1024,beta=.95,
                bias='anchor',c_be=1.,cap_q=50000,depth=2,elig_start=5000,
                grad_clip=1.,k=10,loss='signed',lr_decay=10000.,lr_q=.001,
                opt='adamw',rho=1.,val_every=500,wd=.0001,width=10)

def seal():
    frozen()
    datafile=ROOT/'artifacts/data/freeze_manifest.json'
    data=json.loads(datafile.read_text())
    assert data['status']=='frozen' and len(data['pools'])==10
    endpoint=ROOT/'endpoints.py'
    if not endpoint.exists(): raise RuntimeError('endpoint code must be frozen before fits')
    fits=[]
    for pool in data['pools']:
        di=pool['data_id']
        for n in (1000,5000,20000,100000):
            for arm in ('omit','obs'):
                p=pool['exports'][arm]
                path=ROOT/p['path']
                if sha(path)!=p['sha256']: raise RuntimeError('export hash mismatch')
                fits.append(dict(fit_id=f'S2_{arm}_{di}_{n}',arm=arm,data_id=di,
                                 config=config(n),n_chains=n//100,pool=p['path'],
                                 pool_sha256=p['sha256'],input_dim=5 if arm=='omit' else 6,
                                 seeds={s:seed('fit',di,s) for s in STREAMS}))
    assert len(fits)==80 and len({s['fit_id'] for s in fits})==80
    m=dict(stage='S2',n_fits=80,omit=40,obs=40,freeze_sha256=FREEZE_SHA,
           lock_embedded_sha256=LOCK_EMBED,data_manifest_sha256=sha(datafile),
           endpoint_sha256=sha(endpoint),frozen_code_sha256=code_hash(),
           fits=fits,queue_predecessors=[s for s,_ in STAGES],
           statement='No S2 performance gate; all 80 slots retain denominators.')
    mpath=RESULT/'manifest_S2.json'
    if mpath.exists():
        if json.loads(mpath.read_text())!=m: raise RuntimeError('sealed manifest changed')
    else: write(mpath,m)
    registration=RESULT/'queue_registration.json'
    if registration.exists():
        if json.loads(registration.read_text())['manifest_sha256']!=sha(mpath):
            raise RuntimeError('queue registration manifest changed')
    else:
        write(registration,dict(status='registered_waiting_predecessors',
              manifest_sha256=sha(mpath),n_fits=80,omit=40,obs=40,
              trigger_order=['F1','F2','F3','D','D_ref','H']+[s for s,_ in STAGES]+['S2'],
              registered_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())))
    return m

def predecessors():
    stfile=S1/'results/frozen_followups/status.json'
    if not stfile.exists(): return False,'waiting_followup_controller'
    status=json.loads(stfile.read_text())
    state=status.get('state','')
    if state=='complete':
        for stage,count in STAGES:
            done=S1/'artifacts/logs'/f'{stage}.DONE'
            acct=S1/'results/frozen_followups'/f'accounting_{stage}.json'
            if not done.exists() or not acct.exists(): return False,f'waiting_{stage}'
            a=json.loads(acct.read_text())
            if a['scheduled']!=count or a['records']!=count or a['missing']:
                return False,f'incomplete_{stage}'
        return True,'all_followups_terminal'
    if state.startswith('held_'):
        # A hold releases stage reservations. A live fit worker would contradict release.
        for p in Path('/proc').iterdir():
            if not p.name.isdigit(): continue
            try: cmd=(p/'cmdline').read_bytes()
            except OSError: continue
            if (b'experiments.fleet_r1literal.frozen_followups\x00worker' in cmd or
                b'experiments.fleet_r1literal.tuning_run_fit' in cmd or
                b'experiments.fleet_r1literal.frozen_headline_pipeline\x00worker' in cmd):
                return False,'held_but_reservations_active'
        return True,f'predecessors_{state}_released'
    return False,state if state.startswith('waiting_') else f'waiting_{state}'

def budget(active):
    from experiments.fleet_r1literal.cpu_budget import busy_cores
    return min(CAP,active+max(0,math.floor(44-2-busy_cores(.5))))

def accounting(m):
    records=[]
    for spec in m['fits']:
        p=ROOT/'artifacts/fits'/spec['fit_id']/'record.json'
        records.append(json.loads(p.read_text()) if p.exists() else None)
    def slot_status(r):
        if r is None: return 'missing'
        if r['fit_status']!='complete':
            if r['fit_status']=='diverged' and any(not x.get('finite',True) for x in r.get('trace',[])):
                return 'nonfinite_validation'
            return r['fit_status']
        h=r.get('horizons',{}).get('50000',{})
        if h.get('status')=='failed' and all(x.get('n_anchor',0)==0 for x in r.get('trace',[])):
            return 'missing_validation_anchor'
        return h.get('status','missing_horizon')
    a=dict(stage='S2',scheduled=80,records=sum(r is not None for r in records),
           missing=[s['fit_id'] for s,r in zip(m['fits'],records) if r is None],
           statuses=dict(Counter(slot_status(r) for r in records)),
           manifest_sha256=sha(RESULT/'manifest_S2.json'),thread_cap=44,
           max_workers=36,reserved_controller_tokens=2,
           completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    write(RESULT/'accounting_S2.json',a)
    if not a['missing']: (LOG/'S2.DONE').write_text(a['completed_utc']+'\n')
    return a

def run():
    m=seal();RESULT.mkdir(parents=True,exist_ok=True);LOG.mkdir(parents=True,exist_ok=True)
    lock=(RESULT/'admission_S2.lock').open('a+')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    while True:
        ready,why=predecessors()
        write(RESULT/'status.json',dict(state='waiting_predecessors' if not ready else 'admitted',
                                       prerequisite=why,updated_unix=time.time(),
                                       scheduled=80,started=0))
        if ready: break
        time.sleep(30)
    pending=[]
    for s in m['fits']:
        p=ROOT/'artifacts/fits'/s['fit_id']/'record.json'
        if not p.exists(): pending.append(s)
        elif json.loads(p.read_text())['manifest_sha256']!=sha(RESULT/'manifest_S2.json'):
            raise RuntimeError('existing record provenance mismatch')
    active={};started=0
    q=(RESULT/'queue_S2.csv').open('a',newline='');writer=csv.writer(q)
    while pending or active:
        for fid,proc in list(active.items()):
            rc=proc.poll()
            if rc is not None:
                writer.writerow([time.time(),fid,'end',rc]);q.flush()
                del active[fid]
        admit=budget(len(active))
        while pending and len(active)<admit:
            s=pending.pop(0);fid=s['fit_id']
            env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',
                     OPENBLAS_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',
                     PYTHONHASHSEED='0',CUDA_VISIBLE_DEVICES='')
            log=(LOG/f'{fid}.log').open('a')
            proc=subprocess.Popen(['nice','-n','10',sys.executable,'-u','-m',
                 'experiments.fleet_commonshock.queue','worker',str(RESULT/'manifest_S2.json'),fid],
                 stdout=log,stderr=subprocess.STDOUT,env=env,cwd=ROOT.parent.parent)
            active[fid]=proc;started+=1
            writer.writerow([time.time(),fid,'start',proc.pid,admit]);q.flush()
        write(RESULT/'status.json',dict(state='running',prerequisite=why,scheduled=80,
               started=started,active=len(active),pending=len(pending),updated_unix=time.time()))
        if pending or active: time.sleep(15)
    a=accounting(m)
    write(RESULT/'status.json',dict(state='fits_terminal' if not a['missing'] else 'held_missing',
          scheduled=80,records=a['records'],statuses=a['statuses'],updated_unix=time.time()))
    if a['missing']: return 2
    from .endpoints import run as run_endpoints
    try:
        run_endpoints()
    except BaseException as exc:
        write(RESULT/'status.json',dict(state='held_endpoint_error',reason=f'{type(exc).__name__}: {exc}',
              scheduled=80,records=a['records'],statuses=a['statuses'],updated_unix=time.time()))
        raise
    write(RESULT/'status.json',dict(state='complete',scheduled=80,records=a['records'],
          statuses=a['statuses'],updated_unix=time.time()))
    return 0

def main():
    if sys.argv[1]=='seal': seal();return
    if sys.argv[1]=='run': sys.exit(run())
    if sys.argv[1]=='worker':
        from .fit import worker
        sys.exit(worker(sys.argv[2],sys.argv[3]))
    raise ValueError(sys.argv)

if __name__=='__main__': main()
