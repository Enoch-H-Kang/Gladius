# S2 persistent-regime run report

Status: **queued; protected fits and outcomes pending**. See `BUILD_STATUS.md` for the verified reference certificate, pilot, protected-data freeze, implementation tests, manifest hash, and live queue position.

The approved information change compares estimates that omit a persistent, manager-observed usage regime with estimates that observe it on the same physical rows. The true reward remains additive and unchanged; the omitted arm violates state sufficiency. The measured pilot replacement-probability gaps across regimes were 7.69–10.07 percentage points. These are DGP diagnostics, not estimator outcomes or a claim of maximal stress. The frozen training protocol was selected exploratorily before S2, and no pristine confirmation claim is made.

After `artifacts/logs/ENDPOINTS.DONE`, use `results/endpoints.json` to report all 80 slot outcomes, full-denominator S2 omit/observed and S1/S2 comparisons, uncertainty, policy-information diagnostics, and limitations. Do not state a reward-recovery verdict before those records exist. The fixed-DGP capacity-by-N study remains a separate response to the editor's approximation-error concern.
