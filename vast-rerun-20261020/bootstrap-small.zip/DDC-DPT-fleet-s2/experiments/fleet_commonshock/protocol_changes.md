# S2 protocol changes

The author confirmed the persistent-regime information change on 2026-10-19. S2 uses the same frozen fleet costs, reward, action encoding, trainer, selector, 50,000 Q updates, and numerical tolerances. Its approved DGP addition is the persistent two-state usage regime specified in `protocol/commonshock-converged.md`; its two fitted information sets receive five mileage coordinates or five mileage coordinates plus the observed regime.

No post-confirmation DGP, strength, data-selection, fit-protocol, or tolerance change was made. The implementation additions are isolated under `experiments/fleet_commonshock/`. The queue records attempts separately and classifies missing-anchor, no-eligible-checkpoint, divergence, and process failures without removing slots. The resource-ledger limitation is documented in `BUILD_STATUS.md`.
