"""S2 persistent common usage regime, isolated from the frozen fleet pipeline."""
