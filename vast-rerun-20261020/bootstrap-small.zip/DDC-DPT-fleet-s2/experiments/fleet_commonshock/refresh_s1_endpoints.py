"""Refresh S2 endpoints once the resumed frozen S1 chain is terminal."""
import json
import shutil
import time
from pathlib import Path

from . import queue
from .fit import sha

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results'
LOG = ROOT / 'artifacts/logs'
H = queue.S1 / 'results/headline_frozen'
H_DONE = queue.S1 / 'artifacts/logs/H_frozen.DONE'


def status(state, **detail):
    queue.write(OUT / 'endpoint_refresh_status.json', dict(
        state=state, updated_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        **detail))


def run():
    done = LOG / 'ENDPOINTS_S1_REFRESH.DONE'
    if done.exists():
        status('complete', note='refresh already recorded')
        return
    while True:
        ready, trigger = queue.predecessors()
        if ready:
            break
        status('waiting_predecessors', prerequisite=trigger)
        time.sleep(30)
    if not H_DONE.exists():
        status('held_s1_unavailable', prerequisite=trigger)
        return
    account = json.loads((H / 'accounting.json').read_text())
    assert account['scheduled'] == account['records'] == 40
    assert account['manifest_sha256'] == sha(H / 'manifest.json')
    from experiments.fleet_r1literal.cpu_budget import worker_budget
    while worker_budget(0, 44, 2, 1) < 1:
        status('waiting_cpu', prerequisite=trigger)
        time.sleep(30)
    original = OUT / 'endpoints.json'
    archive = OUT / 'endpoints_before_s1_refresh.json'
    if not archive.exists():
        shutil.copy2(original, archive)
    status('running', prerequisite=trigger, original_sha256=sha(archive))
    from .endpoints import run as evaluate
    result = evaluate()
    assert len(result['S1_rows']) == 40
    done.write_text(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()) + '\n')
    status('complete', prerequisite=trigger,
           original_sha256=sha(archive), refreshed_sha256=sha(original),
           s1_terminal_rows=sum(x['status'] != 'missing' for x in result['S1_rows']))


if __name__ == '__main__':
    run()
