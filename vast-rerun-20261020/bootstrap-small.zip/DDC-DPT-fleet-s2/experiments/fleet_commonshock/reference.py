"""S2 reference ladder, uniform residual enclosure, quadrature and tensor controls."""
import hashlib
import json
import math
import time
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from scipy.special import logsumexp
from .core import Component, Reference, solve, P, B, half_mass, half_survival, all_reward
from experiments.fleet_r1literal.params import BETA,U,V,KCOST,D,ACTIONS
from experiments.fleet_r1literal.texp import RHO,L,Z

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+'\n')

def direct_integral(comp,x,z):
    f=comp.f;lo=0. if z==0 else B[f];hi=B[f] if z==0 else L[f]
    end=min(hi,1.-x)
    if end<=lo: return float(comp.mixed[z,-1])
    knots=comp.grid[(comp.grid>x+lo)&(comp.grid<x+end)]-x
    bounds=np.r_[lo,knots,end]
    integral=0.
    for a,b in zip(bounds[:-1],bounds[1:]):
        if b>a:
            val,err=quad(lambda d: float(np.interp(x+d,comp.grid,comp.mixed[z])) *
                         2*RHO[f]*math.exp(-RHO[f]*d)/Z[f],a,b,epsabs=2e-14,epsrel=2e-14)
            integral+=val
    return integral+float(half_survival(1.-x,f,z))*comp.mixed[z,-1]

def certificate(comp,subdiv=16):
    f=comp.f;K=comp.K;h=comp.h
    grid=comp.grid
    # Every point at which a shifted interpolation knot or half-law endpoint crosses a knot.
    breaks=np.concatenate([grid,grid-B[f],grid-L[f],
                           [1-B[f],1-L[f],0.,1.]])
    breaks=np.unique(breaks[(breaks>=0)&(breaks<=1)])
    pieces=breaks[1:]-breaks[:-1]
    points=(breaks[:-1,None]+pieces[:,None]*np.linspace(0,1,subdiv+1)[None,:]).ravel()
    slope=float(np.max(np.abs(comp.slopes)))
    rho=float(RHO[f]);z=Z[f]
    # W'' = rho W' - p(lo) v'(x+lo) + p(hi) v'(x+hi), within split intervals.
    w2=slope*(rho+2*rho/z+2*rho*math.exp(-rho*B[f])/z+
              2*rho*math.exp(-rho*L[f])/z)
    q02=2*V[f]+BETA*w2
    q12=2*D[f]
    q0p=U[f]+2*V[f]+BETA*slope
    q1p=2*D[f]
    M=max(q02,q12)+.25*(q0p+q1p)**2
    bound_terms=[]
    for zz in (0,1):
        r=np.abs(comp.residual(points,zz)).reshape(-1,subdiv+1)
        max_endpoint=float(np.max(r))
        allowance=float(M*np.max((pieces/subdiv)**2)/8)
        bound_terms.append(dict(regime=zz,max_endpoints=max_endpoint,
                                curvature_M=float(M),interpolation_allowance=allowance,
                                arithmetic_allowance=1e-9,bound=max_endpoint+allowance+1e-9))
    return dict(regimes=bound_terms,bound=max(x['bound'] for x in bound_terms),
                split_points=len(breaks),subintervals=len(pieces)*subdiv,
                max_width=float(np.max(pieces/subdiv)))

def row(f,K,x,z):
    grid=np.linspace(0.,1.,K)
    lo=np.maximum(grid[:-1]-x,0.)
    hi=np.minimum(grid[1:]-x,1.-x)
    lo=np.maximum(lo,0. if z==0 else B[f])
    hi=np.minimum(hi,B[f] if z==0 else L[f])
    valid=hi>lo
    p=np.zeros(K-1);mom=np.zeros(K-1)
    r=RHO[f]
    p[valid]=2*np.exp(-r*lo[valid])*(-np.expm1(-r*(hi[valid]-lo[valid])))/Z[f]
    mom[valid]=(lo[valid]+1/r)*p[valid]-(hi[valid]-lo[valid])*2*np.exp(-r*hi[valid])/Z[f]
    high=((x-grid[:-1])*p+mom)*(K-1)
    out=np.zeros(K);out[:-1]+=p-high;out[1:]+=high
    out[-1]+=half_survival(1.-x,f,z)
    return out

def tensor_controls(out):
    t0=time.perf_counter();result={}
    K=9; comps=[solve(f,K)[0] for f in range(5)]
    grid=np.linspace(0,1,K)
    kernels=[[[np.stack([row(f,K,float(x),z) for x in grid]),
                np.broadcast_to(np.eye(K)[0],(K,K)).copy()] for z in (0,1)] for f in range(5)]
    values=np.zeros((2,)+(K,)*5)
    for z in (0,1):
        for f,c in enumerate(comps):
            shp=[1]*5;shp[f]=K
            values[z]+=c.values[z].reshape(shp)
    states=np.stack(np.meshgrid(*([grid]*5),indexing='ij'),axis=-1).reshape(-1,5)
    reward=all_reward(states).T.reshape((32,)+(K,)*5)
    q=np.empty((2,32)+(K,)*5)
    for z in (0,1):
        mixed=P[z,0]*values[0]+P[z,1]*values[1]
        for a in range(32):
            mats=[kernels[f][z][int(ACTIONS[a,f])] for f in range(5)]
            cont=np.einsum('ai,bj,ck,dl,em,ijklm->abcde',*mats,mixed,optimize=True)
            q[z,a]=reward[a]+BETA*cont
    soft=logsumexp(q,axis=1)
    same=float(np.max(np.abs(soft-values)))
    component=np.zeros_like(q)
    for z in (0,1):
        for f,c in enumerate(comps):
            q0,q1=c.q(grid,z)
            for a in range(32):
                shp=[1]*5;shp[f]=K
                component[z,a]+= (q1 if ACTIONS[a,f] else q0).reshape(shp)
    result['k9_joint_grid_residual']=same
    result['k9_joint_component_Q_max']=float(np.max(np.abs(q-component)))
    rng=np.random.default_rng(2026101909)
    off=rng.random((3,5));off_err=0.
    for z in (0,1):
        mixed=P[z,0]*values[0]+P[z,1]*values[1]
        for x in off:
            rows=[[row(f,K,float(x[f]),z),np.eye(K)[0]] for f in range(5)]
            for a in range(32):
                tmp=mixed
                for f in range(5): tmp=np.tensordot(rows[f][int(ACTIONS[a,f])],tmp,axes=(0,0))
                q_direct=float(all_reward(x[None,:])[0,a]+BETA*tmp)
                q_comp=sum(c.q(x[f],z)[int(ACTIONS[a,f])] for f,c in enumerate(comps))
                off_err=max(off_err,abs(q_direct-q_comp))
    result['k9_joint_offgrid_Q_max']=float(off_err)
    # F=2 K401 same-grid tensor contraction against fine components.
    K=401;coarse=[solve(f,K)[0] for f in range(2)]
    fine=[solve(f,4001)[0] for f in range(2)]
    x=rng.random((100,2));errors=[];fine_diffs=[]
    for z in (0,1):
        v=np.stack([coarse[0].values[zz,:,None]+coarse[1].values[zz,None,:] for zz in (0,1)])
        mixed=P[z,0]*v[0]+P[z,1]*v[1]
        for state in x:
            rows=[[row(f,K,float(state[f]),z),np.eye(K)[0]] for f in range(2)]
            for a in range(4):
                bits=[(a>>f)&1 for f in range(2)]
                cont=rows[0][bits[0]]@mixed@rows[1][bits[1]]
                rew=sum(-(KCOST[f]+D[f]*state[f]**2) if bits[f] else
                        -(U[f]*state[f]+V[f]*state[f]**2) for f in range(2))
                qt=rew+BETA*cont
                qc=sum(coarse[f].q(state[f],z)[bits[f]] for f in range(2))
                qf=sum(fine[f].q(state[f],z)[bits[f]] for f in range(2))
                errors.append(abs(qt-qc));fine_diffs.append(qt-qf)
    result['k401_two_bus_same_grid_Q_max']=float(max(errors))
    result['k401_vs_k4001_max']=float(np.max(np.abs(fine_diffs)))
    result['k401_vs_k4001_rms']=float(np.sqrt(np.mean(np.square(fine_diffs))))
    result['wall_s']=time.perf_counter()-t0
    write(Path(out)/'tensor_controls.json',result)
    return result

def build(out):
    t0=time.perf_counter();out=Path(out);out.mkdir(parents=True,exist_ok=True)
    buses=[];chosen=[]
    for f in range(5):
        runs={};comps={}
        for K in (1001,2001,4001,8001):
            c,r=solve(f,K);comps[K]=c;runs[K]=r
        c=comps[4001];cert=certificate(c)
        if cert['bound']>1e-6: c=comps[8001];cert=certificate(c)
        x=np.linspace(0,1,20001)
        cross=lambda a,b: float(max(np.max(np.abs(np.stack(a.q(x,z))-np.stack(b.q(x,z)))) for z in (0,1)))
        quadr=max(abs(c.continuation(float(xx),z)-direct_integral(c,float(xx),z))
                  for z in (0,1) for xx in np.random.default_rng(9000+f).random(15))
        rec=dict(bus=f+1,grids=list(runs.values()),certificate=cert,
                 cross_2001_4001=cross(comps[2001],comps[4001]),
                 cross_4001_8001=cross(comps[4001],comps[8001]),
                 independent_quadrature_max=float(quadr),release_K=c.K)
        buses.append(rec);chosen.append(c)
        np.save(out/f'v_bus{f+1}.npy',c.values)
        print(json.dumps(dict(bus=f+1,certificate=cert['bound'],cross=rec['cross_2001_4001'],
                              quadrature=quadr)),flush=True)
    bound=BETA/(1-BETA)*sum(r['certificate']['bound'] for r in buses)+1e-8
    status='certified' if (bound<=1e-4 and all(r['certificate']['bound']<=1e-6 and
          r['cross_2001_4001']<=2e-5 and r['independent_quadrature_max']<=1e-10 for r in buses)) else 'failed'
    manifest=dict(status=status,buses=buses,joint_Q_bound=bound,query_allowance=1e-8,
                  wall_s=time.perf_counter()-t0,values_sha256={f'bus{f+1}':sha(out/f'v_bus{f+1}.npy') for f in range(5)})
    write(out/'reference_manifest.json',manifest)
    (out/'reference_status.md').write_text(f'# Reference {status}\n\nJoint Q bound: {bound:.12g}.\n')
    print(json.dumps(dict(status=status,joint_Q_bound=bound,wall_s=manifest['wall_s'])),flush=True)
    return manifest

def load(out):
    out=Path(out)
    return Reference([Component(f,np.load(out/f'v_bus{f+1}.npy')) for f in range(5)])
