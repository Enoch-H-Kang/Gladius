"""Two-regime integrated-hat reference and exact S2 simulator primitives."""
import math
import time
import numpy as np
from scipy.special import expit
from experiments.fleet_r1literal.params import BETA, U, V, KCOST, D, MU, ACTIONS, encode
from experiments.fleet_r1literal.texp import RHO, L, Z, T

P = np.array([[.95, .05], [.05, .95]], dtype=np.float64)
B = -np.log1p(-.5 * Z) / RHO

def half_increment(u, f, z):
    return -np.log1p(-((np.asarray(z) + np.asarray(u)) / 2) * Z[f]) / RHO[f]

def half_mass(lo, hi, f, z):
    lo = np.maximum(np.asarray(lo), B[f] if z else 0.)
    hi = np.minimum(np.asarray(hi), L[f] if z else B[f])
    return np.where(hi > lo, 2 * np.exp(-RHO[f] * lo) *
                    (-np.expm1(-RHO[f] * (hi-lo))) / Z[f], 0.)

def half_survival(d, f, z):
    return half_mass(np.maximum(d, 0.), L[f], f, z)

class Component:
    def __init__(self, f, values):
        self.f = int(f)
        self.values = np.asarray(values, dtype=np.float64)
        assert self.values.ndim == 2 and self.values.shape[0] == 2
        self.K = self.values.shape[1]
        assert self.K >= 2 and np.isfinite(self.values).all()
        self.h = 1. / (self.K-1)
        self.grid = np.linspace(0., 1., self.K)
        self.mixed = P @ self.values
        self.slopes = np.diff(self.mixed, axis=1) / self.h
        rho = RHO[f]; e = np.exp(-rho*self.grid)
        p = -np.expm1(-rho*self.h)/rho
        j = (p-self.h*np.exp(-rho*self.h))/rho
        cell = e[:-1] * (self.mixed[:,:-1]*p+self.slopes*j)
        self.suffix = np.concatenate([np.cumsum(cell[:,::-1],axis=1)[:,::-1],np.zeros((2,1))],axis=1)

    def primitive(self, y, z):
        y = np.clip(np.asarray(y,dtype=np.float64),0.,1.)
        idx = np.minimum((y/self.h).astype(np.int64),self.K-2)
        d = y-self.grid[idx]; rho=RHO[self.f]
        p = -np.expm1(-rho*d)/rho
        j = (p-d*np.exp(-rho*d))/rho
        return self.suffix[z,idx]-np.exp(-rho*self.grid[idx])*(self.mixed[z,idx]*p+self.slopes[z,idx]*j)

    def interp(self,x,z):
        return np.interp(np.asarray(x,dtype=np.float64),self.grid,self.values[z])

    def continuation(self,x,z):
        x=np.asarray(x,dtype=np.float64)
        if np.any((x<0)|(x>1)): raise ValueError('mileage outside [0,1]')
        f=self.f; rho=RHO[f]
        lo=0. if z==0 else B[f]
        hi=B[f] if z==0 else L[f]
        end=np.minimum(hi,1.-x)
        valid=end>lo
        integral=np.where(valid,2*rho/Z[f]*np.exp(rho*x)*
                          (self.primitive(x+lo,z)-self.primitive(x+np.maximum(end,lo),z)),0.)
        return integral+self.mixed[z,-1]*half_survival(1.-x,f,z)

    def q(self,x,z,beta=BETA):
        x=np.asarray(x,dtype=np.float64); f=self.f
        q0=-(U[f]*x+V[f]*x*x)+beta*self.continuation(x,z)
        q1=-(KCOST[f]+D[f]*x*x)+beta*self.mixed[z,0]
        return q0,q1

    def query(self,x,z):
        q0,q1=self.q(x,z)
        soft=np.logaddexp(q0,q1)
        return q0,q1,soft,self.interp(x,z)

    def residual(self,x,z):
        a,b,v,iv=self.query(x,z)
        return v-iv

def solve(f,K,tol=1e-11,max_sweeps=2000):
    t0=time.perf_counter(); x=np.linspace(0.,1.,K)
    values=np.zeros((2,K),dtype=np.float64)
    for sweep in range(1,max_sweeps+1):
        comp=Component(f,values)
        new=np.stack([np.logaddexp(*comp.q(x,z)) for z in range(2)])
        change=float(np.max(np.abs(new-values)))
        if not np.isfinite(change): raise FloatingPointError('nonfinite VI')
        values=new
        if change<=tol:
            comp=Component(f,values)
            if max(float(np.max(np.abs(comp.residual(x,z)))) for z in range(2))<=tol: break
    else: raise RuntimeError('VI did not converge')
    comp=Component(f,values)
    reload=max(float(np.max(np.abs(comp.residual(x,z)))) for z in range(2))
    if reload>tol: raise RuntimeError('reloaded residual exceeds tolerance')
    return comp,dict(bus=f+1,K=K,sweeps=sweep,last_change=change,reloaded_residual=reload,wall_s=time.perf_counter()-t0)

class Reference:
    def __init__(self,comps):
        assert len(comps)==5
        self.components=comps
    def component_query(self,f,x,z): return self.components[f].query(x,z)
    def joint_query(self,states,regimes):
        s=np.atleast_2d(np.asarray(states,dtype=np.float64))
        z=np.broadcast_to(np.asarray(regimes,dtype=np.int64), (len(s),))
        assert s.shape[1]==5 and np.all((z==0)|(z==1))
        q=np.zeros((len(s),32)); v=np.zeros(len(s))
        for f,c in enumerate(self.components):
            qa=np.empty((len(s),2))
            for zz in (0,1):
                mask=z==zz
                if mask.any():
                    q0,q1,soft,_=c.query(s[mask,f],zz)
                    qa[mask,0]=q0; qa[mask,1]=q1; v[mask]+=soft
            q+=qa[:,ACTIONS[:,f]]
        pi=np.exp(q-v[:,None])
        return q,v,pi

def component_reward(x,bits,f):
    return np.where(bits,-(KCOST[f]+D[f]*x*x),-(U[f]*x+V[f]*x*x))

def all_reward(s):
    s=np.atleast_2d(np.asarray(s,dtype=np.float64))
    out=np.zeros((len(s),32),dtype=np.float64)
    for f in range(5): out+=component_reward(s[:,f,None],ACTIONS[None,:,f],f)
    return out

def simulate(n,h,ref,rngs,burn=0,history=False):
    """Independent chains; all increment and regime draws consumed every time."""
    starts,initial,trans,actions,incs=rngs
    x=starts.random((n,5))*.5
    z=(initial.random(n)<.5).astype(np.int8)
    out={k:np.empty((n,h)+shape,dtype=dtype) for k,shape,dtype in
         [('s',(5,),np.float64),('sp',(5,),np.float64),('z',(),np.int8),
          ('zp',(),np.int8),('a',(),np.int8),('r0',(),np.float64)]}
    hist=[]
    for t in range(burn+h):
        bits=np.empty((n,5),dtype=np.int8)
        ds=np.empty((n,5),dtype=np.float64)
        for f,c in enumerate(ref.components):
            p=np.empty(n)
            for zz in (0,1):
                mask=z==zz
                if mask.any():
                    q0,q1,soft,_=c.query(x[mask,f],zz)
                    p[mask]=np.exp(q1-soft)
            bits[:,f]=(actions[f].random(n)<p)
            ds[:,f]=half_increment(incs[f].random(n),f,z)
        xp=np.where(bits,0.,np.minimum(1.,x+ds))
        zp=np.where(trans.random(n)<.05,1-z,z).astype(np.int8)
        if history and t<burn: hist.append((x.copy(),xp.copy(),encode(bits)))
        if t>=burn:
            j=t-burn
            out['s'][:,j]=x;out['sp'][:,j]=xp;out['z'][:,j]=z;out['zp'][:,j]=zp
            out['a'][:,j]=encode(bits)
            out['r0'][:,j]=-(U*x+V*x*x).sum(axis=1)
        x,z=xp,zp
    if history: out['burn_history']=hist
    return out
