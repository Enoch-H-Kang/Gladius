"""Deterministic S2 algebra, kernel, sampler, and mutation diagnostics."""
import json
import math
import time
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from scipy.special import ndtri,logsumexp
from .core import P,B,half_increment,half_mass,half_survival,Reference,Component,all_reward
from .reference import load,row,write,direct_integral
from experiments.fleet_r1literal.params import ACTIONS,BETA,U,V,KCOST,D,MU,encode,decode
from experiments.fleet_r1literal.texp import RHO,L,Z,T,draw
from experiments.fleet_r1literal.oracle1d import Component as S1Component

REF=Path(__file__).resolve().parent/'artifacts/reference'

def half_mean(f,z):
    lo=0. if z==0 else B[f];hi=B[f] if z==0 else L[f]
    return quad(lambda d:d*2*RHO[f]*math.exp(-RHO[f]*d)/Z[f],lo,hi,epsabs=1e-14)[0]

def mean_successor(x,f,z):
    lo=0. if z==0 else B[f];hi=B[f] if z==0 else L[f]
    return quad(lambda d:min(1.,x+d)*2*RHO[f]*math.exp(-RHO[f]*d)/Z[f],
                lo,hi,points=[1.-x] if lo<1.-x<hi else None,epsabs=1e-13)[0]

def algebra(ref):
    rng=np.random.default_rng(202610195)
    s=rng.random((200,5));z=rng.integers(0,2,200)
    q,v,pi=ref.joint_query(s,z)
    product=np.ones_like(pi)
    for f,c in enumerate(ref.components):
        probs=np.empty((len(s),2))
        for zz in (0,1):
            m=z==zz
            if m.any():
                q0,q1,soft,_=c.query(s[m,f],zz)
                probs[m]=np.stack([np.exp(q0-soft),np.exp(q1-soft)],axis=1)
        product*=probs[:,ACTIONS[:,f]]
    zero=math.log(32)/(1-BETA)
    # Lambda-zero fixture mixes the two half-laws with probability 1/2 in each
    # current regime. Its full marginal must reproduce the S1 integrated hat.
    vals=ref.components[0].values[0]
    s1=S1Component(0,vals)
    half=Component(0,np.stack([vals,vals]))
    x=rng.random(100)
    full_kernel=s1.continuation(x)
    full_fixture=.5*(half.continuation(x,0)+half.continuation(x,1))
    lam0err=float(np.max(np.abs(full_fixture-full_kernel)))
    # Replacing P by any row-stochastic p cannot matter when the two future
    # value arrays are identical.
    ps=np.array([.2,.95])
    perr=float(np.max(np.abs(np.array([pp*full_fixture+(1-pp)*full_fixture for pp in ps])-full_kernel)))
    static=0.
    for f,c in enumerate(ref.components):
        q0,q1=c.q(s[:,f],0,beta=0.)
        static=max(static,float(np.max(np.abs(q0+U[f]*s[:,f]+V[f]*s[:,f]**2))),
                   float(np.max(np.abs(q1+KCOST[f]+D[f]*s[:,f]**2))))
    # Explicit label remapping: a new label 1-z maps to the old z; P is symmetric.
    qperm,_,_=ref.joint_query(s,1-(1-z))
    return dict(lambda_zero_S1_kernel_max=lam0err,
        lambda_zero_any_p_kernel_max=perr,beta_zero_static_reward_max=static,
        beta_zero_static_logit_max=float(np.max(np.abs(
            np.exp(all_reward(s)-logsumexp(all_reward(s),axis=1)[:,None]).sum(axis=1)-1))),
        zero_reward_V=zero,zero_reward_Bellman_residual=abs(zero-(math.log(32)+BETA*zero)),
        joint_lse_max=float(np.max(np.abs(logsumexp(q,axis=1)-v))),
        product_policy_max=float(np.max(np.abs(pi-product))),
        permutation_Q_max=float(np.max(np.abs(q-qperm))),
        permutation_transition_max=float(np.max(np.abs(P-P[::-1,::-1]))),
        action_roundtrip=bool(np.array_equal(encode(decode(np.arange(32))),np.arange(32))),
        replacement_reset=bool(np.all(np.where(np.ones((1,5),dtype=bool),0.,1.)==0.)))

def kernel(ref):
    rng=np.random.default_rng(202610196);rows=[]
    for f,c in enumerate(ref.components):
        for z in (0,1):
            rr=np.array([row(f,101,float(x),z) for x in np.linspace(0,1,101)])
            direct=[]
            for x in rng.random(10):
                direct.append(abs(direct_integral(c,float(x),z)-c.continuation(x,z)))
            rows.append(dict(bus=f+1,regime=z,row_sum_error=float(np.max(np.abs(rr.sum(axis=1)-1))),
                             min_weight=float(rr.min()),independent_quad_max=float(max(direct))))
    return rows

def sampler(ref):
    t0=time.perf_counter();rng=np.random.default_rng(202610197)
    n=1000000;z=(rng.random(n)<.5).astype(np.int8)
    inc=np.column_stack([half_increment(rng.random(n),f,z) for f in range(5)])
    means=inc.mean(axis=0);cors=np.corrcoef(inc.T)
    half=np.stack([inc[z==zz].mean(axis=0) for zz in (0,1)])
    half_target=np.array([[half_mean(f,zz) for f in range(5)] for zz in (0,1)])
    std=inc/MU
    expected_c=.5338677204707422
    # Independent 10,000 H100 paths give cluster units for temporal checks.
    nc=10000;H=100;zz=(rng.random(nc)<.5).astype(np.int8)
    histories=np.empty((nc,H,5),dtype=np.float32);reg=np.empty((nc,H),dtype=np.int8)
    for t in range(H):
        reg[:,t]=zz
        for f in range(5): histories[:,t,f]=half_increment(rng.random(nc),f,zz)/MU[f]
        zz=np.where(rng.random(nc)<.05,1-zz,zz)
    serial=[]
    for k in range(1,6):
        r=np.corrcoef(histories[:,:-k,0].ravel(),histories[:,k:,1].ravel())[0,1]
        serial.append(dict(lag=k,observed=float(r),target=expected_c*.9**k))
    switches=float(np.mean(reg[:,1:]!=reg[:,:-1]))
    # Product-policy generation at one fixed state/regime.
    fixed=np.full((1,5),.4);_,_,pi=ref.joint_query(fixed,0)
    probs=np.array([math.exp(c.q(.4,0)[1]-np.logaddexp(*c.q(.4,0))) for c in ref.components])
    empirical=np.bincount(encode(rng.random((n,5))<probs),minlength=32)/n
    product_gap=float(np.max(np.abs(empirical-pi[0])))
    return dict(n_stationary=n,primitive_mean=means.tolist(),target_mean=MU.tolist(),
        half_means=half.tolist(),half_targets=half_target.tolist(),
        correlation=cors.tolist(),target_cross_c=expected_c,
        standardized_variance=float(std.var()),
        regime_share=float(z.mean()),n_serial_chains=nc,H=H,serial=serial,
        serial_regime_share=float(reg.mean()),switch_rate=switches,
        product_policy_max_gap=product_gap,wall_s=time.perf_counter()-t0)

def cells(ref):
    t0=time.perf_counter();rng=np.random.default_rng(202610198)
    states=rng.random((20,5));N=10000;crit=float(ndtri(1-.05/(2*(20*2*32*3))))
    records=[];bad=[]
    for ix,x in enumerate(states):
        for z in (0,1):
            ds=np.column_stack([half_increment(rng.random(N),f,z) for f in range(5)])
            zp=np.where(rng.random(N)<.05,1-z,z)
            expect_keep=np.array([c.continuation(x[f],z) for f,c in enumerate(ref.components)])
            expect_reset=np.array([c.mixed[z,0] for c in ref.components])
            means=np.array([mean_successor(x[f],f,z) for f in range(2)])
            for a in range(32):
                bits=ACTIONS[a];xp=np.where(bits,0.,np.minimum(1.,x+ds))
                cont=np.zeros(N)
                for f,c in enumerate(ref.components):
                    cont+=np.where(zp==0,np.interp(xp[:,f],c.grid,c.values[0]),
                                   np.interp(xp[:,f],c.grid,c.values[1]))
                target=float(np.sum(np.where(bits,expect_reset,expect_keep)))
                pair_target=float((0. if bits[0] else means[0])*(0. if bits[1] else means[1]))
                metrics=[(cont,target,'continuation'),((zp==1).astype(float),P[z,1],'next_regime'),
                         (xp[:,0]*xp[:,1],pair_target,'pair_mileage')]
                for sample,truth,name in metrics:
                    mean=float(sample.mean());se=float(sample.std(ddof=1)/math.sqrt(N))
                    # Deterministic point-mass statistics have exactly zero sample SE.
                    discrepancy=mean-truth;allow=2e-6 if name=='continuation' else 1e-10
                    ok=bool(abs(discrepancy)<=crit*se+allow)
                    if not ok: bad.append(dict(state=ix,regime=z,action=a,metric=name,
                                                discrepancy=discrepancy,se=se))
                    records.append(dict(state=ix,regime=z,action=a,metric=name,
                                        mean=mean,truth=truth,se=se,within=ok))
    # Deliberately wrong kernels must have a visible fixed-cell discrepancy.
    x=np.full(5,.4);z=0
    right=sum(c.continuation(x[f],z) for f,c in enumerate(ref.components))
    swapped=sum(.95*c.continuation(x[f],0)+.05*c.continuation(x[f],1) for f,c in enumerate(ref.components))
    full=sum((c.continuation(x[f],0)+c.continuation(x[f],1))/2 for f,c in enumerate(ref.components))
    result=dict(n_cells=1280,draws_per_cell=N,checks=len(records),critical=crit,
                n_within=len(records)-len(bad),bad=bad,records=records,
                mutation_current_next_detected=bool(abs(right-swapped)>1e-4),
                mutation_full_marginal_detected=bool(abs(right-full)>1e-4),
                mutation_gaps=[float(right-swapped),float(right-full)],
                wall_s=time.perf_counter()-t0)
    return result

def run():
    ref=load(REF);out=REF/'checks';out.mkdir(parents=True,exist_ok=True)
    a=algebra(ref);k=kernel(ref);s=sampler(ref);c=cells(ref)
    write(out/'algebra.json',a);write(out/'kernel.json',k)
    write(out/'sampler.json',s);write(out/'cells.json',c)
    status='pass' if (a['lambda_zero_S1_kernel_max']<=1e-12 and
        a['lambda_zero_any_p_kernel_max']<=1e-12 and
        a['beta_zero_static_reward_max']<=1e-12 and
        a['zero_reward_Bellman_residual']<=1e-12 and
        a['joint_lse_max']<=1e-12 and a['product_policy_max']<=1e-12
        and a['permutation_Q_max']<=1e-10 and all(r['row_sum_error']<=1e-12 and
        r['min_weight']>=-1e-13 and r['independent_quad_max']<=1e-10 for r in k)
        and c['mutation_current_next_detected'] and c['mutation_full_marginal_detected']
        and not c['bad']) else 'hold'
    result=dict(status=status,algebra=a,kernel=k,sampler=s,
                cells_summary={key:val for key,val in c.items() if key!='records'},
                archive='checks/cells.json')
    write(out/'summary.json',result)
    print(json.dumps(dict(status=status,algebra=a,kernel_max=max(x['independent_quad_max'] for x in k),
                          cell_within=c['n_within'],cell_checks=c['checks'],
                          sampler_cross=s['correlation'][0][1],serial=s['serial'],
                          wall_s=s['wall_s']+c['wall_s'])),flush=True)
    return result

if __name__=='__main__': run()
