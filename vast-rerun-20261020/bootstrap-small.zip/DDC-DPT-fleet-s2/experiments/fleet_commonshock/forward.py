"""Frozen-seed, whole-path Monte Carlo validation for 200 component and 40 joint starts."""
import json
import math
import time
from pathlib import Path
import numpy as np
from scipy.special import ndtri
from .core import P, half_increment, component_reward, all_reward
from .reference import load, write
from experiments.fleet_r1literal.params import BETA,U,V,KCOST,D,encode

T=450
STARTS=np.linspace(0.,1.,20)
CRIT=float(ndtri(1-.05/(2*240)))

def summary(ret,truth,tail,numeric):
    mean=ret.mean(axis=1)
    se=ret.std(axis=1,ddof=1)/np.sqrt(ret.shape[1])
    diff=mean-truth
    ok=np.abs(diff)<=CRIT*se+tail+numeric
    return dict(mean=mean.tolist(),se=se.tolist(),signed_difference=diff.tolist(),
                within_interval=ok.tolist(),n_within=int(ok.sum()),critical=CRIT,
                tail_bound=float(tail),numeric_allowance=float(numeric))

def run(refroot,outroot):
    t0=time.perf_counter();ref=load(refroot)
    manifest=json.loads((Path(refroot)/'reference_manifest.json').read_text())
    assert manifest['status']=='certified'
    result=dict(component=[],joint=None,seed_base=20261900)
    for f,c in enumerate(ref.components):
        ra=np.random.default_rng(20261900+10*f)
        rd=np.random.default_rng(20261901+10*f)
        rz=np.random.default_rng(20261902+10*f)
        x=np.broadcast_to(STARTS[:,None,None],(20,2,2000)).copy().reshape(40,2000)
        z=np.broadcast_to(np.arange(2)[None,:,None],(20,2,2000)).copy().reshape(40,2000)
        ret=np.zeros_like(x);disc=1.
        for t in range(T):
            p=np.empty_like(x)
            for zz in (0,1):
                mask=z==zz
                if mask.any():
                    q0,q1,v,_=c.query(x[mask],zz)
                    p[mask]=np.exp(q1-v)
            bits=ra.random(x.shape)<p
            entropy=-(p*np.log(np.maximum(p,1e-300))+(1-p)*np.log(np.maximum(1-p,1e-300)))
            ret+=disc*(component_reward(x,bits,f)+entropy)
            x=np.where(bits,0.,np.minimum(1.,x+half_increment(rd.random(x.shape),f,z)))
            z=np.where(rz.random(x.shape)<.05,1-z,z)
            disc*=BETA
        truth=np.array([c.query(np.array([xx]),zz)[2][0] for xx in STARTS for zz in (0,1)])
        tail=BETA**T/(1-BETA)*(max(U[f]+V[f],KCOST[f]+D[f])+math.log(2))
        numeric=manifest['buses'][f]['certificate']['bound']/(1-BETA)
        result['component'].append(dict(bus=f+1,**summary(ret,truth,tail,numeric)))
        print(json.dumps(dict(bus=f+1,within=result['component'][-1]['n_within'],checks=40)),flush=True)
    ra=[np.random.default_rng(20262000+f) for f in range(5)]
    rd=[np.random.default_rng(20262010+f) for f in range(5)]
    rz=np.random.default_rng(20262020)
    starts=np.stack([np.mod(STARTS+.127*f,1.) for f in range(5)],axis=1)
    x=np.broadcast_to(starts[:,None,None,:],(20,2,1000,5)).copy().reshape(40,1000,5)
    z=np.broadcast_to(np.arange(2)[None,:,None],(20,2,1000)).copy().reshape(40,1000)
    ret=np.zeros((40,1000));disc=1.
    for t in range(T):
        bits=np.empty(x.shape,dtype=np.int8);ds=np.empty(x.shape)
        entropy=np.zeros((40,1000))
        for f,c in enumerate(ref.components):
            p=np.empty((40,1000))
            for zz in (0,1):
                mask=z==zz
                if mask.any():
                    q0,q1,v,_=c.query(x[:,:,f][mask],zz)
                    p[mask]=np.exp(q1-v)
            bits[:,:,f]=ra[f].random(p.shape)<p
            ds[:,:,f]=half_increment(rd[f].random(p.shape),f,z)
            entropy-=p*np.log(np.maximum(p,1e-300))+(1-p)*np.log(np.maximum(1-p,1e-300))
        r=sum(component_reward(x[:,:,f],bits[:,:,f],f) for f in range(5))
        ret+=disc*(r+entropy)
        x=np.where(bits,0.,np.minimum(1.,x+ds))
        z=np.where(rz.random(z.shape)<.05,1-z,z)
        disc*=BETA
    truth=np.array([ref.joint_query(starts[i:i+1],zz)[1][0] for i in range(20) for zz in (0,1)])
    tail=BETA**T*(17.9+math.log(32))/(1-BETA)
    numeric=sum(b['certificate']['bound'] for b in manifest['buses'])/(1-BETA)
    result['joint']=summary(ret,truth,tail,numeric)
    result['wall_s']=time.perf_counter()-t0
    write(Path(outroot)/'forward_checks.json',result)
    print(json.dumps(dict(component=[x['n_within'] for x in result['component']],
                          joint=result['joint']['n_within'],critical=CRIT,wall_s=result['wall_s'])),flush=True)
    return result
